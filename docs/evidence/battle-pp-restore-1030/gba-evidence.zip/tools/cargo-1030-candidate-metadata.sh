#!/bin/bash
set -eu
case "$PWD" in "/home/jerry/develop/open-pokered/.task-tmp/fidelity-1030-pp-gba-tile-candidate"|"/home/jerry/.cache/open-pokered-fidelity/1030-tile-candidate-gba-source/crates/pokered-gba") ;; *) exit 64 ;; esac
export TMPDIR=/home/jerry/develop/open-pokered/.task-tmp/fidelity-1030-tile-candidate-local-tmp CARGO_HOME=/home/jerry/.cache/open-pokered-fidelity/1030-tile-candidate-cargo-home CARGO_INCREMENTAL=0
# metadata has no --jobs/--target-dir options; it does not build.
exec cargo metadata --offline --locked --format-version 1
