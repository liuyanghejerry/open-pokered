"""One final Git-identity candidate; serial fail-stop host and original-order GBA.
Default is read-only source/tools/environment verification; no Cargo or emulator.
Only root-authorized --execute runs once, never remote/publisher or retry.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,struct,subprocess,time,shutil,traceback,signal
R=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
P=R/'audit-1030-candidate-check-plan.json';PLAN_SHA='9733bd27c8236c8e841da60c7e72346c76899ec007bc0bd1915b9d37709071a7'
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert sha(P.read_bytes())==PLAN_SHA
p=json.loads(P.read_text());W=Path(p['worktree']);M=Path(p['mirror']);F=Path(p['freeze'])
assert sha(F.read_bytes())==p['freeze_sha256'];f=json.loads(F.read_text());EF=Path(f['engine_freeze'])
assert sha(EF.read_bytes())==f['engine_freeze_sha256'];ef=json.loads(EF.read_text());E=Path(ef['worktree']);CH=Path(p['cargo_home'])
def git(cwd,*a):return subprocess.check_output(['git',*a],cwd=cwd)
def verify_files(root,entries):
 for name,row in entries.items():
  q=root/name;b=os.readlink(q).encode()if row['mode']=='120000'else q.read_bytes()
  assert q.is_symlink()==(row['mode']=='120000'),('symlink',str(q))
  if row['mode']!='120000':assert bool(q.stat().st_mode&0o111)==(row['mode']=='100755'),('mode',str(q))
  assert sha(b)==row['sha256'],('bytes',str(q))
  assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob'],('blob',str(q))
def group_present(pgid):
 try:os.killpg(pgid,0);return True
 except ProcessLookupError:return False
def verify():
 h=Path(p['engine_host_result']);assert sha(h.read_bytes())==p['engine_host_result_sha256'];host=json.loads(h.read_text())
 assert host['source_head']==p['engine_head'] and host['complete'] and host['all_pass'] and host['all_own_child_commands_terminal']
 assert len(host['checks'])==3 and all(q['exit']==0 and len(q['required_cases_passed'])==4 for q in host['checks'])
 assert git(W,'rev-parse','HEAD').decode().strip()==p['head'] and git(W,'status','--porcelain')==b''
 assert git(E,'rev-parse','HEAD').decode().strip()==p['engine_head'] and git(E,'status','--porcelain')==b''
 verify_files(W,f['complete_non_docs']);verify_files(M,f['complete_non_docs']);verify_files(E,ef['all_tracked_modes_blobs_bytes'])
 assert os.readlink(W/'gfx')==f['gfx_symlink_literal'] and os.readlink(M/'gfx')==f['mirror_gfx_symlink_literal']
 assert len(f['external_gfx'])==702 and all(sha((Path(f['external_gfx_root'])/n).read_bytes())==h for n,h in f['external_gfx'].items())
 assert os.readlink(CH/'registry')==f['cache_registry_symlink_literal']
 assert not (CH/'config.toml').exists() and not (CH/'config').exists() and not (CH/'credentials').exists() and not (CH/'credentials.toml').exists()
 DB=Path(f['cache_db']);assert not (DB/'objects/info/alternates').exists() and not (DB/'shallow').exists()
 assert git(W,'--git-dir',str(DB),'rev-parse',p['engine_head']+'^{tree}').decode().strip()==f['cache_tree']
 checkout_count=0
 for q in (CH/'git/checkouts').glob('dotzuki-*/*') if (CH/'git/checkouts').exists()else[]:
  if q.is_dir():
   assert git(q,'rev-parse','HEAD').decode().strip()==p['engine_head'];verify_files(q,ef['all_tracked_modes_blobs_bytes']);checkout_count+=1
 for name,h in p['tool_sha256'].items():assert sha(Path(name).read_bytes())==h,('tool',name)
 for name,value in os.environ.items():
  if name in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_BUILD_JOBS','CARGO_TARGET_DIR','RUSTUP_TOOLCHAIN']or (name.startswith('CARGO_TARGET_')and name.endswith(('_RUSTFLAGS','_LINKER','_RUNNER')))or name.startswith('CARGO_PROFILE_'):
   assert not value,('Inherited build override',name)
 return {'utc':now(),'game_head':p['head'],'engine_head':p['engine_head'],'compiler_count':len(f['compiler']),'NUL_non_doc_count':len(f['complete_non_docs']),'engine_all_tracked':len(ef['all_tracked_modes_blobs_bytes']),'gfx_count':702,'game_and_engine_clean':True,'all_game_mirror_engine_bytes_modes_blobs_symlinks_equal':True,'canonical_engine_cache_checkouts_verified':checkout_count}
def iwram(elf):
 b=elf.read_bytes();assert b[:6]==b'\x7fELF\x01\x01' and struct.unpack_from('<H',b,18)[0]==40
 shoff=struct.unpack_from('<I',b,32)[0];ents,num,names=struct.unpack_from('<HHH',b,46);assert ents==40
 ss=[struct.unpack_from('<IIIIIIIIII',b,shoff+i*ents)for i in range(num)]
 ns=ss[names];strings=b[ns[4]:ns[4]+ns[5]];found=[]
 for s in ss:
  name=strings[s[0]:].split(b'\0',1)[0].decode()
  if name=='.iwram':found.append({'name':name,'address':s[3],'file_offset':s[4],'size':s[5],'alignment':s[8]})
 assert len(found)==1 and found[0]['address']==0x03000000 and found[0]['size']<=p['gba_policy']['iwram_limit_bytes'];return found[0]
def metadata(row,entry):
 doc=Path(entry['stdout_json']);d=json.loads(doc.read_text());expected='git+https://github.com/liuyanghejerry/dotzuki?rev='+p['engine_head']+'#'+p['engine_head']
 packages=[x for x in d['packages']if x.get('source','')and x['source'].startswith('git+https://github.com/liuyanghejerry/dotzuki')]
 assert len(packages)==row['expected_dotzuki_git_packages'] and all(x['source']==expected for x in packages)
 entry['canonical_dotzuki_packages']=[{'name':x['name'],'version':x['version'],'source':x['source']}for x in packages];entry['stdout_sha256']=sha(doc.read_bytes())
parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');args=parser.parse_args();before=verify()
if not args.execute:
 assert not Path(p['host_target']).exists()and not Path(p['gba_target']).exists()
 proof={'status':'READONLY_PREFLIGHT_PASS_NO_CARGO_OR_EMULATOR','utc':now(),'runner_sha256':sha(Path(__file__).read_bytes()),'plan_sha256':PLAN_SHA,'before':before,'checks':len(p['checks']),'execution_policy':p['execution_policy']}
 dump(R/'audit-1030-candidate-runner-preflight.json',proof);print(json.dumps(proof));raise SystemExit(0)
RESULT=R/'audit-1030-candidate-check-result.json';LOCK=R/'audit-1030-candidate-running.lock'
assert not RESULT.exists()and not Path(p['host_target']).exists()and not Path(p['gba_target']).exists()
assert not any(Path(x['log']).exists()for x in p['checks'])
fd=os.open(LOCK,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(os.getpid()).encode());os.close(fd)
out={'scope':p['scope'],'game_head':p['head'],'engine_head':p['engine_head'],'started_utc':now(),'runner_sha256':sha(Path(__file__).read_bytes()),'plan_sha256':PLAN_SHA,'source_before':before,'checks':[],'complete':False,'all_pass':False,'all_own_child_commands_terminal':False};code=1;proc=None;terminal_unknown=False
try:
 for row in p['checks']:
  verify();entry={k:row[k]for k in ['label','command','cwd','kind','log']};entry['started_utc']=now();out['checks'].append(entry);dump(RESULT,out);t=time.monotonic();print('START '+row['label'],flush=True)
  log=Path(row['log']);env=dict(os.environ)
  if row['kind']=='emulator':env.update(p['emulator_environment'])
  stdout=None
  with log.open('x')as stream:
   if row['kind']=='metadata':
    jp=R/('audit-1030-candidate-'+row['label']+'.json');assert not jp.exists();stdout=jp.open('x');entry['stdout_json']=str(jp)
   try:
    proc=subprocess.Popen(row['command'],cwd=row['cwd'],env=env,stdout=stdout if stdout else stream,stderr=stream if stdout else subprocess.STDOUT,start_new_session=True)
    entry['owned_process_group']=proc.pid
    try:entry['exit']=proc.wait(timeout=row['timeout_seconds'])
    except subprocess.TimeoutExpired:
     terminal_unknown=True;entry['exit']=124;entry['timeout']=True
     try:os.killpg(proc.pid,signal.SIGKILL);entry['owned_group_SIGKILL_sent']=True
     except ProcessLookupError:entry['owned_group_already_absent_at_kill']=True
     entry['leader_exit_after_kill']=proc.wait()
     entry['descendant_terminal_state']='UNKNOWN_AFTER_TIMEOUT'
     entry['all_owned_descendants_terminal']=False
   finally:
    if stdout:stdout.close()
  entry['wall_seconds']=time.monotonic()-t;entry['finished_utc']=now();entry['log_sha256']=sha(log.read_bytes())
  if not terminal_unknown and group_present(proc.pid):terminal_unknown=True;entry['unexpected_descendants_after_leader_exit']=True
  if terminal_unknown:
   out['failure_stage']=row['label'];out['source_ownership_release_allowed']=False
   out['source_lease_held_for_root_diagnosis']=True
   dump(RESULT,out);print('STOP timeout '+row['label']+' descendant terminal state UNKNOWN; source lease retained',flush=True)
   break
  entry['source_after']=verify()
  if entry['exit']==0:
   if row['kind']=='metadata':metadata(row,entry)
   if row['kind']=='test':
    counts=[[int(x)for x in q]for q in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())]
    assert len(counts)==1 and counts[0][0]>0 and counts[0][1]==0;entry['actual_counts']=counts[0]
   if row['kind']=='gba_build':
    elf=Path(p['gba_target'])/'thumbv4t-none-eabi/release/pokered-gba';dest=Path(row['elf_copy']);assert not dest.exists();shutil.copy2(elf,dest);assert sha(elf.read_bytes())==sha(dest.read_bytes());entry['elf_copy']=str(dest);entry['elf_sha256']=sha(dest.read_bytes());entry['iwram']=iwram(dest)
   if row['kind']=='gbafix':entry['rom_sha256']=sha(Path(row['rom']).read_bytes());entry['rom_bytes']=Path(row['rom']).stat().st_size
   if row['kind']=='debug_cli':
    src=Path(p['host_target'])/'debug/pokered-app';dest=R/'audit-1030-candidate-debug';assert not dest.exists();shutil.copy2(src,dest);assert sha(src.read_bytes())==sha(dest.read_bytes());ident={'utc':now(),'game_head':p['head'],'engine_head':p['engine_head'],'source_freeze':str(F),'source_freeze_sha256':sha(F.read_bytes()),'binary':str(dest),'binary_sha256':sha(dest.read_bytes()),'build_log':str(log),'build_log_sha256':entry['log_sha256'],'features':['debug-server'],'not_a_current_master_capture':True};dump(R/'audit-1030-candidate-debug-identity.json',ident);entry['debug_identity']=ident
   if row['kind']=='perf_compare':
    entry['comparison_output']=log.read_text();entry['candidate_metrics_sha256']=sha((R/'audit-1030-candidate-performance.json').read_bytes());entry['unchanged_baseline_sha256']=sha((W/p['gba_policy']['baseline']).read_bytes())
  dump(RESULT,out);print('END '+row['label']+' exit='+str(entry['exit']),flush=True)
  if entry['exit']!=0:out['failure_stage']=row['label'];break
 else:
  out['source_after']=verify();out['complete']=True;out['all_pass']=True;code=0
 if not terminal_unknown and not out['complete']:out['source_after']=verify()
except BaseException as e:
 code=1;out['complete']=False;out['all_pass']=False
 if proc is not None and (proc.poll()is None or group_present(proc.pid)):
  terminal_unknown=True
  try:os.killpg(proc.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  out['active_leader_exit_after_owned_group_kill']=proc.wait()
  out['source_ownership_release_allowed']=False;out['source_lease_held_for_root_diagnosis']=True
 out['failure_stage']=row['label']if 'row'in locals()else'preflight';out['failure_exception']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()};print(out['failure_exception']['traceback'],flush=True)
finally:
 out['finished_utc']=now();out['all_own_child_commands_terminal']=not terminal_unknown
 if terminal_unknown:out['descendant_terminal_state']='UNKNOWN_SOURCE_LEASE_RETAINED_NO_POSTVERIFY_OR_NEXT_STAGE'
 dump(RESULT,out)
 if not terminal_unknown:LOCK.unlink(missing_ok=True)
raise SystemExit(code)
