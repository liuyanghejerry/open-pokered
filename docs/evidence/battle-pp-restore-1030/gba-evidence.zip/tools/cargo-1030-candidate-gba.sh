#!/bin/bash
set -eu
[ "$PWD" = "/home/jerry/.cache/open-pokered-fidelity/1030-tile-candidate-gba-source/crates/pokered-gba" ] || exit 64
case "$1" in perf-benchmark|repro-route22|memory-scenarios|frame-timing|hardware-timing|opening-timing) ;; *) exit 64 ;; esac
export TMPDIR=/home/jerry/develop/open-pokered/.task-tmp/fidelity-1030-tile-candidate-local-tmp CARGO_HOME=/home/jerry/.cache/open-pokered-fidelity/1030-tile-candidate-cargo-home CARGO_INCREMENTAL=0
unset CARGO_PROFILE_DEV_OPT_LEVEL CARGO_PROFILE_DEV_DEBUG
exec cargo +nightly-2025-12-07 build --offline --locked --release --features "$1" --target-dir /home/jerry/develop/open-pokered/.task-tmp/fidelity-1030-tile-candidate-gba-target -j1
