#!/bin/bash
set -eu
[ "$PWD" = "/home/jerry/develop/open-pokered/.task-tmp/fidelity-1030-pp-gba-tile-candidate" ] || exit 64
export TMPDIR=/home/jerry/develop/open-pokered/.task-tmp/fidelity-1030-tile-candidate-local-tmp CARGO_HOME=/home/jerry/.cache/open-pokered-fidelity/1030-tile-candidate-cargo-home CARGO_INCREMENTAL=0
export LD_LIBRARY_PATH=/tmp/pokered-build-lib
export PATH=/home/jerry/.local/share/starheir-build/sysroot/usr/bin:$PATH
export PKG_CONFIG_PATH=/home/jerry/.local/share/starheir-build/sysroot/usr/lib/x86_64-linux-gnu/pkgconfig
export CARGO_PROFILE_DEV_OPT_LEVEL=0 CARGO_PROFILE_DEV_DEBUG=0
task_subcommand="$1"; shift
exec cargo "$task_subcommand" --offline --locked --target-dir /home/jerry/develop/open-pokered/.task-tmp/fidelity-1030-tile-candidate-host-target -j1 "$@"
