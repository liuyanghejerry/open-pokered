# 1030 本地 host / GBA 验证证据

受测游戏为 `9624c7f8e4f793a57abd4c940b9a8d2a8b99fdee`，引擎为实际 Git pin `e533a3d23a0cdbed1524a1ac91184733da4a6f7e`。本包不会把引擎源改标为后续 integration merge head。权威本地运行 session5173 已终结0，28/28命令均exit0，全部owned子进程终结。

游戏host：core2944通过、renderer400通过、app debug334通过/39忽略、app default323通过/37忽略、determinism10通过；metadata分别核11/9个canonical引擎包，显式debug CLI构建及GBA门禁工具检查通过。另附同一e533的独立引擎host三组原始日志：53/450/484通过（均0失败/忽略）。这些是不同suite的原始计数，不能相加成一个suite，也不代表新增普通输入验证。

GBA：原31项performance metric门禁通过；Route22内存40轮、broad13场景（双方330招式）、frame23场景、slow-cart hardware6场景、opening3场景通过。详细原始输出、解析指标与每项原门槛在raw logs、metrics及peer审查中。保持原baseline、feature顺序、normal linker、预算和阈值不变。IWRAM上限仍24320 bytes，startup/IRQ预留8192 bytes；六个实际ELF的.iwram依次为22624/22636/22640/22636/22636/22636 bytes。

**全部为本地固定mGBA0.10.5 SDL验证，不能当作新的官方CI已经通过。** 不声称CI Qt宿主/外部GFX与本地完全相同，也不声称原作硬件、CPU时钟、PCM或所有剧情/功能一致。本包没有重跑Cargo、Game、linker或远程workflow。PP同帧普通输入画面由另一份独立PP证据包证明；本runner本身没有运行这些画面控制。

公开内容由authoritative handoff的65项明确白名单选择：53项允许公开；排除12个ELF/ROM，仅在handoff及 `identities/excluded-artifact-identities.json` 保留原SHA/字节数。另加3个engine raw logs、authoritative handoff及2份独立审查。完整28个command log（含实际空日志）、6个mGBA raw log、Cargo metadata stdout、4个metrics JSON、原runner/plan/3wrapper源及sourcefreeze均按原字节保留。

不含exe/ROM/ELF/硬件state、target、GFX或地图副本、credential/config secret；wrapper/runner仅为实际受测的文本源，不在打包时执行。原JSON内本地绝对路径原文保留，manifest同时给portable相对路径。sourcefreeze只是身份/文件模式/blob/hash元数据。`manifest.json` 对每个成员列出原路径、原SHA和字节数；所有原文件先pin后copy，copy与源再次相等，ZIP逐项读回校验。
