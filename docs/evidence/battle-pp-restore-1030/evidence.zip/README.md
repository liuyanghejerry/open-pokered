# PP 画面补充证据（1030）

本包保留两组相同 fixture、seed42 和完整逐帧输入：每组3568帧，分别为 Ether1328、Elixir1288、Transform Ether952帧。BEFORE 是冻结的 literal master26bd6050（binary ec91d333）；AFTER 是 private9624c7f8 / enginee533a3d2（binary06591337）。这些身份不会改标成未来发布或合入的版本。

前置使用 `--snapshot`、`--skip-intro`、`--warp ViridianForest,28,32`；这是受控 preboot JSON fixture，随后全部为普通按键，**不是 cold boot/CONTINUE 或普通 SAVE 验证**。两组都没有创建 `unused.sav`。历史a2fa/af3/949/965的原作、SAVE和其他控制保持原有身份；本包不复制旧控制器，也不把历史结果算作本轮新增。

四组同完整前缀、同绝对帧对照为：Ether招式选择688、Ether结果1328、Elixir结果1288、Transform后的Ether招式选择952。每个 provider 保留原始 initial state、完整按钮、每帧 press_timeline receipts、get_state states、game.log、最终 result 及4张PNG。JSONL无删行/汇总替换。

Capture API 的响应**未单独存为原始日志**；controller逐次断言响应state等于当前state、后续get_state相等且不推进帧，但归档只能提供该源代码断言、逐帧state和PNG，不能重新构造未存的响应。截图走 `Game.draw`，**不能证明运行了RenderSession缓存路径**。本包不新增原作对照、RNG/PCM/全动画或GBA性能证明。

`manifest.json` 列出每个归档成员对应的原文件绝对路径、字节数及SHA256。路径按原文复制，portable逻辑路径独立列出，原JSON中的机器绝对路径没有改写。Controller源保留实际运行版本c6a3；其中路径与原环境有关，归档用于审查及提取fixture/完整按钮，不声称在任意目录直接启动旧controller即可重放。

不含exe/ROM/ELF/硬件state、target、地图副本或其他PR批次日志。sourcefreeze仅为哈希/模式/身份元数据，不包含其所引用的编译输入或图像资源。
