# PP screenshot inputs — data only

Three exact preinput modern JSON fixtures and complete physical button vectors are copied byte-for-byte from old935 literal-a2fa prefix evidence, cross-checked against old private-af3 evidence. No old controller was imported or executed. The native initial input is fixtureJSON, not SRAM. Post-treatment ordinary.sav files are not initial inputs and are deliberately excluded. No ROM, executable or hardware snapshot is included.

Historical setup was preboot `--snapshot fixture.json --skip-intro --warp ViridianForest,28,32`, seed42, English, private executable/cwd/save path, driven headless speed0. Every recorded historical frame/button was checked. Required proposed screenshot surfaces: Ether chooser688/result1328; Elixir result1288; transformed Ditto Ether chooser952. The complete Transform vector also reaches its historical result1584; that extra surface is optional.

All frame numbers and expected states are historical observations, not a new26bd/9624 success claim. Current controller must be separately authored/reviewed after final CLI identity exists. It must use identical fixtures/seed/fullbuttons/absolute frames for both providers and stop on the first divergent receipt, phase or data guard; no adaptive advancing retry, live setter or silent retiming. If changed entry timing prevents reuse, preserve the first failure and request a separately bounded common-prefix discovery. Do not invent a cold-SAVE prefix.

Old965's separately recorded400-frame ACK continuation is preserved under historical-only; it is not implicitly part of the fresh screenshot proposal. Old93514 ordinarySAVE controls and old949 Mimic controls remain separate evidence with their own identities. No new gameplay, SAVE or CONTINUE is claimed here.
