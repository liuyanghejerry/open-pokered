"""Prepared only: fixed historical DATA prefixes, no old controller imports.
Default verifies custody without starting Game. Execution needs a later READY
plan with both final CLI identities pinned and separate root authorization.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, signal, socket, struct
import subprocess, sys, time, traceback

R = Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
DEFAULT_PLAN = R / 'audit-1030-pp-screenshot-controls-plan-v2.json'
SELF = Path(__file__)
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def read_json(path):
    return json.loads(Path(path).read_text())

def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')

def pinned(rec):
    q = Path(rec['path']); raw = q.read_bytes()
    assert sha(raw) == rec['sha256'], ('pin', str(q))
    if 'bytes' in rec: assert len(raw) == rec['bytes'], ('size', str(q))
    return q

def subset(actual, expected, where):
    if isinstance(expected, dict):
        assert isinstance(actual, dict), (where, actual, expected)
        for k, v in expected.items():
            assert k in actual, (where, 'missing', k)
            subset(actual[k], v, where + '.' + k)
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(actual) == len(expected), (where, actual, expected)
        for i, v in enumerate(expected): subset(actual[i], v, where + '[' + str(i) + ']')
    else:
        assert actual == expected, (where, actual, expected)

def source_check(provider):
    freeze = read_json(pinned(provider['source']))
    worktree = Path(provider['worktree'])
    git = lambda *a: subprocess.check_output(['git', *a], cwd=worktree)
    assert git('rev-parse', 'HEAD').decode().strip() == provider['head']
    assert git('status', '--porcelain') == b''
    entries = freeze['complete_non_docs']; index = {}
    for row in git('ls-files', '-s', '-z').split(b'\0'):
        if not row: continue
        meta, name = row.split(b'\t', 1); mode, blob, stage = meta.decode().split()
        assert stage == '0'; name = os.fsdecode(name)
        if not name.startswith('docs/'): index[name] = (mode, blob)
    assert set(index) == set(entries)
    for name, rec in entries.items():
        q = worktree / name
        assert q.is_symlink() == (rec['mode'] == '120000'), name
        raw = os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes()
        assert sha(raw) == rec['sha256'] and index[name] == (rec['mode'], rec['git_blob']), name
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == rec['git_blob'], name
        if not q.is_symlink(): assert bool(q.stat().st_mode & 0o111) == (rec['mode'] == '100755'), name
    assert os.readlink(worktree / 'gfx') == freeze['gfx_symlink_literal']
    for name, digest in freeze['external_gfx'].items():
        assert sha((Path(freeze['external_gfx_root']) / name).read_bytes()) == digest, name
    return {'head': provider['head'], 'compiler': len(freeze['compiler']),
            'NUL_non_doc_modes_blobs_literals': len(entries), 'gfx': len(freeze['external_gfx']), 'all_equal': True}

def verify(plan, require_ready=False):
    assert sha(SELF.read_bytes()) == plan['controller_sha256']
    pinned(plan['data_report']); manifest = read_json(pinned(plan['data_manifest']))
    root = Path(manifest['root'])
    for rec in manifest['files']: pinned(dict(rec, path=str(root / rec['path'])))
    for rec in manifest['source_copies']: pinned(rec)
    proofs = {}
    for key, provider in plan['providers'].items():
        proofs[key] = source_check(provider)
        if provider['identity']['sha256'] is None:
            assert key == 'after' and not require_ready, 'Final AFTER CLI identity still pending'
            continue
        identity = read_json(pinned(provider['identity']))
        pinned(provider['binary'])
        assert identity[provider['identity_head_key']] == provider['head']
        assert identity['binary_sha256'] == provider['binary']['sha256']
        assert identity[provider['identity_source_key']] == provider['source']['path']
        assert identity[provider['identity_source_sha_key']] == provider['source']['sha256']
        if key == 'after': assert identity['engine_head'] == plan['engine_head']
    if require_ready:
        assert plan['status'] == 'READY_FINAL_IDENTITIES_ROOT_REVIEW_REQUIRED'
        assert all(p['identity']['sha256'] and p['binary']['sha256'] for p in plan['providers'].values())
    for case in plan['cases']:
        buttons = read_json(pinned(case['buttons'])); pinned(case['fixture'])
        assert len(buttons) == case['original_vector_frames']
        assert 0 < case['execute_frames'] <= len(buttons)
        assert all(b is None or b in ['a', 'b', 'up', 'down', 'left', 'right', 'start', 'select'] for b in buttons)
        assert 'select' not in buttons and 'start' not in buttons
        assert max(s['frame'] for s in case['shots']) == case['execute_frames']
        assert sha(json.dumps(buttons[:case['execute_frames']], separators=(',', ':')).encode()) == case['used_prefix_sha256']
    return proofs

class Client:
    def __init__(self, port):
        self.sock = socket.create_connection(('127.0.0.1', port), timeout=15)
        self.sock.settimeout(30); self.file = self.sock.makefile('rwb')
    def cmd(self, cmd, **kw):
        assert cmd in ['get_state', 'press_timeline', 'capture_frame']
        self.file.write((json.dumps(dict(cmd=cmd, **kw)) + '\n').encode()); self.file.flush()
        line = self.file.readline(); assert line, 'Debug server EOF; no retry'
        response = json.loads(line); assert response.get('ok') is True, response
        return response['data']
    def close(self):
        self.file.close(); self.sock.close()

def group_present(pid):
    try: os.killpg(pid, 0); return True
    except ProcessLookupError: return False

def run_case(plan, provider_key, case, outdir, result):
    provider = plan['providers'][provider_key]; here = outdir / case['name']; here.mkdir()
    fixture = here / 'fixture.json'; fixture.write_bytes(pinned(case['fixture']).read_bytes())
    assert sha(fixture.read_bytes()) == case['fixture']['sha256']
    map_prefix = 'crates/pokered-data/maps/'
    map_records = {n[len(map_prefix):]: rec for n, rec in read_json(pinned(provider['source']))['complete_non_docs'].items()
                   if n.startswith(map_prefix)}
    private_maps = here / 'maps'; private_maps.mkdir()
    for name, rec in map_records.items():
        q = private_maps / name; q.parent.mkdir(parents=True, exist_ok=True)
        raw = (Path(provider['worktree']) / map_prefix / name).read_bytes()
        assert sha(raw) == rec['sha256']; q.write_bytes(raw)
    buttons = read_json(pinned(case['buttons']))[:case['execute_frames']]
    dump(here / 'buttons.json', buttons)
    unused_save = here / 'unused.sav'; assert not unused_save.exists()
    port = case['ports'][provider_key]
    argv = [provider['binary']['path'], 'run', '--headless', '--speed', '0', '--seed', '42',
            '--skip-intro', '--snapshot', str(fixture), '--warp', 'ViridianForest,28,32',
            '--lang', 'en', '--no-audio', '--save', str(unused_save), '--debug-port', str(port)]
    entry = {'case': case['name'], 'provider': provider_key, 'argv': argv, 'cwd': str(here),
             'started_utc': now(), 'frames_completed': 0, 'shots': [], 'complete': False}
    result['cases'].append(entry); dump(outdir / 'result.json', result)
    env = dict(os.environ); env['LD_LIBRARY_PATH'] = '/tmp/pokered-build-lib'
    env['POKERED_MAPS_DIR'] = str(private_maps)
    proc = client = None; terminal = False
    log = here / 'game.log'
    try:
        with log.open('x') as stream:
            proc = subprocess.Popen(argv, cwd=here, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            entry['owned_process_group'] = proc.pid
            deadline = time.monotonic() + 30
            while 'Driven-only mode: frames advance only via debug commands.' not in log.read_text():
                assert proc.poll() is None, ('startup-exit', proc.returncode)
                assert time.monotonic() < deadline, 'Startup readiness timeout; no Game retry'
                time.sleep(0.02)
            client = Client(port); initial = client.cmd('get_state'); dump(here / 'initial-state.json', initial)
            subset(initial, {'frame_count': 0, 'screen': 'overworld', 'map_id': 51,
                             'map_name': 'ViridianForest', 'player_x': 28, 'player_y': 32,
                             'money': case['initial_summary']['money'],
                             'party': [{k: m[k] for k in ['species', 'level', 'hp', 'max_hp', 'moves', 'pp', 'status']}
                                       for m in case['initial_summary']['party']]}, 'initial')
            with (here / 'receipts.jsonl').open('x') as receipts, (here / 'states.jsonl').open('x') as states:
                for frame, button in enumerate(buttons, 1):
                    receipt = client.cmd('press_timeline', buttons=[button], advance=True)
                    receipts.write(json.dumps({'frame': frame, 'button': button, 'receipt': receipt}) + '\n'); receipts.flush()
                    subset(receipt, {'queue_start_frame': frame-1, 'start_frame': frame-1, 'end_frame': frame-1,
                                     'frames': 1, 'padding_frames': 0, 'advanced': True, 'frame_count': frame}, 'receipt')
                    state = client.cmd('get_state'); states.write(json.dumps(state) + '\n'); states.flush()
                    subset(state, {'frame_count': frame, 'map_id': 51, 'map_name': 'ViridianForest',
                                   'money': case['initial_summary']['money']}, 'frame')
                    if frame == 1: subset(state, case['first_state_expected'][provider_key], 'first-frame')
                    entry['frames_completed'] = frame
                    for shot in case['shots']:
                        if shot['frame'] != frame: continue
                        subset(state, shot['expected'][provider_key], 'shot.' + shot['name'])
                        path = here / (shot['name'] + '.png'); assert not path.exists()
                        capture = client.cmd('capture_frame', path=str(path))
                        assert capture['path'] == str(path) and capture['state'] == state
                        assert client.cmd('get_state') == state, 'Capture altered public state or frame'
                        raw = path.read_bytes(); assert raw[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II', raw[16:24]) == (160,144)
                        entry['shots'].append({'name': shot['name'], 'frame': frame, 'path': str(path), 'sha256': sha(raw)})
            assert entry['frames_completed'] == case['execute_frames'] and len(entry['shots']) == len(case['shots'])
            assert not unused_save.exists(), 'Screenshot-only prefix unexpectedly wrote SRAM'
            entry['complete'] = True
    finally:
        if client is not None:
            try: client.close()
            except OSError as e: entry['connection_close_error'] = str(e)
        if proc is not None:
            if proc.poll() is None: proc.terminate(); entry['shutdown'] = 'OWNED_PID_SIGTERM_AFTER_CONTROL_OR_FAILURE'
            try: entry['game_exit'] = proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL); entry['game_exit_after_owned_group_kill'] = proc.wait()
                entry['forced_kill_terminal_state'] = 'UNKNOWN_SOURCE_LEASE_HELD'
            terminal = 'forced_kill_terminal_state' not in entry and not group_present(proc.pid)
        entry['all_own_children_terminal'] = terminal
        entry['finished_utc'] = now(); entry['game_log_sha256'] = sha(log.read_bytes())
        entry['source_after'] = verify(plan, require_ready=True) if terminal else 'UNKNOWN_HOLD_SOURCE_LEASE'
        for name, rec in map_records.items(): assert sha((private_maps / name).read_bytes()) == rec['sha256'], name
        assert sha(fixture.read_bytes()) == case['fixture']['sha256']
        dump(outdir / 'result.json', result)
    assert terminal, 'Unknown owned descendants; source lease held'

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--plan', type=Path, default=DEFAULT_PLAN)
    ap.add_argument('--execute', action='store_true'); ap.add_argument('--provider', choices=['before', 'after'])
    args = ap.parse_args(); plan = read_json(args.plan); plan_sha = sha(args.plan.read_bytes())
    proof = verify(plan, require_ready=args.execute)
    if not args.execute:
        print(json.dumps({'status': 'PREPARED_READONLY_NO_GAME_AFTER_IDENTITY_PENDING' if plan['status'] != 'READY_FINAL_IDENTITIES_ROOT_REVIEW_REQUIRED' else 'READONLY_READY_NO_GAME',
                          'plan_sha256': plan_sha, 'controller_sha256': sha(SELF.read_bytes()), 'source': proof})); return 0
    assert args.provider is not None
    root = Path(plan['output_root']); outdir = root / args.provider
    if args.provider == 'after':
        prior = read_json(root / 'before/result.json')
        assert prior['complete'] and prior['all_pass'] and prior['all_own_children_terminal'] and prior['plan_sha256'] == plan_sha
    root.mkdir(exist_ok=True); outdir.mkdir()
    result = {'scope': 'CONTROLLED_PREBOOT_SNAPSHOT_SKIPINTRO_WARP_NOT_COLD_SAVE', 'provider': args.provider,
              'plan_sha256': plan_sha, 'controller_sha256': sha(SELF.read_bytes()), 'source_before': proof,
              'started_utc': now(), 'cases': [], 'complete': False, 'all_pass': False, 'all_own_children_terminal': False}
    code = 1
    try:
        for case in plan['cases']:
            assert sha(args.plan.read_bytes()) == plan_sha
            verify(plan, require_ready=True); print('START ' + args.provider + ' ' + case['name'], flush=True)
            run_case(plan, args.provider, case, outdir, result)
            print('END ' + args.provider + ' ' + case['name'], flush=True)
        assert sha(args.plan.read_bytes()) == plan_sha, 'Plan changed before final verification'
        result['source_after'] = verify(plan, require_ready=True)
        result['complete'] = True; result['all_pass'] = True; code = 0
    except BaseException as e:
        code = 1; result['complete'] = False; result['all_pass'] = False
        result['failure'] = {'type': type(e).__name__, 'message': str(e), 'traceback': traceback.format_exc()}
        print(result['failure']['traceback'], flush=True)
    finally:
        result['finished_utc'] = now()
        result['all_own_children_terminal'] = all(c.get('all_own_children_terminal', False) for c in result['cases'])
        dump(outdir / 'result.json', result)
    return code

if __name__ == '__main__': sys.exit(main())
