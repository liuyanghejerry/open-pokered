import sys,pathlib,json,shutil,hashlib
root=pathlib.Path('/home/jerry/develop/open-pokered');wt=root/'.task-tmp/fidelity-91-plus-checkout';r=root/'.task-tmp/fidelity-39-plus';sys.path.insert(0,str(wt/'scripts'))
from playthrough import Game,m01_boot,m02_oak_speech
import ast,subprocess,playthrough_late
source=subprocess.check_output(['git','show','2d5b751a444164a478cc9431de4b498bdc30b47a:scripts/playthrough_late.py'],cwd=wt,text=True)
node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='lead_with')
namespace=dict(playthrough_late.__dict__)
exec(compile(ast.Module(body=[node],type_ignores=[]),'pinned-old-lead_with','exec'),namespace)
lead_with=namespace['lead_with']
from playthrough_late import use_item
binary=r/'audit-155-cli-immutable/pokered-app'
for trial in [1,2]:
 out=r/f'audit-155-old-fly-driver-{trial}';out.mkdir(exist_ok=True)
 g=Game(binary=binary,seed=1);trace=[]
 try:
  m01_boot(g);m02_oak_speech(g)
  for species,level in [('Venusaur',51),('Lapras',15),('Zapdos',50)]:assert g.d.cmd(cmd='give_pokemon',species=species,level=level)['ok']
  assert g.d.cmd(cmd='warp',map='CinnabarIsland',x=11,y=12)['ok']
  g.wait('control_ready',600)
  assert g.d.cmd(cmd='give_item',item='Hm02',qty=1)['ok']
  use_item(g,'Hm02',party_index=2)
  assert 'Fly' in g.st()['party'][2]['moves']
  original_tap=g.tap
  def tap(btn,gap=8):
   trace.append({'stage':'before','button':btn,'state':g.st()});original_tap(btn,gap);trace.append({'stage':'after','button':btn,'state':g.st()})
  g.tap=tap
  # Bound only the final wait: no physical inputs are changed. The state
  # remains a ready START menu even after480 neutral frames, not a cutscene.
  g.cutscene=lambda:Game.cutscene(g,max_rounds=2)
  failed=False
  try:lead_with(g,'Zapdos')
  except AssertionError:failed=True
  state=g.st();assert failed,(trial,state)
  assert state['screen']=='start-menu' and state['field_menu']['input_ready']
  assert state['party'][0]['species']=='Zapdos'
  (out/'trace.json').write_text(json.dumps(trace,indent=2)+'\n');(out/'end-state.json').write_text(json.dumps(state,indent=2)+'\n')
  print(trial,'old helper fails, swap completed, ready START remains',flush=True)
 finally:
  shutil.copyfile(g.run_dir/'game.log',out/'game.log');g.close()
(r/'audit-155-fly-binary.json').write_text(json.dumps({'head':'2d5b751a444164a478cc9431de4b498bdc30b47a','features':['debug-server'],'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'scope':'real NEW GAME then diagnostic party/map seeding; not a mainline pass'},indent=2)+'\n')
