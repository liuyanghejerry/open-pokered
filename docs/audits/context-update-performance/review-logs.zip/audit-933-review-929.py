from pathlib import Path
import json,hashlib,re,subprocess,datetime
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-929-update-hotpaths'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
handoff=read(r/'audit-929-final-handoff-4.json');assert handoff['head']=='b9612d7791b8fb4bb28dc06b8f0a4291c4973ca3'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==handoff['head']
assert subprocess.check_output(['git','status','--porcelain'],cwd=w)==b''
for name,digest in handoff['changed_file_sha256'].items():assert sha(w/name)==digest
for name,digest in handoff['artifacts'].items():assert sha(r/name)==digest
freeze=read(r/'audit-929-integration-source-freeze-4.json');assert freeze['head']=='a4ee5db524216642c38a87cc1d75bc5a29c576e3'
changes=[]
for name,h in freeze['files'].items():
 if sha(w/name)!=h:changes.append(name)
assert changes==handoff['source_after_frozen_tests_changes_only']
assert len(freeze['files'])==6762
counts={}
for row in read(r/'audit-929-integration-host-checks-4.json'):
 assert row['exit']==0;text=Path(row['log']).read_text()
 if row['label']!='appmetadata':
  m=re.search(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',text);assert m
  counts[row['label']]={'passed':int(m[1]),'ignored':int(m[2])}
 else:
  assert 'Finished' in text
  messages=[json.loads(x)for x in(r/'audit-929-integration-app-artifacts-4.jsonl').read_text().splitlines()]
  assert any(x.get('reason')=='build-finished'and x.get('success')for x in messages)
assert counts=={'appscopeddebug':{'passed':5,'ignored':0},'corefull':{'passed':2890,'ignored':0},'appfulldebug':{'passed':303,'ignored':39},'appscopeddefault':{'passed':5,'ignored':0}}
negative=(r/'audit-929-before-name-controls-2.log').read_text();assert '0 passed; 2 failed;'in negative
gba=[]
perf_rows=read(r/'audit-929-integration-gba-performance-4.json')
for item in perf_rows:
 pin=item['pin'];manifest=read(item['source_freeze']);mirror=Path(manifest['mirror']);assert len(manifest['files'])==2165
 for name,h in manifest['files'].items():assert sha(mirror/name)==h
 if pin=='76':
  assert not manifest['mechanical_pin_changes']
  for name,h in manifest['files'].items():assert sha(w/name)==h
 else:assert len(manifest['mechanical_pin_changes'])==17
 assert sha(r/f'audit-929-integration{pin}-perf-4.gba')==item['rom_sha256']
 assert sha(r/f'audit-929-integration{pin}-perf-4.elf')==item['elf_sha256']
 metrics=read(r/f'audit-929-integration{pin}-perf-4.json')['scenarios'];assert len(metrics)==7
 text=(r/f'audit-929-integration{pin}-compare-4.log').read_text()
 assert 'GBA performance is within the configured regression budget.'in text and 'FAIL'not in text
 lines=re.findall(r'^([a-z0-9-]+)/([a-z_]+):\s+(\d+)\s+->\s+(\d+)\s+ticks.*?limit ([0-9.]+)\)',text,re.M)
 assert len(lines)==31,(pin,len(lines))
 for scene,key,before,after,limit in lines:assert int(after)<=float(limit)and metrics[scene][key]==int(after)
 assert metrics['overworld-idle-v1']['update_avg_ticks']==(349 if pin=='76'else 350)
 assert metrics['trainer-battle-entry-v1']['update_avg_ticks']==(223 if pin=='76'else 225)
 gba.append({'pin':pin,'verified_paths':2165,'all31_unchanged_limits_PASS':True,'idle':metrics['overworld-idle-v1']['update_avg_ticks'],'trainer':metrics['trainer-battle-entry-v1']['update_avg_ticks'],'ROM_sha256':item['rom_sha256']})

paths=[r/'audit-929-before-ordinary-run-1',r/'audit-929-after-ordinary-run-1',r/'audit-929-integration-ordinary-run-4']
rows=[read(p/'all-frame-prefix.json')for p in paths];assert len(rows[0])==9749 and rows[0]==rows[1]==rows[2]
file_rows=[]
for item in read(r/'audit-929-integration-ordinary-equivalence-4.json')['files']:
 name=item['name'];data=(paths[0]/name).read_bytes()
 assert len(data)==item['bytes']and hashlib.sha256(data).hexdigest()==item['sha256']
 assert all((p/name).read_bytes()==data for p in paths)
 if name=='private.sav':assert len(data)==32768 and data[0x3523]==(~sum(data[0x2598:0x3523])&255)
 file_rows.append({'name':name,'bytes':len(data),'sha256':item['sha256'],'all_three_builds_byte_equal':True})
for name in ['audit-929-before-ordinary-build-1.json','audit-929-after-ordinary-build-1.json','audit-929-integration-ordinary-build-4.json']:
 d=read(r/name);assert sha(Path(d['binary']))==d['binary_sha256'];assert sha(r/'audit-929-ordinary-context-prefix-1.rs')==d['source_sha256']
proof=read(r/'audit-929-query-proof-result-3.json');assert proof['result']=='PASS'and proof['record_exit']==0 and proof['no_assertion_failure']and len(proof['completed_scenarios'])==7
normal=read(r/'audit-929-integration76-normal-build-4.json');assert normal['result']=='PASS --locked normal release'
assert 'Finished' in(r/normal['build_log']).read_text()
source_diff=subprocess.check_output(['git','diff','--name-only',handoff['base_master'],'HEAD'],cwd=w,text=True).splitlines()
assert sorted(source_diff)==sorted(handoff['changed_file_sha256'])
result={'reviewer':'root','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':handoff['head'],'tested_source':freeze['head'],'base':handoff['base_master'],'code_review':'Read complete39-added/3-removed production delta and194-line5test file; exact32bitFNV limbs andtwoequal-name guards, no owner/schema/cache/input change. Independent earlier root3,293,760-case wide math agrees with same limb formula.','source_files_verified':6762,'docs_only_after_tests':changes,'host_counts':counts,'GBA':gba,'ordinary_frames':9749,'all_three_raw_prefix_arrays_equal':True,'byte_equal_files':file_rows,'before_real_name_controls_expected_0PASS2FAIL':True,'diagnostic_query_all7_PASS':True,'normal_GBA_build_PASS':True,'production_engine_pin_unchanged_76':True,'no_test_or_actual_rerun':True,'limits':'Native deterministic equivalence within declared accelerated preBOOT fixture and recorded input path; no original-game parity/fresh-campaign/full-Silph-timing claim. Pin99c only isolated experiment, not committed.'}
(r/'audit-933-root-review-929.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
