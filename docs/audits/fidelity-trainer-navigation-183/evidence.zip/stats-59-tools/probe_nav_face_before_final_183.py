from pathlib import Path
import sys,os,json,socket,subprocess
root=Path('/home/jerry/develop/open-pokered');w=root/'.task-tmp/fidelity-91-plus-checkout';r=root/'.task-tmp/fidelity-39-plus';sys.path.insert(0,str(w/'scripts'));from debug_drive import DebugClient
import playthrough
for trial in [1,2]:
 out=r/f'audit-182-nav-face-before-a2-{trial}';assert not out.exists();out.mkdir()
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 log=(out/'game.log').open('w');p=subprocess.Popen([str(r/'audit-181-debug-cli-a4-immutable/pokered-app'),'--scripts-dir',str(w/'crates/pokered-data/maps'),'run','--headless','--debug-port',str(port),'--speed','0','--skip-intro','--no-audio','--seed','42','--save',str(out/'isolated.sav'),'--snapshot',str(r/'audit-183-nav-face-snapshot.json'),'--lang','en'],cwd=w,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib'),stdout=log,stderr=subprocess.STDOUT);d=None
 try:
  d=DebugClient(port=port);v=d.cmd(cmd='warp',map='RocketHideoutB4F',x=19,y=10);assert v.get('ok'),v;d.cmd(cmd='step_frames',count=120)
  g=playthrough.Game.__new__(playthrough.Game);g.d=d;g.observed_npcs={};g.smart_moves=False
  g.nav_to(11,3,'RocketHideoutB4F');(out/'before-face.json').write_text(json.dumps(g.st(),indent=2)+'\n');d.cmd(cmd='capture_frame',path=str(out/'before.png'))
  ns={'NavError':playthrough.NavError};exec('class OldGame:\n'+(r/'audit-183-face-before.py.txt').read_text(),ns);g.face=ns['OldGame'].face.__get__(g)
  try:g.face('up');result='success'
  except playthrough.NavError as e:result=str(e)
  (out/'after-face.json').write_text(json.dumps(g.st(),indent=2)+'\n');d.cmd(cmd='capture_frame',path=str(out/'after.png'));(out/'result.json').write_text(json.dumps({'result':result},indent=2)+'\n');print(trial,result,flush=True)
 finally:
  if d:d.close()
  p.terminate()
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait()
  log.close()
