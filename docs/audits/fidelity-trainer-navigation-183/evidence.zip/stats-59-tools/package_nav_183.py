from pathlib import Path
import json,hashlib,zipfile
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';out=w/'docs/audits/fidelity-trainer-navigation-183';out.mkdir(parents=True,exist_ok=True);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Ran 75 tests' in (r/'audit-183-python-tests-a3.log').read_text() and (r/'audit-183-python-tests-a3.log').read_text().rstrip().endswith('OK')
entries={};groups=['audit-182-nav-face-before-a2','audit-182-nav-face-after-a5','audit-182-nav-face-after-a4','audit-182-nav-face-before-a1','audit-182-nav-face-after-a2']
for name in groups:
 a=r/(name+'-1');b=r/(name+'-2');files=sorted(p.name for p in a.iterdir() if p.suffix in ['.png','.json']);assert files==sorted(p.name for p in b.iterdir() if p.suffix in ['.png','.json']);assert all((a/n).read_bytes()==(b/n).read_bytes() for n in files),name
 for d in [a,b]:
  for p in d.iterdir():
   if p.suffix in ['.png','.json','.log']:entries[str(p.relative_to(r))]=p
for trial in [1,2]:
 before=r/f'audit-182-nav-face-before-a2-{trial}';after=r/f'audit-182-nav-face-after-a5-{trial}';assert (before/'before-face.json').read_bytes()==(after/'before-face.json').read_bytes();assert json.loads((before/'result.json').read_text())['result']=='face(up) failed: Left';assert json.loads((after/'result.json').read_text())['result']=='interrupted';assert json.loads((after/'completion-flags.json').read_text())['data']['EVENT_BEAT_ROCKET_HIDEOUT_4_TRAINER_2'];st=json.loads((after/'completion-state.json').read_text());assert st['map_name']=='RocketHideoutB4F' and st['screen']=='overworld'
for pattern in ['audit-183*.log','audit-183*.json','audit-183*.txt','audit-182-nav-face*.log','audit-182-m22-codegraph.txt','audit-182-field-input-codegraph.txt','audit-182-trainer-finish-codegraph.txt']:
 for p in r.glob(pattern):entries[p.name]=p
for name in ['stats-59-tools/probe_nav_face_182.py','stats-59-tools/probe_nav_face_after_182.py','stats-59-tools/probe_nav_face_final_183.py','stats-59-tools/probe_nav_face_complete_183.py','stats-59-tools/probe_nav_face_complete_final_183.py','stats-59-tools/probe_nav_face_before_final_183.py','stats-59-tools/probe_nav_face_complete_final_a2_183.py','stats-59-tools/package_nav_183.py','audit-181-debug-cli-a4-immutable/manifest.json']:entries[name]=r/name
sources={}
for name in ['scripts/playthrough.py','scripts/test_playthrough_navigation.py']:
 entries['final-source/'+name]=w/name;sources[name]=h(w/name)
for name in ['failure-state.json','failure-flags.json','failure-npcs.json','failure.txt','m21.json']:entries['fresh179/'+name]=r/'audit-179-fresh-m49-a1'/name
# Keep the low-level diagnostic and its blackout; it is not the winning fixture.
for p in (r/'audit-182-nav-face-after-a3-1').iterdir():
 if p.suffix in ['.json','.png','.log']:entries['discarded-low-level-continuation/'+p.name]=p
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
v={'parent_head':'c11da19ac9e83bf1f6dd21f3b5417043e3029325','scope':'Python debug driver/tests only; player runtime unchanged','sources':sources,'binary':json.loads((r/'audit-181-debug-cli-a4-immutable/manifest.json').read_text()),'before':'two matched strong fixture copies, before-face frame416 exact; old2UP+12idle raises at430 while NPC intro owns field','after':'two matched strong fixture copies, bounded pulse/observe yields at448 to ShowDialogue, position11,3/facingLeft unchanged; approach drains script then fights; actual trainer2 flag true and returns overworld RocketHideoutB4F','copies':'all raw JSON/PNG within before and final after groups byte-exact2, no masks; pre-face before/final after full JSON byte-exact','controlled':'JSON template party changed using make_mon Venusaur38/Tackle,RazorLeaf,Cut,VineWhip, warp19,10; not actual fresh progression. Earlier Bulbasaur25 handoff also repeats2; its full continuation blacked out and is retained, not claimed passed','tests':75,'not_claimed':['original-RGB visual equivalence','full exact-head NEWGAME+CONTINUE','green CI or GBA performance'], 'archive':{'entries':len(entries),'bytes':archive.stat().st_size,'sha256':h(archive)}};(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(v['archive'])
(out/'README.md').write_text('''# Delayed trainer field-owner handoff (183)

Frozen parent179 NEW GAME passed m01..m21, then the m22 driver stopped at
RocketHideoutB4F (11,3): `face(up) failed: Left`. The lift-key trainer is at
(11,2). The logical destination is already reached, but the trainer intro owns
field input before its dialogue becomes observable. A two-frame UP pulse is
ignored during this interval; the old helper raises after twelve idle frames.
This is a debug-driver failure, not evidence of an unplayable player interaction.

`face` now observes a bounded sequence of pulses and returns when it sees the
requested facing or a dialogue/battle/choice owner. It sends no acknowledgement
or choice selection. A persistent ignored turn still raises. Object approach
also drains inner field text and script owners before planning again. Existing
map, NPC, battle and completion-flag assertions remain.

Two controlled original-helper/final-helper runs start with identical full
state at frame416. Original helper raises at430. Final helper observes the
ShowDialogue handoff at448, still at (11,3) facing Left, and the subsequent
approach completes the real trainer battle, verifies the trainer2 event flag,
and returns in RocketHideoutB4F. Every raw screenshot/JSON repeats byte-exactly
within each pair. The stronger continuation fixture uses a constructed
Venusaur38 party; it is subsystem evidence. The earlier Bulbasaur25 fixture also
repeats the handoff, but its continuation blacked out and is retained separately.
Neither fixture is claimed as a fresh mainline pass.

75 navigation/recovery tests pass. New tests guard delayed turn, delayed trainer
text, untouched choice, bounded failure and draining inner text before planning.
The first test-fixture BFS error and low-level blackout remain in the archive.
`verification.json` pins source/binary/archive hashes. Only Python tooling and
tests changed; normal on-screen rendering is unchanged, so no new visual PR
comparison is required. Final-source NEW GAME/independent CONTINUE, remaining
fidelity audits, and latest-head green CI remain open.
''')
