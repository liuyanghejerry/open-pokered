from pathlib import Path
import sys, os, tempfile, json, subprocess, hashlib, traceback, signal
signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(RuntimeError('Driver received SIGTERM')))
R = Path('/home/jerry/develop/open-pokered')
W = R / '.task-tmp/fidelity-1224-npc-motion-data'
E = R / '.task-tmp/fidelity-39-plus'
D = E / 'audit-1225-fresh-npc-m10-v3'
D.mkdir()
(D / 'tmp').mkdir()
tempfile.tempdir = str(D / 'tmp')
for key in list(os.environ):
    if key.startswith('POKERED_'):
        del os.environ[key]
sys.path.insert(0, str(W / 'scripts'))
import playthrough as p
import importlib.util
spec = importlib.util.spec_from_file_location("fast_json_wire", E / "audit-1225-fast-json-wire.py")
wire = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wire)
p.DebugClient = wire.accelerated_client(p.DebugClient)
binary = R / '.task-tmp/fidelity-1064-payday-target/debug/pokered-app'
files = subprocess.check_output(['git', 'ls-files', 'crates', 'scripts', 'Cargo.toml', 'Cargo.lock'], cwd=W, text=True).splitlines()
files.append('crates/pokered-core/src/overworld/original_npc_motion.json')
def manifest():
    return {name: hashlib.sha256((W / name).read_bytes()).hexdigest() for name in files if (W / name).is_file()}
before = manifest()
(D / 'source-manifest.json').write_text(json.dumps(before, indent=2) + '\n')
record = {'all_pass': False, 'fresh': True, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(), 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'commands': {}, 'games': [], 'transport': 'Identical JSON commands; ACK each received chunk to avoid the server split-write delayed-ACK stall; private adapter, not game change', 'scope': 'Fresh NEW GAME through m10 regression; no setters, warp, snapshot or save command. Existing milestone driver retains wait_until, step_frames and skip_dialogue helpers. Not animation parity or physical-only full-playthrough proof.'}
def put():
    (D / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
Base = p.Game
class Game(Base):
    def __init__(self, *args, **kwargs):
        assert not kwargs.get('snapshot')
        kwargs.setdefault('binary', binary)
        kwargs.setdefault('seed', 42)
        kwargs.setdefault('speed', 0)
        super().__init__(*args, **kwargs)
        record['games'].append({'pid': self.proc.pid, 'argv': self.proc.args, 'save_exists_at_connection': self.save_path.exists()})
        put()
        original = self.d.cmd
        def command(**kw):
            name = kw['cmd']
            assert name not in {'warp', 'set_flag', 'give_item', 'give_pokemon', 'start_wild_battle', 'save', 'set_seed', 'save_state', 'restore_state'}
            record['commands'][name] = record['commands'].get(name, 0) + 1
            if sum(record['commands'].values()) % 500 == 0:
                put()
            return original(**kw)
        self.d.cmd = command
p.Game = Game
sys.argv = [str(W / 'scripts/playthrough.py'), '--until', 'm10', '--artifacts', str(D)]
try:
    p.main()
    assert (D / 'm10.json').exists()
    record['all_pass'] = True
except BaseException:
    record['failure'] = traceback.format_exc()
    print(record['failure'], flush=True)
finally:
    record['source_unchanged'] = manifest() == before
    record['binary_unchanged'] = hashlib.sha256(binary.read_bytes()).hexdigest() == record['binary_sha256']
    put()
raise SystemExit(0 if record['all_pass'] and record['source_unchanged'] and record['binary_unchanged'] else 1)
