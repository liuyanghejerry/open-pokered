#!/usr/bin/env python3
"""Milestone-driven playthrough driver for open-pokered.

Drives a headless instance purely with button input (press/press_sequence/
step_frames) plus the observation/synchronization commands of the debug
protocol (get_state / wait_until / skip_dialogue), so every milestone is
reproducible end-to-end from a real power-on — no --skip-intro, --warp or
state seeding. Save goes to a throwaway path so the main menu always offers
a clean NEW GAME.

Pathfinding is local: tools/map_data.json carries each map's blocks and
passable-tile whitelist, crates/pokered-data/maps/*/map.json the
connections; BFS runs at tile resolution with live NPC blocking.

Usage:
    python3 scripts/playthrough.py [--port 9020] [--until m06] [--list]
"""
import argparse
import json
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from collections import deque
from pathlib import Path

# Late helpers import the driver's navigation primitives. When this file is
# executed as a script, keep one module/map cache instead of loading a second
# stale copy under the name "playthrough" after a switch opens a passage.
if __name__ == "__main__":
    sys.modules["playthrough"] = sys.modules[__name__]

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from debug_drive import DebugClient  # noqa: E402

BIN = ROOT / "target/debug/pokered-app"
FRAMES_PER_TILE = 16  # eight movement ticks, sampled every two hardware frames


def movement_frames(state, direction=None):
    """Match the observed transport's engine step duration."""
    uphill = state.get('map_name') == 'Route17' and direction in ('up', 'left', 'right')
    return 8 if state.get('player_transport') == 'Biking' and not uphill else FRAMES_PER_TILE


def movement_buttons(state, direction, held, frames):
    # The engine's cycling-road slope injects DOWN on neutral frames; B is
    # the real brake. Other maps retain their ordinary neutral tails.
    return [direction] * held + (['b'] * (frames-held) if state.get('map_name') == 'Route17' else [])
TAP_GAP = 6          # idle frames after a 1-frame tap (edge-trigger safety)

# ── static map data ─────────────────────────────────────────────────────
_MD = json.load(open(ROOT / "tools/map_data.json"))
BLOCKSETS = {b["tileset_id"]: b["blocks"] for b in _MD["blocksets"]}
MAPS = {m["name"]: m for m in _MD["maps"]}
CONNS = {}
for _p in sorted((ROOT / "crates/pokered-data/maps").iterdir()):
    _f = _p / "map.json"
    if _f.exists():
        _j = json.load(open(_f))
        CONNS[_j["name"]] = _j.get("connections") or {}
        # The export supplies decoded blocksets, but its map topology may
        # predate fixes in the canonical build inputs. Read current warps
        # and block bytes from the same sources as the game binary.
        _map = MAPS[_j['name']]
        _map['warps'] = [
            {'x': w['x'], 'y': w['y'], 'dest_map_name': w.get('destMap'),
             'dest_map': MAPS[w['destMap']]['id'] if w.get('destMap') else None,
             'dest_warp_id': w['destWarpId']}
            for w in _j.get('warps', [])]
        _map['width'], _map['height'] = _j['header']['width'], _j['header']['height']
        _block_file = _p / 'map.blk'
        if _block_file.exists():
            _map['blocks'] = list(_block_file.read_bytes())

# A passable destination is necessary but not sufficient: Cavern walls
# include individually passable tile 0x05 whose boundary with floor 0x20
# is forbidden. Read the game's canonical land pair table, not a second
# hand-maintained whitelist (MtMoon1F (10,22)->(9,22) exposed this).
_collision_source = (ROOT / "crates/pokered-data/src/collision.rs").read_text()
_land_pairs = _collision_source.split("pub const TILE_PAIR_COLLISIONS_LAND:", 1)[1].split("];", 1)[0]
LAND_PAIRS = {(int(ts), frozenset((int(a, 16), int(b, 16))))
              for ts, a, b in re.findall(
                  r"tileset:\s*(\d+),\s*tile1:\s*(0x[0-9A-Fa-f]+),\s*tile2:\s*(0x[0-9A-Fa-f]+)",
                  _land_pairs)}
assert LAND_PAIRS, "could not read canonical land collision pairs"
LEDGES = {(d.lower(), int(a, 16), int(b, 16)) for d, a, b in re.findall(
    r"direction: SPRITE_FACING_(\w+),\s*standing_tile:\s*(0x[0-9A-Fa-f]+),\s*ledge_tile:\s*(0x[0-9A-Fa-f]+)",
    _collision_source)}

DELTA = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}

SPINNERS = {}
_spin_source = (ROOT / "crates/pokered-core/src/overworld/spinner_paths.rs").read_text()
for _map, _body in re.findall(r'"(\w+)" => &\[(.*?)\n\s*\],', _spin_source, re.S):
    for _x, _y, _steps in re.findall(r"\((\d+), (\d+), &\[(.*?)\]\)", _body):
        _end_x, _end_y = int(_x), int(_y)
        _count = 0
        for _direction, _length in re.findall(r"dir: Direction::(\w+), steps: (\d+)", _steps):
            _dx, _dy = DELTA[_direction.lower()]
            _end_x += _dx * int(_length)
            _end_y += _dy * int(_length)
            _count += int(_length)
        SPINNERS.setdefault(_map, {})[(int(_x), int(_y))] = ((_end_x, _end_y), _count)


def tile_at(map_name, x, y):
    """Sample the blockset tile id at tile coordinates (blockset_data
    half-block sampling, mirrors pokered-core collision.rs)."""
    m = MAPS[map_name]
    if not (0 <= x < m["width"] * 2 and 0 <= y < m["height"] * 2):
        return None
    index = (y // 2) * m["width"] + (x // 2)
    if index >= len(m["blocks"]):
        return None  # Engine get_block_at returns None for a short map.
    block = m["blocks"][index]
    tiles = BLOCKSETS[m["tileset_id"]][block]
    return tiles[((y % 2) * 2 + 1) * 4 + (x % 2) * 2]


def walkable(map_name, x, y):
    """Tile-resolution passability: blockset tile whitelist (see
    pokered-data/src/collision.rs — anything not whitelisted blocks)."""
    m = MAPS[map_name]
    if not (0 <= x < m["width"] * 2 and 0 <= y < m["height"] * 2):
        return False
    return tile_at(map_name, x, y) in m["passable_tiles"]


def walkable_edge(map_name, start, end):
    return (walkable(map_name, *end)
            and (MAPS[map_name]["tileset_id"],
                 frozenset((tile_at(map_name, *start), tile_at(map_name, *end))))
            not in LAND_PAIRS)


# data/tilesets/tileset_headers.asm grass tiles per tileset name.
GRASS_TILES = {"Overworld": 0x52}

# special_terrain::is_outside_map (engine): only these tilesets flip last_map.
OUTSIDE_MAP_TILESETS = ("overworld", "plateau")


def is_grass(map_name, x, y):
    t = tile_at(map_name, x, y)
    return t is not None and t == GRASS_TILES.get(MAPS[map_name]["tileset_name"])


def find_grass(map_name, x0, y0, radius=12):
    """Nearest wild-encounter grass tile to (x0, y0)."""
    best = None
    for r in range(radius):
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if max(abs(dx), abs(dy)) != r:
                    continue
                x, y = x0 + dx, y0 + dy
                if is_grass(map_name, x, y):
                    return x, y
    return best


def warp_tiles(map_name):
    """All warp tiles on a map — stepping onto any of them warps, so
    pathfinding treats them as walls unless explicitly targeted."""
    return {(w["x"], w["y"]) for w in MAPS[map_name]["warps"]}


def grass_tiles(map_name):
    return {(x, y)
            for y in range(MAPS[map_name]["height"] * 2)
            for x in range(MAPS[map_name]["width"] * 2)
            if is_grass(map_name, x, y)}


def bfs(map_name, start, goal, blocked=frozenset(), allow_spinners=False):
    """BFS over one map; `blocked` is a set of (x, y) tiles NPCs occupy.
    Returns [(tile, direction-of-arrival), …] from start to goal."""
    if start == goal:
        return [(start, None)]
    q = deque([start])
    prev = {start: None}  # node -> ((from_tile, direction taken))
    while q:
        cx, cy = q.popleft()
        for d, (dx, dy) in DELTA.items():
            n = (cx + dx, cy + dy)
            if n in prev or n in blocked or not walkable_edge(map_name, (cx, cy), n):
                continue
            how = d
            if allow_spinners and n in SPINNERS.get(map_name, {}):
                n, count = SPINNERS[map_name][n]
                if n in prev or n in blocked:
                    continue
                how = f"spin_{d}_{count}"
            prev[n] = ((cx, cy), how)
            if n == goal:
                out = []
                c = n
                while prev[c] is not None:
                    p, dd = prev[c]
                    out.append((c, dd))
                    c = p
                return [(start, None)] + out[::-1]
            q.append(n)
    return None


_CONN_DIR = {"up": "north", "down": "south", "left": "west", "right": "east"}
SCRIPTED_LAST_MAP = dict(re.findall(
    r"MapId::(\w+) => Some\(MapId::(\w+)\)",
    (ROOT / "crates/pokered-core/src/overworld/map_loading.rs").read_text()
    .split("pub fn get_map_dimensions", 1)[0]))


def warp_edges_from(map_name, x, y, last_map=None):
    """Static warp edges for stepping onto tile (x, y) on map_name.

    Explicit-dest warps (dest_map set) resolve directly. Exit-mat warps
    (dest_map null) fire dynamically: in-game they warp to the map the
    player entered from (last_map — engine semantics: updated only when
    arriving at an outside tileset, see special_terrain
    is_outside_map). With faithful driving-side tracking there is
    exactly ONE candidate; parents are only a fallback before the first
    real transition."""
    out = []
    last_map = SCRIPTED_LAST_MAP.get(map_name, last_map)
    for w in MAPS[map_name]["warps"]:
        if w["x"] != x or w["y"] != y:
            continue
        if w.get("dest_map_name"):
            destination = MAPS.get(w["dest_map_name"])
            # Some static exits are placeholders replaced by runtime menus.
            # Match resolve_warp_destination: an absent landing is no edge.
            if destination and 0 <= w["dest_warp_id"] < len(destination["warps"]):
                d = destination["warps"][w["dest_warp_id"]]
                out.append((w["dest_map_name"], d["x"], d["y"]))
        else:
            candidates = ([last_map] if last_map is not None
                          else PARENTS.get(map_name, ()))
            for parent in sorted(candidates):
                pm = MAPS[parent]
                if w["dest_warp_id"] < len(pm["warps"]):
                    d = pm["warps"][w["dest_warp_id"]]
                    out.append((parent, d["x"], d["y"]))
    return out


def _build_parents():
    """building name -> maps that have an entry warp into it."""
    parents = {}
    for m in MAPS.values():
        for w in m["warps"]:
            if w.get("dest_map_name"):
                parents.setdefault(w["dest_map_name"], set()).add(m["name"])
    return parents


PARENTS = _build_parents()

# Stair/cave warp surfaces trigger on entry even for dynamic destinations;
# ordinary exit carpets instead require facing the map edge.
_warp_source = (ROOT / 'crates/pokered-data/src/tileset_data.rs').read_text().split(
    'pub fn is_warp_tile(', 1)[1].split('warp_tiles.contains', 1)[0]
WARP_SURFACES = {}
for _names, _values in re.findall(r'(TilesetId::\w+(?:\s*\|\s*TilesetId::\w+)*)\s*=>\s*&\[([^\]]*)\]', _warp_source):
    for _name in re.findall(r'TilesetId::(\w+)', _names):
        WARP_SURFACES[_name] = {int(v, 16) for v in re.findall(r'0x\w+', _values)}

_extra_source = (ROOT / 'crates/pokered-core/src/overworld/special_terrain.rs').read_text().split(
    'pub fn extra_warp_check_type', 1)[1]
WARP_CHECK_MAPS = {}
for _labels, _kind in re.findall(r'(MapId::\w+(?:\s*\|\s*MapId::\w+)*)\s*=>\s*ExtraWarpCheckType::(\w+)', _extra_source):
    for _name in re.findall(r'MapId::(\w+)', _labels):
        WARP_CHECK_MAPS[_name] = _kind
WARP_FRONT_TILESETS = {name.replace('_', '').lower() for name in re.findall(
    r'"(\w+)"', _extra_source.split('_ => match tileset.name()', 1)[1].split('ExtraWarpCheckType::WarpTileInFront', 1)[0])}
_carpet_source = (ROOT / 'crates/pokered-data/src/tileset_data.rs').read_text().split(
    'pub fn is_warp_carpet_tile_in_front', 1)[1].split('tiles.contains', 1)[0]
WARP_CARPETS = {('down', 'up', 'left', 'right')[int(i)]:
                {int(v, 16) for v in re.findall(r'0x\w+', values)}
                for i, values in re.findall(r'(\d)\s*=>\s*&\[([^\]]*)\]', _carpet_source)}
MAP_BORDERS = {p.parent.name: json.loads(p.read_text())['header']['borderBlock']
               for p in (ROOT / 'crates/pokered-data/maps').glob('*/map.json')}

# Buildings the driver refuses to route through. The school house's mats
# are pair-collision/warp-tile mixups in the engine's warp semantics —
# entering it from the city is fine, but the exit's last_map resolution
# contradicts a static model, and the resulting plan-vs-engine mismatch
# creates an infinite city↔schoolhouse travel loop. Gameplay is
# unaffected; the driver simply treats it as a dead zone.
# The school house and the pokecenters are also excluded: the model's
# exit-mat edge (resolved via last_map) disagrees with the engine's
# runtime resolution often enough that the shortcut plan diverges and
# loops. Explicit nav_warp still enters them; cross-planning just never
# routes through.
NO_THROUGH = {"ViridianSchoolHouse", "ViridianPokecenter",
              "PewterPokecenter", "ViridianMart"}
# Elevator exits depend on the runtime entry floor or panel selection. Their
# static 1F destinations must not act as automatic cross-floor shortcuts.
ELEVATOR_MAPS = set(re.findall(
    r'MapId::(\w+) => Some\(ElevatorId::',
    (ROOT / 'crates/pokered-data/src/elevator_data.rs').read_text()))
NO_THROUGH.update(ELEVATOR_MAPS)


def warps_at(map_name, x, y):
    return [w for w in MAPS[map_name]["warps"] if w["x"] == x and w["y"] == y]


def outward_dir(map_name, x, y, d):
    """True when walking direction `d` from (x, y) faces off the map edge
    — the engine's extra_warp_check (FacingEdge) for bottom/top/left/right
    exit mats: they only fire when the player steps toward the edge."""
    m = MAPS[map_name]
    dx, dy = DELTA[d]
    return ((dy < 0 and y == 0) or (dy > 0 and y == m["height"] * 2 - 1)
            or (dx < 0 and x == 0) or (dx > 0 and x == m["width"] * 2 - 1))


def warp_triggers(map_name, x, y, direction):
    """Engine warp surfaces and directional carpet checks, independent of destination."""
    m = MAPS[map_name]
    if tile_at(map_name, x, y) in WARP_SURFACES.get(m['tileset_name'], set()):
        return True
    kind = WARP_CHECK_MAPS.get(map_name, 'WarpTileInFront' if
                              m['tileset_name'].replace('_', '').lower() in WARP_FRONT_TILESETS else 'FacingEdge')
    if kind == 'FacingEdge':
        return outward_dir(map_name, x, y, direction)
    dx, dy = DELTA[direction]
    tx, ty = x+dx, y+dy
    front = tile_at(map_name, tx, ty)
    if front is None and outward_dir(map_name, x, y, direction):
        block = BLOCKSETS[m['tileset_id']][MAP_BORDERS[map_name]]
        front = block[((ty % 2)*2+1)*4+(tx % 2)*2]
    if map_name == 'SSAnneBow':
        return front == 0x15  # Canonical collision-provider special case.
    return front in WARP_CARPETS[direction]


def cross_step(map_name, x, y, d):
    """One tile step, geometry only: the landed tile (may be a warp tile
    — taking the warp is modeled by bfs_cross expanding warp_edges_from
    for it). Mirrors dotzuki map_transitions for connection crossings:
    arrival coords shift by -2*offset (blocks)."""
    dx, dy = DELTA[d]
    nx, ny = x + dx, y + dy
    m = MAPS[map_name]
    w2, h2 = m["width"] * 2, m["height"] * 2
    if 0 <= nx < w2 and 0 <= ny < h2:
        if not walkable_edge(map_name, (x, y), (nx, ny)):
            return None
        return (map_name, nx, ny)
    # A real observation can lie just outside the map during an interrupted
    # border step. Connection transitions require starting on the last
    # in-bounds tile; first walk back inside instead of pushing farther out.
    if not (0 <= x < w2 and 0 <= y < h2):
        return None
    conn = CONNS[map_name].get(_CONN_DIR[d])
    if conn is None:
        return None
    tgt, off = conn["targetMap"], conn["offset"] * 2
    tm = MAPS[tgt]
    if d == "up":
        tn = (max(x - off, 0), tm["height"] * 2 - 1)
    elif d == "down":
        tn = (max(x - off, 0), 0)
    elif d == "left":
        tn = (tm["width"] * 2 - 1, max(y - off, 0))
    else:
        tn = (0, max(y - off, 0))
    return (tgt, *tn) if walkable(tgt, *tn) else None


def ledge_step(map_name, x, y, d):
    if MAPS[map_name]["tileset_name"].lower() != "overworld":
        return None
    dx, dy = DELTA[d]
    if (d, tile_at(map_name, x, y), tile_at(map_name, x + dx, y + dy)) in LEDGES:
        target = (x + 2 * dx, y + 2 * dy)
        if walkable(map_name, *target):
            return (map_name, *target)
    return None


def _path_of(prev, start, goal):
    out = []
    c = goal
    while prev[c] is not None:
        par, d = prev[c]
        out.append((c, d))
        c = par
    return [start] + out[::-1]


def bfs_cross(map_name, start, goal_map, goal, blocked_maps=None,
              last_map=None, allow_ledges=False, excluded_maps=(), allow_spinners=False,
              goal_nodes=None):
    """BFS whose steps are plain directions. Stepping onto a warp tile
    takes the warp: the expansion replaces the landed tile with its warp
    destinations (doors fire immediately; bottom-edge exit mats fire via
    the extra edge-check). Exit mats resolve against `last_map` — the
    driver tracks it from real transitions, so the plan matches what the
    engine will actually do. Search nodes include the remembered outside
    map; returned path nodes retain the public (map, x, y) shape."""
    blocked_maps = blocked_maps or {}
    s = (map_name, *start)
    t = (goal_map, *goal)
    targets = set(goal_nodes) if goal_nodes is not None else {t}
    target_maps = {node[0] for node in targets}
    if not targets:
        return None
    if s in targets:
        return [s]
    if MAPS[map_name]["tileset_name"].lower() in OUTSIDE_MAP_TILESETS:
        last_map = map_name
    root = (*s, last_map)
    q = deque([root])
    prev = {root: None}
    while q:
        current = q.popleft()
        cm, cx, cy, remembered = current
        for d in DELTA:
            how = d
            landed = cross_step(cm, cx, cy, d)
            if landed is None and allow_ledges:
                landed = ledge_step(cm, cx, cy, d)
                how = "jump_" + d
            if landed is None:
                continue
            if allow_spinners and landed[0] == cm and landed[1:] in SPINNERS.get(cm, {}):
                endpoint, count = SPINNERS[cm][landed[1:]]
                landed = (cm, *endpoint)
                how = f"spin_{d}_{count}"
            key = (landed[1], landed[2])
            if key in blocked_maps.get(landed[0], ()):
                continue
            if key in warp_tiles(landed[0]):
                mats = warps_at(*landed)
                # Exit mats (no dest_map) fire only when stepping TOWARD
                # the map edge — sideways steps onto them are plain tiles,
                # otherwise plans ping-pong on the mat (school house bug).
                if not warp_triggers(*landed, d):
                    cands = [landed]
                else:
                    cands = [n for n in warp_edges_from(*landed, remembered)
                             if n != (cm, cx, cy)
                             and (n[0] not in NO_THROUGH or n[0] in target_maps)]
            else:
                cands = [landed]
            for n in cands:
                if n[0] in excluded_maps:
                    continue
                outside = (n[0] if MAPS[n[0]]["tileset_name"].lower()
                           in OUTSIDE_MAP_TILESETS else remembered)
                node = (*n, outside)
                if node in prev:
                    continue
                if (n[1], n[2]) in blocked_maps.get(n[0], ()):
                    continue
                prev[node] = (current, how)
                if n in targets:
                    out = []
                    cur = node
                    while prev[cur] is not None:
                        parent, step = prev[cur]
                        out.append((cur[:3], step))
                        cur = parent
                    return [s] + out[::-1]
                q.append(node)
    return None


class NavError(RuntimeError):
    pass


# Inner PrintText effects can wait for A after their legacy dialogue object
# has been retired. Observe the active effect rather than retained window text.
FIELD_TEXT_EFFECTS = frozenset({
    "PrintFieldText", "PrintFieldParagraph", "PrintItemFieldText",
    "WaitFieldPrompt", "WaitFieldButton", "FinishFieldText",
})


def has_active_dialogue(state):
    return (state.get("dialogue_state") is not None
            or state.get("active_script_effect") in FIELD_TEXT_EFFECTS)


class Game:
    def __init__(self, port=None, save_path=None, record_dir=None,
                 record_video=None, snapshot=None, binary=None, seed=None,
                 speed=None):
        self.binary = Path(binary) if binary else BIN
        self.seed, self.speed = seed, speed
        self.run_dir = Path(tempfile.mkdtemp(prefix="pokered-run-"))
        self.log = open(self.run_dir / "game.log", "w")
        # Persistent save ONLY for --resume (Game(..., save_path=...));
        # a plain run must boot clean or the main menu offers CONTINUE.
        self.persistent = save_path is not None
        if save_path is None:
            save_path = self.run_dir / "play.sav"
        self.save_path = save_path
        # Port collisions with unrelated listening daemons (e.g. a proxy
        # bound to a wide range) silently answer TCP and then drop the
        # connection — which the driver reads as a game crash. Probe for
        # a free port instead of trusting a hardcoded number.
        if port is None:
            s = socket.socket()
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
            s.close()
        cmd = [str(self.binary), "run", "--headless", "--debug-port", str(port),
               "--no-audio", "--save", str(save_path)]
        if seed is not None:
            cmd += ["--seed", str(seed)]
        if speed is not None:
            cmd += ["--speed", str(speed)]
        if snapshot is not None:
            # Load path priority: --snapshot beats --save (see
            # Game::new_with_options); the save file remains the write
            # target once the game saves in-session.
            cmd += ["--snapshot", str(snapshot)]
        if record_dir is not None:
            Path(record_dir).mkdir(parents=True, exist_ok=True)
            cmd += ["--record-frames", str(record_dir)]
        if record_video is not None:
            cmd += ["--record-video", str(record_video)]
        self.proc = subprocess.Popen(
            cmd, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=self.log)
        # A connect failure must not orphan the just-spawned game: the
        # first crash of this driver leaked a headless instance that kept
        # port 9020 busy and hijacked every later run's connection.
        try:
            self.d = DebugClient(port)
        except BaseException:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
            self.log.close()
            shutil.rmtree(self.run_dir, ignore_errors=True)
            raise
        self.frame0 = None
        # Engine default at new game (screen.rs OverworldScreen::new).
        self.last_map = "PalletTown"
        self.observed_npcs = {}

    def checkpoint(self, mid):
        """Persist SaveData and record the completed milestone id. Only
        meaningful for resume runs; fresh runs keep throwaway saves."""
        assert self.persistent, "checkpoint outside a --resume run"
        r = self.d.cmd(cmd="save")
        assert r["ok"], r
        (ROOT / "scripts" / ".playthrough.marker").write_text(mid)

    def marker_at_least(self, mid):
        """True when the completed-milestone marker is >= `mid`."""
        m = (ROOT / "scripts" / ".playthrough.marker")
        if not m.exists():
            return False
        return self.milestone_index(m.read_text().strip()) >= \
            self.milestone_index(mid)

    @staticmethod
    def milestone_index(mid):
        for i, (m, _, _) in enumerate(MILESTONES):
            if m == mid:
                return i
        return -1

    def track_last_map(self, current_map):
        """Engine-faithful last_map tracking (screen.rs' PendingWarp
        save_last_map): updated only when the player arrives at a map
        with an outside tileset ("overworld" / "plateau" — see
        special_terrain::is_outside_map). Interior maps leave it as is,
        which is what makes the forest gate corridor work: last_map
        stays Route2 through SouthGate → Forest → NorthGate."""
        # map_data.json uses title case ("Overworld"), unlike the engine
        # trait name ("overworld"). Also initialize from a resumed outside
        # map even when this is the first observation in the process.
        if MAPS[current_map]["tileset_name"].lower() in OUTSIDE_MAP_TILESETS:
            self.last_map = current_map
        self._prev_map = current_map

    # ── protocol helpers ────────────────────────────────────────────────
    def st(self):
        s = self.d.cmd(cmd="get_state")["data"]
        if s.get("screen") == "overworld" and s.get("map_blocks") is not None:
            # CUT, switches and boulders change collision geometry live.
            # Every driver must use observed geometry. Battle observations
            # report a placeholder map, so never update a map cache from them.
            MAPS[s["map_name"]]["blocks"] = s["map_blocks"]
            self.track_last_map(s["map_name"])
        return s

    def wait(self, condition, max_frames=600, must=True):
        r = self.d.cmd(cmd="wait_until", condition=condition,
                       max_frames=max_frames)
        assert r["ok"], f"wait_until failed: {r}"
        if must:
            assert r["data"]["reached"], (
                f"condition '{condition}' not reached in {max_frames} frames")
        return r["data"]

    def tap(self, btn, gap=TAP_GAP):
        """One fresh press, then release; field Joypad is sampled every two
        hardware frames. UI/dialogue edges still use one held frame."""
        state = self.st()
        field = (state["screen"] == "overworld"
                 and state.get("dialogue_state") is None
                 and state.get("choice") is None
                 and state.get("active_script_effect") is None)
        held = 2 if field else 1
        self.d.drive([btn] * held, frames=held + gap)

    def skip(self):
        r = self.d.cmd(cmd="skip_dialogue")
        assert r["ok"], r
        return r["data"]

    def step(self, n):
        if getattr(self, 'smart_moves', False):
            state = self.st()
            if (state.get('map_name') == 'Route17' and state.get('screen') == 'overworld'
                    and not any(state.get(k) for k in ('dialogue_state', 'field_menu', 'choice', 'script_running'))):
                return self.d.drive(['b'] * n, frames=n)
        return self.d.step(n)

    # ── observation ─────────────────────────────────────────────────────
    def pos(self):
        s = self.st()
        return s["map_name"], s["player_x"], s["player_y"]

    def navigation_snapshot_changed(self, state):
        """Recheck a failed plan before treating it as a navigation error.

        The headless game keeps advancing while the driver computes a path.
        Trainer sight can therefore replace an overworld snapshot with a
        dialogue or battle before BFS reports that the old position is
        unreachable. Let the outer navigation loop handle that interruption
        instead of turning a stale observation into a false path failure.
        """
        current = self.st()
        keys = ("screen", "map_name", "player_x", "player_y",
                "dialogue_state")
        return any(current.get(key) != state.get(key) for key in keys)

    def destination_blocked_by_live_npc(self, current_map, target_map, x, y):
        """Whether a moving NPC temporarily occupies the requested tile."""
        return current_map == target_map and (x, y) in self.live_npcs(current_map)

    def live_npcs(self, map_name):
        data = self.d.cmd(cmd="get_npcs")["data"]
        npcs = data.get("npcs", data) if isinstance(data, dict) else data
        self.remember_npcs(map_name, npcs)
        live = {(n["x"], n["y"]) for n in npcs
                if n.get("visible", True) and (n["x"], n["y"]) != (-1, -1)}
        # Remember every observed NPC tile: wandering NPCs patrol a
        # small band, and plans that thread it pinch indefinitely at
        # drive time. Learned bands are avoided by PREFERRED routes.
        self.observed_npcs.setdefault(map_name, set()).update(live)
        return live

    def remember_npcs(self, map_name, npcs):
        """Planner hook for observations whose lifetime exceeds one map visit."""
        pass

    def npc_blocked(self, map_name):
        return self.live_npcs(map_name) | self.observed_npcs.get(map_name, set())

    def evidence(self, tag):
        s = self.st()
        print(f"[{tag}] frame={s['frame_count']} screen={s['screen']} "
              f"map={s['map_name']} pos=({s['player_x']},{s['player_y']}) "
              f"party={s['party_count']} money={s['money']} "
              f"effect={s['active_script_effect']}")
        return s

    # ── movement ────────────────────────────────────────────────────────
    def nav_to(self, x, y, map_name=None, tries=80):
        """Closed-loop BFS walk: re-localize after each straight segment so
        drift, ledges and NPC shuffles self-correct. Wild battles on the
        way (grass routes) are run from and the walk resumes."""
        for _ in range(tries):
            # ONE state snapshot for both the battle check and the map
            # check: the engine keeps simulating between our commands, and
            # two back-to-back polls can straddle a battle transition —
            # get_state on a battle screen reports the battle's default
            # map (PalletTown), which the map check then misreads as
            # "warped out" (observed in Viridian Forest trainer LOS).
            s = self.st()
            # A caller owns scripted events at the requested destination
            # (notably m06's rival challenge); don't consume that battle here.
            if (s["screen"] == "overworld" and (map_name is None or s["map_name"] == map_name)
                    and (s["player_x"], s["player_y"]) == (x, y)):
                return
            # Sighted trainers now speak before opening the battle screen.
            # A direction-only navigator would keep walking into that dialogue
            # forever. Use the existing dialogue driver; choices still fail.
            if s["screen"] == "overworld" and s.get("dialogue_state") is not None:
                if not self.cutscene():
                    raise NavError("navigation dialogue did not finish")
                s = self.st()
            if s["screen"] == "battle":
                prefer = ("fight" if s["script_awaiting_battle"]
                          else "run")
                self.battle_loop(prefer=prefer)
                self.cutscene()
                s = self.st()
            cm, cx, cy = s["map_name"], s["player_x"], s["player_y"]
            if map_name is not None and cm != map_name:
                raise NavError(f"warped out of {map_name} -> {cm}")
            if (cx, cy) == (x, y):
                return
            blocked = self.npc_blocked(cm) | (warp_tiles(cm) - {(x, y)})
            path = bfs(cm, (cx, cy), (x, y), blocked=blocked,
                       allow_spinners=getattr(self, "smart_moves", False))
            if not path:
                # Learned NPC bands must never seal a map: retry with
                # live positions only.
                path = bfs(cm, (cx, cy), (x, y),
                           blocked=self.live_npcs(cm)
                           | (warp_tiles(cm) - {(x, y)}),
                           allow_spinners=getattr(self, "smart_moves", False))
            if not path:
                if self.navigation_snapshot_changed(s):
                    continue
                if self.destination_blocked_by_live_npc(cm, map_name, x, y):
                    self.step(200)
                    continue
                raise NavError(f"no path in {cm}: ({cx},{cy})->({x},{y})")
            dirs = [d for _, d in path[1:]]
            i = 0
            import os as _os2
            while i < len(dirs):
                if dirs[i].startswith("spin_"):
                    _, direction, count = dirs[i].split("_")
                    self.d.drive([direction] * FRAMES_PER_TILE,
                                 frames=(int(count) + 1) * FRAMES_PER_TILE + 32)
                    break  # Observe the scripted slide's actual endpoint.
                j = i
                # Re-observe at least every three tiles. Long held runs can
                # outlive a wild-battle handoff or collision pause and drift
                # onto a different ladder/door before the next state poll.
                while (j + 1 < len(dirs) and dirs[j + 1] == dirs[i]
                       and j + 1 - i < 3):
                    j += 1
                tiles = j - i + 1
                if _os2.environ.get("PT_DEBUG"):
                    print(f"   [nto] {cm}({cx},{cy}) {dirs[i]}x{tiles} "
                          f"[-> {x},{y}]", flush=True)
                px0, py0 = self.pos()[1:]
                held = tiles * movement_frames(s, dirs[i])
                self.d.drive(movement_buttons(s, dirs[i], held, held+4), frames=held + 4)
                i = j + 1
                s2 = self.st()
                if (s2["map_name"] != cm or s2["screen"] == "battle"
                        or s2.get("dialogue_state") is not None
                        or s2.get('player_transport') != s.get('player_transport')):
                    break
                actual = (s2["player_x"], s2["player_y"])
                if actual != path[j + 1][0]:
                    if actual == (px0, py0):
                        print(f"   [ntoPINCH] at {cm}({px0},{py0})", flush=True)
                        self.step(60)
                    # Collision/turn timing can leave us short of the planned
                    # endpoint. Never send the remaining turns from that stale
                    # path: they can now point into a different ladder/door.
                    break
            self.step(8)
        raise NavError(f"nav_to({x},{y}) did not converge")

    def face(self, direction):
        """Cross one field Joypad sample, then verify the requested facing."""
        state = self.st()
        if state["player_facing"].lower() == direction:
            return
        self.d.drive([direction] * 2, frames=2 + 12)
        state = self.st()
        if state["player_facing"].lower() != direction:
            # A trainer can promote its dialogue/battle during the turn.
            # approach_object observes and drains this interruption before
            # checking the interaction's facing and story completion again.
            if (state["screen"] != "overworld"
                    or state.get("dialogue_state") is not None
                    or state.get("choice") is not None
                    or state.get("active_script_effect") is not None):
                return
            raise NavError(f"face({direction}) failed: {state['player_facing']}")

    def approach_object(self, x, y, map_name):
        """Face an object from a reachable adjacent tile (trainers may
        occupy one side after walking up to challenge the player)."""
        for _ in range(4):
            state = self.st()
            if state["screen"] == "battle":
                self.battle_loop(prefer="fight" if state["script_awaiting_battle"] else "run")
                self.cutscene()
            elif state.get("dialogue_state") is not None:
                self.cutscene()
            cm, cx, cy = self.pos()
            if cm != map_name:
                raise NavError(f"object approach left {map_name} -> {cm}")
            live = self.live_npcs(cm)
            was_live_npc = (x, y) in live
            blocked = live | warp_tiles(cm) | {(x, y)}
            candidates = []
            for direction, (dx, dy) in DELTA.items():
                target = (x - dx, y - dy)
                if target in blocked:
                    continue
                path = bfs(cm, (cx, cy), target, blocked,
                           allow_spinners=getattr(self, "smart_moves", False))
                if path:
                    candidates.append((len(path), target, direction))
            if not candidates:
                raise NavError(f"no approach to {cm} object ({x},{y})")
            _, target, direction = min(candidates)
            try:
                self.nav_to(*target, cm)
            except NavError:
                continue
            self.face(direction)
            # Facing can itself start a wild encounter or trainer dialogue.
            # Return only while the requested interaction is still reachable.
            state = self.st()
            if (state["screen"] == "overworld" and state["map_name"] == map_name
                    and was_live_npc and (x, y) not in self.live_npcs(map_name)):
                # An on-step battle may move/hide the NPC. The caller verifies
                # its completion flag or re-observes the NPC's actual position.
                return
            if (state["screen"] == "overworld" and state["map_name"] == map_name
                    and (state["player_x"], state["player_y"]) == target
                    and state["player_facing"].lower() == direction
                    and state.get("dialogue_state") is None):
                return
        raise NavError(f"object approach did not settle: {map_name} ({x},{y})")

    def navigation_excluded_maps(self):
        if getattr(self, "smart_moves", False):
            flags = self.d.cmd(cmd="get_flags")["data"]
            if not flags.get("EVENT_GAVE_SAFFRON_GUARDS_DRINK"):
                bag = self.d.cmd(cmd="get_bag")["data"]
                if not any(item['item'] in ('FreshWater', 'SodaPop', 'Lemonade')
                           and item.get('qty', 0) > 0 for item in bag):
                    return ("SaffronCity",)
        return ()

    def navigation_barriers(self):
        """Observed script barriers supplied by a planner, keyed by map."""
        return getattr(self, 'script_navigation_barriers', {})

    def nav_to_map(self, x, y, map_name, tries=150, avoid_grass=True):
        """Cross-map closed-loop walk (connections included). Prefers a
        route that avoids wild-encounter grass when one exists (wilds
        interrupt the walk — sometimes fatally at low HP); falls back
        to any walkable path. Wild encounters that still happen are run
        from (or fought for trainers) and the walk re-localizes."""
        self.last_pinch = None
        self.pinch_count = 0
        excluded_maps = self.navigation_excluded_maps()
        for attempt in range(tries):
            # Single snapshot for battle + position, same race as nav_to.
            s = self.st()
            if (s["screen"] == "overworld" and s["map_name"] == map_name
                    and (s["player_x"], s["player_y"]) == (x, y)):
                return
            # Sighted trainers now speak before opening the battle screen.
            # A direction-only navigator would keep walking into that dialogue
            # forever. Use the existing dialogue driver; choices still fail.
            if s["screen"] == "overworld" and s.get("dialogue_state") is not None:
                if not self.cutscene():
                    raise NavError("navigation dialogue did not finish")
                s = self.st()
            if s["screen"] == "battle":
                prefer = ("fight" if s["script_awaiting_battle"]
                          else "run")
                self.battle_loop(prefer=prefer)
                self.cutscene()
                s = self.st()
            cm, cx, cy = s["map_name"], s["player_x"], s["player_y"]
            self.track_last_map(cm)
            import os
            if os.environ.get("PT_DEBUG") and attempt % 10 == 0:
                print(f"   [nav {map_name}({x},{y}) try={attempt} "
                      f"at {cm}({cx},{cy}) last={self.last_map}]", flush=True)
            if cm == map_name and (cx, cy) == (x, y):
                return
            blocked = {cm: self.npc_blocked(cm)}
            barriers = self.navigation_barriers()
            path = None
            if avoid_grass:
                path = bfs_cross(cm, (cx, cy), map_name, (x, y),
                                 blocked_maps={
                                     **barriers,
                                     cm: blocked[cm] | grass_tiles(cm) | barriers.get(cm, set())},
                                 last_map=self.last_map,
                                 allow_ledges=getattr(self, "smart_moves", False),
                                 allow_spinners=getattr(self, "smart_moves", False),
                                 excluded_maps=excluded_maps)
                if path:
                    departed = False
                    for node, _ in path[1:]:
                        if node[0] != cm:
                            departed = True
                        elif departed:
                            # Grass avoidance applies to the current map.
                            # Leaving and re-entering it can therefore reverse
                            # the preferred route on the next observation,
                            # causing an endless cave/road oscillation. Let
                            # the ordinary collision-aware search decide such
                            # routes without the local grass preference.
                            path = None
                            break
            if path is None:
                # Fallback: live NPC positions only — the learned bands
                # must never seal off a whole map (they patrol wide).
                path = bfs_cross(cm, (cx, cy), map_name, (x, y),
                                 blocked_maps={**barriers, cm: self.live_npcs(cm) | barriers.get(cm, set())},
                                 last_map=self.last_map,
                                 allow_ledges=getattr(self, "smart_moves", False),
                                 allow_spinners=getattr(self, "smart_moves", False),
                                 excluded_maps=excluded_maps)
            if not path:
                if self.navigation_snapshot_changed(s):
                    continue
                if self.destination_blocked_by_live_npc(cm, map_name, x, y):
                    self.step(200)
                    continue
                raise NavError(f"no cross path: {cm}({cx},{cy}) "
                               f"-> {map_name}({x},{y}) "
                               f"blocked={sorted(blocked.get(cm, set()))}")
            import os as _os
            if _os.environ.get("PT_DEBUG") and attempt % 5 == 0:
                plan = []
                cur = None
                for node, how in path[1:10]:
                    m, px, py = node
                    if m != cur:
                        plan.append(f"[{m}]")
                        cur = m
                    plan.append(f"{how or 'START'}({px},{py})")
                print(f"   [navplan] {' '.join(plan)}", flush=True)
            steps = [how for _, how in path[1:]]
            # Block warp tiles of the current map for the walking phase,
            # except tiles the plan deliberately steps onto (sideways mat
            # steps) — otherwise straight drives can drift onto a door and
            # teleport into a building.
            plain_warp = {n[1:3] for n, how in path[1:]
                          if n[0] == cm and how in DELTA
                          and (n[1], n[2]) in warp_tiles(cm)}
            if cm in blocked:
                blocked[cm] |= (warp_tiles(cm) - plain_warp)
            # walk at most 3 tiles per segment, then re-check (a wild
            # battle or an unplanned warp may interrupt; the closed loop
            # re-localizes and re-plans either way)
            i = 0
            while i < len(steps):
                if steps[i].startswith("spin_"):
                    _, direction, count = steps[i].split("_")
                    self.d.drive([direction] * FRAMES_PER_TILE,
                                 frames=(int(count) + 1) * FRAMES_PER_TILE + 32)
                    break  # Observe the forced slide before another input.
                if steps[i].startswith("jump_"):
                    direction = steps[i].removeprefix("jump_")
                    self.d.drive([direction] * 24, frames=40)
                    break  # Two-tile jump: observe the landing and replan.
                j = i
                while (j + 1 < len(steps) and steps[j + 1] == steps[i]
                       and j + 1 - i < 3):
                    j += 1
                tiles = j - i + 1
                held = tiles * movement_frames(s, steps[i])
                # A blanket held tail turns 1-tile segments into 2-tile
                # strides: near doors that over-runs onto the warp tile
                # and re-warps (passing the Pewter PC door westbound did
                # exactly that). Idle-heavy tail instead when any tile of
                # the segment is adjacent to a warp tile.
                # path[0] is the bare start node; the rest are
                # (node, direction) pairs.
                seg_start = path[i] if i == 0 else path[i][0]
                seg_end = path[i + tiles][0]
                near_warp = False
                # n may be a (x, y) or (map, x, y) node depending on the
                # BFS flavour — coordinates are always the last two.
                for n in (seg_start, seg_end):
                    for w in warp_tiles(cm):
                        if abs(w[0] - n[-2]) <= 1 and abs(w[1] - n[-1]) <= 1:
                            near_warp = True
                if near_warp:
                    if seg_end[0] != cm:
                        # Directional carpets check held input on the step's
                        # completion frame. A turn can consume the first frame;
                        # keep a short held tail through the warp handoff.
                        held += 4
                    frames = held + 16          # all-idle tail: drift-safe
                else:
                    # Warp/connection-firing steps need the direction held
                    # at the step-completion frame; pad those only.
                    idx_after = i + tiles
                    if idx_after < len(path) and path[idx_after][0][0] != cm:
                        held += 32
                    frames = held + 8
                px0, py0 = self.pos()[1:]
                if _os.environ.get("PT_DEBUG"):
                    print(f"   [seg] {cm}({px0},{py0}) {steps[i]}x{tiles} "
                          f"held={held}", flush=True)
                self.d.drive(movement_buttons(s, steps[i], held, frames), frames=frames)
                i = j + 1
                s = self.st()
                if (s["screen"] == "battle" or s["map_name"] != cm
                        or s.get("dialogue_state") is not None):
                    break
                if ((s["player_x"], s["player_y"]) != seg_end[1:]
                        and (s["player_x"], s["player_y"]) != (px0, py0)):
                    # Partial progress (NPC/input lock) invalidates every
                    # later direction, even though this segment moved.
                    break
                # Pinch: the segment made no progress (a wandering NPC
                # holds the plan's next tile). Sidestep onto a free
                # perpendicular tile and re-plan — waiting alone does
                # not work when the NPC patrols inside the pinch column.
                if (s["player_x"], s["player_y"]) == (px0, py0):
                    if _os.environ.get("PT_DEBUG"):
                        data = self.d.cmd(cmd="get_npcs")["data"]
                        npcs = data.get("npcs", data) if isinstance(data, dict) else data
                        print("   [pinch] npcs:", [
                            (n.get("text_id"), n["x"], n["y"])
                            for n in npcs if n.get("visible", True)],
                            flush=True)
                        if self.pinch_count >= 3:
                            full = self.st()
                            print("   [pinch!]", {k: full[k] for k in (
                                "screen", "map_name", "player_x",
                                "player_y", "warp_fade", "script_running",
                                "player_movement_state")}, flush=True)
                    if self.last_pinch == (cm, cx, cy):
                        self.pinch_count += 1
                    else:
                        self.last_pinch = (cm, cx, cy)
                        self.pinch_count = 0
                    free = None
                    for d2 in ("left", "right", "up", "down"):
                        dx, dy = DELTA[d2]
                        n = (px0 + dx, py0 + dy)
                        if (walkable(cm, *n) and n not in
                                self.npc_blocked(cm)
                                and n not in warp_tiles(cm)):
                            free = d2
                            break
                    if self.pinch_count >= 3:
                        # Stuck at the same spot: flee along a long open
                        # corridor so the next plan cannot immediately
                        # drag the loop back (e.g. 5 tiles west of the
                        # Viridian fence band opens the south exit).
                        flee = None
                        for d2, (dx, dy) in DELTA.items():
                            ok = True
                            for k in range(1, 6):
                                n = (px0 + dx * k, py0 + dy * k)
                                if not walkable(cm, *n):
                                    ok = False
                                    break
                            if ok:
                                flee = d2
                                break
                        if flee:
                            held = 5 * movement_frames(s, flee)
                            self.d.drive(movement_buttons(s, flee, held, held+8), frames=held+8)
                            self.step(8)
                        else:
                            self.step(200)
                    elif free:
                        held = movement_frames(s, free)
                        self.d.drive(movement_buttons(s, free, held, held+8), frames=held+8)
                        self.step(6)
                    else:
                        # A wandering NPC pauses for hundreds of frames
                        # between steps; a short wait catches it mid-pause.
                        self.step(200)
                    break
            self.step(6)
        raise NavError(f"nav_to_map({map_name},{x},{y}) did not converge")

    def nav_warp(self, x, y, from_map, to_map=None, tries=30,
                 approach="walk"):
        """Walk onto the warp tile at (x, y) and wait for the map change.

        approach="down": bottom-edge exit mats only fire when the player
        faces the map edge with the direction still held (engine mirrors
        the original CheckWarps extra_warp_check), so path to (x, y-1)
        first and walk down through the mat."""
        if approach in DELTA:
            ax, ay = DELTA[approach]
            for _ in range(3):
                try:
                    self.nav_to(x - ax, y - ay, map_name=from_map,
                                tries=tries)
                except NavError:
                    if to_map is not None and self.pos()[0] == to_map:
                        destination = self._wait_for_warp(from_map, to_map)
                        if destination is not None:
                            return destination
                        raise
                    if self.pos()[0] != from_map:
                        raise
                    # One map can contain disconnected rooms. Reach the
                    # inward tile via real stairs/connections before the
                    # final directional step onto the requested warp.
                    self.nav_to_map(x - ax, y - ay, from_map,
                                    tries=tries, avoid_grass=False)
                self.d.drive([approach] * (2 * FRAMES_PER_TILE + 32),
                             frames=2 * FRAMES_PER_TILE + 40)
                destination = self._wait_for_warp(from_map, to_map)
                if destination is not None:
                    return destination
            raise NavError(f"warp at ({x},{y}) never fired ({from_map})")
        else:
            try:
                self.nav_to(x, y, map_name=from_map, tries=tries)
            except NavError:
                # A warp may finish during nav_to's final settlement. That
                # is success only for the explicitly requested destination;
                # never reinterpret a blackout/unexpected map as success.
                current_map = self.pos()[0]
                if to_map is not None and current_map == to_map:
                    destination = self._wait_for_warp(from_map, to_map)
                    if destination is not None:
                        return destination
                    raise
                if current_map != from_map:
                    raise
                # An inward neighbor may be in another disconnected room
                # of this map (Mt Moon B1F). Cross-map BFS follows the real
                # stairs back through the connecting floor when necessary.
                for d, (dx, dy) in DELTA.items():
                    inner = (x - dx, y - dy)
                    if walkable(from_map, *inner):
                        self.nav_to_map(*inner, map_name=from_map,
                                        tries=tries, avoid_grass=False)
                        self.d.drive([d] * 40, frames=48)
                        break
                else:
                    raise
            # Exit carpets may need another outward hold. Stair/cave tiles
            # trigger on the completed step: holding through their fade can
            # retrigger the arrival warp (RedsHouse2F -> 1F -> 2F).
            state = self.st()
            automatic = tile_at(from_map, x, y) in WARP_SURFACES.get(
                MAPS[from_map]['tileset_name'], set())
            if (not automatic and state['screen'] == 'overworld'
                    and state['map_name'] == from_map
                    and state.get('warp_fade') == 'Idle'):
                for d in DELTA:
                    if outward_dir(from_map, x, y, d):
                        self.d.drive([d] * 40, frames=48)
                        break
        destination = self._wait_for_warp(from_map, to_map)
        if destination is not None:
            return destination
        raise NavError(f"warp at ({x},{y}) never fired ({from_map})")

    def _wait_for_warp(self, from_map, to_map):
        """Observe a warp attempt; return None when gameplay interrupted it."""
        for _ in range(40):
            state = self.st()
            cm = state["map_name"]
            if state["screen"] == "battle":
                # An expected destination may start its @load battle before
                # our first poll. Leave that scripted handoff to the caller.
                if to_map is not None and cm == to_map and state.get("script_awaiting_battle"):
                    return cm
                prefer = ("fight" if state["script_awaiting_battle"]
                          else "run")
                self.battle_loop(prefer=prefer)
                self.cutscene()
                return None
            if state.get("dialogue_state") is not None:
                if not self.cutscene():
                    raise NavError("warp approach dialogue did not finish")
                return None
            if cm != from_map:
                if to_map is not None:
                    assert cm == to_map, f"unexpected warp target {cm}"
                # Arrival may kick off an @load cutscene (e.g. the Mart
                # parcel hand-off) — settle it before returning control.
                assert self.cutscene(), f"{cm} on-enter cutscene stalled"
                # Settling can complete another warp or open a battle. Never
                # return a destination observed before that hand-off finished.
                settled = self.st()
                scripted_battle = settled['screen'] == 'battle' and settled.get('script_awaiting_battle')
                if settled['screen'] != 'overworld' and not scripted_battle:
                    return None
                cm = settled['map_name']
                if cm == from_map:
                    return None
                if to_map is not None:
                    assert cm == to_map, f"unexpected settled warp target {cm}"
                return cm
            self.step(10)
        return None

    # ── cutscenes & dialogue ────────────────────────────────────────────
    def cutscene(self, max_rounds=300):
        """Advance a scripted cutscene until control returns — or until the
        script hands off into battle (startBattle suspends the script, so
        control_ready never fires; that's a successful hand-off, not a
        stall). wait_until burns through non-dialogue effects; dialogue
        pages collapse via skip_dialogue. Gift nickname prompts choose NO
        to keep the route's canonical species names. Other open choices
        need a deliberate decision and fail loudly."""
        for _ in range(max_rounds):
            r = self.d.cmd(cmd="wait_until", condition="control_ready",
                           max_frames=240)
            if r["data"]["reached"]:
                return True
            state = r["data"]["state"]
            if state["screen"] == "battle":
                return True
            if state["choice"] is not None:
                if (state.get("active_script_effect") == "GivePokemon"
                        and state["choice"]["options"] == ["YES", "NO"]):
                    self.choose("NO")
                    continue
                raise NavError(f"cutscene blocked on choice "
                               f"{state['choice']['options']} "
                               f"(cursor {state['choice']['selected']})")
            if has_active_dialogue(state):
                self.skip()
        return False

    def dialogue_then_choice(self, timeout_frames=3600):
        """After an interaction A-tap: collapse dialogue pages (and dismiss
        blocking dex-entry screens) until the option menu opens. The dex
        preview needs real A taps — wait_until steps with neutral input,
        so it would sit there forever."""
        for _ in range(timeout_frames // 60):
            s = self.st()
            if s["choice"] is not None:
                return s["choice"]
            if s["active_script_effect"] == "ShowPokedexEntry":
                self.tap("a", 10)
            elif has_active_dialogue(s):
                self.skip()
            else:
                self.step(30)
        raise NavError("expected a choice menu, never opened")

    def choose(self, label):
        """Move the cursor to `label` in the open choice menu, press A.
        Matches case-insensitively (scripts use both YES/NO and Yes/No).
        The menu wraps both ways, so take the shorter arc."""
        ch = self.st()["choice"]
        assert ch is not None, "no choice open"
        opts = ch["options"]
        if label not in opts:
            label = next(o for o in opts if o.lower() == label.lower())
        idx = opts.index(label)
        n = len(ch["options"])
        delta = (idx - ch["selected"]) % n
        if delta:
            down = delta * 2 <= n
            for _ in range(delta if down else n - delta):
                self.d.drive(["down" if down else "up"], frames=12)
            s = self.st()["choice"]
            assert s["selected"] == idx, s
        self.tap("a", 10)

    def talk(self, post="control_ready", budget=600):
        """Interact with whatever we face, then settle the conversation."""
        self.tap("a", 20)
        if post == "choice_open":
            self.wait("choice_open", budget)
        else:
            self.cutscene()

    # ── party / training ────────────────────────────────────────────────
    def leader(self):
        return self.st()["party"][0]

    def heal_pokecenter(self, door, city, pc):
        """Enter the Pokecenter, heal at the nurse (YES), verify full HP,
        walk back out. `door` is the city-side warp tile. The post-exit
        door-pocket escape drives Viridian's south lane; for any other
        city the caller finds the player on the door tile and routes
        from there."""
        dx, dy = door
        self.nav_to_map(dx, dy + 1, city)
        self.nav_warp(dx, dy, city, pc)
        self.nav_to(3, 3, map_name=pc)         # across the counter from
        self.face("up")                        # the nurse (3,1); the
        self.tap("a", 20)                      # counter row is solid
        for _ in range(40):
            s = self.st()
            if s["choice"] is not None:
                self.choose("YES")
                break
            if s["dialogue_state"] is not None:
                self.skip()
            else:
                self.step(20)
        assert self.cutscene(), "heal cutscene never finished"
        s = self.st()
        assert all(m["hp"] == m["max_hp"] for m in s["party"]), s["party"]
        self.nav_warp(3, 7, pc, city, approach="down")
        if city != "ViridianCity":
            return
        # We are standing ON the city door tile. Step EAST with a tail of
        # idle frames only (any held tail would drift back onto the door
        # and re-warp), then let normal navigation take over.
        self.d.drive(["right"] * FRAMES_PER_TILE, frames=24)
        self.step(6)
        # Step out of the door pocket; the city fence band can seal it.
        for _ in range(3):
            try:
                self.nav_to(26, 26, map_name=city)
                break
            except NavError:
                self.nav_warp(3, 7, pc, city, approach="down")
        else:
            self.nav_to(23, 26, map_name=city)

    PREFERRED_MOVES = ["VineWhip", "Ember", "Bubble", "WaterGun",
                       "ThunderShock", "Absorb", "RazorLeaf", "Tackle",
                       "Scratch", "Pound"]

    def _preferred_slot(self, moves):
        """Best usable slot in the LIVE fight menu, by preference order
        (STAB/typed damage first). Menu entries carry live PP — the
        save-data party is a battle-start snapshot, so mid-battle PP
        exists only here."""
        for want in self.PREFERRED_MOVES:
            for i, m in enumerate(moves):
                if m["move"] == want and m["pp"] > 0 and not m["disabled"]:
                    return i
        for i, m in enumerate(moves):
            if m["pp"] > 0 and not m["disabled"]:
                return i
        return None

    def _select_move(self):
        """Closed-loop FIGHT-menu selection: read the live menu (cursor +
        per-slot PP), walk the cursor to the best usable slot, press A.
        Re-reads after every cursor step, so a stale position or a
        rejected slot (No PP) self-corrects. Returns once the menu closes
        (turn executing) or the battle leaves MoveSelect."""
        for _ in range(24):
            s = self.st()
            if s["screen"] != "battle" or s["battle_phase"] != "MoveSelect":
                return
            menu = s.get("battle_moves")
            if not menu:
                self.step(4)
                continue
            moves = menu["moves"]
            want = None
            if getattr(self, "smart_moves", False):
                from playthrough_late import damage_slot
                want = damage_slot(moves, s)
            if want is None:
                want = self._preferred_slot(moves)
            if want is None:
                # No usable slot: the engine refuses to open this menu
                # (forced Struggle), so this is only a defensive exit.
                self.tap("b", 8)
                self.step(10)
                return
            n = len(moves)
            cur = menu["cursor"]
            if cur != want:
                delta = (want - cur) % n
                up = delta * 2 > n    # shorter arc; the menu wraps
                for _ in range(n - delta if up else delta):
                    self.d.drive(["up" if up else "down"], frames=10)
                continue
            self.tap("a", 4)
            self.step(10)

    def leave_grass(self, map_name):
        """BFS out of the grass patch to the nearest solid ground, then
        walk the short path (wandering NPCs and wild fights may occur
        mid-way; the caller's loop re-enters if the map changes)."""
        cm, cx, cy = self.pos()
        if cm != map_name or not is_grass(cm, cx, cy):
            return
        path = bfs(cm, (cx, cy), None) if False else None
        # nearest non-grass via BFS
        from collections import deque as _dq
        q = _dq([(cx, cy)])
        prev = {(cx, cy): None}
        goal = None
        while q:
            x0, y0 = q.popleft()
            for d, (dx, dy) in DELTA.items():
                n = (x0 + dx, y0 + dy)
                if n in prev or not walkable(cm, *n):
                    continue
                prev[n] = ((x0, y0), d)
                if not is_grass(cm, *n):
                    goal = n
                    q.clear()
                    break
                q.append(n)
        if goal is None:
            raise NavError(f"could not leave grass at {cm}({cx},{cy})")
        dirs = []
        cur = goal
        while prev[cur] is not None:
            p0, dd = prev[cur]
            dirs.append(dd)
            cur = p0
        dirs.reverse()
        for d in dirs:
            self.d.drive([d] * FRAMES_PER_TILE, frames=FRAMES_PER_TILE + 8)
        self.step(6)

    def train_until(self, level, map_name, spot, heal, max_cycles=400):
        """Wander over wild-encounter grass near `spot` fighting battles
        until the leader reaches `level`. Heals at `heal` (pokecenter
        door, city, pc) when HP drops below 40%; blackout self-heals and
        the loop re-navigates."""
        import time
        t0 = time.time()
        x, y = find_grass(map_name, *spot) or spot
        battles = 0
        print(f"[train] grass spot {map_name} ({x},{y}), "
              f"target L{level}", flush=True)
        for cyc in range(max_cycles):
            s = self.st()
            if s["screen"] == "battle":
                battles += 1
                self.battle_loop(prefer="fight")
                self.cutscene()
                continue
            mon = s["party"][0]
            if cyc % 25 == 0:
                print(f"[train] cyc={cyc} battles={battles} "
                      f"L{mon['level']} hp={mon['hp']}/{mon['max_hp']} "
                      f"({time.time()-t0:.0f}s)", flush=True)
            if mon["level"] >= level:
                print(f"[train] level {mon['level']} reached "
                      f"({time.time()-t0:.0f}s, {battles} battles)")
                return True
            if mon["hp"] < mon["max_hp"] * 0.6:
                print(f"[train] hp {mon['hp']}/{mon['max_hp']} -> heal",
                      flush=True)
                self.leave_grass(map_name)
                if map_name == "Route1":
                    # Outbound: grass -> Route1 north crossing -> city
                    # south lane -> PC door (proven m08 corridor).
                    self.nav_to(10, 1, map_name="Route1")
                    self.d.drive(["up"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)
                    self.step(8)
                    self.nav_to(23, 26, map_name="ViridianCity")
                elif heal[1] == "ViridianCity":
                    # Outbound staged: grass -> Route2 south edge ->
                    # crossing -> city north lane -> PC door.
                    self.nav_to(8, 70, map_name="Route2")
                    self.d.drive(["down"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)
                    self.step(8)
                    self.nav_to(20, 32, map_name="ViridianCity")
                self.heal_pokecenter(*heal)
                # Return leg staged through the patrol-free city lane
                # (same drift-resistance as m09's gate chain).
                if map_name == "Route1":
                    # Return: city south lane -> crossing -> grass.
                    self.nav_to(20, 32, map_name="ViridianCity")
                    self.nav_to(20, 33, map_name="ViridianCity")
                    self.d.drive(["down"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)
                    self.step(8)
                    self.nav_to(x, y, map_name, tries=120)
                elif heal[1] == "PewterCity":
                    # Return through the forest corridor in reverse — the
                    # only link between Route 2's sections. Staged gates
                    # (mirror of m09) instead of cross-BFS: the engine's
                    # last_map stays Route2 through the whole chain, so
                    # every mat fires deterministically.
                    self.nav_to(18, 34, map_name="PewterCity")
                    self.d.drive(["down"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)   # S connection
                    self.step(8)
                    self.nav_warp(3, 11, "Route2",
                                  "ViridianForestNorthGate",
                                  approach="down")
                    self.nav_to(5, 6, map_name="ViridianForestNorthGate")
                    self.nav_warp(5, 7, "ViridianForestNorthGate",
                                  "ViridianForest", approach="down")
                    self.nav_to(17, 46, map_name="ViridianForest")
                    self.nav_warp(17, 47, "ViridianForest",
                                  "ViridianForestSouthGate")
                    self.nav_to(4, 6, map_name="ViridianForestSouthGate")
                    self.nav_warp(4, 7, "ViridianForestSouthGate",
                                  "Route2", approach="down")
                    self.nav_to(x, y, map_name, tries=120)
                elif heal[1] == "ViridianCity":
                    self.nav_to(20, 32, map_name="ViridianCity")
                    self.nav_to(18, 1, map_name="ViridianCity")
                    self.d.drive(["up"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)   # N connection
                    self.step(8)
                    self.nav_to(x, y, map_name, tries=120)
                else:
                    try:
                        self.nav_to_map(x, y, map_name, tries=450)
                    except NavError:
                        self.step(300)
                        self.nav_to_map(x, y, map_name, tries=450)
                continue
            # wander: a vertical shuttle over the grass; wilds interrupt
            cm, cx, cy = self.pos()
            if cm != map_name:
                # Lost the map (blackout or a battle drift): stage the
                # return from wherever we are, same drift-proof pattern.
                if cm == "PewterCity" and map_name == "Route2":
                    self.nav_to(18, 34, map_name="PewterCity")
                    self.d.drive(["down"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)
                    self.step(8)
                    self.nav_warp(3, 11, "Route2",
                                  "ViridianForestNorthGate",
                                  approach="down")
                    self.nav_to(5, 6, map_name="ViridianForestNorthGate")
                    self.nav_warp(5, 7, "ViridianForestNorthGate",
                                  "ViridianForest", approach="down")
                    self.nav_to(17, 46, map_name="ViridianForest")
                    self.nav_warp(17, 47, "ViridianForest",
                                  "ViridianForestSouthGate")
                    self.nav_to(4, 6, map_name="ViridianForestSouthGate")
                    self.nav_warp(4, 7, "ViridianForestSouthGate",
                                  "Route2", approach="down")
                    self.nav_to(x, y, map_name, tries=120)
                elif cm == "ViridianCity" and map_name == "Route2":
                    self.nav_to(20, 32, map_name="ViridianCity")
                    self.nav_to(18, 1, map_name="ViridianCity")
                    self.d.drive(["up"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)
                    self.step(8)
                    self.nav_to(x, y, map_name, tries=120)
                else:
                    # Blackout at home / elsewhere: generic re-route with
                    # a generous budget (rare path; the closed loop wins
                    # eventually via the staged city legs).
                    try:
                        self.nav_to_map(x, y, map_name, tries=450)
                    except NavError:
                        self.step(300)
                        self.nav_to_map(x, y, map_name, tries=450)
                continue
            dy = 4 if cy <= y else -4
            self.d.drive(["down" if dy > 0 else "up"] * 32, frames=36)
            if self.st()["screen"] != "battle":
                self.d.drive(["up" if dy > 0 else "down"] * 32, frames=36)
        return False

    # ── battle ──────────────────────────────────────────────────────────
    def battle_loop(self, prefer="fight", max_iters=1600):
        """Generic battle driver. prefer="run" picks RUN from the menu
        (wild encounters); falls back to FIGHT if escape keeps failing.
        The 2x2 menu clamps cursor movement, so up+left always lands on
        FIGHT and down+right on RUN regardless of saved cursor state."""
        fight = prefer == "fight"
        iters_in_mode = 0
        import os
        dbg = os.environ.get("PT_DEBUG")
        # Keep a bounded allowance for terminal text after the combat budget.
        # A long fight can reach its final KO on the last iteration; waiting
        # without buttons then leaves ShowingText / TrainerVictory blocked.
        for it in range(max_iters + 120):
            s = self.st()
            if it >= max_iters and s["screen"] == "battle":
                live = s.get("battle_live") or {}
                enemies = live.get("enemy_party") or [live.get("enemy", {})]
                players = live.get("player_party") or [live.get("player", {})]
                defeated = lambda team: bool(team) and all(mon.get("hp") == 0 for mon in team)
                if not (defeated(enemies) or defeated(players)):
                    break
            if dbg:
                print(f"   [battle it={it} fight={fight} mode_iters="
                      f"{iters_in_mode}] phase={s['battle_phase']!r} "
                      f"msg={s['battle_message']!r}", flush=True)
            # LOS trainer battles are not script-suspended, so the
            # caller's wild/run heuristic can't see them — detect the
            # trainer marker in the phase and commit to fighting.
            if not fight and "Trainer" in s["battle_phase"]:
                fight = True
            if s["screen"] != "battle":
                break
            ph = s["battle_phase"]
            if ph.startswith("LearnMove") and getattr(self, "smart_moves", False):
                from playthrough_late import learn_move
                getattr(self, 'learn_move', lambda state: learn_move(self, state))(s)
            elif ph == "PlayerMenu":
                if s["map_name"].startswith("SafariZone"):
                    # Safari's menu has RUN at the same bottom-right corner.
                    self.tap("down", 8)
                    self.tap("right", 8)
                    self.tap("a", 8)
                    continue
                if fight and getattr(self, "smart_moves", False):
                    from playthrough_late import battle_recovery_plan
                    recovery = getattr(self, 'battle_recovery_plan', battle_recovery_plan)(s)
                    if recovery:
                        if recovery[0] == 'switch':
                            self._switch_target = recovery[1]
                            self.tap('up', 8)
                            self.tap('right', 8)
                            self.tap('a', 8)
                            continue
                        self._medicine, self._medicine_target = recovery
                        self.tap("down", 8)
                        self.tap("left", 8)
                        self.tap("a", 8)
                        continue
                    party = s.get("battle_live", {}).get("player_party", [])
                    if any(mon["species"] == "Zapdos" for mon in party):
                        from playthrough_late import battle_party_target
                        target = battle_party_target(s)
                        if party[target]["species"] != s["battle_live"]["player"]["species"]:
                            self.tap("up", 8)
                            self.tap("right", 8)
                            self.tap("a", 8)
                            continue
                if not fight and iters_in_mode > 3:
                    fight = True          # escape keeps failing: brawl
                iters_in_mode += 1
                if fight:
                    self.d.drive(["up", "left"], frames=10)   # -> FIGHT
                    self.tap("a", 4)                          # open FIGHT
                    if not self._await_phase("MoveSelect", 120):
                        continue               # text ate the press; retry
                    self._select_move()
                else:
                    self.d.drive(["down", "right"], frames=10)  # -> RUN
                    self.tap("a", 4)                            # try escape
                self.step(30)
            elif ph == "MoveSelect":
                self._select_move()
                self.step(30)
            elif ph == "BagSelect" and getattr(self, "smart_moves", False):
                menu = s["battle_bag"]
                target = next(i for i, v in enumerate(menu["items"]) if v["item"] == self._medicine)
                self.tap("a" if menu["cursor"] == target else "down", 8)
            elif ph.startswith("ItemTargetSelect") and getattr(self, "smart_moves", False):
                target = self._medicine_target
                self.tap("a" if s["battle_party_cursor"] == target else "down", 8)
            elif ph == "ShiftPrompt":
                self.tap("b" if getattr(self, "smart_moves", False) else "a", 8)
                self.step(30)
            elif ph in {"PartySelect", "PlayerFaintSwitch"} and getattr(self, "smart_moves", False):
                from playthrough_late import battle_party_target
                target = getattr(self, 'battle_party_target', battle_party_target)(s)
                self.tap("a" if s["battle_party_cursor"] == target else "down", 8)
            else:
                # Intro{..}/ShowingText{..}/TrainerVictory{..} pages
                self.tap("a", 10)
        self.wait("not_battle", 1800)

    def _await_phase(self, name, max_frames):
        for _ in range(max_frames // 4):
            s = self.st()
            if s["screen"] != "battle":
                return False
            if s["battle_phase"] == name:
                return True
            self.step(4)
        return False

    def close(self):
        try:
            self.d.close()
        finally:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=5)
            self.log.close()
            shutil.rmtree(self.run_dir, ignore_errors=True)


# ── milestones ──────────────────────────────────────────────────────────
def m01_boot(g):
    """Power-on → main menu → NEW GAME → Oak speech starts."""
    g.wait("screen=language-select", 1800)
    for _ in range(40):                      # A has an accept window; the
        g.tap("a", 30)                       # first press may be swallowed
        r = g.d.cmd(cmd="wait_until", condition="screen=title",
                    max_frames=120)
        if r["data"]["reached"]:
            break
    for _ in range(30):                      # title settles, then A
        g.tap("a", 10)
        if g.st()["screen"] == "main-menu":
            break
    assert g.st()["screen"] == "main-menu"
    for _ in range(20):                      # fresh save → NEW GAME (cursor 0)
        g.tap("a", 20)
        if g.st()["screen"] == "oak":
            break
    g.wait("screen=oak", 600)


def m02_oak_speech(g):
    """A through the speech; both name menus default (RED / BLUE)."""
    for _ in range(200):
        if g.st()["screen"] == "overworld":
            break
        g.tap("a", 18)
    g.wait("screen=overworld", 900)          # ShrinkPlayer
    s = g.evidence("m02")
    assert s["player_name"] == "RED", s["player_name"]
    assert s["map_name"] == "RedsHouse2F"


def m03_leave_house(g):
    g.nav_warp(7, 1, "RedsHouse2F", "RedsHouse1F")   # stairs down
    g.nav_warp(3, 7, "RedsHouse1F", "PalletTown",
               approach="down")                      # door mat: exit south
    g.evidence("m03")


def m04_oak_intercept(g):
    """North edge of Pallet Town → Oak interception → into the lab.

    The (10,1)/(11,1) coord trigger opens Oak's dialogue the moment the
    walk touches the north row, and from then on the script owns the
    player (its follow-Oak hand-off warps into the lab). nav_to has no A
    to give, so when it stalls with the interception dialogue open we
    settle the cutscene HERE — where the hijack is expected — instead of
    teaching nav_to to settle scripts mid-route (global settlements step
    extra frames inside every nav, and frame-timing shifts around warp
    landings bounce fragile transitions like the RedsHouse stairs)."""
    for _ in range(3):
        try:
            g.nav_to(11, 1, "PalletTown")
        except NavError as e:
            if "OaksLab" in str(e):
                break          # the interception carried us into the lab
            s = g.st()
            if (s["map_name"] == "PalletTown"
                    and (s["dialogue_state"] is not None
                         or s["script_running"])):
                g.cutscene()   # settle; the follow hands off into OaksLab
            else:
                raise
        else:
            break
    assert g.cutscene(), "oak interception cutscene never finished"
    s = g.st()
    assert s["map_name"] == "OaksLab", s["map_name"]
    g.evidence("m04")


def m05_take_starter(g, which="bulbasaur"):
    balls = {"bulbasaur": (8, 3), "squirtle": (7, 3), "charmander": (6, 3)}
    bx, by = balls[which]
    g.nav_to(bx, by + 1)                     # stand below the ball
    g.face("up")
    g.tap("a", 20)                           # dex-preview dialogue
    ch = g.dialogue_then_choice()            # pages → "Do you want X?"
    assert ch["options"] == ["YES", "NO"], ch
    g.choose("YES")
    # AddPartyMon asks for a nickname after the receipt jingle. Keep the
    # canonical species name used by later route assertions.
    ch = g.dialogue_then_choice()
    assert g.st()["active_script_effect"] == "GivePokemon", g.st()
    assert ch["options"] == ["YES", "NO"], ch
    g.choose("NO")
    assert g.cutscene(), "starter cutscene never finished"
    s = g.evidence("m05")
    assert s["party_count"] == 1, s


def m06_rival_battle(g):
    g.nav_to(5, 6, "OaksLab")                # trigger row -> rival challenge
    assert g.cutscene(), "rival challenge cutscene never finished"
    g.wait("screen=battle", 900)
    g.battle_loop()
    g.wait("not_battle", 1800)
    assert g.cutscene(), "post-battle script never settled"
    g.evidence("m06")


def m07_mart_parcel(g):
    """Exit the lab, cross Route 1 to Viridian, collect Oak's parcel."""
    g.nav_warp(5, 11, "OaksLab", "PalletTown", approach="down")   # lab door
    g.nav_to_map(20, 26, "ViridianCity")         # west avenue (patrol-free)
    g.nav_to(20, 32, map_name="ViridianCity")    # south lane x=20-21
    g.nav_to_map(29, 20, "ViridianCity")         # below mart
    g.nav_warp(29, 19, "ViridianCity", "ViridianMart")            # @load: parcel
    g.evidence("m07-in-mart")
    g.nav_warp(4, 7, "ViridianMart", "ViridianCity", approach="down")
    g.evidence("m07-back-outside")


def m08_deliver_parcel(g):
    """Back to Pallet Town, hand the parcel to Oak, receive the POKéDEX.
    The Viridian return leg is staged through the patrol-free x=23
    corridor — the BFS-shortest route crosses the wandering youngster's
    patrol band and pinches indefinitely."""
    g.nav_to(20, 32, map_name="ViridianCity")    # south lane x=20-21
    g.evidence("m08-southlane")
    g.nav_to_map(12, 12, "PalletTown")           # Route1 crossing
    g.evidence("m08-back-home")
    g.nav_warp(12, 11, "PalletTown", "OaksLab")
    g.nav_to(5, 3, map_name="OaksLab")
    g.face("up")
    g.tap("a", 20)
    assert g.cutscene(), "parcel delivery cutscene never finished"
    g.evidence("m08-delivered")
    # Post-delivery, Oak's talk flips to the POKéDEX rating branch —
    # sample one line as evidence the flag actually flipped.
    g.tap("a", 30)
    g.d.cmd(cmd="wait_until", condition="dialogue_ready", max_frames=300)
    s = g.st()
    print(f"[m08] oak-after-delivery: {s.get('dialogue') or s['dialogue_state']}")
    g.skip()
    g.cutscene()


def walk_pallet_to_pewter(g):
    """Pallet Town -> Route 2 -> forest gate chain -> Pewter City: the
    m09 verified corridor. Also the whiteout recovery walk for m10's
    relocation (a forest fight loss blacks out to the player's house)."""
    # Explicit gate chain: cross-BFS routing through the forest depends on
    # a last_map that drifts from the engine's, which can detour the plan
    # back through Pallet Town (no path to Pewter). Staged nav_warp calls
    # execute the verified corridor deterministically instead.
    g.nav_to_map(3, 44, "Route2")                     # below south gate
    g.nav_warp(3, 43, "Route2", "ViridianForestSouthGate")
    g.nav_to(5, 1, map_name="ViridianForestSouthGate")
    g.nav_warp(5, 0, "ViridianForestSouthGate", "ViridianForest")
    g.nav_to(1, 1, map_name="ViridianForest")
    g.nav_warp(1, 0, "ViridianForest", "ViridianForestNorthGate")
    g.nav_to(5, 1, map_name="ViridianForestNorthGate")
    g.nav_warp(5, 0, "ViridianForestNorthGate", "Route2")
    g.nav_to_map(16, 29, "PewterCity")


def m09_to_pewter(g):
    """North through Route 2, Viridian Forest (trainer LOS fights), to
    Pewter City — the first gym town. Gate houses are traversed by the
    warp-aware BFS automatically."""
    g.nav_warp(5, 11, "OaksLab", "PalletTown", approach="down")
    for attempt in range(3):
        g.heal_pokecenter((23, 25), "ViridianCity", "ViridianPokecenter")
        try:
            walk_pallet_to_pewter(g)
            break
        except NavError:
            state = g.st()
            party = (state.get('battle_live') or {}).get('player_party', [])
            if (attempt == 2 or state.get('screen') != 'overworld'
                    or state.get('map_name') != 'ViridianCity'
                    or 'player_won: false' not in state.get('battle_phase', '')
                    or not party or not all(mon['hp'] == 0 for mon in party)):
                raise
            g.evidence(f"m09-blackout-{attempt + 1}")
            # Repeating the forest with the same level-5 starter can fail
            # without earning any XP. Bring forward the existing m10
            # preparation, using real Route 1 battles and Center healing.
            g.nav_to(20, 32, map_name='ViridianCity')
            g.nav_to(20, 33, map_name='ViridianCity')
            g.d.drive(['down'] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)
            g.step(8)
            g.nav_to(12, 7, map_name='Route1')
            heal = ((23, 25), 'ViridianCity', 'ViridianPokecenter')
            assert g.train_until(13, 'Route1', (12, 7), heal), 'forest recovery training stalled'
    g.evidence("m09")


def forest_corridor_back(g):
    """PewterCity -> Route2 north -> NorthGate -> forest -> SouthGate ->
    Route2 south: the m09 chain in reverse, Pewter-ward traffic only."""
    g.nav_to(18, 34, map_name="PewterCity")
    g.d.drive(["down"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)
    g.step(8)
    g.nav_warp(3, 11, "Route2", "ViridianForestNorthGate", approach="down")
    g.nav_to(5, 6, map_name="ViridianForestNorthGate")
    g.nav_warp(5, 7, "ViridianForestNorthGate", "ViridianForest",
               approach="down")
    g.nav_to(17, 46, map_name="ViridianForest")
    g.nav_warp(17, 47, "ViridianForest", "ViridianForestSouthGate")
    g.nav_to(4, 6, map_name="ViridianForestSouthGate")
    g.nav_warp(4, 7, "ViridianForestSouthGate", "Route2", approach="down")


def m10_brock(g):
    """Grind to Vine Whip (L13) in Route 2 grass, heal, then beat Brock
    for the BOULDERBADGE."""
    g.evidence("m10-arrived")
    # Heal at VIRIDIAN, not Pewter: Route 2's south section connects
    # straight to Viridian City (proven corridor, no forest gates), so
    # the training round trip stays short and deterministic.
    heal = ((23, 25), "ViridianCity", "ViridianPokecenter")
    # Relocate to the Route 1 training grass next to Viridian. Heal at
    # the Pewter PC first: heal_pokecenter's PewterCity exit path stages
    # the exact Pewter -> forest -> Route2-south chain (same tiles as the
    # old forest_corridor_back), and a full-HP party survives the forest
    # fights that a loss would turn into a blackout home. On a whiteout
    # anyway (NavError landing in Pallet Town) the blackout already healed
    # the party — re-walk the proven m09 chain and retry the crossing.
    for attempt in range(3):
        try:
            g.heal_pokecenter((13, 25), "PewterCity", "PewterPokecenter")
            forest_corridor_back(g)
            break
        except NavError as e:
            if attempt == 2 or "-> PalletTown" not in str(e):
                raise
            g.evidence(f"m10-whiteout-{attempt}")
            walk_pallet_to_pewter(g)
    g.nav_to(8, 70, map_name="Route2")
    g.d.drive(["down"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)   # -> city north border (18,0)
    g.step(8)
    g.nav_to(18, 1, map_name="ViridianCity")
    g.nav_to(20, 32, map_name="ViridianCity")
    g.nav_to(20, 33, map_name="ViridianCity")
    g.d.drive(["down"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)
    g.step(8)
    g.nav_to(12, 7, map_name="Route1")
    assert g.train_until(13, "Route1", (12, 7), heal), "training stalled"
    g.evidence("m10-trained")
    # Gym attempts repeat the healing/corridor route after normal losses.
    # The final Pewter heal restores forest PP and becomes the blackout
    # destination. The badge flag is the success check.
    for attempt in range(3):
        g.heal_pokecenter(*heal)
        # Stage the town hop: city north crossing -> forest corridor (m09
        # outbound chain) -> Pewter. Cross-BFS town hops drift; the chain
        # is the verified path.
        g.nav_to(20, 32, map_name="ViridianCity")
        g.nav_to(18, 1, map_name="ViridianCity")
        g.d.drive(["up"] * (3 * FRAMES_PER_TILE), frames=3 * FRAMES_PER_TILE + 4)    # N connection -> Route2 (8,71)
        g.step(8)
        forest_corridor_out(g)
        # Forest encounters can exhaust Vine Whip before the gym's
        # Diglett/Sandshrew trainer. Restore both HP and PP locally.
        g.heal_pokecenter((13, 25), "PewterCity", "PewterPokecenter")
        g.nav_to_map(16, 18, "PewterCity")   # below the gym door (16,17)
        g.nav_warp(16, 17, "PewterCity", "PewterGym")
        try:
            g.nav_to(4, 2, map_name="PewterGym")  # below Brock (4,1)
        except NavError:
            if g.st()["map_name"] != "PewterCity":
                raise
            # The gym's first trainer can also cause a normal blackout.
            g.evidence(f"m10-gym-trainer-blackout-{attempt + 1}")
            continue
        g.face("up")
        g.tap("a", 20)                        # Brock's challenge speech
        assert g.cutscene(), "Brock challenge cutscene never finished"
        g.wait("screen=battle", 900)
        g.battle_loop(prefer="fight")
        g.wait("not_battle", 1800)
        assert g.cutscene(), "badge ceremony never finished"
        flags = g.d.cmd(cmd="get_flags")["data"]
        if flags.get("EVENT_BEAT_BROCK"):
            g.evidence("m10")
            return
        print(f"[m10] attempt {attempt + 1} lost — blacked out, retrying",
              flush=True)
    raise NavError("Brock never beaten in 3 attempts")


def forest_corridor_out(g):
    """Overworld Route2-south -> forest gates -> Route2-north (m09's
    verified chain, shared by the m10 heal round trips)."""
    g.nav_to_map(3, 44, "Route2")
    g.nav_warp(3, 43, "Route2", "ViridianForestSouthGate")
    g.nav_to(5, 1, map_name="ViridianForestSouthGate")
    g.nav_warp(5, 0, "ViridianForestSouthGate", "ViridianForest")
    g.nav_to(1, 1, map_name="ViridianForest")
    g.nav_warp(1, 0, "ViridianForest", "ViridianForestNorthGate")
    g.nav_to(5, 1, map_name="ViridianForestNorthGate")
    g.nav_warp(5, 0, "ViridianForestNorthGate", "Route2")


MILESTONES = [
    ("m01", "boot to NEW GAME / Oak speech", m01_boot),
    ("m02", "Oak speech + default names → bedroom", m02_oak_speech),
    ("m03", "leave home → Pallet Town", m03_leave_house),
    ("m04", "Oak interception → OaksLab", m04_oak_intercept),
    ("m05", "take starter (bulbasaur)", m05_take_starter),
    ("m06", "first rival battle", m06_rival_battle),
    ("m07", "Route 1 → Viridian Mart parcel", m07_mart_parcel),
    ("m08", "deliver parcel → POKéDEX", m08_deliver_parcel),
    ("m09", "Viridian Forest → Pewter City", m09_to_pewter),
    ("m10", "train + Boulder Badge (Brock)", m10_brock),
]

from playthrough_late import LATE_MILESTONES
MILESTONES += LATE_MILESTONES


def state_done(mid, g):
    """Replay-safety: the checkpoint marker is the single authority —
    after a preserved save the game resumes mid-run, and state predicates
    (overworld+RED, OaksLab...) are satisfied by ANY later stage, so only
    the marker decides what already happened."""
    return g.marker_at_least(mid)


def resume_reentry(g):
    """Bring a resumed game back into the checkpointed overworld.

    --save does NOT short-circuit boot: the game still plays the intro and
    parks on the main menu, where a save present makes CONTINUE the default
    cursor. Milestones m01+ are skipped under --resume, so nobody would tap
    through — without this the first executed milestone reads pos (0,0) on
    a menu screen and BFS dies with 'no path'. A on CONTINUE restores the
    saved overworld directly (no Oak speech to sit through)."""
    for _ in range(40):                      # language-select / title
        s = g.st()
        if s["screen"] in ("main-menu", "overworld"):
            break
        g.tap("a", 30)
    for _ in range(20):                      # main menu: A = CONTINUE
        if g.st()["screen"] in ("overworld",):
            break
        g.tap("a", 30)
    g.wait("screen=overworld", 600)
    s = g.evidence("resume-reentry")
    assert s["screen"] == "overworld", s["screen"]


def main():
    ap = argparse.ArgumentParser()
    # Default port=None: Game probes a free port instead of trusting 9020.
    # A hardcoded default turns any leaked/stale game on that port into a
    # silent hijack — the driver then "plays" the old instance and fails
    # in ways that look like engine bugs.
    ap.add_argument("--port", type=int, default=None,
                    help="debug port (default: probe a free port)")
    ap.add_argument("--until", default=None, help="stop after this milestone")
    ap.add_argument("--starter", default="bulbasaur",
                    choices=["bulbasaur", "squirtle", "charmander"])
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--resume", action="store_true",
                    help="use the persistent .playthrough.sav + marker: "
                         "skip milestones already satisfied")
    ap.add_argument("--artifacts", type=Path,
                    help="retain milestone observations and failure/game logs here")
    ap.add_argument("--record", default=None, metavar="DIR",
                    help="record every rendered frame to DIR (passes "
                         "--record-frames to the game); assemble with e.g. "
                         "ffmpeg -framerate 240 -i frame-%%06d.png -r 60 out.mp4. "
                         "For full-run video prefer --record-video instead")
    ap.add_argument("--record-video", default=None, metavar="FILE",
                    help="record straight to FILE as H.264 mp4 (passes "
                         "--record-video to the game, which pipes raw frames "
                         "into ffmpeg — no intermediate PNGs)")
    args = ap.parse_args()

    if args.list:
        for mid, desc, _ in MILESTONES:
            print(f"{mid}: {desc}")
        return

    if args.until is not None and Game.milestone_index(args.until) < 0:
        ap.error(f"unknown milestone: {args.until}")
    if args.artifacts:
        args.artifacts.mkdir(parents=True, exist_ok=True)

    g = Game(args.port, save_path=(ROOT / "scripts" / ".playthrough.sav")
             if args.resume else None, record_dir=args.record,
             record_video=args.record_video)
    if args.resume and g.marker_at_least("m01"):
        resume_reentry(g)
    try:
        stage, league_retries = 0, 0
        while stage < len(MILESTONES):
            mid, desc, fn = MILESTONES[stage]
            if args.resume and state_done(mid, g):
                print(f"== {mid}: {desc}")
                print(f"   skipped (state/marker already satisfied)")
                if args.until == mid:
                    break
                stage += 1
                continue
            print(f"== {mid}: {desc}")
            t0 = time.time()
            g.smart_moves = Game.milestone_index(mid) >= Game.milestone_index("m11")
            try:
                if mid == "m05":
                    fn(g, args.starter)
                else:
                    fn(g)
            except (AssertionError, RuntimeError):
                from playthrough_late import retry_elite_four
                if not retry_elite_four(g, mid, league_retries):
                    raise
                league_retries += 1
                stage = next(i for i, entry in enumerate(MILESTONES) if entry[0] == 'm45')
                continue
            print(f"   done ({time.time()-t0:.1f}s wall)")
            if g.persistent:
                g.checkpoint(mid)
            if args.artifacts:
                if g.save_path.exists():
                    shutil.copy2(g.save_path, args.artifacts / f"{mid}.sav")
                observations = {cmd: g.d.cmd(cmd=cmd) for cmd in
                                ("get_state", "get_flags", "get_party", "get_bag")}
                if hasattr(g, "first_clear_verification"):
                    observations["first_clear_verification"] = g.first_clear_verification
                (args.artifacts / f"{mid}.json").write_text(
                    json.dumps(observations, ensure_ascii=False, indent=2))
            if args.until == mid:
                break
            stage += 1
        print("PLAYTHROUGH REACHED REQUESTED MILESTONE")
    except Exception:
        if args.artifacts:
            import traceback
            (args.artifacts / "failure.txt").write_text(traceback.format_exc())
            try:
                (args.artifacts / "failure-state.json").write_text(
                    json.dumps(g.st(), ensure_ascii=False, indent=2))
                (args.artifacts / "failure-npcs.json").write_text(
                    json.dumps(g.d.cmd(cmd="get_npcs"), ensure_ascii=False, indent=2))
                (args.artifacts / "failure-flags.json").write_text(
                    json.dumps(g.d.cmd(cmd="get_flags"), ensure_ascii=False, indent=2))
                (args.artifacts / "failure-fixture.json").write_text(
                    json.dumps(g.d.cmd(cmd="export_fixture")["data"], ensure_ascii=False, indent=2))
            except Exception:
                pass  # The game may have crashed; keep the original exception.
        raise
    finally:
        if args.artifacts:
            g.log.flush()
            shutil.copy2(g.run_dir / "game.log", args.artifacts / "game.log")
        g.close()


if __name__ == "__main__":
    main()
