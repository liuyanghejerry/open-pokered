import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

root = Path('/home/jerry/develop/open-pokered')
r = root / '.task-tmp/fidelity-39-plus'
w = root / '.task-tmp/fidelity-892-field-poison'
sys.path.insert(0, str(w / 'scripts'))
from debug_drive import DebugClient

out = r / 'audit-895-poison-party-captures'
out.mkdir(exist_ok=False)
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = '/tmp/pokered-build-lib'
env['POKERED_MAPS_DIR'] = str(w / 'crates/pokered-data/maps')
records = []
for stage in ['before', 'after']:
    binary = r / ('audit-895-current-master-before-debug' if stage == 'before' else 'audit-892-after-debug')
    parent = Path((r / ('audit-895-native-poison-current-before-path.txt' if stage == 'before' else 'audit-894-native-poison-legal-after-path.txt')).read_text().strip())
    for repeat in [1, 2]:
        trial = out / f'{stage}-{repeat}'
        trial.mkdir()
        fixture = parent / f'single-{repeat}/readback.json'
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        client = None
        actions = []
        with (trial / 'game.log').open('w') as log:
            process = subprocess.Popen([str(binary), 'run', '--headless', '--speed', '0', '--seed', '42',
                '--debug-port', str(port), '--skip-intro', '--snapshot', str(fixture),
                '--warp', 'RedsHouse2F,3,6', '--lang', 'en', '--no-audio',
                '--save', str(trial / 'unused.sav')], cwd=trial, env=env, stdout=log, stderr=subprocess.STDOUT)
            try:
                client = DebugClient(port)
                client.step(120)

                def tap(button, frames=32):
                    actions.append({'button': button, 'held': 4, 'frames': frames})
                    assert client.cmd(cmd='press_timeline', buttons=[button]*4+[None]*(frames-4), advance=True)['ok']

                initial = client.state()
                tap('start', 60)
                assert client.state()['screen'] == 'start-menu'
                for _ in range(8):
                    menu = client.state()['field_menu']
                    if menu['items'][menu['cursor']].lower().replace('é', 'e') == 'pokemon':
                        break
                    tap('down')
                else:
                    raise AssertionError('Pokemon row not reached')
                tap('a')
                state = client.state()
                assert state['screen'] == 'party'
                png = trial / 'party.png'
                assert client.cmd(cmd='capture_frame', path=str(png))['ok']
                assert state['party'] == initial['party']
                tap('b', 60)
                assert client.state()['party'] == initial['party']
            finally:
                if client is not None:
                    client.close()
                process.terminate()
                process.wait(timeout=10)
        record = {'stage': stage, 'repeat': repeat, 'source_commit': 'fcbcd10c553f3f2999c5c50400e3fe090c814584' if stage == 'before' else '24ab208a6b3473d6a126d3ff4bbf2abdbba69ee5',
            'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'fixture_sha256': hashlib.sha256(fixture.read_bytes()).hexdigest(),
            'frame': state['frame_count'], 'state': state, 'actions': actions, 'png_sha256': hashlib.sha256(png.read_bytes()).hexdigest(),
            'scope': 'Reload genuine ordinarySAVE output from actual4-step poison trial; preinput only, ordinarySTART/Pokemon/B, no postboot mutations. Shows current party status badge; separate HP0 FNT-priority UI repair is pendingPR242.'}
        (trial / 'record.json').write_text(json.dumps(record, indent=2))
        records.append(record)
        print(stage, repeat, state['frame_count'], record['png_sha256'], flush=True)
assert len({x['frame'] for x in records}) == 1
assert records[0]['png_sha256'] == records[1]['png_sha256']
assert records[2]['png_sha256'] == records[3]['png_sha256']
assert all(x['actions'] == records[0]['actions'] for x in records)
(out / 'verification.json').write_text(json.dumps({'trials': records}, indent=2))
print('2 matched pairs, same frame/inputs, duplicate pixels exact', flush=True)
