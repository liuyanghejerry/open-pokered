from pathlib import Path
import sys, tempfile, shutil, hashlib
exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r = root / '.task-tmp/fidelity-39-plus'
out = Path(tempfile.mkdtemp(prefix='audit-894-original-poison-legal-', dir=r))
(r/'audit-894-original-poison-legal-path.txt').write_text(str(out)+'\n')
rom = r/'movement-91-setup/walking-reference.gbc'
prior = Path((r/'audit-883-original-cut-grass-v2-path.txt').read_text().strip())
raw_specimen = json.loads((r/'audit-894-rattata-raw.json').read_text())
raw = {'raw':raw_specimen['raw'], 'partner':raw_specimen['raw']}
maxhp=raw_specimen['mon']['max_hp']
prep = out/'preparation'; prep.mkdir(); shutil.copyfile(rom, prep/'original.gbc')
p = PyBoy(str(prep/'original.gbc'), window='null', sound_emulated=True, color_palette=[0xffffff,0xaaaaaa,0x555555,0]); p.set_emulation_speed(0)
p.load_state(io.BytesIO((prior/'map-preparation/prepared-map.state').read_bytes()))
for key, value in [('wCurMap',38),('wXCoord',3),('wYCoord',6),('wDestinationWarpID',255),('wXBlockCoord',1),('wYBlockCoord',0)]: p.memory[symbols[key][1]] = value
view = symbols['wOverworldMap'][1]+7+4+10*(6>>1)+(3>>1)
a = symbols['wCurrentTileBlockMapViewPointer'][1]; p.memory[a:a+2] = [view&255, view>>8]
entry = symbols['EnterMap'][1]; p.memory[0xdfe0:0xdfe4] = [0xfb,0xc3,entry&255,entry>>8]; p.register_file.PC = 0xdfe0
for key in ['a','b','start','select','up','down','left','right']: p.button_release(key)
p.tick(240); assert int(p.memory[symbols['wCurMap'][1]]) == 38
assert [int(p.memory[symbols[k][1]]) for k in ['wXCoord','wYCoord']] == [3,6]
p.save_state((prep/'prepared.state').open('wb')); p.screen.image.save(prep/'prepared.png'); p.stop(save=False)
records = []
cases = {'single':[(1,8),(maxhp,0)]}
for case, members in cases.items():
    for repeat in [1,2]:
        trial = out/f'{case}-{repeat}'; trial.mkdir(); private = trial/'original.gbc'; shutil.copyfile(rom, private)
        p = PyBoy(str(private), window='null', sound_emulated=True, color_palette=[0xffffff,0xaaaaaa,0x555555,0]); p.set_emulation_speed(0); p.load_state(io.BytesIO((prep/'prepared.state').read_bytes()))
        party = symbols['wPartyMons'][1]; monraw = []
        for i,(hp,status) in enumerate(members):
            mon = list(raw['raw'] if i == 0 else raw['partner']); mon[1:3] = [0,hp]; mon[4] = status; monraw += mon
        p.memory[party:party+len(monraw)] = monraw; p.memory[symbols['wPartyCount'][1]] = len(members)
        p.memory[symbols['wPartySpecies'][1]:symbols['wPartySpecies'][1]+7] = [165]*len(members)+[255]*(7-len(members))
        nick = [145,128,147,147,128,147,128]+[80]*4
        for i in range(len(members)): p.memory[symbols['wPartyMonNicks'][1]+11*i:symbols['wPartyMonNicks'][1]+11*(i+1)] = nick
        for key,value in [('wStepCounter',0),('wLastBlackoutMap',0),('wOptions',1),('wBattleAndStartSavedMenuItem',0),('wPartyAndBillsPCSavedMenuItem',0),('wBagSavedMenuItem',0),('wListScrollOffset',0)]: p.memory[symbols[key][1]] = value
        p.memory[symbols['wPlayerMoney'][1]:symbols['wPlayerMoney'][1]+3] = [0,0x30,0]
        p.save_state((trial/'constructed.state').open('wb')); get = lambda key: int(p.memory[symbols[key][1]])
        actions=[]; events=[]; frames=[]; captures={}; ow=[0]
        def state():
            rows=[list(p.memory[party+44*i:party+44*(i+1)]) for i in range(len(members))]
            return {'frame':p.frame_count,'map':get('wCurMap'),'x':get('wXCoord'),'y':get('wYCoord'),'step':get('wStepCounter'),'bgp':int(p.memory[0xff47]),'which':get('wWhichPokemon'),'hTextID':get('hTextID'),'menu':get('wCurrentMenuItem'),'menu_max':get('wMaxMenuItem'),'party_raw':rows,'hp':[(m[1]<<8)|m[2] for m in rows],'status':[m[4] for m in rows]}
        def event(label):
            if label == 'OverworldLoop': ow[0] += 1; return
            e={'label':label,'state':state(),'HL':p.register_file.HL,'B':p.register_file.B,'loaded_bank':get('hLoadedROMBank')}; events.append(e)
        for label in ['OverworldLoop','ApplyOutOfBattlePoisonDamage','DisplayTextID','PrintText','ChangeBGPalColor0_4Frames','HandleBlackOut','ResetStatusAndHalveMoneyOnBlackout','EnterMap','SavePartyAndDexData']:
            if label in symbols: p.hook_register(*symbols[label], lambda _,label=label:event(label), None)
        def tick(n):
            for _ in range(n): p.tick(1); frames.append(state())
        def tap(key,held=16,neutral=32):
            actions.append({'frame':p.frame_count,'button':key,'held':held,'neutral':neutral}); p.button_press(key); tick(held); p.button_release(key); tick(neutral)
        def shot(tag):
            path=trial/(tag+'.png'); p.screen.image.save(path); captures[tag]={'state':state(),'tilemap':list(p.memory[symbols['wTileMap'][1]:symbols['wTileMap'][1]+360]),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}; return captures[tag]['state']
        initial=shot('initial'); assert initial['step']==0
        for index,key in enumerate(['right','left','right','left']): tap(key); shot(f'step-{index+1}')
        after4=shot('after-four'); assert after4['step']==252, after4
        before_ow=ow[0]
        for index in range(30):
            if case == 'blink': tick(100); break
            if ow[0]>before_ow and (case!='wipe' or get('wCurMap')==0): break
            tap('a',2,160); shot(f'ack-{index}')
        else: raise AssertionError(('poison text/blackout did not settle',state(),events))
        tick(100); final=shot('final')
        expected={'single':([0,maxhp],[0,0]),'double':([0,0,35],[0,0,0]),'blink':([2,35],[8,0]),'wipe':([35,35],[0,0])}[case]
        assert (final['hp'],final['status'])==expected, final
        tap('start',2,100); shot('save-start'); saveindex=4 if get('wMaxMenuItem')==7 else 3
        for _ in range(8):
            if get('wCurrentMenuItem')==saveindex: break
            tap('down',2,30)
        tap('a',2,100)
        for _ in range(10):
            if any(e['label']=='SavePartyAndDexData' for e in events): break
            tap('a',2,250)
        assert any(e['label']=='SavePartyAndDexData' for e in events); tick(300); shot('saved'); p.stop(save=True)
        saved=private.with_suffix('.gbc.ram').read_bytes(); assert saved[0x3523]==(~sum(saved[0x2598:0x3523])&255)
        for i,mon in enumerate(final['party_raw']): assert saved[0x2f34+44*i:0x2f34+44*(i+1)]==bytes(mon)
        record={'case':case,'repeat':repeat,'scope':'Pre-validation EnterMap bootstrap to genuine RedsHouse2F38(3,6), legal party/status/HP/step0/cash3000/lastblackout0 construction. Afterwards only actual right,left,right,left, actualA text ACK and ordinarySTART/SAVE. No validation RAM writes or directpoisoncall.','initial':initial,'after4':after4,'final':final,'events':events,'actions':actions,'captures':captures,'normal_save':True,'sram_sha256':hashlib.sha256(saved).hexdigest(),'sram_checksum':saved[0x3523],'saved_money_bcd':saved[0x25f3:0x25f6].hex(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'constructed_state_sha256':hashlib.sha256((trial/'constructed.state').read_bytes()).hexdigest(),'rom_sha256':hashlib.sha256(rom.read_bytes()).hexdigest()}
        (trial/'record.json').write_text(json.dumps(record,indent=2)); (trial/'frames.json').write_text(json.dumps(frames,indent=2)); records.append(record); print(case,repeat,'PASS',final['hp'],final['status'],saved[0x25f3:0x25f6].hex(),flush=True)
(out/'verification.json').write_text(json.dumps({'source_revision':'fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c','trials':records},indent=2)); print('output',out,flush=True)
