import copy
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile

root = Path('/home/jerry/develop/open-pokered')
evidence = root / '.task-tmp/fidelity-39-plus'
work = root / '.task-tmp/fidelity-892-field-poison'
sys.path.insert(0, str(work / 'scripts'))
from debug_drive import DebugClient

stage, binary_arg, source = sys.argv[1:]
binary = Path(binary_arg)
sha = hashlib.sha256(binary.read_bytes()).hexdigest()
if stage == 'before':
    identity = json.loads((evidence / 'audit-895-current-master-before-identity.json').read_text())
    assert source == identity['source_commit']
    assert sha == identity['binary_sha256']
out = Path(tempfile.mkdtemp(prefix=f'audit-895-native-poison-current-{stage}-', dir=evidence))
(evidence / f'audit-895-native-poison-current-{stage}-path.txt').write_text(str(out) + '\n')
old = Path((evidence / 'audit-883-native-cut-grass-before-path.txt').read_text().strip())
template = json.loads((old / 'healthy-fixture.json').read_text())
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = '/tmp/pokered-build-lib'
env['POKERED_MAPS_DIR'] = str(work / 'crates/pokered-data/maps')
results = []
for case in ['single']:
    fixture = copy.deepcopy(template)
    specimen = json.loads((evidence / 'audit-894-rattata-raw.json').read_text())['mon']
    fixture['party'] = [copy.deepcopy(specimen), copy.deepcopy(specimen)]
    first, second = fixture['party']
    first['hp'] = 3 if case == 'blink' else 1
    first['status'] = 'Poison'
    second['hp'] = 1 if case in ['double', 'wipe'] else specimen['max_hp']
    second['status'] = 'Poison' if case in ['double', 'wipe'] else 'None'
    if case == 'double':
        third = copy.deepcopy(second)
        third.update(hp=35, status='None')
        fixture['party'].append(third)
    data = fixture['game_data']
    data['position'] = {'map_id': 38, 'x': 3, 'y': 6, 'x_block': 1, 'y_block': 0}
    data['last_blackout_map'] = 0
    data['player_money'] = 3000
    data['options']['text_speed'] = 'Fast'
    fp = out / (case + '-fixture.json')
    fp.write_text(json.dumps(fixture, indent=2))
    for repeat in [1, 2]:
        trial = out / f'{case}-{repeat}'
        trial.mkdir()
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        states, actions, frames = [], [], []
        client = None
        with (trial / 'game.log').open('w') as log:
            process = subprocess.Popen([
                str(binary), 'run', '--headless', '--speed', '0', '--seed', '42',
                '--debug-port', str(port), '--skip-intro', '--snapshot', str(fp),
                '--warp', 'RedsHouse2F,3,6', '--lang', 'en', '--no-audio',
                '--save', str(trial / 'ordinary.sav'),
            ], cwd=trial, env=env, stdout=log, stderr=subprocess.STDOUT)
            try:
                client = DebugClient(port)
                client.step(120)

                def state(tag):
                    value = client.state()
                    states.append({'tag': tag, 'state': value})
                    return value

                def tap(button, total=32, held=4):
                    actions.append({'button': button, 'held': held, 'frames': total})
                    assert client.cmd(cmd='press_timeline', buttons=[button] * held + [None] * (total-held), advance=True)['ok']

                initial = state('initial')
                assert initial['screen'] == 'overworld'
                assert initial['map_name'] == 'RedsHouse2F'
                assert (initial['player_x'], initial['player_y']) == (3, 6)
                assert [m['hp'] for m in initial['party']] == [m['hp'] for m in fixture['party']]
                for direction, pos in [('right', (4, 6)), ('left', (3, 6)), ('right', (4, 6))]:
                    tap(direction)
                    value = state('step-' + direction)
                    assert (value['player_x'], value['player_y']) == pos, value
                    assert [m['hp'] for m in value['party']] == [m['hp'] for m in fixture['party']]
                # Observe the complete fourth step and poison continuation, with
                # no acknowledgements until all frame captures have finished.
                for number in range(120):
                    assert client.cmd(cmd='press_timeline', buttons=['left' if number < 4 else None], advance=True)['ok']
                    value = state(f'fourth-{number:03}')
                    path = trial / f'frame-{number:03}.png'
                    assert client.cmd(cmd='capture_frame', path=str(path))['ok']
                    frames.append({'index': number, 'frame': value['frame_count'], 'map': value['map_name'],
                        'screen': value['screen'], 'position': [value['player_x'], value['player_y']],
                        'party': value['party'], 'dialogue': value['dialogue'],
                        'dialogue_state': value['dialogue_state'],
                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
                after_tick = state('after-tick-without-ack')
                for number in range(50):
                    value = state('settle-' + str(number))
                    if value['screen'] == 'overworld' and value['dialogue_state'] is None:
                        break
                    tap('a', 80)
                else:
                    raise AssertionError('field poison continuation did not settle')
                settled = state('settled')
                if case != 'wipe':
                    assert settled['map_name'] == 'RedsHouse2F'
                    assert (settled['player_x'], settled['player_y']) == (3, 6)
                tap('start', 60)
                assert state('start')['screen'] == 'start-menu'
                for _ in range(8):
                    menu = state('save-cursor')['field_menu']
                    if menu['items'][menu['cursor']] == 'Save':
                        break
                    tap('down')
                else:
                    raise AssertionError('SAVE cursor not reached')
                tap('a')
                assert state('save')['screen'] == 'save'
                client.step(200)
                tap('a', 400)
                client.step(300)
                final = state('saved')
                assert (trial / 'ordinary.sav').exists()
            finally:
                (trial / 'actions.json').write_text(json.dumps(actions, indent=2))
                (trial / 'states.json').write_text(json.dumps(states, indent=2))
                (trial / 'frames.json').write_text(json.dumps(frames, indent=2))
                if client is not None:
                    client.close()
                process.terminate()
                process.wait(timeout=10)
        subprocess.run([str(binary), 'import-snapshot', '--input', str(trial / 'ordinary.sav'),
            '-o', str(trial / 'readback.json')], cwd=trial, env=env, capture_output=True, check=True)
        saved = json.loads((trial / 'readback.json').read_text())
        ram = (trial / 'ordinary.sav').read_bytes()
        assert len(ram) == 32768
        assert ram[0x3523] == (~sum(ram[0x2598:0x3523])) & 255
        record = {'stage': stage, 'case': case, 'repeat': repeat, 'source_commit': source,
            'binary_sha256': sha, 'fixture_sha256': hashlib.sha256(fp.read_bytes()).hexdigest(),
            'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'initial': initial, 'after_tick_without_ack': after_tick, 'settled': settled,
            'final': final, 'saved_party': saved['party'], 'normal_save': True,
            'sram_sha256': hashlib.sha256(ram).hexdigest(), 'checksum': ram[0x3523],
            'party_raw_hex': ram[0x2f34:0x2f34+44*len(saved['party'])].hex(),
            'scope': 'Pre-input legal poisoned party/map construction only; actual four single walking steps, 120-frame observation without A, ordinary acknowledgement and START/SAVE/YES. No post-boot setters. Currentmaster fcbcd clean BEFORE construction/build/captures use its actual identity.'}
        (trial / 'record.json').write_text(json.dumps(record, indent=2))
        results.append(record)
        print(stage, case, repeat, 'saved', [(m['hp'], m['status']) for m in saved['party']],
            'map', settled['map_name'], 'noACK', after_tick['dialogue'], flush=True)
(out / 'verification.json').write_text(json.dumps({'trials': results}, indent=2))
print('2 legal-species poisonedwalking and ordinarySAVE controls complete', out, flush=True)
