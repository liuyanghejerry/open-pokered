from pathlib import Path
import subprocess,json,hashlib,re,datetime
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-926-capture-rng-audit'
run=lambda args:subprocess.check_output(args,cwd=w,text=True).strip()
assert run(['git','status','--porcelain'])==''
source=run(['git','rev-parse','HEAD']);base='32f74146eff45ec883e706d119ad56f90c2be8f0'
subprocess.run(['git','merge-base','--is-ancestor',base,source],cwd=w,check=True)
original=r/'cargo-926-capture-rng-audit.sh';wrapper=r/'cargo-933-926-current-host.sh';text=original.read_text();assert text.count('-j4')==1;wrapper.write_text(text.replace('-j4','-j1'));wrapper.chmod(0o755)
groups=[('core',['test','-p','pokered-core','--lib']),('app-debug',['test','-p','pokered-app','--lib','--features','debug-server']),('app-default',['test','-p','pokered-app','--lib']),('det-debug',['test','-p','pokered-app','--test','agent_determinism','--features','debug-server']),('det-default',['test','-p','pokered-app','--test','agent_determinism']),('build',['build','-p','pokered-app','--bin','pokered-app','--features','debug-server'])]
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'base':base,'wrapper':wrapper.name,'wrapper_sha256':hashlib.sha256(wrapper.read_bytes()).hexdigest(),'groups':{}}
for label,args in groups:
 log=r/f'audit-933-926-master32f-{label}.log'
 with log.open('w')as f:p=subprocess.run([str(wrapper),*args],cwd=w,stdout=f,stderr=subprocess.STDOUT)
 text=log.read_text();row={'exit':p.returncode,'args':args,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if label!='build':
  match=re.search(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',text);row['passed']=int(match[1])if match else None;row['ignored']=int(match[2])if match else None
 else:row['build_finished']='Finished' in text
 result['groups'][label]=row;(r/'audit-933-926-master32f-tests.json').write_text(json.dumps(result,indent=2)+'\n');print(label,row,flush=True)
 if p.returncode or(label!='build'and row['passed']is None):raise SystemExit(1)
assert run(['git','rev-parse','HEAD'])==source and run(['git','status','--porcelain'])==''
result['complete']=True;(r/'audit-933-926-master32f-tests.json').write_text(json.dumps(result,indent=2)+'\n');print('926 current32f host complete',source,flush=True)
