#!/usr/bin/env python3
"""Verify the test-only master integration without relabeling frozen captures."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

R = Path(__file__).resolve().parent
W = R.parent / "fidelity-924-battle-medicine-negative"
OUT = W / "docs/audits/battle-medicine-no-effect"
FROZEN = "6ddab384307c4bdcbcf92feb46f205d90eb4a3d7"
MASTER = "f0787e19e7623106eac1d6b8de7430ca1eb4428b"
HEAD = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=W, text=True).strip()
assert HEAD == "75e1151e0ef1d4d5cc0998336b9231a814dab0d0"
subprocess.run(["git", "merge-base", "--is-ancestor", MASTER, HEAD], cwd=W, check=True)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(name):
    return json.loads((R / name).read_text())


frozen_identity = load("audit-924-fix-after-identity.json")
frozen_hashes = frozen_identity["source_file_sha256"]
assert len(frozen_hashes) == 2166
current_hashes = {path: sha((W / path).read_bytes()) for path in frozen_hashes}
changed = [path for path in frozen_hashes if frozen_hashes[path] != current_hashes[path]]
assert changed == ["crates/pokered-app/src/game.rs"]
test_insert = (
    "        // The initial direction sample can roll a cave encounter before the\n"
    "        // boulder push starts. This test owns the push presentation only.\n"
    "        game.overworld.state.encounter_cooldown=1;\n"
).encode()
game = (W / changed[0]).read_bytes()
assert game.count(test_insert) == 1
assert sha(game.replace(test_insert, b"", 1)) == frozen_hashes[changed[0]]
assert b'#[cfg(all(test, feature = "debug-server"))]\nmod gift_dialogue_debug_tests' in game

tests = {}
for name, counts in [("app-debug-full", (304, 39)), ("app-default-full", (293, 37))]:
    path = R / f"audit-924-f078-{name}.log"
    matches = re.findall(r"test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;", path.read_text())
    assert tuple(map(int, matches[-1])) == counts, (name, matches)
    tests[name] = {"passed": counts[0], "ignored": counts[1], "log": path.name, "sha256": sha(path.read_bytes())}

mirror = load("audit-924-f078-gba-mirror.json")
assert mirror["source_head"] == HEAD
assert mirror["copied_paths"] == current_hashes
mirror_dir = Path(mirror["mirror"])
assert all(sha((mirror_dir / path).read_bytes()) == value for path, value in current_hashes.items())
old_rom = (R / "audit-924-final2.gba").read_bytes()
new_rom = (R / "audit-924-f078.gba").read_bytes()
assert new_rom == old_rom
assert sha(new_rom) == "0e1d06c9a962e8d4061986940d48614db091f9868544ded5b65b85b3996407f2"
assert "Finished `release` profile" in (R / "audit-924-f078-gba-build.log").read_text()
gba_identity = load("audit-924-f078-gba-identity.json")
assert gba_identity["source_head"] == HEAD and gba_identity["ROM_byteequal"] is True

selected = [
    "audit-924-f078-app-debug-full.log",
    "audit-924-f078-app-default-full.log",
    "audit-924-f078-gba-build.log",
    "audit-924-f078-gba-mirror.json",
    "audit-924-f078-gba-identity.json",
    Path(__file__).name,
]
archive = OUT / "master-f078-integration-logs.zip"
manifest = {}
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in selected:
        data = (R / name).read_bytes()
        manifest[name] = {"bytes": len(data), "sha256": sha(data)}
        z.writestr(name, data)
    z.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(selected) | {"manifest.json"}
    for name, info in manifest.items():
        data = z.read(name)
        assert len(data) == info["bytes"] and sha(data) == info["sha256"]

proof = {
    "audit": 924,
    "integration_source_head": HEAD,
    "integrated_master": MASTER,
    "frozen_actual_AFTER_source": FROZEN,
    "frozen_actual_BEFORE_source": "e26bc5c562730a55526691cddcbddcaad6da872b",
    "recorded_inputs_SAVE_and_screenshots_not_relabelled": True,
    "source_paths_compared": len(current_hashes),
    "unchanged_paths": len(current_hashes) - 1,
    "changed_path": changed[0],
    "entire_game_rs_equal_after_removing_exact_cfg_test_insert": True,
    "exact_cfg_test_insert": test_insert.decode(),
    "production_and_core_test_bytes_unchanged": True,
    "fresh_full_app_tests": tests,
    "reused_exact_core_tests": {"source": FROZEN, "passed": 2898, "reason": "All core production and test source paths are byte-identical."},
    "fresh_GBA": {
        "source_head": HEAD,
        "verified_mirror_paths": len(current_hashes),
        "build_exit": 0,
        "ROM_sha256": sha(new_rom),
        "entire_ROM_equal_to_measured_final2": True,
        "reused_exact_ROM_performance": load("audit-924-final-verification.json")["GBA"],
        "additional_performance_execution": False,
        "reason": "A new build produced exactly the same complete ROM as the seven-scenario measured candidate.",
    },
    "archive": {"path": archive.name, "bytes": archive.stat().st_size, "sha256": sha(archive.read_bytes()), "entries": len(selected) + 1, "all_entries_readback_verified": True, "manifest": manifest},
    "source_file_sha256": current_hashes,
}
data = json.dumps(proof, indent=2) + "\n"
(R / "audit-924-f078-integration.json").write_text(data)
(OUT / "master-f078-integration.json").write_text(data)
print(json.dumps({"source_head": HEAD, "proof_sha256": sha(data.encode()), "archive": proof["archive"]}, indent=2))
