import copy
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import types

root = Path('/home/jerry/develop/open-pokered')
work = root / '.task-tmp/fidelity-891-save-builder-dex'
evidence = root / '.task-tmp/fidelity-39-plus/audit-891-runtime'
evidence.mkdir(exist_ok=False)
sys.path.insert(0, str(work / 'scripts'))
from debug_drive import DebugClient
import save_builder as after

baseline = subprocess.check_output(['git', 'show', 'd0873d89b34bed10a481067682a1690ac4a14879:scripts/save_builder.py'], cwd=root, text=True)
(evidence / 'save_builder-before.py').write_text(baseline)
before = types.ModuleType('save_builder_before_891')
before.__file__ = str(work / 'scripts/save_builder.py')
exec(compile(baseline, before.__file__, 'exec'), before.__dict__)
binary = root / '.task-tmp/fidelity-39-plus/audit-880-fix-master729-before-debug'
binary_sha = hashlib.sha256(binary.read_bytes()).hexdigest()
assert binary_sha == 'c7f51b327265fdfc45a78d4fab562e6453e396aba8cc2e88dc15bf8a39c04477'
template = json.loads((root / 'docs/audits/rare-candy-move-learning/fixture.json').read_text())
records = []
for stage, module in [('before', before), ('after', after)]:
    module.SaveBuilder._tpl = copy.deepcopy(template)
    for case in ['boundary', 'complete']:
        builder = module.SaveBuilder()
        dex = builder.data['game_data']['pokedex']
        dex['seen'] = [0] * 19
        dex['owned'] = [0] * 19
        builder.position('RedsHouse2F', 3, 6)
        if case == 'boundary':
            for species in ['Bulbasaur', 'Wartortle', 'Blastoise', 'Mew']:
                builder.dex(species)
        else:
            builder.dex_complete()
        trial = evidence / f'{stage}-{case}'
        trial.mkdir()
        fixture = trial / 'fixture.json'
        fixture.write_text(json.dumps(builder.data, indent=2))
        with socket.socket() as listener:
            listener.bind(('127.0.0.1', 0))
            port = listener.getsockname()[1]
        env = os.environ.copy()
        env['LD_LIBRARY_PATH'] = '/tmp/pokered-build-lib'
        env['POKERED_MAPS_DIR'] = str(work / 'crates/pokered-data/maps')
        actions = []
        with (trial / 'game.log').open('w') as log:
            process = subprocess.Popen([str(binary), 'run', '--headless', '--speed', '0', '--seed', '42',
                '--debug-port', str(port), '--skip-intro', '--snapshot', str(fixture),
                '--warp', 'RedsHouse2F,3,6', '--lang', 'en', '--no-audio', '--save', str(trial / 'ordinary.sav')],
                cwd=trial, env=env, stdout=log, stderr=subprocess.STDOUT)
            client = None
            try:
                client = DebugClient(port)
                client.step(120)
                initial = client.state()
                assert initial['screen'] == 'overworld', initial['screen']
                actual = initial['evaluation']['pokedex']
                expected = ([2, 9, 10] if stage == 'before' else [1, 8, 9, 151]) if case == 'boundary' else list(range(2 if stage == 'before' else 1, 152))
                assert actual['owned_numbers'] == expected, actual
                assert actual['owned'] == (4 if case == 'boundary' else 151), actual
                def tap(button, frames=32, held=4):
                    actions.append({'button': button, 'held': held, 'frames': frames})
                    assert client.cmd(cmd='press_timeline', buttons=[button] * held + [None] * (frames - held), advance=True)['ok']
                tap('start', 60)
                assert client.state()['screen'] == 'start-menu'
                for _ in range(8):
                    menu = client.state()['field_menu']
                    if menu['items'][menu['cursor']] == 'Save':
                        break
                    tap('down')
                else:
                    raise AssertionError('SAVE menu row not reached')
                tap('a')
                assert client.state()['screen'] == 'save'
                client.step(200)
                tap('a', 400)
                client.step(300)
                final = client.state()
                assert final['evaluation']['pokedex'] == actual
                assert final['party'] == initial['party']
                save = trial / 'ordinary.sav'
                assert save.exists()
            finally:
                (trial / 'actions.json').write_text(json.dumps(actions, indent=2))
                if client is not None:
                    client.close()
                process.terminate()
                process.wait(timeout=10)
        readback = trial / 'readback.json'
        subprocess.run([str(binary), 'import-snapshot', '--input', str(save), '-o', str(readback)], cwd=trial, env=env, capture_output=True, check=True)
        saved = json.loads(readback.read_text())
        assert saved['game_data']['pokedex'] == builder.data['game_data']['pokedex']
        ram = save.read_bytes()
        assert len(ram) == 32768 and ram[0x3523] == (~sum(ram[0x2598:0x3523])) & 255
        record = {'stage': stage, 'case': case, 'binary_source': '72912bc174a5af7059f254581dfb720574021b7f',
            'binary_sha256': binary_sha, 'helper_sha256': hashlib.sha256((baseline if stage == 'before' else (work / 'scripts/save_builder.py').read_text()).encode()).hexdigest(),
            'fixture_sha256': hashlib.sha256(fixture.read_bytes()).hexdigest(), 'initial_dex': actual,
            'saved_dex': saved['game_data']['pokedex'], 'main_sram_checksum': ram[0x3523],
            'sram_sha256': hashlib.sha256(ram).hexdigest(), 'normal_save': True, 'party_preserved': True,
            'actions': actions, 'scope': 'Fresh clean frozen engine729, private preboot fixture only, no postboot setters; actual field START/SAVE/YES and independent SRAM readback. This tests the helper-produced bitmaps, not new game production code or original RNG.'}
        (trial / 'record.json').write_text(json.dumps(record, indent=2))
        records.append(record)
        print(stage, case, 'actual owned', actual['owned_numbers'], 'checksum', ram[0x3523], flush=True)
(evidence / 'verification.json').write_text(json.dumps({'trials': records, 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
print('4 controlled boots + ordinary SAVE PASS', flush=True)
