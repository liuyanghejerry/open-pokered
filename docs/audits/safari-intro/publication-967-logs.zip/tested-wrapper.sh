#!/bin/bash
case "$PWD" in
  /home/jerry/develop/open-pokered/.task-tmp/fidelity-910-safari-intro-audit) ;;
  *) echo "Refusing Safari intro audit build outside its own worktree" >&2; exit 64 ;;
esac
export TMPDIR=/home/jerry/develop/open-pokered/.task-tmp/fidelity-910-local-tmp
export CARGO_INCREMENTAL=0 LD_LIBRARY_PATH=/tmp/pokered-build-lib
export PATH=/home/jerry/.local/share/starheir-build/sysroot/usr/bin:$PATH
export PKG_CONFIG_PATH=/home/jerry/.local/share/starheir-build/sysroot/usr/lib/x86_64-linux-gnu/pkgconfig
export CARGO_HOME=/tmp/fidelity-cargo-home
export CARGO_PROFILE_DEV_OPT_LEVEL=0 CARGO_PROFILE_DEV_DEBUG=0
task_subcommand="$1"; shift
exec cargo "$task_subcommand" --offline --target-dir /home/jerry/develop/open-pokered/.task-tmp/fidelity-910-safari-intro-audit-target -j1 "$@"
