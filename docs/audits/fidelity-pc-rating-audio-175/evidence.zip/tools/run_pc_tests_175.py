from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,os,sys
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');rev=sys.argv[1];env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib')
def run(p):
 with (r/f'audit-175-suite-{p}-{rev}.log').open('w') as f:
  x=subprocess.run([str(r/f'audit-175-after-{rev}-immutable'/f'pokered_{p}'),'--test-threads=4'],stdout=f,stderr=subprocess.STDOUT,env=env)
 lines=(r/f'audit-175-suite-{p}-{rev}.log').read_text().splitlines();print(p,x.returncode,[s for s in lines if s.startswith('test result:')],flush=True)
 return x.returncode
with ThreadPoolExecutor(max_workers=4) as pool: codes=list(pool.map(run,['core','data','app','agent','audio']))
raise SystemExit(max(codes))
