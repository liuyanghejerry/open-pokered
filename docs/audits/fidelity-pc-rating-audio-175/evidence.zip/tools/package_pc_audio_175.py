from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';perf=Path('/home/jerry/develop/open-pokered-perf118');out=w/'docs/audits/fidelity-pc-rating-audio-175';out.mkdir(parents=True,exist_ok=True);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());gba=load(r/'audit-175-gba-source-manifest-a4.json');assert len(gba['sources'])==59;assert all(h(w/f)==sha==h(perf/f) for f,sha in gba['sources'].items());compare=(r/'audit-175-gba-compare-a4.log').read_text();assert compare.count(' -> ')==31 and 'GBA performance is within the configured regression budget.' in compare
for pkg,count in [('core',2748),('data',263),('app',221),('agent',54),('audio',99)]:
 assert f'{count} passed; 0 failed;' in (r/f'audit-175-suite-{pkg}-a4.log').read_text()
targeted=(r/'audit-175-ci-targeted-a4.log').read_text();assert '3 passed; 0 failed; 2 ignored;' in targeted and '4 passed; 0 failed;' in targeted
entries={}
for pattern in ['audit-175-*.log','audit-175-*.json']:
 for f in r.glob(pattern):entries[str(f.relative_to(r))]=f
for name in ['freeze_pc_175.py','run_pc_tests_175.py','stage_pc_gba_175.py','probe_pc_rating_audio_175.rs','package_pc_audio_175.py']:
 f=r/'stats-59-tools'/name;entries['tools/'+name]=f
entries['binaries/after-a4-manifest.json']=r/'audit-175-after-a4-immutable/manifest.json'
paths=subprocess.check_output(['git','diff','--name-only'],cwd=w,text=True).splitlines();sources={}
for name in paths:
 p=w/name
 if p.is_file() and name.startswith('crates/'):
  entries['final-source/'+name]=p;sources[name]=h(p)
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,f in sorted(entries.items()):z.write(f,name)
verification={'native_revision':'a4','tests':{'core':2748,'data':263,'app':221,'app_ignored':33,'agent':54,'audio':99},'ci_regressions':{'core_integration':4,'app_integration':3,'app_integration_ignored':2},'sources':sources,'gba_source_count':59,'gba_metrics':31,'archive':{'bytes':archive.stat().st_size,'sha256':h(archive),'entries':len(entries)},'scope':'rating sound/music lifecycle and old PC acknowledgement tests; physical PCM/ROM matching and broader draft gates remain'};(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n');shutil.copy2(r/'audit-175-gba-source-manifest-a4.json',out/'gba-source-manifest.json');shutil.copy2(r/'audit-175-gba-compare-a4.log',out/'gba-compare.log');print(verification['archive'])
