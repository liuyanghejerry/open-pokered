use pokered_audio::{audio_manager::AudioManager,music_data::MusicId,sfx_data::SfxId};
fn main() {
 for id in [SfxId::Denied,SfxId::PokedexRating,SfxId::GetItem1,SfxId::CaughtMon,SfxId::LevelUp,SfxId::GetKeyItem,SfxId::GetItem2] {
  let mut m=AudioManager::new();m.play_music(MusicId::POKECENTER);
  for _ in 0..60 {m.update_frame();}
  m.play_sfx(id);let initial=m.sequencer.music_playing;let mut active_music_frames=0;let mut elapsed=0;
  while m.is_sfx_playing() && elapsed<3000 {if m.sequencer.music_playing {active_music_frames+=1;}m.update_frame();elapsed+=1;}
  assert!(elapsed<3000);
  println!("{:?}: initial_music={}, elapsed={}, music_active_during_sfx={}, end_music={}",id,initial,elapsed,active_music_frames,m.sequencer.music_playing);
 }
}
