from pathlib import Path
import re,sys,shutil,json,hashlib
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';rev=sys.argv[1];log=r/f'audit-175-native-{rev}.log';s=log.read_text();assert 'Finished `test`' in s;d=r/f'audit-175-after-{rev}-immutable';d.mkdir(exist_ok=True);manifest={}
for m in re.finditer(r'Executable unittests src/lib.rs \(([^)]+/pokered_(core|data|app|agent|audio)-[a-f0-9]+)\)',s):
 p=Path(m[1]);target=d/f'pokered_{m[2]}';shutil.copy2(p,target);manifest[m[2]]={'source_binary':str(p),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
assert set(manifest)=={'core','data','app','agent','audio'};(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(list(manifest))
