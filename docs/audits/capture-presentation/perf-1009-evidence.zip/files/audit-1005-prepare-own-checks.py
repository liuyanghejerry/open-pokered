from pathlib import Path
import hashlib,json,os,shutil,subprocess
ROOT=Path('/home/jerry/develop/open-pokered');R=ROOT/'.task-tmp/fidelity-39-plus';W=ROOT/'.task-tmp/fidelity-1005-pr261-draw-cost';M=Path('/home/jerry/.cache/open-pokered-fidelity/1005-gba-source');TMP=ROOT/'.task-tmp/fidelity-1005-local-tmp'
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();assert head.startswith('9bce1d63')
assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==b''
entries={}
for record in subprocess.check_output(['git','ls-tree','-rz','--full-tree','HEAD'],cwd=W).split(b'\0'):
 if not record:continue
 meta,name=record.split(b'\t',1);name=name.decode();mode,typ,blob=meta.decode().split()
 if name.startswith('docs/'):continue
 assert typ=='blob'
 p=W/name;data=os.readlink(p).encode() if mode=='120000' else p.read_bytes()
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
 entries[name]={'mode':mode,'git_blob':blob,'sha256':sha(data)}
compiler={p:v for p,v in entries.items()if p.startswith(('crates/','vendor/','.cargo/','run-wasm/'))or p in ['Cargo.toml','Cargo.lock']}
assert 'run-wasm/Cargo.toml'in compiler and 'run-wasm/src/main.rs'in compiler
assert not M.exists();M.mkdir(parents=True);TMP.mkdir(exist_ok=False)
for name,row in compiler.items():
 p=W/name;dest=M/name;dest.parent.mkdir(parents=True,exist_ok=True)
 if row['mode']=='120000':dest.symlink_to(os.readlink(p))
 else:shutil.copy2(p,dest)
 assert sha(os.readlink(dest).encode() if dest.is_symlink() else dest.read_bytes())==row['sha256']
(M/'gfx').symlink_to(ROOT/'gfx',target_is_directory=True)
gfx={str(p.relative_to(ROOT/'gfx')):sha(p.read_bytes())for p in sorted((ROOT/'gfx').rglob('*'))if p.is_file()};assert len(gfx)==702
freeze={'head':head,'parent':'d8d4d2a9473b308e545dc22c30dcc68f3f2e86bf','worktree':str(W),'compiler':compiler,'complete_non_docs':entries,'external_gfx_root':str(ROOT/'gfx'),'external_gfx':gfx,'gfx_symlink_literal':os.readlink(W/'gfx'),'source_clean':True,'no_build_yet':True}
fp=R/'audit-1005-own-source-before.json';fp.write_text(json.dumps(freeze,indent=2)+'\n')
mp=R/'audit-1005-own-gba-mirror.json';mp.write_text(json.dumps({'source_head':head,'mirror':str(M),'compiler_paths':compiler,'gfx_symlink_literal':os.readlink(M/'gfx'),'all_bytes_modes_equal':True},indent=2)+'\n')
host=R/'cargo-1005-host.sh';host.write_text((R/'cargo-984-host.sh').read_text().replace('fidelity-984-physical-move-slots','fidelity-1005-pr261-draw-cost').replace('fidelity-984-local-tmp','fidelity-1005-local-tmp').replace('outside984','outside1005'));host.chmod(0o755)
gba=R/'cargo-1005-gba.sh';gba.write_text((R/'cargo-984-gba.sh').read_text().replace('984-gba-source','1005-gba-source').replace('private984','private1005').replace('fidelity-984-local-tmp','fidelity-1005-local-tmp').replace('fidelity-984-gba-target','fidelity-1005-gba-target').replace('build --offline --release','build --offline --locked --release'));gba.chmod(0o755)
patch=R/'audit-1005-own-source.patch';patch.write_bytes(subprocess.check_output(['git','diff',head+'^',head,'--','crates/pokered-app/src/render/overworld.rs','crates/pokered-app/src/render/session.rs'],cwd=W))
rom=R/'audit-1005-candidate.gba';env={'LD_LIBRARY_PATH':'/tmp/pokered-mgba/usr/lib/x86_64-linux-gnu:/tmp/pokered-build-lib','SDL_AUDIODRIVER':'dummy','SDL_VIDEODRIVER':'dummy','MGBA_COMMAND':'stdbuf -oL -eL /tmp/pokered-mgba/usr/games/mgba -1'}
plan={'source_head':head,'worktree':str(W),'mirror':str(M),'freeze':str(fp),'freeze_sha256':sha(fp.read_bytes()),'mirror_manifest':str(mp),'mirror_manifest_sha256':sha(mp.read_bytes()),'compiler_count':len(compiler),'complete_non_doc_count':len(entries),'external_gfx_count':len(gfx),'source_patch':str(patch),'source_patch_sha256':sha(patch.read_bytes()),'wrapper_sha256':{str(p):sha(p.read_bytes())for p in [host,gba]},'policy':'ROOT_PREREVIEW_REQUIRED_BEFORE_LAUNCH; serial -j1; first stage failure stop; no source edit while checks active; no rerun/threshold/layoutpadding/extra candidate.','coverage':'One complete appdebug lib command includes new liveblock/full/cached pixel regression, all existing renderer/session/walking/dark/animation tests and capture caller/snapshot tests; one ownmirror GBA build + record + 31 unchanged gated metrics compare. No new gameplay/SAVE capture in this runner.','checks':[{'label':'appdebug','cwd':str(W),'command':[str(host),'test','-p','pokered-app','--lib','--features','debug-server','--locked'],'log':str(R/'audit-1005-own-appdebug.log'),'timeout':1800},{'label':'gba-build','cwd':str(M/'crates/pokered-gba'),'command':[str(gba)],'log':str(R/'audit-1005-own-gba-build.log'),'timeout':1800},{'label':'gba-fix','cwd':str(W),'command':['/tmp/pokered-font-cargo-home/bin/agb-gbafix',str(ROOT/'.task-tmp/fidelity-1005-gba-target/thumbv4t-none-eabi/release/pokered-gba'),'-o',str(rom)],'log':str(R/'audit-1005-own-gba-fix.log'),'timeout':60},{'label':'gba-record','cwd':str(W),'command':['python3',str(W/'scripts/gba_performance.py'),'record','--rom',str(rom),'--output',str(R/'audit-1005-own-gba-perf.json'),'--log',str(R/'audit-1005-own-gba-perf-raw.log')],'log':str(R/'audit-1005-own-gba-record.log'),'environment':env,'timeout':150},{'label':'gba-compare','cwd':str(W),'command':['python3',str(W/'scripts/gba_performance.py'),'compare','--baseline',str(W/'crates/pokered-gba/perf-baseline.json'),'--candidate',str(R/'audit-1005-own-gba-perf.json')],'log':str(R/'audit-1005-own-gba-compare.log'),'timeout':60}]}
p=R/'audit-1005-own-check-plan.json';p.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'head':head,'compiler':len(compiler),'non_doc':len(entries),'gfx':len(gfx),'freeze_sha':plan['freeze_sha256'],'patch_sha':plan['source_patch_sha256'],'plan':str(p),'plan_sha':sha(p.read_bytes())}))
