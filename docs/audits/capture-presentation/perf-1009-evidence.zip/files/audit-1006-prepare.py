#!/usr/bin/env python3
"""1006 preparation only: immutable source and historical binary proof; no build/run."""
import hashlib,json,os,subprocess
from pathlib import Path
R=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
W=R.parent/'fidelity-1006-pr261-render-baseline'
MASTER='44f2234823eb5bd0d793ef966871f6028426aaa2'
BEFORE='d8d4d2a9473b308e545dc22c30dcc68f3f2e86bf'
OLD='0fb1b57fd3096ba0332cd814319305fee1dc754b'
AFTER='9bce1d6382bd350721551f5e249e6b7cebd6cd2e'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*a,cwd=W): return subprocess.check_output(['git',*a],cwd=cwd)
def dump(name,d): (R/name).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def tree(ref,cwd=W):
 out={}
 for entry in git('ls-tree','-rz','--full-tree',ref,cwd=cwd).split(b'\0'):
  if not entry: continue
  meta,path=entry.split(b'\t',1);mode,typ,blob=meta.decode().split();p=os.fsdecode(path)
  if not p.startswith('docs/'): out[p]={'mode':mode,'git_blob':blob}
 return out
def freeze():
 assert git('rev-parse','HEAD').decode().strip()==MASTER
 assert not git('status','--porcelain','--untracked-files=all').strip()
 t=tree('HEAD');compiler_keys=json.loads((R/'audit-1005-own-source-before.json').read_text())['compiler']
 assert all(p in t for p in compiler_keys)
 for p,v in t.items():
  f=W/p;b=os.readlink(f).encode() if v['mode']=='120000' else f.read_bytes()
  assert git('hash-object','--stdin',cwd=W) is not None if False else True
  expected=git('cat-file','blob',v['git_blob'])
  assert b==expected,p
  v['sha256']=sha(b)
 gfx=W/'gfx';ext=Path('/home/jerry/develop/open-pokered/gfx')
 if not gfx.exists(): gfx.symlink_to(ext,target_is_directory=True)
 assert gfx.is_symlink() and gfx.resolve()==ext
 gfxmap={str(p.relative_to(ext)):sha(p.read_bytes()) for p in sorted(ext.rglob('*')) if p.is_file()}
 assert len(gfxmap)==702
 return {'head':MASTER,'scope':'literal master44f; complete tracked non-doc NUL tree including literal symlinks; compiler scope includes both run-wasm files','worktree':str(W),'compiler':{p:t[p] for p in compiler_keys},'complete_non_docs':t,'external_gfx_root':str(ext),'external_gfx':gfxmap,'gfx_symlink_literal':os.readlink(gfx),'source_clean':True,'no_build_yet':True}
if __name__=='__main__':
 f=freeze();dump('audit-1006-literal-master-source-before.json',f)
 old=tree(OLD);before=tree(BEFORE);assert old==before
 expanded=json.loads((R/'audit-993-expanded-compiler-source.json').read_text());assert len(expanded['files'])==2173
 for p,v in expanded['files'].items(): assert sha(git('show',f'{BEFORE}:{p}'))==v['sha256'],p
 old2172=json.loads((R/'audit-937-v5-905-source-before.json').read_text());assert old2172['count']==2172
 for p,v in old2172['files'].items(): assert sha(git('show',f'{OLD}:{p}'))==v['sha256'],p
 identity=json.loads((R/'audit-943-after-cli-build-identity.json').read_text());b=Path(identity['binary_path']);assert sha(b.read_bytes())==identity['binary_sha256'];assert identity['source_head']==OLD and identity['exit']==0 and identity['source_exact_after']
 a=tree(AFTER);changed=[p for p in before if a.get(p)!=before[p]];assert changed==['crates/pokered-app/src/render/overworld.rs','crates/pokered-app/src/render/session.rs']
 proof={'status':'PASS','scope':'historical943 binary is source-equivalent optimization baseline d8d, NOT literal master44f','historical_source':OLD,'public_base':BEFORE,'all_non_doc_mode_blob_count':len(before),'all_non_doc_mode_blob_equal':old==before,'legacy2172_manifest_unchanged':True,'legacy2172_manifest_sha256':sha((R/'audit-937-v5-905-source-before.json').read_bytes()),'expanded2173_manifest_sha256':sha((R/'audit-993-expanded-compiler-source.json').read_bytes()),'expanded2173_all_blobs_verified':True,'run_wasm_paths':['run-wasm/Cargo.toml','run-wasm/src/main.rs'],'historical_binary':str(b),'binary_sha256':identity['binary_sha256'],'identity_path':str(R/'audit-943-after-cli-build-identity.json'),'identity_sha256':sha((R/'audit-943-after-cli-build-identity.json').read_bytes()),'optimization_source':AFTER,'optimization_source_delta':changed}
 dump('audit-1006-historical-before-equivalence.json',proof)
 review={'status':'PASS_NO_BLOCKER','kind':'independent static source review; no new tests or actual claimed','source':AFTER,'parent':BEFORE,'patch_sha256':sha((R/'audit-1005-own-source.patch').read_bytes()),'frozen_manifest_sha256':sha((R/'audit-1005-own-source-before.json').read_bytes()),'production_files':changed,'findings':[{'topic':'mutation window','result':'key creation through draw_full and background cache key contains no Game.update or live map-data mutation; resource/cache/framebuffer mutations do not modify the borrowed live grid'},{'topic':'presence and dimensions','result':'shared hash exactly matches former OverworldVisualKey FNV bytes: absent0; present1,width,height,blocks. Some(0) remains a valid provided value; None recomputes for direct callers'},{'topic':'live CUT/gate edits','result':'each render invocation re-reads all live blocks; no cross-frame fingerprint field added. Existing whole-frame and background cache invalidation both receive the changed value'},{'topic':'output and owners','result':'only same-call hash forwarding changes; no persistent owner, render count, threshold, scene or asset changes'},{'topic':'meaningful regression','result':'new real RenderSession mutation test keeps player stationary, edits a visible live block, rejects Reuse, compares all packed pixels and palette to uncached draw, then allows next-frame Reuse. This is a live-grid contract test, not an actual CUT interaction'}],'verification_reported_by_owner':{'app_debug':{'passed':330,'ignored':39},'GBA':{'rows_passed':31,'movement_draw_max_before':3114,'movement_draw_max_after':3107,'unchanged_limit':3113.1,'render_count_unchanged':24},'scope':'owner/root terminal results; no independent duplicate builds'},'actual_plan_boundary':'headless run updates without RenderSession; capture_frame draws through PokemonGame.draw. Planned PNGs establish visible equality, while cached path is verified by RenderSession tests and GBA benchmark.','unsupported_claims':['new original-source animation parity','headless control exercising RenderSession','all scene framebuffer equivalence','historical943 is literal master']}
 dump('audit-1006-cross-review-1005.json',review)
 (R/'audit-1006-cross-review-1005.md').write_text('# Independent1005 review\n\nPASS, no source blocker in9bce1d63 againstd8d4d2a9. The fingerprint is passed only within one render call; no live map mutation occurs before consumption. Presence/dimensions and Some(0) are preserved, direct callers recompute, and each subsequent render still reads the live grid. No persistent owner, render count or performance threshold changes.\n\nThe new stationary live-block-edit test compares the complete cached framebuffer and display palette against an uncached draw and verifies invalidation followed by reuse. Owner/root reported330 app tests and31 GBA rows passing; movement draw_max3114→3107 against the unchanged3113.1 limit.\n\nPlanned headless PNG control is visible-output evidence only: it calls Game.draw and does not exercise RenderSession. Cache-path evidence is the semantic test and GBA measurement. Literal44f master, historical0fb/d8d and9bce must retain separate identities.\n')
 print(json.dumps({'status':'prepared_no_build_no_actual','baseline_head':MASTER,'compiler':len(f['compiler']),'non_doc':len(f['complete_non_docs']),'gfx':len(f['external_gfx']),'943_equivalence':True,'review':'PASS_NO_BLOCKER'}))
