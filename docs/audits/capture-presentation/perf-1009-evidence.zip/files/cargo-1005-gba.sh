#!/bin/bash
set -eu
case "$PWD" in
 /home/jerry/.cache/open-pokered-fidelity/1005-gba-source/crates/pokered-gba) ;;
 *) echo "Refusing outside private1005GBA mirror" >&2; exit 64 ;;
esac
export TMPDIR=/home/jerry/develop/open-pokered/.task-tmp/fidelity-1005-local-tmp
export CARGO_HOME=/tmp/fidelity-cargo-home CARGO_INCREMENTAL=0
unset CARGO_PROFILE_DEV_OPT_LEVEL CARGO_PROFILE_DEV_DEBUG
exec cargo +nightly-2025-12-07 build --offline --locked --release --features perf-benchmark --target-dir /home/jerry/develop/open-pokered/.task-tmp/fidelity-1005-gba-target -j1
