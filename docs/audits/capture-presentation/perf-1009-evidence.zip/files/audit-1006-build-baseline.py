#!/usr/bin/env python3
"""Default validates only. --execute is a single literal44f fresh CLI build, never actual gameplay."""
import argparse,datetime,hashlib,importlib.util,json,shutil,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prepare1006',R/'audit-1006-prepare.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
freeze_path=R/'audit-1006-literal-master-source-before.json'
expected=json.loads(freeze_path.read_text());assert p.freeze()==expected
cmd=[str(R/'cargo-1006-baseline-host.sh'),'build','-p','pokered-app','--bin','pokered-app','--features','debug-server','--locked']
a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');args=a.parse_args()
if not args.execute:
 print(json.dumps({'status':'prepared_no_build','command':cmd,'worktree':str(p.W),'source':p.MASTER,'freeze_sha256':p.sha(freeze_path.read_bytes())}));raise SystemExit
identity_path=R/'audit-1006-before-cli-identity.json'
assert not identity_path.exists(),'single-build identity already exists; refusing second attempt'
Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-1006-local-tmp').mkdir(exist_ok=True)
identity={'source_head':p.MASTER,'source_freeze':str(freeze_path),'source_freeze_sha256':p.sha(freeze_path.read_bytes()),'command':cmd,'cwd':str(p.W),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','scope':'literal master44f once-built CLI; private independent target; no gameplay'}
identity_path.write_text(json.dumps(identity,indent=2)+'\n')
log=R/'audit-1006-before-cli-build.log'
with log.open('wb') as f: result=subprocess.run(cmd,cwd=p.W,stdout=f,stderr=subprocess.STDOUT)
identity.update(status='terminal',exit=result.returncode,build_log=str(log),build_log_sha256=p.sha(log.read_bytes()))
identity['source_bytes_modes_and_gfx_equal_after']=p.freeze()==expected
assert identity['source_bytes_modes_and_gfx_equal_after']
if result.returncode==0:
 source=p.W.parent/'fidelity-1006-pr261-render-baseline-target/debug/pokered-app'
 dest=R/'audit-1006-before-44f-debug';assert not dest.exists();shutil.copy2(source,dest)
 identity.update(binary=str(dest),binary_sha256=p.sha(dest.read_bytes()),binary_bytes=dest.stat().st_size,maps=str(p.W/'crates/pokered-data/maps'))
identity_path.write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity))
raise SystemExit(result.returncode)
