# 1005：PR261 绘制成本修复交接

候选 clean `9bce1d6382bd350721551f5e249e6b7cebd6cd2e`，父版本为实际 PR261 `d8d4d2a9`。只改 `render/overworld.rs` 和 `render/session.rs`，含一个新缓存／完整像素回归。没有编辑 W905 或 W998，也没有推送。

原 CI ROM 在本地逐项复现七个场景及 3114 > 3113.1 的确定失败。d8d 相对 actual master44f 的新捕球检查只在战斗更新分支，不能将它归因为 Overworld 的额外检查。修复的是既有热路径冗余：整帧缓存已扫描的 live map 指纹在同一帧传给背景缓存，省去第二次完整方块 FNV 扫描；每帧仍检查实时方块，未建立跨帧 revision 或新状态所有者。

Root 审过 runner 后只启动一次顺序检查，五阶段 exit0。完整 app debug-server：330 通过、39 忽略，新 live block 修改→cache miss→完整像素／调色板一致、旧行走／水面／暗洞缓存，以及原普通捕获和老人教学续接均通过。2173 compiler、2691 NUL 非文档路径的 bytes/modes/blobs 和702 gfx 在每阶段后均等于冻结值。

GBA 独立 fresh mirror/target 构建并只记录一次：31 个原门禁全部通过。Movement max3114→3107，原门槛3113.1不变；draw/per-frame225→224，24 renders不变，七个场景所有 samples/renders也相同。Trainer update223、idle349、Oak draw/per-frame2996仍通过。保留 CI 失败、本地精确失败复现和最初缺 libmgba 的无 benchmark 环境失败，没有rerun或调整门槛。

本项未新增普通输入／SAVE／截图；1006负责 literal master44f 与 current9bce 配对，1007 nativeCLI构建另有root记录，9430fb不冒称master。此处是本地单候选通过，尚未声称发布后远端CI全绿。

`audit-1005-final-handoff.json` 列出日志、wrapper/runner、精确diff、前后完整sourcefreeze及CI失败复现的显式归档输入与SHA；不得glob整批audit目录。CI artifactZIP、候选ROM/ELF/nativeexe保持本地，不进入公开证据ZIP。原捕获矩阵和历史身份不覆盖。
