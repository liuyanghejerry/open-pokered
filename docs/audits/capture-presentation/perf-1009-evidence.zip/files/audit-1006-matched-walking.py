#!/usr/bin/env python3
"""Prepared1006 control. Default prints plan. --execute requires frozen literal44f and9bce CLIs.
No gameplay setters, skipping intro, startup warp, forced encounter, or retry of advancing requests.
Headless capture_frame uses Game.draw, not RenderSession; cache proof remains tests/GBA.
"""
import argparse,datetime,hashlib,json,os,shutil,socket,subprocess,tempfile,time,traceback
from pathlib import Path
R=Path(__file__).resolve().parent
ROOT=R.parents[1]
MASTER='44f2234823eb5bd0d793ef966871f6028426aaa2'
OLD='0fb1b57fd3096ba0332cd814319305fee1dc754b'
PUBLIC='d8d4d2a9473b308e545dc22c30dcc68f3f2e86bf'
AFTER='9bce1d6382bd350721551f5e249e6b7cebd6cd2e'
FIXTURE=Path((R/'audit-894-native-poison-legal-after-path.txt').read_text().strip())/'single-1'
SAVE=FIXTURE/'ordinary.sav'
SAVE_SHA='f152133f0b7f90a0ab2191aa73e3273e99a6d25bffe4d5d2cf1aaee851703493'
PROVIDERS=[('literal-master-before',R/'audit-1006-before-cli-identity.json',MASTER),('optimization-before',R/'audit-943-after-cli-build-identity.json',OLD),('optimization-after',R/'audit-1007-after-cli-identity.json',AFTER)]
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def checksum(b):return {'computed':(255-sum(b[0x2598:0x3523]))&255,'stored':b[0x3523]}
def projection(s):return {k:s.get(k) for k in ['frame_count','screen','map_id','map_name','player_x','player_y','direction','player_direction','party','money','dialogue','choice','active_script_effect']}
def loadidentity(label,p,head):
 d=json.loads(p.read_text());assert d['source_head']==head and d['exit']==0
 b=Path(d.get('binary',d.get('binary_path')));assert sha(b.read_bytes())==d['binary_sha256']
 maps=Path(d.get('maps',d.get('maps_path')));assert maps.is_dir()
 return {'label':label,'identity':str(p),'identity_sha256':sha(p.read_bytes()),'source_head':head,'binary':str(b),'binary_sha256':d['binary_sha256'],'maps':str(maps),'historical_equivalent_public':PUBLIC if head==OLD else None}
def plan():
 return {'status':'PREPARED_NOT_EXECUTED','scope':'3-provider visible equality; headless Game.draw does not exercise RenderSession','source_master':MASTER,'optimization_parent':PUBLIC,'source_after':AFTER,'fixture':str(SAVE),'fixture_sha256':SAVE_SHA,'fixture_provenance':'Existing ordinarySAVE from legal Rattata poison control24ab, not fresh campaign; first0HP/statusNone and second31HP/statusNone after completed generic field event. No remaining poison. Original file unchanged.','seed':42,'cold_continue_prefix':'On literal master, A on frame indices0,32,64... until first Overworld (max4000); retain exact per-frame buttons and replay them unchanged on both optimization providers. Abort on unexpected battle/Oak/naming.','settle_and_walk':[{'button':None,'frames':96},{'button':'right','frames':32},{'button':None,'frames':16},{'button':'left','frames':16},{'button':None,'frames':32}],'same_frame_sampling':'final frame only, same actual frame_count across all3; full PNG bytes/pixels and common gameplay projection','mutation_policy':'Only private preboot copies of ordinarySAVE/sidecar/binary, same-hash checks; ordinary inputs and readonly get_state/capture_frame. No live writes; no advance retry.','SAVE_scope':'Input ordinarySAVE main checksum validated and all copies byte-exact. No new gameplay SAVE is needed for renderer-only optimization.','cached_path_proof':'1005 real RenderSession live-grid/pixel test330 app suite +31 GBA gates; no headless cached-render claim.'}
class Client:
 def __init__(self,port,events):
  until=time.monotonic()+30
  while True:
   try:self.s=socket.create_connection(('127.0.0.1',port),timeout=2);break
   except OSError:
    if time.monotonic()>until:raise
    time.sleep(.05)
  self.s.settimeout(30);self.f=self.s.makefile('rwb');self.events=events
 def cmd(self,**kw):
  self.f.write((json.dumps(kw)+'\n').encode());self.f.flush();line=self.f.readline()
  assert line,'closed connection; no retry'
  ans=json.loads(line);self.events.write(json.dumps({'request':kw,'response':ans},ensure_ascii=False)+'\n');self.events.flush()
  assert ans.get('ok'),ans
  return ans
 def state(self):return self.cmd(cmd='get_state')['data']
 def frame(self,button):self.cmd(cmd='press_timeline',buttons=[button],advance=True);return self.state()
 def close(self):self.f.close();self.s.close()
def run_one(info,out,prefix):
 trial=out/info['label'];trial.mkdir();local=trial/'pokered-app';shutil.copy2(info['binary'],local);assert sha(local.read_bytes())==info['binary_sha256']
 local_save=trial/'ordinary.sav';shutil.copy2(SAVE,local_save)
 side=FIXTURE/'ordinary.script_flags.json';shutil.copy2(side,trial/side.name)
 assert sha(local_save.read_bytes())==SAVE_SHA
 (trial/'gfx').symlink_to(ROOT/'gfx',target_is_directory=True)
 env=dict(os.environ,POKERED_MAPS_DIR=info['maps'],LD_LIBRARY_PATH='/tmp/pokered-build-lib')
 with socket.socket() as reserve:reserve.bind(('127.0.0.1',0));port=reserve.getsockname()[1]
 argv=[str(local),'run','--headless','--speed','0','--seed','42','--debug-port',str(port),'--save',str(local_save),'--lang','en','--no-audio']
 events=(trial/'commands.jsonl').open('w');log=(trial/'process.log').open('wb');proc=None;c=None;record={'provider':info,'argv':argv,'private_cwd':str(trial),'input_SAVE_sha256':SAVE_SHA,'input_sidecar_sha256':sha(side.read_bytes()),'initial_checksum':checksum(local_save.read_bytes()),'status':'running'}
 dump(trial/'record.json',record)
 try:
  proc=subprocess.Popen(argv,cwd=trial,env=env,stdout=log,stderr=subprocess.STDOUT);c=Client(port,events)
  initial=c.state();assert initial['frame_count']==0,initial
  if prefix is None:
   prefix=[]
   while len(prefix)<4000:
    button='a' if len(prefix)%32==0 else None;state=c.frame(button);prefix.append(button)
    assert state['frame_count']==len(prefix)
    assert state['screen'] not in ['battle','oak','oak-speech','naming'],state
    if state['screen']=='overworld':break
   else:raise AssertionError('CONTINUE failed within4000 frames')
   dump(out/'cold-continue-buttons.json',prefix)
  else:
   for i,button in enumerate(prefix,1):
    state=c.frame(button);assert state['frame_count']==i
  loaded=c.state();assert loaded['screen']=='overworld' and loaded['map_name']=='RedsHouse2F' and (loaded['player_x'],loaded['player_y'])==(3,6),loaded
  actions=prefix.copy()
  for button,count in [(None,96),('right',32),(None,16),('left',16),(None,32)]:
   for _ in range(count):
    state=c.frame(button);actions.append(button);assert state['frame_count']==len(actions)
    assert state['screen']=='overworld' and state['map_name']=='RedsHouse2F',state
  final=c.state();assert final['player_y']==6 and final['player_x']!=3,final
  for k in ['party','money']:assert loaded.get(k)==final.get(k),(k,loaded.get(k),final.get(k))
  shot=trial/'final.png';capture=c.cmd(cmd='capture_frame',path=str(shot));after=c.state();assert after['frame_count']==final['frame_count']
  assert projection(after)==projection(final)
  assert sha(local_save.read_bytes())==SAVE_SHA,'no ordinarySAVE write intended'
  record.update(status='PASS',loaded=loaded,final=final,final_projection=projection(final),capture_response=capture,input_frames=len(actions),final_frame=final['frame_count'],full_buttons_sha256=sha((json.dumps(actions,separators=(',',':'))+'\n').encode()),PNG=str(shot),PNG_sha256=sha(shot.read_bytes()),saved_file_unchanged=True)
  dump(trial/'full-buttons.json',actions)
  return prefix,record
 except BaseException as e:
  record.update(status='FAIL_STOPPED',error=repr(e),traceback=traceback.format_exc());raise
 finally:
  if c:
   try:c.close()
   except OSError:pass
  if proc and proc.poll() is None:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill();proc.wait()
  log.close();events.close();record['process_exit']=proc.returncode if proc else None;dump(trial/'record.json',record)
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');args=a.parse_args()
 if not args.execute:print(json.dumps(plan(),indent=2));return
 assert sha(SAVE.read_bytes())==SAVE_SHA and checksum(SAVE.read_bytes())['computed']==checksum(SAVE.read_bytes())['stored']
 proof=json.loads((R/'audit-1006-historical-before-equivalence.json').read_text());assert proof['status']=='PASS' and proof['all_non_doc_mode_blob_equal']
 infos=[loadidentity(*p) for p in PROVIDERS]
 out=Path(tempfile.mkdtemp(prefix='audit-1006-matched-walking-',dir=R));(R/'audit-1006-matched-walking-path.txt').write_text(str(out)+'\n');dump(out/'plan.json',plan());shutil.copy2(__file__,out/'controller.py')
 prefix=None;records=[]
 try:
  for info in infos:
   prefix,record=run_one(info,out,prefix);records.append(record);print(info['label'],record['status'],record['final_frame'],record['PNG_sha256'],flush=True)
  assert len({r['final_frame'] for r in records})==1
  assert len({r['full_buttons_sha256'] for r in records})==1
  assert len({r['PNG_sha256'] for r in records})==1
  assert all(records[0]['final_projection']==r['final_projection'] for r in records)
  summary={'status':'PASS','records':records,'same_complete_buttons':True,'same_actual_frame':True,'same_PNG_bytes':True,'same_common_gameplay_projection':True,'cache_path_exercised':False,'scope':plan()['scope']}
  dump(out/'summary.json',summary);print(out,flush=True)
 except BaseException as e:
  dump(out/'failure.json',{'status':'FAIL_STOPPED','error':repr(e),'traceback':traceback.format_exc(),'completed_records':records});raise
if __name__=='__main__':main()
