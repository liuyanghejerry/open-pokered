"""Single frozen candidate, serial fail-stop checks. Default is read-only preflight.
Root must review this script and plan before author executes --execute.
No publisher, rerun, threshold edit, shared target clean or process-wide kill.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,subprocess,time
R=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
PLAN=R/'audit-1008-own-check-plan.json'
PLAN_SHA='4995651e14f24b8ce8b00245900a031ab6eee3184fbb493228cbb2b321292e4f'
sha=lambda b:hashlib.sha256(b).hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert sha(PLAN.read_bytes())==PLAN_SHA
plan=json.loads(PLAN.read_text());W=Path(plan['worktree']);M=Path(plan['mirror']);F=Path(plan['freeze'])
assert sha(F.read_bytes())==plan['freeze_sha256'];f=json.loads(F.read_text())
def verify_source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==plan['source_head']
 assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==b''
 for name,row in f['complete_non_docs'].items():
  p=W/name
  data=os.readlink(p).encode()if row['mode']=='120000'else p.read_bytes()
  assert sha(data)==row['sha256'],('source bytes',name)
  assert p.is_symlink()if row['mode']=='120000'else not p.is_symlink()
  if row['mode']!='120000':assert bool(p.stat().st_mode&0o111)==(row['mode']=='100755'),('source mode',name)
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['git_blob'],('source Git blob',name)
 for name,row in f['compiler'].items():
  p=M/name;data=os.readlink(p).encode()if row['mode']=='120000'else p.read_bytes()
  assert sha(data)==row['sha256'],('mirror bytes',name)
  assert p.is_symlink()if row['mode']=='120000'else not p.is_symlink()
  if row['mode']!='120000':assert bool(p.stat().st_mode&0o111)==(row['mode']=='100755'),('mirror mode',name)
 assert os.readlink(W/'gfx')==f['gfx_symlink_literal']
 assert os.readlink(M/'gfx')==f['external_gfx_root']
 assert all(sha((Path(f['external_gfx_root'])/n).read_bytes())==h for n,h in f['external_gfx'].items())
 for name,digest in plan['wrapper_sha256'].items():assert sha(Path(name).read_bytes())==digest
 assert sha(Path(plan['source_patch']).read_bytes())==plan['source_patch_sha256']
 return {'utc':stamp(),'head':plan['source_head'],'compiler_count':len(f['compiler']),'complete_non_doc_count':len(f['complete_non_docs']),'gfx_count':len(f['external_gfx']),'all_bytes_modes_blobs_equal':True,'source_clean':True}
def after_freeze(label):
 checked=verify_source();snapshot={k:v for k,v in f.items()if k!='no_build_yet'};snapshot['checked_after_stage']=label;snapshot['check']=checked
 p=R/f'audit-1008-own-source-after-{label}.json';p.write_text(json.dumps(snapshot,indent=2)+'\n')
 return {'path':str(p),'sha256':sha(p.read_bytes()),'check':checked}
parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');args=parser.parse_args()
check=verify_source()
if not args.execute:
 proof={'result':'READONLY_PREFLIGHT_PASS_NO_CHECK_EXECUTED','script_sha256':sha(Path(__file__).read_bytes()),'plan_sha256':PLAN_SHA,'source':check,'commands':plan['checks'],'coverage':plan['coverage']}
 (R/'audit-1008-own-runner-preflight.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps({'result':proof['result'],'script_sha256':proof['script_sha256'],'head':plan['source_head'],'checks':len(plan['checks']),'source':check}),flush=True)
 raise SystemExit(0)
result_path=R/'audit-1008-own-check-results.json';assert not result_path.exists(),'No rerun or overwrite of any prior candidate result'
lock=R/'audit-1008-own-running.lock';fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(os.getpid()).encode());os.close(fd)
results={'head':plan['source_head'],'plan_sha256':PLAN_SHA,'script_sha256':sha(Path(__file__).read_bytes()),'started_utc':stamp(),'checks':[],'complete':False,'all_pass':False}
exit_code=1
try:
 for item in plan['checks']:
  verify_source();log=Path(item['log']);assert not log.exists(),('do not overwrite old check log',str(log))
  env=dict(os.environ);env.update(item.get('environment',{}));print('START '+item['label'],flush=True)
  entry={'label':item['label'],'command':item['command'],'cwd':item['cwd'],'log':str(log),'start_utc':stamp()};begin=time.monotonic()
  with log.open('w')as out:
   try:entry['exit']=subprocess.run(item['command'],cwd=item['cwd'],env=env,stdout=out,stderr=subprocess.STDOUT,timeout=item['timeout']).returncode
   except subprocess.TimeoutExpired:entry['exit']=124;entry['timeout']=True
  entry['end_utc']=stamp();entry['wall_seconds']=time.monotonic()-begin;entry['log_sha256']=sha(log.read_bytes())
  entry['counts']=[[int(x)for x in row]for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())]
  entry['source_after']=after_freeze(item['label']);results['checks'].append(entry);result_path.write_text(json.dumps(results,indent=2)+'\n')
  print('END '+item['label']+' exit='+str(entry['exit']),flush=True)
  if entry['exit']!=0:
   results['failure_stage']=item['label'];break
 else:
  results['complete']=True;results['all_pass']=True;exit_code=0
 results['finished_utc']=stamp();results['all_own_child_commands_terminal']=True
 if (R/'audit-1008-candidate.gba').exists():results['candidate_rom_sha256']=sha((R/'audit-1008-candidate.gba').read_bytes())
 result_path.write_text(json.dumps(results,indent=2)+'\n')
finally:
 lock.unlink(missing_ok=True)
raise SystemExit(exit_code)
