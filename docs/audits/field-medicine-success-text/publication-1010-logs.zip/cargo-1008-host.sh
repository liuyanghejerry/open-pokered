#!/bin/bash
case "$PWD" in
  /home/jerry/develop/open-pokered/.task-tmp/fidelity-1008-field-medicine-perf) ;;
  *) echo "Refusing build outside1008 worktree" >&2; exit 64 ;;
esac
export TMPDIR=/home/jerry/develop/open-pokered/.task-tmp/fidelity-1008-local-tmp
export CARGO_INCREMENTAL=0 LD_LIBRARY_PATH=/tmp/pokered-build-lib
export PATH=/home/jerry/.local/share/starheir-build/sysroot/usr/bin:$PATH
export PKG_CONFIG_PATH=/home/jerry/.local/share/starheir-build/sysroot/usr/lib/x86_64-linux-gnu/pkgconfig
export CARGO_HOME=/tmp/fidelity-cargo-home
export CARGO_PROFILE_DEV_OPT_LEVEL=0 CARGO_PROFILE_DEV_DEBUG=0
task_subcommand="$1"; shift
exec cargo "$task_subcommand" --offline --target-dir /home/jerry/develop/open-pokered/.task-tmp/fidelity-1008-field-medicine-perf-target -j1 "$@"
