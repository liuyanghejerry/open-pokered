"""Read-only recomputation of completed 1008 results; writes only new handoff files."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess
R=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(name):return json.loads((R/name).read_text())
def file_record(path):
 p=Path(path)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
results=read('audit-1008-own-check-results.json')
assert results['complete'] and results['all_pass'] and results['all_own_child_commands_terminal']
assert not (R/'audit-1008-own-running.lock').exists()
plan=read('audit-1008-own-check-plan.json');freeze=read('audit-1008-own-source-before.json')
W=Path(plan['worktree']);M=Path(plan['mirror'])
assert results['head']==plan['source_head']=='744ebbb9b891db442488f79f3d22f462e698956d'
assert sha((R/'audit-1008-own-check-plan.json').read_bytes())==results['plan_sha256']
assert sha((R/'audit-1008-run-own-checks.py').read_bytes())==results['script_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==results['head']
assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==b''
expected=['appdebug','appdefault','determinism','gba-build','gba-fix','gba-record','gba-compare']
assert [c['label'] for c in results['checks']]==expected
for check in results['checks']:
 assert check['exit']==0
 assert sha(Path(check['log']).read_bytes())==check['log_sha256']
 after=Path(check['source_after']['path']);assert sha(after.read_bytes())==check['source_after']['sha256']
 post=json.loads(after.read_text())
 for key in ['compiler','complete_non_docs','external_gfx','gfx_symlink_literal']:
  assert post[key]==freeze[key],(check['label'],key)
 assert post['check']['all_bytes_modes_blobs_equal'] and post['check']['source_clean']
for field,base in [('complete_non_docs',W),('compiler',M)]:
 for name,row in freeze[field].items():
  p=base/name;data=os.readlink(p).encode() if row['mode']=='120000' else p.read_bytes()
  assert sha(data)==row['sha256']
  assert p.is_symlink()==(row['mode']=='120000')
  if not p.is_symlink():assert bool(p.stat().st_mode&0o111)==(row['mode']=='100755')
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['git_blob']
assert os.readlink(W/'gfx')==freeze['gfx_symlink_literal']
assert os.readlink(M/'gfx')==freeze['external_gfx_root']
for name,digest in freeze['external_gfx'].items():assert sha((Path(freeze['external_gfx_root'])/name).read_bytes())==digest
for name,digest in plan['wrapper_sha256'].items():assert sha(Path(name).read_bytes())==digest
for c,n in zip(results['checks'][:3],[(330,39),(319,37),(10,0)]):assert c['counts']==[[n[0],0,n[1]]]
rom=R/'audit-1008-candidate.gba';assert sha(rom.read_bytes())==results['candidate_rom_sha256']
metrics=read('audit-1008-own-gba-perf.json');prior=read('audit-1005-own-gba-perf.json')
assert set(metrics['scenarios'])==set(prior['scenarios'])
scenario_comparison={}
for name,current in metrics['scenarios'].items():
 old=prior['scenarios'][name]
 scenario_comparison[name]={'samples':current['samples'],'renders':current['renders'],'same_samples_renders_as_1005':all(current[k]==old[k] for k in ['samples','renders']),'changed_metrics_vs_1005':{k:{'1005':old[k],'1008':v}for k,v in current.items()if old[k]!=v}}
compare_log=(R/'audit-1008-own-gba-compare.log').read_text()
core=read('audit-1008-retained-core-proof.json');mapping=read('audit-1008-private-source-mapping.json')
# Explicit selected public audit inputs: never glob shared evidence directories.
inputs=['audit-1008-finalize.py','audit-1008-own-check-results.json','audit-1008-own-check-plan.json','audit-1008-own-source-before.json','audit-1008-own-gba-mirror.json','audit-1008-own-source.patch','audit-1008-private-source-mapping.json','audit-1008-retained-core-proof.json','audit-1008-run-own-checks.py','audit-1008-own-runner-preflight.json','audit-1008-root-prereview.json','cargo-1008-host.sh','cargo-1008-gba.sh','audit-1008-merge-1005.log','audit-1008-initial-reader-failure.json','audit-1008-prepare-initial-dict-reader.py','audit-1008-prepare-own-checks-v2.py','audit-1008-own-checks-console.log','audit-1008-own-gba-perf.json','audit-1008-own-gba-perf-raw.log']
for check in results['checks']:inputs.extend([str(Path(check['log']).name),str(Path(check['source_after']['path']).name)])
selected=[file_record(R/name)for name in inputs]
assert len(selected)==len({x['path']for x in selected})
proof={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS_COMPLETE_7_SERIAL_STAGES','head':results['head'],'worktree':str(W),'branch':'test/field-medicine-perf-1008','parents':{'clean_920':'6a8b151a19d0fb225bd941f90ccc283887a9515a','merged_1005':'9bce1d6382bd350721551f5e249e6b7cebd6cd2e','old_prepared269':'a07a79148022a28579cb9bd18939969841930fe6'},'changes':mapping,'test_counts':{'appdebug':{'passed':330,'ignored':39},'appdefault':{'passed':319,'ignored':37},'determinism':{'passed':10,'ignored':0}},'core_retained_original_identity_only':core,'source_identity':{'complete_compiler':len(freeze['compiler']),'NUL_non_docs_including_literal_symlink_and_modes':len(freeze['complete_non_docs']),'gfx':len(freeze['external_gfx']),'all_7_before_after_full_records_and_current_bytes_modes_blobs_equal':True,'clean_HEAD':True},'checks':results['checks'],'GBA':{'candidate_rom':file_record(rom),'unchanged_31_gate_compare_exit':0,'compare_output':compare_log,'scenario_comparison_vs_1005':scenario_comparison},'new_gameplay_or_SAVE_or_screen_controls':False,'publication_policy':'No push/PR/merge. Await actual261 MERGED; future freshmaster docs-only source identity must be proven, otherwise STOP and coordinate. No reuse of old1000publisher/sourceeq. Historical920 actual/source/SAVE identities remain unchanged.','preserved_failure':'initial preparation reader compared SHA string against old manifest record dict; corrected only metadata reader in v2 before builds; original script and diagnostic retained. No gameplay/test failure in this seven-stage run.','explicit_public_inputs':selected,'excluded_from_public_archive':['GBA ROM/ELF','native executable','external gfx binaries','whole shared audit directory','unrelated grouped audit937 logs'],'all_runner_and_own_child_commands_terminal':True}
for name in ['audit-1008-final-handoff.json','audit-1008-final-handoff.md']:assert not (R/name).exists(),name
(R/'audit-1008-final-handoff.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
lines=['# 1008 field medicine + map fingerprint performance integration','',f"Frozen clean `{results['head']}`: clean920 `6a8b151a` merged exact1005 `9bce1d63` without conflicts. Relative1005 only the two field-medicine source paths; relativeold269 only the two renderer files.",'','Seven serial `-j1` stages all exited0, once: appdebug330PASS/39ignored, default319PASS/37ignored, determinism10PASS, fresh own-mirror GBA build/fix/record/compare. All31 unchanged gates pass. Core2934 is retained solely under originala07a/v5 identity with exact component mapping; no new core test was run.','',f"Current/before/after identity: {len(freeze['compiler'])} complete compiler paths, {len(freeze['complete_non_docs'])} NUL-listed non-doc paths with Git blob/mode/literal symlink, {len(freeze['external_gfx'])} external gfx; all seven poststage proofs and current clean source match.",'','GBA current measurements:']
for n,s in metrics['scenarios'].items():lines.append(f"- `{n}`: samples{s['samples']}, renders{s['renders']}, drawmax{s['draw_max_ticks']}, draw/frame{s['draw_per_frame_ticks']}, updateavg{s['update_avg_ticks']}.")
lines.extend(['','No new actual input/SAVE/screenshots; historical920 evidence retains its old source labels. Initial metadata-reader failure is preserved separately. No publisher or remoteCI run. Root must wait for actual261 merge, then prove freshmaster has no unexpected compiler/non-doc changes before any result reuse.','',f"Candidate ROM SHA256 `{results['candidate_rom_sha256']}` (not included in public evidence input list).",'',f"HandoffJSON: `{sha((R/'audit-1008-final-handoff.json').read_bytes())}`. Exact logs, commands, wrappers, seven source-after manifests and explicit selected archive inputs are listed there."])
(R/'audit-1008-final-handoff.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'result':proof['result'],'head':results['head'],'handoff_sha256':sha((R/'audit-1008-final-handoff.json').read_bytes()),'md_sha256':sha((R/'audit-1008-final-handoff.md').read_bytes()),'explicit_public_input_count':len(selected),'ROM_sha256':results['candidate_rom_sha256']}))
