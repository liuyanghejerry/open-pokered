from pathlib import Path
import hashlib,json,os,shutil,subprocess
ROOT=Path('/home/jerry/develop/open-pokered');R=ROOT/'.task-tmp/fidelity-39-plus';W=ROOT/'.task-tmp/fidelity-1008-field-medicine-perf';M=Path('/home/jerry/.cache/open-pokered-fidelity/1008-gba-source');TMP=ROOT/'.task-tmp/fidelity-1008-local-tmp'
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();assert head=='744ebbb9b891db442488f79f3d22f462e698956d'
assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==b''

def non_doc_delta(base):
 return [p.decode() for p in subprocess.check_output(['git','diff','--name-only','-z',base,head],cwd=W).split(b'\0') if p and not p.startswith(b'docs/')]
assert non_doc_delta('9bce1d6382bd350721551f5e249e6b7cebd6cd2e')==['crates/pokered-core/src/items/bag_use.rs','crates/pokered-data/src/dialog_text.rs']
assert non_doc_delta('a07a79148022a28579cb9bd18939969841930fe6')==['crates/pokered-app/src/render/overworld.rs','crates/pokered-app/src/render/session.rs']
assert subprocess.check_output(['git','diff','6a8b151a19d0fb225bd941f90ccc283887a9515a',head,'--','crates/pokered-core','crates/pokered-data','Cargo.toml','Cargo.lock','vendor/','.cargo/'],cwd=W)==b''
batchpath=R/'audit-937-batch-results-v5.json'
assert sha(batchpath.read_bytes())=='851fc416b16f10a8329c3efe94c99a6cfc865b77be5378b8e4f54267dcd52798'
batch=json.loads(batchpath.read_text());group=batch['groups']['920'];assert group['tested_merge']=='a07a79148022a28579cb9bd18939969841930fe6' and group['status']=='PASS'
oldmanifest=Path(group['before_manifest']);assert sha(oldmanifest.read_bytes())==group['before_manifest_sha256'];oldfiles=json.loads(oldmanifest.read_text())['files']
corecheck=next(c for c in group['commands']if c['label']=='core');assert corecheck['exit']==0 and corecheck['test_results']==[{'outcome':'ok','passed':2934,'failed':0,'ignored':0}]
assert sha(Path(corecheck['log']).read_bytes())==corecheck['log_sha256']
component={p:h for p,h in oldfiles.items()if p.startswith(('crates/pokered-core/','crates/pokered-data/','vendor/','.cargo/'))or p in ['Cargo.toml','Cargo.lock']}
assert all(sha((W/p).read_bytes())==record['sha256'] and (W/p).stat().st_size==record['bytes'] and record['kind']=='regular' and not(W/p).is_symlink() for p,record in component.items())
proof={'head':head,'privatebase920':'6a8b151a19d0fb225bd941f90ccc283887a9515a','merged1005':'9bce1d6382bd350721551f5e249e6b7cebd6cd2e','relative1005medicinepaths':non_doc_delta('9bce1d6382bd350721551f5e249e6b7cebd6cd2e'),'relativeold269rendererpaths':non_doc_delta('a07a79148022a28579cb9bd18939969841930fe6'),'retained_core2934':{'originaltestedhead':group['tested_merge'],'batch_sha256':sha(batchpath.read_bytes()),'log':corecheck['log'],'log_sha256':corecheck['log_sha256'],'component_paths_byteequal':component,'no_new_core_test':True},'policy':'Do not reuse1000publisher/sourceeq. Futureactual261freshmaster maydifferonlydocs;anysourcechangeSTOP. No publication beforeactualparentmerge.'}
(R/'audit-1008-private-source-mapping.json').write_text(json.dumps(proof,indent=2)+'\n')
entries={}
for record in subprocess.check_output(['git','ls-tree','-rz','--full-tree','HEAD'],cwd=W).split(b'\0'):
 if not record:continue
 meta,name=record.split(b'\t',1);name=name.decode();mode,typ,blob=meta.decode().split()
 if name.startswith('docs/'):continue
 assert typ=='blob'
 p=W/name;data=os.readlink(p).encode() if mode=='120000' else p.read_bytes()
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
 entries[name]={'mode':mode,'git_blob':blob,'sha256':sha(data)}
compiler={p:v for p,v in entries.items()if p.startswith(('crates/','vendor/','.cargo/','run-wasm/'))or p in ['Cargo.toml','Cargo.lock']}
assert 'run-wasm/Cargo.toml'in compiler and 'run-wasm/src/main.rs'in compiler
assert not M.exists();M.mkdir(parents=True);TMP.mkdir(exist_ok=False)
for name,row in compiler.items():
 p=W/name;dest=M/name;dest.parent.mkdir(parents=True,exist_ok=True)
 if row['mode']=='120000':dest.symlink_to(os.readlink(p))
 else:shutil.copy2(p,dest)
 assert sha(os.readlink(dest).encode() if dest.is_symlink() else dest.read_bytes())==row['sha256']
(M/'gfx').symlink_to(ROOT/'gfx',target_is_directory=True)
gfx={str(p.relative_to(ROOT/'gfx')):sha(p.read_bytes())for p in sorted((ROOT/'gfx').rglob('*'))if p.is_file()};assert len(gfx)==702
freeze={'head':head,'private_parent920':'6a8b151a19d0fb225bd941f90ccc283887a9515a','merged1005':'9bce1d6382bd350721551f5e249e6b7cebd6cd2e','worktree':str(W),'compiler':compiler,'complete_non_docs':entries,'external_gfx_root':str(ROOT/'gfx'),'external_gfx':gfx,'gfx_symlink_literal':os.readlink(W/'gfx'),'source_clean':True,'no_build_yet':True}
fp=R/'audit-1008-own-source-before.json';fp.write_text(json.dumps(freeze,indent=2)+'\n')
mp=R/'audit-1008-own-gba-mirror.json';mp.write_text(json.dumps({'source_head':head,'mirror':str(M),'compiler_paths':compiler,'gfx_symlink_literal':os.readlink(M/'gfx'),'all_bytes_modes_equal':True},indent=2)+'\n')
host=R/'cargo-1008-host.sh';host.write_text((R/'cargo-984-host.sh').read_text().replace('fidelity-984-physical-move-slots','fidelity-1008-field-medicine-perf').replace('fidelity-984-local-tmp','fidelity-1008-local-tmp').replace('outside984','outside1008'));host.chmod(0o755)
gba=R/'cargo-1008-gba.sh';gba.write_text((R/'cargo-984-gba.sh').read_text().replace('984-gba-source','1008-gba-source').replace('private984','private1008').replace('fidelity-984-local-tmp','fidelity-1008-local-tmp').replace('fidelity-984-gba-target','fidelity-1008-gba-target').replace('build --offline --release','build --offline --locked --release'));gba.chmod(0o755)
patch=R/'audit-1008-own-source.patch';patch.write_bytes(subprocess.check_output(['git','diff',head+'^',head,'--','crates/pokered-app/src/render/overworld.rs','crates/pokered-app/src/render/session.rs'],cwd=W))
rom=R/'audit-1008-candidate.gba';env={'LD_LIBRARY_PATH':'/tmp/pokered-mgba/usr/lib/x86_64-linux-gnu:/tmp/pokered-build-lib','SDL_AUDIODRIVER':'dummy','SDL_VIDEODRIVER':'dummy','MGBA_COMMAND':'stdbuf -oL -eL /tmp/pokered-mgba/usr/games/mgba -1'}
plan={'source_head':head,'worktree':str(W),'mirror':str(M),'freeze':str(fp),'freeze_sha256':sha(fp.read_bytes()),'mirror_manifest':str(mp),'mirror_manifest_sha256':sha(mp.read_bytes()),'compiler_count':len(compiler),'complete_non_doc_count':len(entries),'external_gfx_count':len(gfx),'source_patch':str(patch),'source_patch_sha256':sha(patch.read_bytes()),'wrapper_sha256':{str(p):sha(p.read_bytes())for p in [host,gba]},'policy':'ROOT_PREREVIEW_REQUIRED_BEFORE_LAUNCH; serial -j1; first stage failure stop; no source edit while checks active; no rerun/threshold/layoutpadding/extra candidate.','coverage':'Three complete appdebug/defaultlib/determinism commands; newliveblock/full/cachedpixel and existingfieldmedicine/capture/session/snapshot regressions. OwnmirrorGBA build/record/31unchangedgates. Core2934 retainedonlyasoriginala07a/v5componentwithallcore/data/Cargo identityproven, no newcorelibtestrun. No newgameplay/SAVEcapture.','checks':[{'label':'appdebug','cwd':str(W),'command':[str(host),'test','-p','pokered-app','--lib','--features','debug-server','--locked'],'log':str(R/'audit-1008-own-appdebug.log'),'timeout':1800},{'label':'appdefault','cwd':str(W),'command':[str(host),'test','-p','pokered-app','--lib','--locked'],'log':str(R/'audit-1008-own-appdefault.log'),'timeout':1800},{'label':'determinism','cwd':str(W),'command':[str(host),'test','-p','pokered-app','--test','agent_determinism','--features','debug-server','--locked'],'log':str(R/'audit-1008-own-determinism.log'),'timeout':1800},{'label':'gba-build','cwd':str(M/'crates/pokered-gba'),'command':[str(gba)],'log':str(R/'audit-1008-own-gba-build.log'),'timeout':1800},{'label':'gba-fix','cwd':str(W),'command':['/tmp/pokered-font-cargo-home/bin/agb-gbafix',str(ROOT/'.task-tmp/fidelity-1008-gba-target/thumbv4t-none-eabi/release/pokered-gba'),'-o',str(rom)],'log':str(R/'audit-1008-own-gba-fix.log'),'timeout':60},{'label':'gba-record','cwd':str(W),'command':['python3',str(W/'scripts/gba_performance.py'),'record','--rom',str(rom),'--output',str(R/'audit-1008-own-gba-perf.json'),'--log',str(R/'audit-1008-own-gba-perf-raw.log')],'log':str(R/'audit-1008-own-gba-record.log'),'environment':env,'timeout':150},{'label':'gba-compare','cwd':str(W),'command':['python3',str(W/'scripts/gba_performance.py'),'compare','--baseline',str(W/'crates/pokered-gba/perf-baseline.json'),'--candidate',str(R/'audit-1008-own-gba-perf.json')],'log':str(R/'audit-1008-own-gba-compare.log'),'timeout':60}]}
p=R/'audit-1008-own-check-plan.json';p.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'head':head,'compiler':len(compiler),'non_doc':len(entries),'gfx':len(gfx),'freeze_sha':plan['freeze_sha256'],'patch_sha':plan['source_patch_sha256'],'plan':str(p),'plan_sha':sha(p.read_bytes())}))
