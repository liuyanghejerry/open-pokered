#!/bin/bash
set -eu
case "$PWD" in
 /home/jerry/.cache/open-pokered-fidelity/1008-gba-source/crates/pokered-gba) ;;
 *) echo "Refusing outside private1008GBA mirror" >&2; exit 64 ;;
esac
export TMPDIR=/home/jerry/develop/open-pokered/.task-tmp/fidelity-1008-local-tmp
export CARGO_HOME=/tmp/fidelity-cargo-home CARGO_INCREMENTAL=0
unset CARGO_PROFILE_DEV_OPT_LEVEL CARGO_PROFILE_DEV_DEBUG
exec cargo +nightly-2025-12-07 build --offline --locked --release --features perf-benchmark --target-dir /home/jerry/develop/open-pokered/.task-tmp/fidelity-1008-gba-target -j1
