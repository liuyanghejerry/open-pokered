from pathlib import Path
import json,hashlib,zipfile
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');w=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout');perf=Path('/home/jerry/develop/open-pokered-perf118');out=w/'docs/audits/gba-map-scroll-hotcode-182';out.mkdir(parents=True,exist_ok=True);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((r/'audit-182-gba-final-source-manifest.json').read_text());assert len(m['sources'])==60 and all(h(w/n)==sha==h(perf/n) for n,sha in m['sources'].items());assert h(w/'crates/pokered-gba/perf-baseline.json')==m['baseline_sha256'];assert 'Finished `release`' in (r/'audit-182-gba-production-build-final.log').read_text();assert 'Finished `release`' in (r/'audit-182-gba-benchmark-build-final.log').read_text()
records=[r/'audit-182-gba-scroll-performance-a1.json',r/'audit-182-gba-scroll-performance-a1-repeat.json'];assert records[0].read_bytes()==records[1].read_bytes();assert (r/'audit-182-gba-scroll-compare-a1.log').read_text().count(' -> ')==31 and 'regressed from' not in (r/'audit-182-gba-scroll-compare-a1.log').read_text();binary=json.loads((r/'audit-182-gba-final-binary-manifest.json').read_text());assert h(r/'audit-182-gba-benchmark-final.elf')==binary['benchmark_sha256'];before=json.loads((r/'audit-181-gba-performance-a3.json').read_text())['scenarios'];after=json.loads(records[0].read_text())['scenarios'];assert all((before[n]['samples'],before[n]['renders'])==(v['samples'],v['renders']) for n,v in after.items())
entries={}
for pattern in ['audit-182-gba-*.log','audit-182-gba-*.json','audit-182*.txt','audit-182*.ld','audit-182*.rs','audit-182-draw-*.json','audit-182-gba-*.symbols.txt']:
 for p in r.glob(pattern):entries[p.name]=p
for name in ['audit-181-gba-performance-a3.json','audit-181-gba-compare-a3.log','stats-59-tools/instrument_draw_182.py','stats-59-tools/package_gba_scroll_182.py']:entries[name]=r/name
for group in ['audit-182-draw-source-before','audit-182-draw-source-diagnostic']:
 for p in (r/group).rglob('*'):
  if p.is_file():entries[str(p.relative_to(r))]=p
entries['final-gba.ld']=w/'crates/pokered-gba/gba.ld';entries['unchanged-perf-baseline.json']=w/'crates/pokered-gba/perf-baseline.json'
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for n,p in sorted(entries.items()):z.write(p,n)
v={'fix':'place existing dma3_scroll_indices in IWRAM; no implementation/render/font/data change','source_manifest':m,'binary':binary,'performance':{'metrics':31,'pass':31,'original_baseline_sha256':m['baseline_sha256'],'movement_before':3122,'movement_after':3078,'movement_limit':3113.1,'oak_draw_avg':after['oak-dialogue-v1']['draw_per_frame_ticks'],'copies':'two complete final benchmark JSONs byte-exact; final rebuild ELF byte-exact to recorded ELF','sample_render_counts':'all7 unchanged'},'diagnostic':{'peak_frame':4217,'map':'RedsHouse2F','camera':'3,7 subx14','sections':'instrumented3124ticks setup176 prepare1399 bg661 foreground585 outside303; not finalbudgetclaim','withdrawn':['foreground restore/save placement3117fail','plusprepare3118fail','all peak/state/draw source instrumentation'],'scope':'diagnostics retained; exact60 WT/perf source restored except adopted linker rule'},'archive':{'entries':len(entries),'bytes':archive.stat().st_size,'sha256':h(archive)},'open':['latestheadCI','finalsourceNEWGAME and independentCONTINUE','remainingfidelity audits']};(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(v['archive'])
(out/'README.md').write_text('''# GBA map scrolling instruction placement (182)

The remaining original performance budget failure was movement draw peak3122
versus3113.1. Perf-only instrumentation identifies frame4217, ordinary walking
in RedsHouse2F with camera(3,7) subx14. A second diagnostic divides its draw into
setup176, cache preparation1399, background661, foreground585 and outside303
ticks. These instrumented readings are diagnostic, not final-head measurements.

Place the existing GBA `dma3_scroll_indices` helper in the linker’s existing
IWRAM hot-code block. This helper scrolls the indexed cache and clears its
exposed strip. Its implementation and all shared renderer code remain unchanged.
The original 24320-byte cap and 8KiB startup/IRQ reserve are unchanged.

Both normal production and perf-benchmark release builds pass. In both, the
952-byte helper is at0x03002869; IWRAM ends0x030051f0 (20976bytes). The exact final
benchmark rebuild is byte-exact to the frozen ELF measured twice. The two full
performance JSONs are byte-exact, all31 unchanged budgets pass, and all7 scene
sample/render counts remain unchanged. Movement peak3122→3078; Oak average2984
also stays within3004.9. Baseline SHA is pinned in verification.json.

Earlier foreground restore/save placement (3117) and extra cache preparation
placement (3118) still failed and were withdrawn. All diagnostic source edits
were restored byte-exactly. The archive retains their evidence and the failed
GameScreen cast build. Final60 WT/perf source hashes match. ROM/ELF binaries are
not bundled; hashes and symbol tables pin the immutable local builds.

This is instruction placement only and changes no on-screen output, so no new
visual PR comparison is required. Latest-head CI, final native mainline and
independent CONTINUE, and the remaining fidelity audit gates are still open.
''')
