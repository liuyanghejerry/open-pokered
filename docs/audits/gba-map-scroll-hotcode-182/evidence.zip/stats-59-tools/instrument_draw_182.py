from pathlib import Path
import json,hashlib
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');base=Path('/home/jerry/develop/open-pokered-perf118');names=['crates/pokered-app/src/render/overworld.rs','crates/pokered-app/src/render/session.rs','crates/pokered-gba/src/main.rs'];manifest={}
for n in names:
 p=base/n;src=r/'audit-182-draw-source-before'/n;src.parent.mkdir(parents=True,exist_ok=True);assert not src.exists();src.write_bytes(p.read_bytes());manifest[n]=hashlib.sha256(p.read_bytes()).hexdigest()
p=base/names[0];s=p.read_text();s=s.replace('pub struct OverworldBackgroundCache {','#[cfg(all(target_os = "none", target_arch = "arm"))]\nfn diagnostic_clock() -> u16 { unsafe { core::ptr::read_volatile(0x04000108 as *const u16) } }\n\npub struct OverworldBackgroundCache {\n    #[cfg(all(target_os = "none", target_arch = "arm"))]\n    pub(crate) diagnostic: [u16; 5],',1);s=s.replace('        Self {\n            width,\n            height,','        Self {\n            #[cfg(all(target_os = "none", target_arch = "arm"))]\n            diagnostic: [0; 5],\n            width,\n            height,',1)
a=s.index('pub(crate) fn draw_overworld_cached_with(');b=s.index('\nfn draw_overworld_impl(',a);part=s[a:b];part=part.replace('    draw_overworld_impl(','    #[cfg(all(target_os = "none", target_arch = "arm"))]\n    { cache.diagnostic[0] = diagnostic_clock(); }\n    draw_overworld_impl(',1).replace('        Some(cache),','        Some(&mut *cache),',1);part=part.replace('    );\n}','    );\n    #[cfg(all(target_os = "none", target_arch = "arm"))]\n    { cache.diagnostic[4] = diagnostic_clock(); }\n}',1);s=s[:a]+part+s[b:]
n='                    let damage = cache.prepare(fb, key, scroll_background.as_deref_mut());';assert s.count(n)==1;s=s.replace(n,'                    #[cfg(all(target_os = "none", target_arch = "arm"))]\n                    { cache.diagnostic[1] = diagnostic_clock(); }\n'+n+'\n                    #[cfg(all(target_os = "none", target_arch = "arm"))]\n                    { cache.diagnostic[2] = diagnostic_clock(); }');n='                    cache.key = Some(key);';assert s.count(n)==1;s=s.replace(n,'                    #[cfg(all(target_os = "none", target_arch = "arm"))]\n                    { cache.diagnostic[3] = diagnostic_clock(); }\n'+n);p.write_text(s)
p=base/names[1];s=p.read_text();n='impl RenderSession {\n';assert s.count(n)==1;s=s.replace(n,n+'    #[cfg(all(target_os = "none", target_arch = "arm"))]\n    pub fn diagnostic_background_ticks(&self) -> Option<[u16; 5]> {\n        self.background_cache.as_ref().map(|v| v.diagnostic)\n    }\n',1);p.write_text(s)
p=base/names[2];s=p.read_text();n='        let mark4 = profile_now();';assert s.count(n)==1;s=s.replace(n,n+'''
        #[cfg(feature = "perf-benchmark")]
        if frame == 4217 {
            if let Some(m) = render_session.diagnostic_background_ticks() {
                agb::println!("diagnostic-draw f={} total={} setup={} prepare={} bg={} foreground={} outside={}", frame, mark3.wrapping_sub(mark2), m[1].wrapping_sub(m[0]), m[2].wrapping_sub(m[1]), m[3].wrapping_sub(m[2]), m[4].wrapping_sub(m[3]), mark3.wrapping_sub(mark2).wrapping_sub(m[4].wrapping_sub(m[0])));
            }
        }
''');p.write_text(s);(r/'audit-182-draw-source-before-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
