# Grass cached drawing audit372
Base:4939ef99cb43398cc91d39e6258a925036036378. Tested source:9e5547a34400616f79dfdee6315ef84fd0159909.
Player underlay patch y60..75 did not cover the grass priority overlay y72..79. Old overlay pixels therefore survived scrolling. Each grass overlay now records an underlay patch, restored in reverse draw order with the sprites.
Actual master/candidate share all6001 inputs, screens and stock, create no save, repeat byte equal. Master151 cached/full mismatches, first722; candidate0. Candidate frame722 PNG equals master full-draw reference PNG byte-for-byte. Only cached output is corrected, RGB bbox65,74,76,78. This is a cached/full regression comparison, not Original battle timing/RNG parity.
Fresh native480-frame walk test1 and renderer tests15 pass. No ROM, save, emulator state, executable or full snapshot included. Recursive battle Debug observations reduced to tags.
