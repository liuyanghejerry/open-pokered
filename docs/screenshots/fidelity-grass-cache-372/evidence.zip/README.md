# Grass cached drawing audit after START merge183
Base:f915cf25e6212ac63bf534321abd12e161034b48. Tested source:47ff3d9a09a96f4068e795e2e784dbd4b6ec7ee7.
Player patch y60..75 did not cover grass overlay y72..79. Old pixels survived scrolling; grass tiles now record their own underlay, restored in reverse order with sprites.
Actual master/candidate share all6001 inputs/screens/stock, repeat byte equal, create no save. Master151 cached/full mismatches, candidate0. Frame722 candidate PNG is byte equal to master full-draw reference PNG. Only cached output corrected, RGB bbox65,74,76,78. The merged START reset is present: both postbattle menus start at0. No Original battle timing/RNG parity claim.
Fresh480-frame walk test1 and renderer15 pass. No ROM, save, emulator state, executable or full snapshot; Debug battle observations reduced to tags.
