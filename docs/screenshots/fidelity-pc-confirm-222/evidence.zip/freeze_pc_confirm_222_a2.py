from pathlib import Path
import subprocess,hashlib,json,shutil,os,re,sys
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-222-pc-confirm-checkout';out=r/'audit-222-pc-native-a2-immutable';out.mkdir(exist_ok=False);log=(r/'audit-222-pc-native-build-a2.log').read_text();assert 'Finished `test` profile' in log
base='0c5848538585cb1a995586344781a46b65b0992d';sources=subprocess.check_output(['git','diff','--name-only',base,'--','crates'],cwd=wt).decode().splitlines();m={'base':base,'sources':{s:hashlib.sha256((wt/s).read_bytes()).hexdigest() for s in sources},'binaries':{}}
for binary in ['core','app']:
 matches=[p for p in re.findall(r'Executable .*?\((/[^\n]+)\)',log) if f'pokered_{binary}-' in p];assert len(matches)==1,matches;shutil.copy2(matches[0],out/binary);m['binaries'][binary]=hashlib.sha256((out/binary).read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib')
for binary in ['core','app']:
 with (r/f'audit-222-pc-native-{binary}-tests-a2.log').open('w') as f:q=subprocess.run([str(out/binary)],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(binary,q.returncode,flush=True)
 if q.returncode:sys.exit(q.returncode)
for rep in [1,2]:
 path=r/f'audit-222-pc-native-capture-a2-{rep}';assert not path.exists();env['PC_CONFIRM_CAPTURE_222']=str(path)
 with (r/f'audit-222-pc-native-capture-a2-{rep}.log').open('w') as f:q=subprocess.run([str(out/'app'),'capture_pc_confirm_222','--ignored','--nocapture'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
 print('capture',rep,q.returncode,flush=True)
 if q.returncode:sys.exit(q.returncode)
a=r/'audit-222-pc-native-capture-a2-1';b=r/'audit-222-pc-native-capture-a2-2';files=[p for p in a.rglob('*') if p.is_file()];assert len(files)==4536
for p in files:assert p.read_bytes()==(b/p.relative_to(a)).read_bytes(),p
for p in a.rglob('frames.json'):
 rows=json.loads(p.read_text());assert len(rows)==161;assert rows[0]['yes']==True
v={'PNG':9016,'cases':28,'frames_each':161,'repeat_all_bytes_exact':True,'cached_full_every_frame_equal':True,'owner_and_fulltests_pass':True};(r/'audit-222-pc-native-verification.json').write_text(json.dumps(v,indent=2));print(v)
