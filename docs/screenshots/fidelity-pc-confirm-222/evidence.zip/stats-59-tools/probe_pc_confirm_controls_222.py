exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state'
context=os.environ.get('PC_CONTEXT_222','change');case=os.environ.get('PC_CASE_222','idle')
for repeat in [1,2]:
 out=r/f'audit-222-original-pc-{context}-{case}-a1-{repeat}';out.mkdir(exist_ok=False)
 p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()));get=lambda n:int(p.memory[symbols[n][1]])
 p.memory[symbols['wOptions'][1]]=(get('wOptions')&0xf0)|3;p.memory[symbols['wNumHoFTeams'][1]]=0;e=symbols['wEventFlags'][1]+37//8;p.memory[e]=int(p.memory[e])|(1<<(37%8))
 p.memory[symbols['wBoxCount'][1]]=1;sp=int(p.memory[symbols['wPartySpecies'][1]]);a=symbols['wBoxSpecies'][1];p.memory[a]=sp;p.memory[a+1]=0xff
 for dest,src,n in [('wBoxMons','wPartyMons',33),('wBoxMonNicks','wPartyMonNicks',11)]:
  for i in range(n):p.memory[symbols[dest][1]+i]=int(p.memory[symbols[src][1]+i])
 p.memory[symbols['wNumBoxItems'][1]]=1;a=symbols['wBoxItems'][1]
 for i,v in enumerate([0x14,4,0xff]):p.memory[a+i]=v
 now=[-1];events=[];cues={n:None for n in ['PCMainMenu','BillsPCMenu','PlayerPCMenu','BillsPCRelease','ChangeBox','OpenOaksPC','PlayerPCToss','DisplayListMenuID','DisplayChooseQuantityMenu','DisplayTwoOptionMenu']};need=[False];ack_until=-1;last_ack=-100;held=set()
 target={'change':'ChangeBox','release':'BillsPCRelease','toss':'PlayerPCToss','oak':'OpenOaksPC'}[context]
 def hook(n):
  if n in cues and cues[n] is None and (n!='DisplayTwoOptionMenu' or cues[target] is not None):cues[n]=now[0]
  if n=='WaitForTextScrollButtonPress':need[0]=True
  events.append({'t':now[0],'routine':n,'cycles':p._cycles(),'cursor':get('wCurrentMenuItem'),'wrapping':get('wMenuWrappingEnabled'),'menuID':get('wTwoOptionMenuID')})
 for n in list(cues)+['WaitForTextScrollButtonPress','YesNoChoice','RemovePokemon','RemoveItemFromInventory','DisplayDexRating']:
  assert n in symbols,n;p.hook_register(*symbols[n],hook,n)
 rows=[]
 for t in range(2600):
  now[0]=t;keys={'a'} if t<2 else set();main=cues['PCMainMenu'];pc=cues['PlayerPCMenu'] if context=='toss' else cues['BillsPCMenu'];li=cues['DisplayListMenuID'];qty=cues['DisplayChooseQuantityMenu'];conf=cues['DisplayTwoOptionMenu'];dest=cues[target]
  if main is not None and dest is None and (pc is None or context=='oak'):
   idx={'change':0,'release':0,'toss':1,'oak':2}[context]
   for j in range(idx):
    if main+70+j*24<=t<main+72+j*24:keys={'down'}
   if main+70+idx*24<=t<main+72+idx*24:keys={'a'}
  if pc is not None and dest is None and context!='oak':
   idx={'change':3,'release':2,'toss':2}[context]
   for j in range(idx):
    if pc+70+j*24<=t<pc+72+j*24:keys={'down'}
   if pc+70+idx*24<=t<pc+72+idx*24:keys={'a'}
  if context in ['release','toss'] and li is not None and conf is None and (context=='release' or qty is None) and li+70<=t<li+72:keys={'a'}
  if context=='toss' and qty is not None and conf is None and qty+40<=t<qty+42:keys={'a'}
  if need[0] and not held and t-last_ack>=20 and conf is None:need[0]=False;ack_until=t+2;last_ack=t
  if t<ack_until:keys={'a'}
  if conf is not None:
   if conf+40<=t<conf+42:keys={'up'} if case=='up' else {'down'} if case in ['down-down','down-up'] else {'up','down'} if case=='up-down' else set()
   if conf+64<=t<conf+66:keys={'down'} if case=='down-down' else {'up'} if case=='down-up' else set()
   if conf+90<=t<conf+92:keys={'a','b'} if case=='ab' else {'a'} if case=='a' else set()
  for k in held-keys:p.button_release(k)
  for k in keys-held:p.button_press(k)
  held=keys;p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png');rows.append({'t':t,'input':sorted(keys),'cues':dict(cues),'cursor':get('wCurrentMenuItem'),'max':get('wMaxMenuItem'),'wrapping':get('wMenuWrappingEnabled'),'menuID':get('wTwoOptionMenuID'),'boxCount':get('wBoxCount'),'pcItems':[int(p.memory[a+i]) for i in range(3)],'textID':get('wTextBoxID')})
  if conf is not None and t>=conf+140:break
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False);assert conf is not None,(context,case,cues)
 print(context,case,repeat,cues,'stable',[(rows[conf+i]['t'],rows[conf+i]['cursor'],rows[conf+i]['wrapping'],rows[conf+i]['menuID']) for i in [30,55,80]],'effects',[e for e in events if e['routine'] in ['RemovePokemon','RemoveItemFromInventory','DisplayDexRating']],flush=True)
 if repeat==2:
  first=r/f'audit-222-original-pc-{context}-{case}-a1-1';assert all(f.read_bytes()==(first/f.name).read_bytes() for f in out.iterdir())
