from pathlib import Path
import os,subprocess,json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
for context in ['change','release','toss','oak']:
 for case in ['idle','up','down-down','down-up','up-down','ab','a']:
  if context=='change' and case=='idle':continue
  log=r/f'audit-222-original-pc-{context}-{case}-a1.log'
  with log.open('w') as f:q=subprocess.run([str(r/'stats-59-tools/venv/bin/python'),str(r/'stats-59-tools/probe_pc_confirm_controls_222.py')],env=dict(os.environ,PC_CONTEXT_222=context,PC_CASE_222=case),stdout=f,stderr=subprocess.STDOUT)
  print(context,case,q.returncode,flush=True)
  if q.returncode:raise SystemExit(q.returncode)
