from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-222-pc-confirm-checkout';d=wt/'docs/screenshots/fidelity-pc-confirm-222';d.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((r/'audit-222-pc-native-a3-immutable/manifest.json').read_text())
for name,h in m['sources'].items():assert sha((wt/name).read_bytes())==h,name
files={}
for side in ['master','native']:
 tag='a1' if side=='master' else 'a3'
 for rep in [1,2]:
  p=r/f'audit-222-pc-{side}-capture-{tag}-{rep}'
  for f in p.rglob('*'):
   if f.is_file():files[str(f.relative_to(r))]=f
  files[p.name+'.log']=r/(p.name+'.log')
 for name in [f'audit-222-pc-{side}-{tag}-immutable/manifest.json',f'audit-222-pc-{side}-verification.json',f'audit-222-pc-{side}-build-{tag}.log']:files[name]=r/name
for context in ['change','release','toss','oak']:
 for case in ['idle','up','down-down','down-up','up-down','ab','a']:
  for rep in [1,2]:
   p=r/f'audit-222-original-pc-{context}-{case}-a1-{rep}'
   for f in p.iterdir():
    if f.is_file():files[str(f.relative_to(r))]=f
for name in ['audit-222-original-confirm-verification.json','audit-222-pc-master-owner-negative-a1.log','audit-222-pc-native-core-tests-a3.log','audit-222-pc-native-app-tests-a3.log','audit-222-pc-confirm-owner-helper.rs','freeze_pc_confirm_222.py','freeze_pc_confirm_222_a2.py','freeze_pc_confirm_222_a3.py','audit-222-pc-native-core-tests-a1.log','audit-222-pc-native-core-tests-a2.log','audit-222-pc-native-app-tests-a1.log','audit-222-pc-native-app-tests-a2.log','package_pc_confirm_222.py','stats-59-tools/probe_pc_confirm_controls_222.py','run_pc_confirm_source_222.py','audit-222-source-batch-a1.log']:files[name]=r/name
for name in m['sources']:files['final-source/'+name]=wt/name
files['actual-master-game-with-test-only-helper.rs']=root/'.task-tmp/fidelity-222-pc-confirm-before-checkout/crates/pokered-app/src/game.rs'
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['home/yes_no.asm','engine/menus/text_box.asm','home/window.asm','engine/pokemon/bills_pc.asm','engine/menus/save.asm','engine/menus/oaks_pc.asm','engine/menus/players_pc.asm']:files['original-source/'+name]=ref/name
png={};blobs=set()
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  b=p.read_bytes()
  if p.suffix=='.png':
   h=sha(b);png[name]=h
   if h not in blobs:blobs.add(h);z.writestr('png-blobs/'+h+'.png',b)
  else:z.writestr(name,b)
 z.writestr('png-files.json',json.dumps(png,indent=2))
assert len(png)==62104,len(png)
with zipfile.ZipFile(d/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for context in ['change','release','toss','oak']:
 for side,label in [('master','before'),('native','after')]:
  tag='a1' if side=='master' else 'a3'
  shutil.copy2(r/f'audit-222-pc-{side}-capture-{tag}-1/{context}-idle/frame-0030.png',d/f'{context}-{label}.png')
v={'master_before':m['base'],'source_hashes':m,'PNG':len(png),'every_archive_file_roundtrip_bytes_equal':True,'archive_sha256':sha((d/'evidence.zip').read_bytes())};(d/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
(d/'README.md').write_text('''# PC confirmation controls, isolated audit 222

Original Release, Change Box, PC Toss and Oak rating all use YesNoChoice.
InitYesNo clears the menu ID; DisplayTwoOptionMenu starts cursor 0 (YES),
HandleMenuInput clamps with wrapping disabled and gives UP priority.
B cancels even when A is pressed simultaneously. Actual master 0c58485
instead starts NO and toggles on either direction. This independent fix
changes only these defaults and directional controls in PcScreen, with
actual PokemonGame regression tests. Existing NO tests now explicitly
select DOWN and retain their no-release/no-save assertions.

Original controlled pre-PC fixture is map41 at13,4 facingUP, Medium,
Exeggutor13 in box1 and Potion4 in PC items, Pokedex flag seeded. Genuine
PC input navigation reaches all four choices. Seven cases each, twice:
idle, UP, DOWN twice, DOWN then UP, simultaneous UP+DOWN, A+B, and A.
All 28 cases start YES; repeated direction clamps; UP wins; A+B cancels.
A alone releases one Pokemon, tosses one Potion, opens the box list or
prints the Dex rating. Entire raw JSON/hooks and all44072 original PNG
repeat byte-exact within each case; seeded data is not natural acquisition.

Actual Game also uses a controlled collision-checked Viridian Center13,4
fixture with Exeggutor13, PC Potion4, Pokedex flag, seed42/English/Medium.
Real A opens the map's hidden PC event; actual menus are navigated through
inputs, not by forcing PcPhase. Four contexts x seven cases x161 frames
x two repeats x actual master/candidate =18032 PNG. Measurements begin
on first native choice frame, with UP/DOWN at40/64 and A/A+B at90.
Every recorded frame checks retained render against full redraw, all pixels.
Within each side every raw JSON and PNG repeats byte-exact. Unmodified
master plus identical cfg(test) helper fails the source-driven owner test
at initial NO; candidate passes all28 cases and complete core/app tests.
Before/after images use the same fixture/input/frame30 for four contexts.

62104 PNG paths are stored losslessly as SHA256 blobs with png-files.json;
every image and every other archived file is read back and byte-compared.
Primary assembly, full raw records, logs, helpers and source/binary hash
manifests are included. No ROM, emulator state, SRAM or executable is
published. These are controlled real-runtime inputs, not natural traversal
or absolute original CPU/PPU timing and pixel alignment. PC text paragraphs,
typing, global repeat timing, choice post-confirm wait15, audio order,
layout and broader PC lifecycle are outside this narrow fix and remain
separate audits. Native transactions still commit immediately after A;
this PR does not claim original post-confirm delay alignment.
''');print({'PNG':len(png),'bytes':(d/'evidence.zip').stat().st_size,'roundtrip':True})
