from pathlib import Path
import hashlib,json,zipfile,shutil,sys
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';kind=sys.argv[1];defs={'list':('fidelity-219-bag-list-checkout','fidelity-bag-list-219','a1',3388),'swap':('fidelity-221-bag-swap-checkout','fidelity-bag-swap-221','a1',4508),'pc':('fidelity-222-pc-confirm-checkout','fidelity-pc-confirm-222','a2',18032)};wtname,dirname,tag,count=defs[kind];wt=root/'.task-tmp'/wtname;d=wt/'docs/screenshots'/dirname;m=json.loads((r/f'audit-223-{kind}-native-{tag}-immutable/manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for name,h in m['sources'].items():assert sha((wt/name).read_bytes())==h,name
files={}
for side,t in [('master','a1'),('native',tag)]:
 for rep in [1,2]:
  p=r/f'audit-223-{kind}-{side}-capture-{t}-{rep}'
  for f in p.rglob('*'):
   if f.is_file():files[str(f.relative_to(r))]=f
  files[p.name+'.log']=r/(p.name+'.log')
 for name in [f'audit-223-{kind}-{side}-verification.json']:files[name]=r/name
for name in [f'audit-223-{kind}-native-{tag}-immutable/manifest.json','audit-223-menu-master-a1-immutable/manifest.json','audit-223-menu-master-build-a1.log',f'audit-223-{kind}-native-build-{tag}.log',f'audit-223-{kind}-core-tests-{tag}.log',f'audit-223-{kind}-app-tests-{tag}.log',f'audit-223-{kind}-master-owner-negative-a1.log','record_menu_baseline_223.py','record_integrations_223.py','record_pc_native_223.py','package_integrations_223.py']:files[name]=r/name
for name in m['sources']:files['final-source/'+name]=wt/name
files['actual-master-game-with-test-only-helpers.rs']=root/'.task-tmp/fidelity-223-menu-before-checkout/crates/pokered-app/src/game.rs';png={};blobs=set();zipname='integration-591480e.zip'
with zipfile.ZipFile(d/zipname,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  b=p.read_bytes()
  if p.suffix=='.png':
   h=sha(b);png[name]=h
   if h not in blobs:blobs.add(h);z.writestr('png-blobs/'+h+'.png',b)
  else:z.writestr(name,b)
 z.writestr('png-files.json',json.dumps(png,indent=2))
assert len(png)==count,(len(png),count)
with zipfile.ZipFile(d/zipname) as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
if kind=='list':
 pairs=[('cancel','mark-b',100),('select','a-select',100),('mark','self-select',100),('priority','up-down',4)]
elif kind=='swap':pairs=[('wait','swap',100),('reopen','swap',145),('merge','merge',115),('early','early-down',16)]
else:pairs=[(x,x+'-idle',30) for x in ['change','release','toss','oak']]
for name,case,frame in pairs:
 for side,t,label in [('master','a1','before'),('native',tag,'after')]:shutil.copy2(r/f'audit-223-{kind}-{side}-capture-{t}-1/{case}/frame-{frame:04}.png',d/f'{name}-{label}.png')
v={'base':m['base'],'candidate':m,'PNG':len(png),'repeat_all_raw_and_png_exact':True,'every_cached_full_pixel_equal':True,'archive_every_file_roundtrip_exact':True,'archive_sha256':sha((d/zipname).read_bytes())};(d/'integration-591480e.json').write_text(json.dumps(v,indent=2)+'\n')
with (d/'README.md').open('a') as f:f.write('\n\n## Current master integration 591480e\n\nThe paired images above have been replaced with actual master591480e and\nthis independently frozen candidate using the identical helper, fixture,\ninputs and relative frame. Production master is unchanged: only cfg(test)\nhelpers are appended. Full source/binary hash manifests, complete fresh\ncore/app regression logs, negative master owner test, and '+str(count)+'\nPNG with complete raw JSON are in integration-591480e.zip; every archive\nfile is read back and byte-compared. Both repetitions are byte-exact,\nevery recorded cached frame matches every full-redraw pixel. Earlier\nevidence.zip remains historical and is not claimed as this integration.\nLatest doc commit CI must be green before merge; stacked swap still\nrequires its list dependency and own master integration checks.\n')
print({'kind':kind,'PNG':count,'bytes':(d/zipname).stat().st_size,'roundtrip':True})
