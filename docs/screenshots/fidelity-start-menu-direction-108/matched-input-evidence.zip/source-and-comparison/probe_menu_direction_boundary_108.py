exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/victory-100-source-setup-3f-hole';summary=[]

summary=[]

summary=[]
for at,duration in [(121,1),(122,1),(123,1),(124,1),(125,1),(121,8)]:
 for trial in [1,2]:
  p=PyBoy(str(setup/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'pretrigger.state').read_bytes()));events=[];rows=[];now=[-1]
  def hook(name):events.append({'t':now[0],'routine':name,'a':p.register_file.A})
  for name in ['Joypad','HandleMenuInput','DelayFrames','PlaySound']:
   p.hook_register(*symbols[name],hook,name)
  for t in range(145):
   now[0]=t
   for boot_at,key,pressed in [(0,'right',True),(16,'right',False),(71,'start',True),(111,'start',False),(120,'down',True),(121,'down',False)]:
    if t==boot_at:(p.button_press if pressed else p.button_release)(key)
   if t==at:p.button_press('up')
   if t==at+duration:p.button_release('up')
   p.tick(1)
   rows.append({'t':t,'current_item':int(p.memory[symbols['wCurrentMenuItem'][1]]),'held':int(p.memory[symbols['hJoyHeld'][1]]),'pressed':int(p.memory[symbols['hJoyPressed'][1]])})
  p.stop(save=False);summary.append({'at':at,'duration':duration,'trial':trial,'events':events,'rows':rows})
  print(at,duration,trial,[(r['t'],r['current_item']) for r in rows if 119<=r['t']<=127],[(e['t'],e['routine']) for e in events if 120<=e['t']<=127],flush=True)
(root/'.task-tmp/fidelity-39-plus/menu-108-source-after-direction.json').write_text(json.dumps(summary,indent=2))
