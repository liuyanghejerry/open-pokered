from pathlib import Path
import subprocess
root=Path('/home/jerry/develop/open-pokered');wt=root/'.task-tmp/fidelity-202-typing-checkout'
source=subprocess.check_output(['git','show','f4921b8:crates/pokered-app/src/game.rs'],cwd=root,text=True);a=source.index('#[cfg(all(test, not(target_os = "none")))]\nmod typing_pulse_capture_159');h=source[a:].replace('_159','_202').replace('FIDELITY_TYPING_CAPTURE','FIDELITY_TYPING_CAPTURE_202')
# Release triggering A before the first native glyph: DisplayTextID entry timing remains a separate audit.
h=h.replace('if t==2 {input.release(GbButton::A);}','if t==1 {input.release(GbButton::A);}')
# Preserve raw snapshots, report actual sound request for verifying typing versus scrolling.
h=h.replace('"config_speed":format!("{:?}",g.state.config.text_speed),','"config_speed":format!("{:?}",g.state.config.text_speed),"sfx":format!("{:?}",g.overworld.sfx_event),')
p=wt/'crates/pokered-app/src/game.rs';p.write_text(p.read_text()+'\n'+h);(root/'.task-tmp/fidelity-39-plus/audit-202-capture-helper.rs').write_text(h);(wt/'gfx').symlink_to(root/'gfx',target_is_directory=True)
