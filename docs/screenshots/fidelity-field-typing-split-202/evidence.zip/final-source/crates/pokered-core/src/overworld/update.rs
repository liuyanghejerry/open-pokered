//! `update_frame()` method and all helper methods for the OverworldScreen.
//!
//! Contains the main game loop tick, script effect processing, NPC movement,
//! wild encounter checks, and map transition logic.

use crate::alloc_prelude::*;
use super::screen::{
    self, BedroomDialogue, ConnectionNpcPreview, EmotionBubbleState, HealingMachineState,
    MapData, OverworldAudioRequest, OverworldGameDataRequest, OverworldScreen, OverworldSfxEvent,
    PendingConnection, PendingTrainerBattle, PendingWarp, PendingWildEncounter,
    TrainerEncounterIntro,
    PokedexEntryState, WARP_FADE_IN_FRAMES, WARP_FADE_OUT_FRAMES, WARP_FADE_OUT_WHITE_FRAMES,
    WarpFadeState, build_npc_runtime_states,
};
use crate::game_state::{GameScreen, ScreenAction};
use crate::overworld::{
    bookshelf, collision, doors_elevators, npc_interaction, npc_movement, player_movement,
    presentation, script_bridge, special_terrain, wild_encounters,
};
use crate::overworld::script_bridge::HealingMachinePhase;
use crate::overworld::spinner_paths::spinner_paths;
use dotzuki_engine::overworld::{
    Direction, MovementState, NpcMovementType, OverworldInput, PlayerState, TransportMode,
};
use dotzuki_engine::overworld::collision::CollisionProvider;
use dotzuki_engine::overworld::map_transitions::{
    calculate_connection_transition as engine_calculate_connection_transition,
};
use dotzuki_engine::tileset::TilesetTrait;
use dotzuki_engine::GameData;
use dotzuki_engine_script::{CommandResult, MapScriptConfig};
use pokered_data::blockset_data;
use pokered_data::impl_traits::PokemonMapData;
use pokered_data::map_data_loader::get_map_json;
use pokered_data::maps::MapId;
use pokered_data::tileset_data;
use pokered_data::tilesets::TilesetId;
use player_movement::{InputState as MovementInput, MoveResult};
use alloc::collections::VecDeque;

// ── Free helper functions ─────────────────────────────────────────

fn resolve_npc_index(
    npc_id: &str,
    npc_states: &[npc_movement::NpcRuntimeState],
    config: &MapScriptConfig,
) -> Option<usize> {
    if let Some(idx) = script_bridge::find_npc_index_by_id(npc_states, npc_id) {
        return Some(idx);
    }
    if let Some(npc_text_id) = config.npc_id_by_script_id(npc_id) {
        return npc_states.iter().position(|n| n.text_id == npc_text_id);
    }
    if let Some(npc_text_id) = config.npc_id_by_toggle(npc_id) {
        return npc_states.iter().position(|n| n.text_id == npc_text_id);
    }
    None
}

fn is_in_tile_bounds<T: TilesetTrait>(map: &MapData<T>, x: u16, y: u16) -> bool {
    let width_tiles = (map.width as u16) * 2;
    let height_tiles = (map.height as u16) * 2;
    x < width_tiles && y < height_tiles
}

/// Whether the player's standing tile at position `x`, `y` (player units —
/// 2 tiles per unit, same space as map.json warp coordinates) is walkable:
/// in bounds, not a counter tile, and passable. Mirrors the movement
/// collision rules; reused by the editor warp resolver (safe spawns).
pub fn is_script_walkable_tile<T: TilesetTrait>(map: &MapData<T>, x: u16, y: u16) -> bool {
    if !is_in_tile_bounds(map, x, y) {
        return false;
    }
    let ts = pokered_data::tilesets::resolve_concrete(&map.tileset);
    let provider = collision::PokemonCollisionProvider::new(map.id, ts);
    let tile = provider.get_tile_at_position(ts, &map.blocks, map.width, x, y);
    let header = tileset_data::get_tileset_header(ts);
    !header.is_counter_tile(tile) && provider.is_tile_passable(ts, tile)
}

fn plan_terrain_path<T: TilesetTrait>(
    map: &MapData<T>,
    start: (u16, u16),
    target: (u16, u16),
) -> Option<Vec<(u16, u16)>> {
    if start == target {
        return Some(Vec::new());
    }
    if !is_in_tile_bounds(map, start.0, start.1) || !is_in_tile_bounds(map, target.0, target.1) {
        return None;
    }
    if !is_script_walkable_tile(map, target.0, target.1) {
        return None;
    }

    let width_tiles = (map.width as usize) * 2;
    let height_tiles = (map.height as usize) * 2;
    let total = width_tiles * height_tiles;
    let mut visited = vec![false; total];
    let mut prev: Vec<Option<(u16, u16)>> = vec![None; total];
    let mut queue = VecDeque::new();

    let index_of = |x: u16, y: u16| -> usize { (y as usize) * width_tiles + x as usize };

    let start_idx = index_of(start.0, start.1);
    visited[start_idx] = true;
    queue.push_back(start);

    while let Some((x, y)) = queue.pop_front() {
        if (x, y) == target {
            break;
        }

        for dir in [
            Direction::Down,
            Direction::Up,
            Direction::Left,
            Direction::Right,
        ] {
            let (dx, dy) = player_movement::direction_delta(dir);
            let nx_i = x as i32 + dx as i32;
            let ny_i = y as i32 + dy as i32;
            if nx_i < 0 || ny_i < 0 {
                continue;
            }
            let nx = nx_i as u16;
            let ny = ny_i as u16;
            if !is_in_tile_bounds(map, nx, ny) {
                continue;
            }
            if !is_script_walkable_tile(map, nx, ny) {
                continue;
            }

            let nidx = index_of(nx, ny);
            if visited[nidx] {
                continue;
            }

            visited[nidx] = true;
            prev[nidx] = Some((x, y));
            queue.push_back((nx, ny));
        }
    }

    let target_idx = index_of(target.0, target.1);
    if !visited[target_idx] {
        return None;
    }

    let mut rev_path = Vec::new();
    let mut cur = target;
    while cur != start {
        rev_path.push(cur);
        let idx = index_of(cur.0, cur.1);
        cur = prev[idx]?;
    }
    rev_path.reverse();
    Some(rev_path)
}

/// L-shaped path: walk X first, then Y. Ignores terrain — used as
/// fallback when `plan_terrain_path` fails (e.g. door tiles).
fn plan_straight_path(start: (u16, u16), target: (u16, u16)) -> Vec<(u16, u16)> {
    let mut path = Vec::new();
    let (mut x, mut y) = start;
    while x != target.0 {
        x = if target.0 > x { x + 1 } else { x - 1 };
        path.push((x, y));
    }
    while y != target.1 {
        y = if target.1 > y { y + 1 } else { y - 1 };
        path.push((x, y));
    }
    path
}

/// Terrain-aware path that also handles unwalkable targets (e.g. door
/// tiles): route to the closest reachable walkable neighbor of the
/// target, then append the target itself as the final step. Returns
/// `None` only when even that is impossible.
fn plan_terrain_path_allow_target_step<T: TilesetTrait>(
    map: &MapData<T>,
    start: (u16, u16),
    target: (u16, u16),
) -> Option<Vec<(u16, u16)>> {
    if let Some(path) = plan_terrain_path(map, start, target) {
        return Some(path);
    }
    if is_script_walkable_tile(map, target.0, target.1) {
        // Walkable but unreachable — nothing better to try.
        return None;
    }
    let mut best: Option<Vec<(u16, u16)>> = None;
    for dir in [
        Direction::Down,
        Direction::Up,
        Direction::Left,
        Direction::Right,
    ] {
        let (dx, dy) = player_movement::direction_delta(dir);
        let nx = target.0 as i32 + dx as i32;
        let ny = target.1 as i32 + dy as i32;
        if nx < 0 || ny < 0 {
            continue;
        }
        let neighbor = (nx as u16, ny as u16);
        if let Some(mut path) = plan_terrain_path(map, start, neighbor) {
            if best.as_ref().map_or(true, |b| path.len() < b.len()) {
                path.push(target);
                best = Some(path);
            }
        }
    }
    best
}

fn path_u16_to_u8(path: &[(u16, u16)]) -> Option<Vec<(u8, u8)>> {
    path.iter()
        .map(|&(x, y)| Some((u8::try_from(x).ok()?, u8::try_from(y).ok()?)))
        .collect()
}

fn direction_toward_player(from_x: u16, from_y: u16, to_x: u16, to_y: u16) -> Option<Direction> {
    let dx = to_x as i32 - from_x as i32;
    let dy = to_y as i32 - from_y as i32;
    if dx == 0 && dy == 0 {
        return None;
    }
    if dx.abs() > dy.abs() {
        Some(if dx > 0 {
            Direction::Right
        } else {
            Direction::Left
        })
    } else {
        Some(if dy > 0 {
            Direction::Down
        } else {
            Direction::Up
        })
    }
}

fn get_npc_text_from_json(
    map_id: MapId,
    text_id: u8,
) -> Option<Vec<pokered_data::map_json::TextPageJson>> {
    let map_json = pokered_data::map_data_loader::get_map_json(map_id)?;
    let key = text_id.to_string();
    map_json.text.npc.get(&key).cloned()
}

fn get_sign_text_from_json(
    map_id: MapId,
    text_id: u8,
) -> Option<Vec<pokered_data::map_json::TextPageJson>> {
    let map_json = pokered_data::map_data_loader::get_map_json(map_id)?;
    let key = text_id.to_string();
    map_json.text.sign.get(&key).cloned()
}

pub(crate) fn resolve_warp_destination(dest_map: MapId, dest_warp_id: u8) -> Option<(u8, u8)> {
    let map_json = get_map_json(dest_map)?;
    let idx = dest_warp_id as usize;
    if idx < map_json.warps.len() {
        Some((map_json.warps[idx].x, map_json.warps[idx].y))
    } else {
        None
    }
}

pub(crate) fn execute_warp(
    map_data: &MapData,
    px: u8,
    py: u8,
    last_map: Option<MapId>,
) -> Option<(MapId, u8, u8)> {
    let transition = dotzuki_engine::overworld::map_transitions::check_warp_at(map_data, px, py)?;
    let dest_map = if transition.is_last_map {
        last_map?
    } else {
        transition.new_map
    };
    let (dx, dy) = resolve_warp_destination(dest_map, transition.dest_warp_id)?;
    Some((dest_map, dx, dy))
}

// ── OverworldScreen game-loop methods ─────────────────────────────

impl<G: GameData<Tileset = TilesetId>> OverworldScreen<G> {
    /// Re-baseline the button edge detectors (`prev_*_pressed`) to the
    /// buttons currently held. Frontends must call this whenever control
    /// returns to the overworld from a sub-screen (START menu, bag, save…):
    /// those screens consumed the button press while the overworld was
    /// suspended, leaving `prev_*` stale — without the re-baseline the
    /// still-held press reads as a fresh edge on the first frame back (e.g.
    /// A on START-menu EXIT instantly talks to the facing NPC). The original
    /// avoids this structurally: home/joypad.asm recomputes hJoyPressed
    /// against hJoyReleased every frame, so a press consumed by one loop can
    /// never re-fire in another.
    pub fn sync_prev_input(&mut self, a: bool, b: bool, up: bool, down: bool) {
        self.prev_a_pressed = a;
        self.prev_b_pressed = b;
        self.prev_up_pressed = up;
        self.prev_down_pressed = down;
    }

    pub fn update_frame(&mut self, input: OverworldInput) -> ScreenAction {
        self.frame_counter = self.frame_counter.wrapping_add(1);
        self.sfx_event = OverworldSfxEvent::None;
        if self.preserve_audio_requests_next_frame {
            self.preserve_audio_requests_next_frame = false;
        } else {
            self.audio_requests.clear();
        }

        // Push the configured text speed into any active dialogue (the frontend
        // sets `text_delay_frames` from the options menu every frame).
        let text_delay = self.text_delay_frames;
        if let Some(ref mut dlg) = self.pending_dialogue {
            dlg.set_text_delay_frames(text_delay);
        }

        // Edge detection for the A button must be computed BEFORE any early-return
        // paths (warp fade, script effects, door auto-step, etc.) so that
        // `prev_a_pressed` stays in sync with the physical key state every frame.
        // Without this, holding A across a dialogue-creation boundary causes the
        // first page to be skipped because the held state is mistaken for a new press.
        let a_just_pressed = input.a && !self.prev_a_pressed;
        let b_just_pressed = input.b && !self.prev_b_pressed;
        let up_just_pressed = input.up && !self.prev_up_pressed;
        let down_just_pressed = input.down && !self.prev_down_pressed;
        self.prev_a_pressed = input.a;
        self.prev_b_pressed = input.b;
        self.prev_up_pressed = input.up;
        self.prev_down_pressed = input.down;

        // Link presence (Cable Club): while a link session is connected and
        // the player is inside Colosseum/TradeCenter, the app sets
        // `link_opponent` and the room's opponent NPC (text id 1 — the map
        // config binding the scene's talkOpponent trigger uses) is pinned to
        // the remote player's position every frame — the original's
        // `TradeCenter_Script` moves the opponent sprite on map entry
        // (scripts/TradeCenter.asm:17-30). Stationary so the overworld's
        // wander logic never fights the override.
        if let Some(presence) = self.link_opponent {
            if let Some(npc) = self.npc_states.iter_mut().find(|n| n.text_id == 1) {
                npc.x = presence.x;
                npc.y = presence.y;
                npc.facing = presence.facing;
                npc.movement_type = dotzuki_engine::overworld::NpcMovementType::Stationary;
                npc.visible = true;
            }
        }

        // PokemonTower5FDefaultScript clears the latch as soon as the player
        // leaves the four protected tiles, allowing another heal on re-entry.
        if self.state.current_map == MapId::PokemonTower5F
            && self.state.player.movement_state == MovementState::Idle
            && !self.player_in_purified_zone()
        {
            self.set_flag_live("EVENT_IN_PURIFIED_ZONE", false);
        }

        // UpdateMovingBgTiles: water/flower tile animation ticks every frame
        // (vblank-driven in the original).
        self.tile_anim.tick();

        // ITEMFINDER: PlaySoundWaitForCurrent blocks for the exact lifetime of
        // each HEALING_MACHINE/PURCHASE track, four alternating pairs. The
        // result text is printed only after the eighth track has ended.
        if let Some((mut remaining, mut frames)) = self.itemfinder_dings {
            frames = frames.saturating_sub(1);
            if frames == 0 {
                if remaining == 0 {
                    self.itemfinder_dings = None;
                    let text = self.localize_message(
                        crate::overworld::hidden_items::ITEMFINDER_FOUND_MESSAGE,
                    );
                    self.pending_dialogue = Some(BedroomDialogue::from_message(&text));
                } else {
                    let healing = remaining % 2 == 0;
                    let sound_id = if healing {
                        "SFX_HEALING_MACHINE"
                    } else {
                        "SFX_PURCHASE"
                    };
                    self.audio_requests.push(OverworldAudioRequest::PlaySound {
                        sound_id: sound_id.to_string(),
                    });
                    frames = if healing {
                        crate::overworld::hidden_items::ITEMFINDER_HEALING_MACHINE_FRAMES
                    } else {
                        crate::overworld::hidden_items::ITEMFINDER_PURCHASE_FRAMES
                    };
                    remaining -= 1;
                    self.itemfinder_dings = Some((remaining, frames));
                }
            } else {
                self.itemfinder_dings = Some((remaining, frames));
            }
            // The original is still inside ItemUseItemfinder while waiting;
            // no movement, NPC update, or other input is processed.
            return ScreenAction::Continue;
        }

        // FLASH white-out frames after a dark cave is lit. GBPalWhiteOutWithDelay3
        // blocks ALL gameplay for its 3-frame Delay3 (the overworld loop sits
        // inside the routine, home/fade.asm) — the renderer whites the screen
        // while `flash_lit_frames > 0` and movement/NPCs stay frozen here.
        if self.flash_lit_frames > 0 {
            self.flash_lit_frames -= 1;
            return ScreenAction::Continue;
        }

        // Naming screen open/submit white flash (GBPalWhiteOutWithDelay3,
        // naming_screen.asm:88/163) — same blocking Delay3 as above.
        if self.naming_flash_frames > 0 {
            self.naming_flash_frames -= 1;
            return ScreenAction::Continue;
        }

        // FLY's `_LeaveMapAnim`: unlike TELEPORT/DIG this is a bird pickup,
        // two coordinate-list passes and a blocking off-screen hold. Only its
        // completion starts GBFadeOutToWhite and permits the map commit.
        if let Some(mut fly) = self.fly_departure.take() {
            let done = fly.tick();
            if fly.frame == presentation::FLY_DEPARTURE_FIRST_PATH_START {
                self.audio_requests.push(OverworldAudioRequest::PlaySound {
                    sound_id: "SFX_FLY".to_string(),
                });
            }
            if done {
                self.warp_fade_state = WarpFadeState::FadingOut {
                    frames_remaining: presentation::FLY_DEPARTURE_FADE_FRAMES,
                };
            } else {
                self.fly_departure = Some(fly);
            }
            return ScreenAction::Continue;
        }

        // TELEPORT/DIG/ESCAPE ROPE spin-out (_LeaveMapAnim): freeze gameplay
        // while the player spins and rises off screen; the warp fade-out
        // (GBFadeOutToWhite) starts when the spin finishes.
        if let Some(mut spin) = self.teleport_spin.take() {
            if let Some(sfx) = spin.tick() {
                self.audio_requests.push(OverworldAudioRequest::PlaySound {
                    sound_id: presentation::teleport_spin_sfx(sfx).to_string(),
                });
            }
            if spin.is_done() {
                self.warp_fade_state = WarpFadeState::FadingOut {
                    frames_remaining: WARP_FADE_OUT_WHITE_FRAMES,
                };
            } else {
                self.teleport_spin = Some(spin);
            }
            return ScreenAction::Continue;
        }

        // ShakeElevator: freeze gameplay while the screen shakes.
        if let Some(mut shake) = self.elevator_shake.take() {
            if let Some(sfx) = shake.tick() {
                self.audio_requests.push(OverworldAudioRequest::PlaySound {
                    sound_id: presentation::elevator_shake_sfx(sfx).to_string(),
                });
            }
            if !shake.is_done() {
                self.elevator_shake = Some(shake);
            }
            return ScreenAction::Continue;
        }

        // S.S. Anne departure cutscene (VermilionDockSSAnneLeavesScript +
        // VermilionDock_EraseSSAnne, scripts/VermilionDock.asm): the ship
        // sails away with smoke puffs and an east view scroll. Freezes
        // gameplay like the original's blocking routine; the ship's map
        // blocks become water and the dock→ship warp is removed
        // (wNumberOfWarps--) when the erase phase begins.
        if let Some(mut dep) = self.ship_departure.take() {
            let prev_phase = dep.phase();
            if let Some(sfx) = dep.tick() {
                self.audio_requests.push(OverworldAudioRequest::PlaySound {
                    sound_id: presentation::ship_departure_sfx(sfx).to_string(),
                });
            }
            if dep.phase() == presentation::ShipDeparturePhase::Erase
                && prev_phase != presentation::ShipDeparturePhase::Erase
            {
                self.apply_ss_anne_departure_erase();
            }
            if !dep.is_done() {
                self.ship_departure = Some(dep);
            }
            return ScreenAction::Continue;
        }

        match self.warp_fade_state {
            WarpFadeState::FadingOut { frames_remaining } => {
                if frames_remaining <= 1 {
                    self.warp_fade_state = WarpFadeState::BlackScreen;
                    if self.warp_fade_to_white
                        && self.pending_warp.is_none()
                        && self.player_in_purified_zone()
                    {
                        // Delay3 twice after GBFadeOutToWhite. The BlackScreen
                        // transition itself consumes the sixth white frame.
                        self.flash_lit_frames = 5;
                    }
                } else {
                    self.warp_fade_state = WarpFadeState::FadingOut {
                        frames_remaining: frames_remaining - 1,
                    };
                }
                return ScreenAction::Continue;
            }
            WarpFadeState::BlackScreen => {
                self.commit_pending_warp();
                self.warp_fade_state = WarpFadeState::FadingIn {
                    frames_remaining: WARP_FADE_IN_FRAMES,
                };
                return ScreenAction::Continue;
            }
            WarpFadeState::FadingIn { frames_remaining } => {
                if frames_remaining <= 1 {
                    self.warp_fade_state = WarpFadeState::Idle;
                    // Fade complete; the next warp defaults to fade-to-black.
                    self.warp_fade_to_white = false;
                } else {
                    self.warp_fade_state = WarpFadeState::FadingIn {
                        frames_remaining: frames_remaining - 1,
                    };
                }
                return ScreenAction::Continue;
            }
            WarpFadeState::Idle => {}
        }

        // EnterMapAnim performs Delay3, GBFadeInFromWhite and a blocking bird
        // graphics copy before the first arrival coordinate becomes visible.
        if self.fly_arrival_delay_frames > 0 {
            self.fly_arrival_delay_frames -= 1;
            if self.fly_arrival_delay_frames == 0 {
                self.enter_map_fly_anim = Some(presentation::EnterMapFlyState::new());
                self.audio_requests.push(OverworldAudioRequest::PlaySound {
                    sound_id: "SFX_FLY".to_string(),
                });
            }
            return ScreenAction::Continue;
        }

        // EnterMapAnim .flyAnimation (player_animations.asm:53-70): the FLY
        // arrival bird — flaps every step (Delay3) along
        // FlyAnimationEnterScreenCoords while the player sprite is swapped
        // for the bird; gameplay stays frozen like the spin-in.
        if let Some(mut fly) = self.enter_map_fly_anim.take() {
            fly.tick();
            if fly.is_done() {
                self.audio_requests.push(OverworldAudioRequest::PlayMapMusic {
                    map: self.state.current_map,
                });
            } else {
                self.enter_map_fly_anim = Some(fly);
            }
            return ScreenAction::Continue;
        }

        // EnterMapAnim arrival spin-in (player_animations.asm:1-91): once
        // the fade-in-from-white completes, the player descends from off the
        // top of the screen and spins in place (FLY / TELEPORT / DIG / ESCAPE
        // ROPE / dungeon-warp arrivals). Gameplay stays frozen while it
        // runs, like the original's blocking routine.
        if let Some(mut anim) = self.enter_map_anim.take() {
            if let Some(sfx) = anim.tick() {
                self.audio_requests.push(OverworldAudioRequest::PlaySound {
                    sound_id: presentation::enter_map_spin_sfx(sfx).to_string(),
                });
            }
            if !anim.is_done() {
                self.enter_map_anim = Some(anim);
            }
            return ScreenAction::Continue;
        }

        // Elevator arrival shake (SilphCoElevatorShakeScript): starts once the
        // elevator's warp-to-floor has fully completed.
        if self.elevator_shake_pending
            && matches!(self.warp_fade_state, WarpFadeState::Idle)
            && self.pending_warp.is_none()
            && self.active_script_effect.is_none()
        {
            self.elevator_shake_pending = false;
            self.elevator_shake = Some(presentation::ElevatorShakeState::new(
                doors_elevators::elevator_shake_params(),
            ));
            return ScreenAction::Continue;
        }

        // ── Script engine tick ────────────────────────────────────────
        // While a FollowNpc effect is active, suppress warp triggers: the
        // player's shadow-walk trail can pass over a door warp tile (e.g.
        // Pallet Town's Oak escort crosses (12,11)), and warping mid-follow
        // freezes the script and drops the leftover effect at commit — the
        // hideObject cleanup right after followNpc never runs. The follow
        // finishes first; the scene then walks the player onto the door
        // tile deliberately (movePlayer) to trigger the warp safely.
        let effect_was_follow_npc = matches!(
            self.active_script_effect,
            Some(script_bridge::ScriptEffect::FollowNpc { .. })
        );
        if let Some(ref mut effect) = self.active_script_effect {
            let naming_was_open = self.pending_naming_screen.is_some();
            if let script_bridge::ScriptEffect::GivePokemon { species, flow, .. } = effect {
                if flow.is_none() {
                    *flow = Some(super::script_interactions::GiftPokemonFlow::new(species, &self.player_name, self.party_count, self.box_count, self.gift_box_number, self.script_engine.script_lang() == Some("zh")));
                }
            }
            // Only allocate the protected-name view when a page is created.
            let dialogue_names: Vec<&str> = if self.pending_dialogue.is_none()
                && matches!(effect, script_bridge::ScriptEffect::ShowDialogue { .. })
            {
                core::iter::once(self.player_name.as_str())
                    .chain(core::iter::once(self.rival_name.as_str()))
                    .chain(self.script_dialogue_names.iter().map(String::as_str))
                    .collect()
            } else {
                Vec::new()
            };
            let done = Self::tick_active_effect(
                effect,
                a_just_pressed,
                b_just_pressed,
                input.a,
                input.b,
                up_just_pressed,
                down_just_pressed,
                &mut self.pending_dialogue,
                &mut self.pending_choice,
                &mut self.pending_pokedex_entry,
                &mut self.pending_naming_screen,
                &mut self.party_select_requested,
                &mut self.pending_emotion_bubble,
                &mut self.pending_healing_machine,
                &mut self.npc_states,
                &self.state.player,
                &mut self.scripted_player_path,
                self.map_data.as_ref(),
                &self.map_script_config,
                self.party_count,
                &mut self.audio_requests,
                self.state.current_map,
                &mut self.sfx_event,
                &mut self.ship_departure,
                &dialogue_names,
                self.script_music_playing,
                self.script_sfx_playing,
            );
            if !naming_was_open && self.pending_naming_screen.is_some() {
                // DisplayNamingScreen entry: GBPalWhiteOutWithDelay3 before the
                // screen is drawn (naming_screen.asm:88).
                self.naming_flash_frames = crate::naming_screen::NAMING_FLASH_FRAMES;
            }
            if done {
                // `giveItem` must report whether the bag had room (the original's
                // GiveItem carry flag). Capture the item id while `effect` is still
                // borrowed; the room check runs after the borrow ends, against the
                // frame-seeded bag snapshot (same source `hasItem` reads).
                let give_item_id = match effect {
                    script_bridge::ScriptEffect::GiveItem { item_id, quantity } => Some((item_id.clone(), *quantity)),
                    _ => None,
                };
                // `givePokemon` must report whether the mon was handed over (the
                // original _GivePokemon carry flag): party room OR current PC box
                // room — the box counts as success ("sent to BOX!").
                let is_give_pokemon =
                    matches!(effect, script_bridge::ScriptEffect::GivePokemon { .. });
                let base_result = Self::finish_effect(effect);
                // StartBattle must SUSPEND the script (not resume it now): the
                // battle hasn't run yet, so the `await game.startBattle(...)`
                // result is delivered later by `resume_script_after_battle`.
                let awaiting_battle = matches!(
                    effect,
                    script_bridge::ScriptEffect::StartBattle { .. }
                        | script_bridge::ScriptEffect::StartWildBattle { .. }
                        | script_bridge::ScriptEffect::OldManTutorial
                );
                // ElevatorMenu also suspends: the app opens the floor menu and
                // delivers the chosen index via `resume_script_after_elevator`.
                let awaiting_elevator = matches!(
                    effect,
                    script_bridge::ScriptEffect::ElevatorMenu { .. }
                );
                // FilterBag likewise suspends until the app returns the chosen
                // item (or cancel) via `resume_script_after_filter_bag`.
                let awaiting_filter_bag = matches!(
                    effect,
                    script_bridge::ScriptEffect::FilterBag { .. }
                );
                // TradePokemon suspends too: the app plays the trade cutscene
                // (engine/movie/trade.asm), applies the party mutation, then
                // delivers whether the offered mon was held via
                // `resume_script_after_trade`.
                let awaiting_trade = matches!(
                    effect,
                    script_bridge::ScriptEffect::TradePokemon { .. }
                );
                let effect_done = self.active_script_effect.take();
                // The bag mutation itself is still queued by `apply_finished_effect`
                // below and applied by the app layer; here we only compute the
                // await result the scene branches on. `true` when the item can be
                // taken (already held, or a free slot exists), `false` when full.
                let result = if let Some((item_id, quantity)) = give_item_id {
                    let has_room = if let Some(bag) = &self.script_bag_snapshot {
                        pokered_data::items::ItemId::from_const_name(&item_id)
                            .is_some_and(|id| bag.clone().add_item(id, quantity).is_ok())
                    } else {
                        let held = self.script_bag_names.iter().any(|n| *n == item_id);
                        held || self.script_bag_names.len() < crate::items::inventory::BAG_ITEM_CAPACITY
                    };
                    CommandResult::Bool(has_room)
                } else if is_give_pokemon {
                    // Mirrors _GivePokemon: party first, else the current PC box;
                    // failure only when BOTH are full (engine/events/give_pokemon.asm).
                    CommandResult::Bool(
                        self.party_count < 6 || (self.box_count as usize) < crate::pokemon::pc_box::MONS_PER_BOX,
                    )
                } else {
                    base_result
                };
                if let Some(ref eff) = effect_done {
                    log::info!(target: "pokered::overworld", "[Script] Effect done: {:?}", core::mem::discriminant(eff));
                }
                self.apply_finished_effect(effect_done);
                if awaiting_battle {
                    // Hold the script; it resumes when the battle ends.
                    self.script_awaiting_battle = true;
                } else if awaiting_elevator {
                    // Hold the script; it resumes when the app returns the
                    // chosen floor via `resume_script_after_elevator`.
                    self.script_awaiting_elevator = true;
                } else if awaiting_filter_bag {
                    // Hold the script; it resumes when the app returns the
                    // chosen item via `resume_script_after_filter_bag`.
                    self.script_awaiting_filter_bag = true;
                } else if awaiting_trade {
                    // Hold the script; it resumes when the app finishes the
                    // trade cutscene (or rejects the trade) via
                    // `resume_script_after_trade`.
                    self.script_awaiting_trade = true;
                } else if let Ok(Some(next_cmd)) = self.script_engine.signal_done(result) {
                    log::info!(target: "pokered::overworld", "[Script] Next command: {:?}", core::mem::discriminant(&next_cmd));
                    self.active_script_effect = Some(script_bridge::dispatch_command_with_names(
                        &next_cmd,
                        &self.player_name,
                        &self.rival_name,
                        &self.starter_display_name(),
                    ));
                }
                self.sync_flags_from_engine();
            }
            // Scripted player path must also advance during script effects so
            // that MovePlayer can observe the path draining. Without this, the
            // MovePlayer effect waits for scripted_player_path to empty, but
            // the standalone path-following block (below) is unreachable while
            // active_script_effect is Some — causing a deadlock.
            // It advances BEFORE the NPC tick (same order as the standalone
            // path-following block below): the tick must see the player
            // already Walking toward its next tile, not a stale Idle player,
            // or an NPC could start a step onto that tile in the gap.
            let pos_before = (self.state.player.x, self.state.player.y);
            self.advance_scripted_player_path();
            // Only check warps when a step actually completed and the position
            // changed.  Checking on the frame that *starts* a walk would fire
            // on the old (warp-tile) position before the player has moved away,
            // causing an immediate re-warp (e.g. entering OaksLab at the door
            // tile and getting warped back to PalletTown).
            let pos_after = (self.state.player.x, self.state.player.y);
            if pos_before != pos_after && !effect_was_follow_npc {
                self.try_trigger_warp_at_player_position();
            }

            // NPC movement must continue during script effects so that
            // MoveNpc / StartNpcMove / AwaitNpcMove effects can complete.
            self.run_npc_movement_tick();
            return ScreenAction::Continue;
        }
        // External awaits are completed by the frontend, not by VM polling.
        // The pending command can be emitted again while WaitingForCommand;
        // an NPC trade's connect dialogue must not reopen its party selector.
        let externally_waiting=self.script_awaiting_trade || self.script_awaiting_battle
            || self.script_awaiting_elevator || self.script_awaiting_filter_bag;
        if !externally_waiting {
            if let Some(cmd) = self.script_engine.tick() {
                self.active_script_effect = Some(script_bridge::dispatch_command_with_names(
                    &cmd,
                    &self.player_name,
                    &self.rival_name,
                    &self.starter_display_name(),
                ));
                return ScreenAction::Continue;
            }
        }

        // ── Cutscene management ────────────────────────────────────────
        // When a cutscene is active and the script engine is idle,
        // either start or end the cutscene.
        if self.cutscene_manager.needs_start() {
            if let Some(script_name) = self.cutscene_manager.current_script_name().map(|s| s.to_string()) {
                if self.script_engine.has_function(&script_name) {
                    self.script_engine.set_player_position(
                        self.state.player.x as u8,
                        self.state.player.y as u8,
                    );
                    if let Ok(Some(cmd)) = self.script_engine.call_function_no_args(&script_name) {
                        self.cutscene_manager.mark_started();
                        self.active_script_effect =
                            Some(script_bridge::dispatch_command_with_names(
                                &cmd,
                                &self.player_name,
                                &self.rival_name,
                                &self.starter_display_name(),
                            ));
                        self.sync_flags_from_engine();
                        return ScreenAction::Continue;
                    }
                }
            }
        } else if self.cutscene_manager.is_active()
            && self.active_script_effect.is_none()
            && self.script_engine.is_idle()
        {
            // Script finished → end current and start next if queued.
            let _next = self.cutscene_manager.end_cutscene();
            // If `end_cutscene` started a new cutscene, `needs_start` will
            // be true on the next frame and the logic above will kick in.
        }

        // Door exit auto-step (PlayerStepOutFromDoor / BIT_EXITING_DOOR).
        // When exiting_door is active, advance the walk animation ignoring real input.
        if self.state.exiting_door {
            if self.state.player.movement_state != MovementState::Idle {
                let step_done = player_movement::advance_step(&mut self.state);
                if step_done {
                    self.state.exiting_door = false;
                }
            } else {
                self.state.exiting_door = false;
            }
            return ScreenAction::Continue;
        }

        // Initiate the auto-step when standing_on_door is flagged after a warp.
        if self.state.standing_on_door {
            self.state.standing_on_door = false;
            self.state.player.facing = Direction::Down;
            self.state.player.movement_state = MovementState::Walking;
            self.state.walk_counter = player_movement::WALK_COUNTER_INIT;
            self.state.exiting_door = true;
            return ScreenAction::Continue;
        }

        // Scripted player movement — follow path ignoring real input.
        if !self.scripted_player_path.is_empty() {
            let pos_before = (self.state.player.x, self.state.player.y);
            self.advance_scripted_player_path();
            let pos_after = (self.state.player.x, self.state.player.y);
            if pos_before != pos_after {
                self.try_trigger_warp_at_player_position();
            }
            self.run_npc_movement_tick();
            return ScreenAction::Continue;
        }

        // While a dialogue box is active, consume A/B-button to advance pages;
        // block all movement and Start input.
        if let Some(ref mut dlg) = self.pending_dialogue {
            if dlg.holding_open() {
                // HoldTextDisplayOpen: keep text box open while A is held
                if !input.a || b_just_pressed {
                    if self.pending_cut.is_some() {
                        self.cut_retained_dialogue = Some(dlg.clone());
                    }
                    self.pending_dialogue = None;
                }
            } else if !dlg.waiting_for_input() {
                dlg.reveal_next_char_with_buttons(input.a || input.b);
            } else if a_just_pressed || b_just_pressed {
                if dlg.waiting_for_input() {
                    // Page fully revealed → advance to next page
                    if dlg.is_last_page() && a_just_pressed {
                        // Last page + A pressed → start holding open
                        dlg.start_holding_open();
                    } else if !dlg.advance() {
                        if self.pending_cut.is_some() {
                            self.cut_retained_dialogue = Some(dlg.clone());
                        }
                        self.pending_dialogue = None;
                    }
                }
                self.sfx_event = OverworldSfxEvent::TextAdvance;
            }
            if self.pending_dialogue.is_none()
                && self.pending_field_move_step.is_some()
                && self.field_move_step_needs_restore
            {
                // HoldTextDisplayOpen returns on the A-release frame. Start
                // SURF's blocking teardown in that same frame; waiting for
                // the next overworld update shifts the entire step by one.
                self.field_move_step_needs_restore = false;
                self.field_move_restore = Some(presentation::FieldMoveRestoreState::new());
            }
            return ScreenAction::Continue;
        }

        // UsedCut mutates/redraws the map only after UsedCutText returns, then
        // AnimCut owns the next 18 frames with its four-sprite OAM overlay.
        if self.cut_anim.is_none() {
            if let Some(cut) = self.pending_cut.take() {
                if let Some(replacement) = cut.replacement_block {
                    if let Some(map) = self.map_data.as_mut() {
                        map.set_block(cut.block_x, cut.block_y, replacement);
                    }
                }
                self.cut_anim = Some(presentation::CutAnimState::new(
                    self.state.player.facing,
                    cut.kind,
                ));
                return ScreenAction::Continue;
            }
        }
        if let Some(mut cut) = self.cut_anim.take() {
            if cut.tick() {
                self.cut_retained_dialogue = None;
                self.audio_requests.push(OverworldAudioRequest::PlaySound {
                    sound_id: "SFX_CUT".to_string(),
                });
            } else {
                if cut.tree_spread_px() > 0 {
                    self.cut_retained_dialogue = None;
                }
                self.cut_anim = Some(cut);
            }
            return ScreenAction::Continue;
        }

        // ItemUseSurfboard queues its simulated forward press before PrintText,
        // but the blocking text routine, palette white-out, graphics reloads,
        // and CloseTextDisplay all finish before the overworld consumes it.
        // Preserve the original 37 white + 23 map-only restoration frames.
        if self.pending_field_move_step.is_some() && self.field_move_step_needs_restore {
            self.field_move_step_needs_restore = false;
            self.field_move_restore = Some(presentation::FieldMoveRestoreState::new());
            return ScreenAction::Continue;
        }
        if let Some(mut restore) = self.field_move_restore.take() {
            if !restore.tick() {
                self.field_move_restore = Some(restore);
                return ScreenAction::Continue;
            }
            // The final restore tick and the first simulated movement setup
            // share a display frame in the original overworld loop.
        }
        if self.field_move_step.is_none() {
            if let Some(step) = self.pending_field_move_step.take() {
                self.state.player.movement_state = MovementState::Walking;
                self.state.walk_counter = step.walk_counter();
                self.field_move_step = Some(step);
                return ScreenAction::Continue;
            }
        }
        if let Some(mut step) = self.field_move_step.take() {
            let done = step.tick();
            let (x, y) = step.player_position();
            self.state.player.x = x;
            self.state.player.y = y;
            self.state.walk_counter = step.walk_counter();
            if done {
                self.state.player.movement_state = MovementState::Idle;
                self.state.walk_counter = 0;
            } else {
                self.field_move_step = Some(step);
            }
            self.run_npc_movement_tick();
            return ScreenAction::Continue;
        }

        // FishingAnim (player_animations.asm:378-469): the rod animation
        // freezes gameplay like the original's blocking DelayFrames loops
        // (the player sprite shake, the "!" bubble, and the rod piece are
        // rendered from this state). When it finishes, the rod response text
        // is queued — and on a bite the hooked mon's battle is armed so
        // home/overworld.asm's `.newBattle` fires once that text closes.
        if let Some(mut anim) = self.fishing_anim.take() {
            anim.tick();
            if anim.is_done() {
                if let Some(pf) = self.pending_fishing.take() {
                    use crate::overworld::fishing::{response_text, RodResponse};
                    let text = self.localize_message(response_text(pf.response));
                    self.pending_dialogue = Some(BedroomDialogue::from_message(&text));
                    if let RodResponse::Bite { species, level } = pf.response {
                        self.post_dialogue_battle = Some(PendingWildEncounter {
                            species,
                            level,
                            old_man: false,
                            hooked: true,
                        });
                    }
                }
            } else {
                self.fishing_anim = Some(anim);
            }
            return ScreenAction::Continue;
        }

        // Start the rod animation once the "You used the <ROD>!" text is
        // dismissed. The original (FishingInit, item_effects.asm:1906-1911)
        // prints the item-use text, then plays SFX_HEAL_AILMENT and waits
        // 80 frames, and only then runs the blocking FishingAnim. The cast
        // pause freezes gameplay like the original's DelayFrames; the
        // response (rolled at item use, 1869-1877) rides along until the
        // animation completes.
        if let Some(pf) = self.pending_fishing.take() {
            use crate::overworld::fishing::RodResponse;
            if self.fishing_cast_delay > 0 {
                self.fishing_cast_delay -= 1;
                if self.fishing_cast_delay > 0 {
                    self.pending_fishing = Some(pf);
                    return ScreenAction::Continue;
                }
                // The pause elapsed this frame: kick off FishingAnim.
                self.fishing_anim = Some(presentation::FishingAnimState::new(
                    self.state.player.facing,
                    matches!(pf.response, RodResponse::Bite { .. }),
                ));
                self.pending_fishing = Some(pf);
                return ScreenAction::Continue;
            }
            // First frame after the text closed: start the 80-frame pause
            // (FishingInit's `ld c, 80; call DelayFrames`) with the
            // pre-cast SFX_HEAL_AILMENT.
            self.fishing_cast_delay = 80;
            self.audio_requests.push(OverworldAudioRequest::PlaySound {
                sound_id: "SFX_HEAL_AILMENT".to_string(),
            });
            self.pending_fishing = Some(pf);
            return ScreenAction::Continue;
        }

        // FLASH lit a dark cave: the message has been dismissed — white out
        // the screen for a few frames (GBPalWhiteOutWithDelay3).
        if self.flash_pending_white && self.pending_dialogue.is_none() {
            self.flash_pending_white = false;
            self.flash_lit_frames = presentation::FLASH_WHITE_FRAMES;
        }

        // Safari Zone game-over eject: once the "SAFARI GAME is over!" message has
        // been dismissed (pending_dialogue cleared above), warp the player back to
        // the Safari Zone gate via a normal fade transition.
        if let Some(warp) = self.safari_eject_pending.take() {
            self.pending_warp = Some(warp);
            self.warp_fade_state = WarpFadeState::FadingOut {
                frames_remaining: WARP_FADE_OUT_FRAMES,
            };
            self.sfx_event = OverworldSfxEvent::GoOutside;
            return ScreenAction::Continue;
        }

        // Deferred post-dialogue warp (field TELEPORT): the "Warp to the last
        // #MON CENTER." text has been dismissed — play the leave-map spin
        // (_LeaveMapAnim escape-warp path); the fade starts when it finishes.
        if let Some(warp) = self.post_dialogue_warp.take() {
            self.pending_warp = Some(warp);
            self.warp_fade_to_white = true;
            self.teleport_spin = Some(presentation::TeleportSpinState::new(
                self.state.player.facing,
                presentation::TELEPORT_SPIN_FACINGS,
            ));
            return ScreenAction::Continue;
        }

        // Deferred post-dialogue wild battle (fishing rods): the rod's result
        // text ("Oh! It's a bite!") has been dismissed — hand the hooked mon
        // to the app as a pending wild encounter (home/overworld.asm's
        // `.newBattle`, reached when wCurOpponent != 0 after the item flow).
        if let Some(encounter) = self.post_dialogue_battle.take() {
            self.pending_wild_encounter = Some(encounter);
            return ScreenAction::Continue;
        }

        // Tick down a trainer-engage "!" bubble. Bubbles raised by script
        // effects (ShowEmotionBubble) are ticked by tick_active_effect, but
        // the trainer-LOS path below creates the bubble WITHOUT a script
        // effect — without this tick its countdown never moves and the
        // engage intro would wait on `frames_remaining == 0` forever.
        if let Some(ref mut bubble) = self.pending_emotion_bubble {
            if bubble.frames_remaining == 0 {
                self.pending_emotion_bubble = None;
            } else {
                bubble.frames_remaining -= 1;
            }
        }

        // Trainer line-of-sight detection: runs every frame during normal gameplay.
        // When a trainer spots the player, run the ENGAGE INTRO first
        // (CheckFightingMapTrainers, home/trainers.asm:129-159): "!" bubble →
        // trainer walks up to the player → THEN the battle. The intro state
        // replaces the instant-battle path; `pending_trainer_battle` is set
        // when the intro completes.
        // The engage guard mirrors BIT_SEEN_BY_TRAINER (trainers.asm): while a
        // spotted trainer's before-battle text is showing, the sight check must
        // not re-fire for it (or any other trainer) — the player is frozen.
        if self.pending_trainer_battle.is_none()
            && self.trainer_encounter_intro.is_none()
            && self.trainer_intro_text_pending.is_none()
            && !self.player_in_purified_zone()
        {
            let trainer_headers =
                pokered_data::trainer_headers::get_trainer_headers(self.state.current_map);
            if let Some(sighting) = npc_interaction::check_trainer_line_of_sight(
                &self.npc_states,
                &self.npc_pokemon_data,
                trainer_headers,
                &self.unified_flags,
                self.state.player.x,
                self.state.player.y,
            ) {
                let tc = pokered_data::trainer_data::TrainerClass::from_u8(sighting.trainer_class);
                let trainer_id =
                    pokered_data::trainer_data::make_trainer_id(tc, sighting.trainer_set);
                let end_battle_text = self
                    .npc_pokemon_data
                    .get(sighting.npc_index as usize)
                    .and_then(|d| d.end_battle_text.clone());
                // PlayTrainerMusic (home/trainers.asm:390-443): RIVAL1/2/3
                // keep the current music; gym leaders keep theirs too
                // (wGymLeaderNo — identified by class here); everyone else
                // gets MEET_EVIL / MEET_FEMALE / MEET_MALE by the lists in
                // data/trainers/encounter_types.asm.
                let music = crate::battle::trainer_encounter::encounter_music(tc);
                if let Some(id) = music {
                    let name = format!("{:?}", id); // enum Debug → name
                    self.audio_requests
                        .push(OverworldAudioRequest::PlayMusic { music_id: name });
                }
                // EXCLAMATION_BUBBLE over the trainer (predef EmotionBubble,
                // trainers.asm:132-135), held for 32 frames while input is
                // locked.
                self.pending_emotion_bubble = Some(EmotionBubbleState {
                    npc_id: String::new(), // resolved by index below
                    emotion: "exclamation".to_string(),
                    frames_remaining: 32,
                });
                // TrainerWalkUpToPlayer_Bank0: the trainer closes the sight
                // line to face the player. Compute the straight path.
                let npc = &self.npc_states[sighting.npc_index as usize];
                let mut path: Vec<(u8, u8)> = Vec::new();
                let (mut x, mut y) = (npc.x, npc.y);
                let (dx, dy) = (
                    self.state.player.x as i32 - npc.x as i32,
                    self.state.player.y as i32 - npc.y as i32,
                );
                // Walk along the dominant axis first (the original walks the
                // sight line: one axis), stopping one tile short of the player.
                let step_x = dx.signum();
                let step_y = dy.signum();
                let dist = (dx.abs() + dy.abs()).saturating_sub(1); // keep 1 tile gap
                for _ in 0..dist {
                    if dx.abs() >= dy.abs() {
                        x = (x as i32 + step_x) as u16;
                    } else {
                        y = (y as i32 + step_y) as u16;
                    }
                    path.push((x as u8, y as u8));
                }
                let npc_index = sighting.npc_index as usize;
                if !path.is_empty() {
                    npc_movement::start_scripted_move(
                        &mut self.npc_states[npc_index],
                        &path,
                    );
                }
                self.trainer_encounter_intro = Some(TrainerEncounterIntro {
                    trainer_id,
                    npc_index: sighting.npc_index,
                    end_battle_text,
                    rival_triplet_base: None,
                });
            }
        }

        // Advance the engage-intro: once the "!" bubble is gone AND the
        // walk-up finished, show the trainer's before-battle text
        // (DisplayEnemyTrainerTextAndStartBattle, home/trainers.asm:141-158:
        // DisplayTextID with the trainer's text, then StartTrainerBattle when
        // it closes). The text reuses the talk pipeline — the map's scene
        // storyline first, map.json npc text as fallback — so sight and talk
        // show the same line, localized.
        if let Some(intro) = self.trainer_encounter_intro.take() {
            let bubble_done = self
                .pending_emotion_bubble
                .as_ref()
                .map_or(true, |b| b.frames_remaining == 0);
            let walk_done = self
                .npc_states
                .get(intro.npc_index as usize)
                .map_or(true, |n| npc_movement::is_scripted_move_done(n));
            if bubble_done && walk_done {
                let text_id = self
                    .npc_states
                    .get(intro.npc_index as usize)
                    .map(|n| n.text_id)
                    .unwrap_or(0);
                let showed_text = text_id > 0
                    && (self.try_call_script_npc_talk(text_id)
                        || self.try_show_npc_json_text(text_id));
                if showed_text {
                    // Park the intro; promote to pending_trainer_battle when
                    // the text (and its storyline, if any) winds down.
                    self.trainer_intro_text_pending = Some(intro);
                } else {
                    // No before-battle text exists anywhere: straight to the
                    // battle (previous behavior).
                    self.pending_trainer_battle = Some(PendingTrainerBattle {
                        trainer_id: intro.trainer_id,
                        npc_index: intro.npc_index,
                        end_battle_text: intro.end_battle_text,
                        rival_triplet_base: intro.rival_triplet_base,
                    });
                }
            } else {
                self.trainer_encounter_intro = Some(intro);
            }
        }

        // Promote the text phase: when the before-battle dialogue and its
        // storyline have fully wound down, pend the battle. If the storyline
        // started a battle itself (startBattle inside the script), stand
        // down — the script machinery owns it.
        if let Some(intro) = self.trainer_intro_text_pending.take() {
            if self.script_awaiting_battle
                || self.pending_trainer_battle.is_some()
                || self.post_dialogue_battle.is_some()
                || self.pending_wild_encounter.is_some()
            {
                // battle owned elsewhere — drop the intro
            } else {
                let text_done = self.pending_dialogue.is_none()
                    && self.pending_choice.is_none()
                    && self.active_script_effect.is_none()
                    && self.script_engine_idle();
                if text_done {
                    self.pending_trainer_battle = Some(PendingTrainerBattle {
                        trainer_id: intro.trainer_id,
                        npc_index: intro.npc_index,
                        end_battle_text: intro.end_battle_text,
                        rival_triplet_base: intro.rival_triplet_base,
                    });
                } else {
                    self.trainer_intro_text_pending = Some(intro);
                }
            }
        }

        // CheckForEngagingTrainers sets wJoyIgnore (all input held) from the
        // moment of engagement until the battle starts: the player can't walk
        // off or interact while the "!" bubble shows, the trainer walks up,
        // and the before-battle text is on screen. (An open dialogue's own
        // early-return below already holds the text phase; this covers the
        // bubble/walk phase and the frames between text close and battle.)
        if self.trainer_encounter_intro.is_some() || self.trainer_intro_text_pending.is_some() {
            self.run_npc_movement_tick();
            return ScreenAction::Continue;
        }

        // Route12/16 DefaultScript starts the encounter after the flute's
        // field-use text closes, without a second A press or facing requirement.
        let snorlax = match self.state.current_map {
            MapId::Route12 => Some((pokered_data::event_flags::EventFlag::EVENT_FIGHT_ROUTE12_SNORLAX, 1)),
            MapId::Route16 => Some((pokered_data::event_flags::EventFlag::EVENT_FIGHT_ROUTE16_SNORLAX, 7)),
            _ => None,
        };
        if let Some((flag, text_id)) = snorlax {
            if self.state.player.movement_state == MovementState::Idle
                && self.unified_flags.check(flag)
                && self.try_call_script_npc_talk(text_id)
            {
                return ScreenAction::Continue;
            }
        }

        // SafariZoneCheck runs after JoypadOverworld, before START and A.
        // A last ball used in battle ends the hunt on returning to the idle
        // field; it does not require another walking step.
        if self.active_script_effect.is_none()
            && self.scripted_player_path.is_empty()
            && !self.cutscene_manager.is_blocking()
            && self.pending_connection.is_none()
            && self.ledge_jump.is_none()
            && self.state.player.movement_state == MovementState::Idle
            && self.state.walk_counter == 0
            && self.safari_game_active
            && self.safari_balls == 0
            && pokered_data::map_flags::is_safari_zone_map(self.state.current_map)
            && self.pending_wild_encounter.is_none()
            && self.pending_dialogue.is_none()
            && self.safari_eject_pending.is_none()
        {
            self.trigger_safari_game_over();
            return ScreenAction::Continue;
        }

        // A-button: check signs first, then NPCs (matches original game priority).
        // Held during a trainer engage intro (wJoyIgnore).
        if a_just_pressed
            && self.state.player.movement_state == MovementState::Idle
            && self.trainer_encounter_intro.is_none()
            && self.trainer_intro_text_pending.is_none()
        {
            // Check tile-based OnInteract triggers first
            {
                let (dx, dy) = player_movement::direction_delta(self.state.player.facing);
                let facing_x = (self.state.player.x as i32 + dx as i32).max(0) as u32;
                let facing_y = (self.state.player.y as i32 + dy as i32).max(0) as u32;
                let map_key = script_bridge::map_id_to_script_key(self.state.current_map);
                if let Some(fn_name) = self.trigger_manager.check_interact_mut(&map_key, facing_x, facing_y) {
                    if self.script_engine.has_function(&fn_name) {
                        self.script_engine.set_player_position(
                            self.state.player.x as u8,
                            self.state.player.y as u8,
                        );
                        if let Ok(Some(cmd)) = self.script_engine.call_function_no_args(&fn_name) {
                            self.active_script_effect =
                                Some(script_bridge::dispatch_command_with_names(
                                    &cmd,
                                    &self.player_name,
                                    &self.rival_name,
                                    &self.starter_display_name(),
                                ));
                            self.sync_flags_from_engine();
                            return ScreenAction::Continue;
                        }
                    }
                }
            }

            // Hidden items (home/overworld.asm:89-96): the hidden-event check
            // runs BEFORE the sign/sprite check, and a matched spot consumes
            // the A press even when the item was already taken (hItemAlreadyFound
            // = 0 loops the overworld without DisplayTextID).
            {
                let (dx, dy) = player_movement::direction_delta(self.state.player.facing);
                let facing_x = self.state.player.x as i32 + dx as i32;
                let facing_y = self.state.player.y as i32 + dy as i32;
                if facing_x >= 0 && facing_y >= 0 {
                    let (fx, fy) = (facing_x as u8, facing_y as u8);
                    if pokered_data::hidden_items::find_hidden_item(
                        self.state.current_map,
                        fx,
                        fy,
                    )
                    .is_some()
                    {
                        self.handle_hidden_item(fx, fy);
                        return ScreenAction::Continue;
                    }
                    // Hidden coins (Game Corner floor spots) — the ref checks
                    // them in the same hidden-event pass.
                    if self.handle_hidden_coin(fx, fy) {
                        return ScreenAction::Continue;
                    }
                }
            }

            // PrintBookshelfText (engine/events/hidden_events/bookshelves.asm):
            // facing UP, the faced tile matched against BookshelfTileIDs —
            // bookshelves, the wall TOWN MAP, elevators, #MON stuff shelves,
            // and the INDIGO PLATEAU statues (runs before sign/NPC checks,
            // like the original's hidden-event pass).
            if self.state.player.facing == Direction::Up {
                if let Some(map) = &self.map_data {
                    let (dx, dy) = player_movement::direction_delta(self.state.player.facing);
                    let fx = (self.state.player.x as i32 + dx as i32).max(0) as u8;
                    let fy = (self.state.player.y as i32 + dy as i32).max(0) as u8;
                    let concrete = pokered_data::tilesets::resolve_concrete(&map.tileset);
                    let tile = bookshelf::faced_tile_id(
                        &map.blocks,
                        map.width,
                        concrete,
                        fx,
                        fy,
                    );
                    let tileset_id = dotzuki_engine::tileset::TilesetTrait::id(&map.tileset);
                    if let Some(mut kind) = bookshelf::lookup(tileset_id, tile) {
                        // BookOrSculptureText: the MANSION tileset's (8,6) tile
                        // $38 is the DIGLETT sculpture variant.
                        if kind == bookshelf::BookshelfText::PokemonBooks
                            && tileset_id == bookshelf::TS_MANSION
                            && tile == 0x38
                            && fx == 8
                            && fy == 6
                        {
                            kind = bookshelf::BookshelfText::DiglettSculpture;
                        }
                        let text = bookshelf::text_for(kind, self.state.player.x as u8);
                        self.pending_dialogue = Some(crate::overworld::screen::BedroomDialogue::from_message(&self.localize_message(&text)));
                        if kind == bookshelf::BookshelfText::TownMap {
                            self.pending_town_map = true;
                        }
                        return ScreenAction::Continue;
                    }
                }
            }

            if let Some(map) = &self.map_data {
                // Copy early to avoid borrow conflict with mutable self calls below.
                let map_tileset = map.tileset;
                let sign_tuples: Vec<(u8, u8, u8)> =
                    map.signs.iter().map(|s| (s.x, s.y, s.text_id)).collect();

                if let Some(sign_text_id) = npc_interaction::check_sign_interaction(
                    &sign_tuples,
                    self.state.player.x,
                    self.state.player.y,
                    self.state.player.facing,
                ) {
                    if self.try_call_script_sign_talk(sign_text_id) {
                        return ScreenAction::Continue;
                    }
                    if let Some(text_pages) =
                        get_sign_text_from_json(self.state.current_map, sign_text_id)
                    {
                        if !text_pages.is_empty() {
                            let pages = self.localize_text_pages(&text_pages);
                            self.pending_dialogue = Some(BedroomDialogue::from_text_pages(
                                &pages,
                                &self.player_name,
                                &self.rival_name,
                                &self.starter_display_name(),
                            ));
                            return ScreenAction::Continue;
                        }
                    }
                }

                let interaction = npc_interaction::try_interact(
                    &self.npc_states,
                    &self.npc_pokemon_data,
                    self.state.player.x,
                    self.state.player.y,
                    self.state.player.facing,
                    self.map_data.as_ref(),
                    &collision::PokemonCollisionProvider::new(self.state.current_map, map_tileset),
                );

                match interaction {
                    npc_interaction::InteractionResult::Talk { npc_index, text_id }
                    | npc_interaction::InteractionResult::AlreadyDefeated { npc_index, text_id } => {
                        self.npc_face_player(npc_index);
                        if self.try_call_script_npc_talk(text_id) {
                            return ScreenAction::Continue;
                        }
                        if self.try_show_npc_json_text(text_id) {
                            return ScreenAction::Continue;
                        }
                    }
                    npc_interaction::InteractionResult::TrainerBattle {
                        npc_index,
                        trainer_class,
                        trainer_set,
                    } => {
                        // TalkToTrainer (home/trainers.asm:89-123): talking to an
                        // undefeated trainer shows its before-battle text and then
                        // ALWAYS starts the fight (EngageMapTrainer +
                        // StartTrainerBattle). The intro is parked as the text
                        // phase; the promotion pass fires the battle once the
                        // text (and its storyline, if any) winds down — and
                        // stands down when the scene starts its own battle
                        // (gym leaders).
                        let face_dir =
                            player_movement::opposite_direction(self.state.player.facing);
                        let tc = pokered_data::trainer_data::TrainerClass::from_u8(trainer_class);
                        let trainer_id =
                            pokered_data::trainer_data::make_trainer_id(tc, trainer_set);
                        let end_battle_text = self
                            .npc_pokemon_data
                            .get(npc_index as usize)
                            .and_then(|d| d.end_battle_text.clone());
                        let intro = TrainerEncounterIntro {
                            trainer_id,
                            npc_index,
                            end_battle_text,
                            rival_triplet_base: None,
                        };
                        let text_id = self
                            .npc_states
                            .iter()
                            .find(|n| n.npc_index == npc_index)
                            .map(|n| n.text_id)
                            .unwrap_or(0);
                        if let Some(npc) = self
                            .npc_states
                            .iter_mut()
                            .find(|n| n.npc_index == npc_index)
                        {
                            npc.facing = face_dir;
                        }
                        if self.try_call_script_npc_talk(text_id)
                            || self.try_show_npc_json_text(text_id)
                        {
                            self.trainer_intro_text_pending = Some(intro);
                            return ScreenAction::Continue;
                        }
                        // No scene, no text: start immediately.
                        self.pending_trainer_battle = Some(PendingTrainerBattle {
                            trainer_id: intro.trainer_id,
                            npc_index: intro.npc_index,
                            end_battle_text: intro.end_battle_text,
                            rival_triplet_base: intro.rival_triplet_base,
                        });

                    }
                    npc_interaction::InteractionResult::ItemPickup { npc_index, .. } => {
                        self.npc_face_player(npc_index);
                        let text_id = self
                            .npc_states
                            .iter()
                            .find(|n| n.npc_index == npc_index)
                            .map(|n| n.text_id)
                            .unwrap_or(0);
                        if text_id > 0 {
                            if self.try_call_script_npc_talk(text_id) {
                                return ScreenAction::Continue;
                            }
                            if self.try_show_npc_json_text(text_id) {
                                return ScreenAction::Continue;
                            }
                        }
                    }
                    _ => {}
                }
            }
        }

        // Tick pending connection walk and apply the map swap when done.
        // During the walk the viewport stays in the old coordinate system
        // (smooth scroll); new-map NPCs are rendered via connection_npc_preview.
        if self.pending_connection.is_some() {
            if self.state.walk_counter > 0 {
                let dec = if self.state.player.transport == TransportMode::Biking
                    && self.state.player.bike_speedup_active
                {
                    2
                } else {
                    1
                };
                self.state.walk_counter = self.state.walk_counter.saturating_sub(dec);
            }
            if self.state.walk_counter == 0 {
                if let Some(pc) = self.pending_connection.take() {
                    self.state.player.movement_state = MovementState::Idle;
                    if pc.save_last_map {
                        self.last_map = Some(pc.old_map);
                    }
                    let new_map = pc.transition.new_map;
                    self.state.current_map = new_map;
                    // EnterMap on the new map: STRENGTH wears off, the dark-cave
                    // state follows the map, and city maps are marked visited.
                    self.strength_active = false;
                    self.tried_push_boulder = false;
                    self.boulder_dust_frames = 0;
                    self.dark_cave.enter_map(new_map);
                    if pokered_data::map_flags::is_city_map(new_map) {
                        self.game_data_requests
                            .push(OverworldGameDataRequest::MarkTownVisited { map: new_map });
                    }
                    let (map_data, npc_pokemon_data) =
                        crate::overworld::map_data_loading::load_full_map_data(new_map, self.game_data.tileset_provider());
                    self.map_data = Some(map_data);
                    self.npc_pokemon_data = npc_pokemon_data;
                    // LoadTilesetHeader: hTileAnimations follows the new tileset.
                    if let Some(ref md) = self.map_data {
                        self.tile_anim.set_tileset(presentation::tile_anim_kind(
                            pokered_data::tileset_data::get_tileset_header(md.tileset).animation,
                        ));
                    }
                    self.load_map_script(new_map);
                    self.audio_requests
                        .push(OverworldAudioRequest::PlayMapMusic { map: new_map });
                    let hidden_npc_ids = self.map_script_config.hidden_npc_ids();
                    self.npc_states = self
                        .map_data
                        .as_ref()
                        .map(|md| build_npc_runtime_states(&md.npcs, &self.npc_pokemon_data, &hidden_npc_ids))
                        .unwrap_or_default();
                    self.apply_hidden_object_flags();
                    self.restore_trainer_defeated_flags(new_map);
                    self.state.player.x = pc.transition.new_x;
                    self.state.player.y = pc.transition.new_y;
                    // EnterMap: CheckForceBikeOrSurf — walking across the
                    // Route 16/18 road ends mounts and locks the bike; the
                    // gates release it (auto-dismount).
                    self.apply_map_entry_transport(new_map, self.state.player.x, self.state.player.y);
                    // CollisionCheckOnWater .stopSurfing across a connection:
                    // crossing onto a passable land tile ends the surf (the
                    // collision layer allowed the cross).
                    self.dismount_surf_if_on_land();
                    self.connection_npc_preview = None;
                }
            }
            self.run_npc_movement_tick();
            return ScreenAction::Continue;
        }

        if self.cutscene_manager.is_blocking() {
            self.run_npc_movement_tick();
            return ScreenAction::Continue;
        }

        // Start menu is held during a trainer engage intro (wJoyIgnore).
        if input.start
            && self.trainer_encounter_intro.is_none()
            && self.trainer_intro_text_pending.is_none()
        {
            return ScreenAction::Transition(GameScreen::StartMenu);
        }

        // wJoyIgnore during a trainer engage intro: d-pad/A/B ignored while
        // the "!" bubble shows and the trainer walks up.
        let intro_holding_input =
            self.trainer_encounter_intro.is_some() || self.trainer_intro_text_pending.is_some();
        let movement_input = MovementInput {
            up: input.up && !intro_holding_input,
            down: input.down && !intro_holding_input,
            left: input.left && !intro_holding_input,
            right: input.right && !intro_holding_input,
            a_button: input.a && !intro_holding_input,
            b_button: input.b && !intro_holding_input,
            start: input.start && !intro_holding_input,
            select: input.select && !intro_holding_input,
        };

        let get_tile_id_at_position =
            |blocks: &[u8], width: u8, tileset: G::Tileset, x: u16, y: u16| -> u8 {
                let block_x = (x / 2) as usize;
                let block_y = (y / 2) as usize;
                let sub_x = (x % 2) as usize;
                let sub_y = (y % 2) as usize;

                if block_x < width as usize {
                    let block_idx = block_y * (width as usize) + block_x;
                    if block_idx < blocks.len() {
                        let block_id = blocks[block_idx];
                        let concrete = pokered_data::tilesets::resolve_concrete(&tileset);
                        return blockset_data::block_tiles(concrete, block_id)
                            .map(|t| t[(sub_y * 2 + 1) * 4 + sub_x * 2])
                            .unwrap_or(0);
                    }
                }
                0
            };

        if let Some(map) = &self.map_data {
            let prev_x = self.state.player.x;
            let prev_y = self.state.player.y;

            let collision_provider = collision::PokemonCollisionProvider::new(map.id, map.tileset)
                .with_warp_border_probe(map.tileset, self.state.player.x, self.state.player.y, self.state.player.facing);

            let standing_tile = get_tile_id_at_position(
                &map.blocks,
                map.width,
                map.tileset,
                self.state.player.x,
                self.state.player.y,
            );

            // Spinner / arrow tiles (Facility & Gym tilesets, e.g. Viridian
            // Gym, Rocket Hideout). The original is TABLE-driven: each map's
            // script maps (x, y) → an RLE "dir × steps" list
            // (<Map>ArrowTilePlayerMovement + DecodeArrowMovementRLE,
            // map_objects.asm:5-27) which is fed as simulated input — the
            // player travels a STRAIGHT line per run while the sprite spins
            // (LoadSpinnerArrowTiles), plus SFX_ARROW_TILES on trigger.
            // B1F/B4F arrow tiles have no table (decorative only).
            if self.state.player.movement_state == MovementState::Idle
                && self.active_script_effect.is_none()
                && self.pending_warp.is_none()
                && self.scripted_player_path.is_empty()
                && special_terrain::is_spinner_tile(map.tileset, standing_tile)
            {
                let map_name = crate::overworld::script_bridge::map_id_to_script_key(map.id)
                    .to_string();
                let entry = spinner_paths(&map_name).iter().find(|&&(sx, sy, _)| {
                    sx as u16 == self.state.player.x && sy as u16 == self.state.player.y
                });
                if let Some(&(_, _, steps)) = entry {
                    // Build the straight-line tile path from the RLE steps.
                    let (mut x, mut y) = (self.state.player.x, self.state.player.y);
                    let mut path: Vec<(u16, u16)> = Vec::new();
                    for st in steps {
                        let (dx, dy) = player_movement::direction_delta(st.dir);
                        for _ in 0..st.steps {
                            x = (x as i32 + dx as i32).max(0) as u16;
                            y = (y as i32 + dy as i32).max(0) as u16;
                            path.push((x, y));
                        }
                    }
                    if !path.is_empty() {
                        self.sfx_event = OverworldSfxEvent::ArrowTiles;
                        self.scripted_player_path.extend(path);
                        // The arrow owns this frame too: do not let held input
                        // start an extra step before the queued path takes over.
                        self.advance_scripted_player_path();
                        return ScreenAction::Continue;
                    }
                }
            }

            // Route 17 (Cycling Road) slope: JoypadOverworld
            // (home/overworld.asm:1826-1835) simulates a PAD_DOWN press every
            // frame while no trainer battle is active and the player holds no
            // d-pad / A / B button — the slope auto-walks the player downhill.
            // (The original checks BIT_TRAINER_BATTLE; the port's equivalent
            // is a sighted-but-not-yet-started battle.)
            let movement_input = if map.id == MapId::Route17
                && self.pending_trainer_battle.is_none()
                && !movement_input.up
                && !movement_input.down
                && !movement_input.left
                && !movement_input.right
                && !movement_input.a_button
                && !movement_input.b_button
            {
                MovementInput {
                    down: true,
                    ..movement_input
                }
            } else {
                movement_input
            };

            // DoBikeSpeedup (home/overworld.asm:377-388): the bike normally
            // steps at double speed; on Route 17 the speedup is cancelled
            // while UP/LEFT/RIGHT is held (fighting the slope) — the bike
            // then moves at walking speed.
            self.state.player.bike_speedup_active = !(map.id == MapId::Route17
                && (movement_input.up || movement_input.left || movement_input.right));

            let target_tile = if let Some(dir) = movement_input.direction_pressed() {
                let (dx, dy) = player_movement::direction_delta(dir);
                let target_x = ((self.state.player.x as i32) + dx as i32).max(0) as u16;
                let target_y = ((self.state.player.y as i32) + dy as i32).max(0) as u16;

                get_tile_id_at_position(&map.blocks, map.width, map.tileset, target_x, target_y)
            } else {
                standing_tile
            };

            // Build sprite positions for collision check.
            // Include NPC destinations (tiles they're walking toward) to prevent
            // race conditions where player walks into a tile an NPC is heading to.
            // This mirrors the occupied vector logic in npc_movement.rs.
            let npc_positions: Vec<collision::SpritePosition> = self
                .npc_states
                .iter()
                .filter(|npc| npc.visible)
                .flat_map(|npc| {
                    let cur = collision::SpritePosition { x: npc.x, y: npc.y };
                    if npc.walk_counter > 0 {
                        // NPC is walking - include destination tile
                        let (dx, dy) = player_movement::direction_delta(npc.facing);
                        let dest = collision::SpritePosition {
                            x: (npc.x as i32 + dx as i32).max(0) as u16,
                            y: (npc.y as i32 + dy as i32).max(0) as u16,
                        };
                        vec![cur, dest]
                    } else {
                        vec![cur]
                    }
                })
                .collect();

            let movement_before = self.state.player.movement_state;
            let transport_before = self.state.player.transport;

            // process_frame normally chains held input straight into the next
            // step. Land idle at the gym lock / arrow pads so their handlers
            // can take control before another walk is started. Other scripts
            // (notably Oak's escort) rely on uninterrupted step chaining.
            let movement_input = if movement_before == MovementState::Walking {
                let (dx, dy) = player_movement::direction_delta(self.state.player.facing);
                let x = (self.state.player.x as i32 + dx as i32).max(0) as u16;
                let y = (self.state.player.y as i32 + dy as i32).max(0) as u16;
                let map_key = script_bridge::map_id_to_script_key(map.id);
                let gym_gate = map.id == MapId::ViridianCity
                    && self.map_script_config.coord_event_fn(x, y) == Some("coordGymLocked");
                let scripted_landing = gym_gate
                    || spinner_paths(&map_key).iter().any(|&(sx, sy, _)| {
                        (x, y) == (sx as u16, sy as u16)
                    });
                if scripted_landing {
                    MovementInput {
                        up: false,
                        down: false,
                        left: false,
                        right: false,
                        ..movement_input
                    }
                } else {
                    movement_input
                }
            } else {
                movement_input
            };

            let result = if let Some(ref mut jump) = self.ledge_jump {
                let done = jump.tick();
                let (x, y) = jump.player_position();
                self.state.player.x = x;
                self.state.player.y = y;
                self.state.walk_counter = jump.walk_counter();
                if done {
                    self.state.player.movement_state = MovementState::Idle;
                    self.state.walk_counter = 0;
                    self.ledge_jump = None;
                    MoveResult::NoInput
                } else {
                    MoveResult::StillMoving
                }
            } else {
                player_movement::process_frame(
                    &mut self.state,
                    &movement_input,
                    map,
                    standing_tile,
                    target_tile,
                    &npc_positions,
                    &collision_provider,
                )
            };

            // Surf dismount (CollisionCheckOnWater .stopSurfing): the engine
            // flipped the transport back to Walking after stepping ashore —
            // PlayDefaultMusic, i.e. resume the map's own music.
            if transport_before == TransportMode::Surfing
                && self.state.player.transport == TransportMode::Walking
            {
                let current_map = self.state.current_map;
                self.audio_requests
                    .push(OverworldAudioRequest::PlayMapMusic { map: current_map });
            }

            let mut turn_encounter_check: Option<(MapId, G::Tileset, u8, u8)> = None;
            // A step completes when the engine returns to Idle OR when the
            // position advanced — the engine chains straight into the next
            // step on the same frame when the direction stays held (no Idle
            // frame in between; process_frame's step-done branch calls
            // try_move immediately). Both cases must roll the encounter
            // check exactly once per TILE entered.
            let pos_changed = self.state.player.x != prev_x || self.state.player.y != prev_y;
            let step_completed = (movement_before == MovementState::Walking
                && self.state.player.movement_state == MovementState::Idle)
                || (movement_before == MovementState::Walking && pos_changed);

            // REPEL wore-off is detected where the counter now ticks — inside
            // check_wild_encounter_on_step's gate (the classic
            // TryDoWildEncounter placement, wild_encounters.asm:19-25 +
            // .lastRepelStep): the roll path consumes the step and reports the
            // >0 → 0 transition, whose "wore off" text REPLACES that step's
            // encounter roll. Steps that never reach the roll (warp tile,
            // script, cooldown, chained steps into another tile) never tick
            // repel and never wear it off.
            let mut repel_wore_off = false;

            let encounter_check_data = if step_completed
                && self.pending_wild_encounter.is_none()
            {
                let new_standing_tile = collision_provider.get_tile_at_position(
                    map.tileset, &map.blocks, map.width,
                    self.state.player.x,
                    self.state.player.y,
                );
                // hlcoord 9,9: current half-block's bottom-right 8px tile.
                let right_tile = wild_encounters::encounter_rate_tile(
                    map.tileset, &map.blocks, map.width,
                    self.state.player.x, self.state.player.y,
                );
                Some((map.id, map.tileset, new_standing_tile, right_tile))
            } else {
                None
            };

            self.prev_movement_state = self.state.player.movement_state;
            let mut warped_or_edge = false;

            match result {
                MoveResult::Warped { warp_index: _ } => {
                    warped_or_edge = true;
                    // A coordinate gate on the door itself must run before
                    // the warp, including approaches that bypass its doorstep.
                    if let Some(fn_name) = self.map_script_config.coord_event_fn(
                        self.state.player.x,
                        self.state.player.y,
                    ) {
                        let fn_name = fn_name.to_string();
                        if self.script_engine.has_function(&fn_name) {
                            self.script_engine.set_player_position(
                                self.state.player.x as u8,
                                self.state.player.y as u8,
                            );
                            if let Ok(Some(cmd)) = self.script_engine.call_function_no_args(&fn_name) {
                                self.active_script_effect = Some(
                                    script_bridge::dispatch_command_with_names(
                                        &cmd,
                                        &self.player_name,
                                        &self.rival_name,
                                        &self.starter_display_name(),
                                    ),
                                );
                                self.sync_flags_from_engine();
                                return ScreenAction::Continue;
                            }
                        }
                    }
                    if let Some((dest_map, warp_x, warp_y)) = execute_warp(
                        map,
                        self.state.player.x as u8,
                        self.state.player.y as u8,
                        self.last_map,
                    ) {
                        // PlayMapChangeSound: door tile → GoInside, otherwise → GoOutside
                        if doors_elevators::is_standing_on_door(map.tileset, standing_tile) {
                            self.sfx_event = OverworldSfxEvent::GoInside;
                        } else {
                            self.sfx_event = OverworldSfxEvent::GoOutside;
                        }
                        let save_last_map = special_terrain::is_outside_map(map.tileset);
                        self.pending_warp = Some(PendingWarp {
                            dest_map,
                            dest_x: warp_x,
                            dest_y: warp_y,
                            save_last_map,
                            // IsPlayerOnDungeonWarp (hidden_events.asm:1-17):
                            // stepping on a warp pad/hole sets BIT_DUNGEON_WARP
                            // → the arrival plays EnterMapAnim's spin-in.
                            // Door warps fade in without it.
                            arrival_spin: crate::overworld::special_terrain::check_warp_pad_or_hole(
                                map.tileset,
                                standing_tile,
                            ) != pokered_data::tileset_data::WarpPadOrHoleType::None,
                        });
                        self.warp_fade_state = WarpFadeState::FadingOut {
                            frames_remaining: WARP_FADE_OUT_FRAMES,
                        };
                    }
                }
                MoveResult::ReachedMapEdge => {
                    warped_or_edge = true;
                    if let Some(dir) = movement_input.direction_pressed() {
                        if let Some(transition) = engine_calculate_connection_transition(
                            map,
                            &PokemonMapData,
                            self.state.player.x,
                            self.state.player.y,
                            dir,
                        ) {
                            let save_last_map = special_terrain::is_outside_map(map.tileset);
                            self.pending_connection = Some(PendingConnection {
                                transition,
                                save_last_map,
                                old_map: self.state.current_map,
                            });
                            self.state.player.movement_state = MovementState::Walking;
                            self.state.walk_counter = player_movement::WALK_COUNTER_INIT;

                            // Pre-load destination NPCs so the renderer can draw
                            // them offset during the walk (scroll-in effect).
                            // The +delta accounts for the player being one step
                            // before the boundary while new_x/y is one step after.
                            let (dx, dy) = player_movement::direction_delta(dir);
                            let step_offset_x =
                                self.state.player.x as i32 + dx as i32 - transition.new_x as i32;
                            let step_offset_y =
                                self.state.player.y as i32 + dy as i32 - transition.new_y as i32;
                            let (dest_map, dest_pokemon_data) =
                                crate::overworld::map_data_loading::load_full_map_data(transition.new_map, self.game_data.tileset_provider());
                            let dest_key = script_bridge::map_id_to_script_key(transition.new_map);
                            let hidden = self
                                .script_loader
                                .get_config(&dest_key)
                                .map(|c| c.hidden_npc_ids())
                                .unwrap_or_default();
                            let mut preview_npcs =
                                build_npc_runtime_states(&dest_map.npcs, &dest_pokemon_data, &hidden);
                            crate::overworld::trainer_engine::apply_trainer_defeated_flags(
                                &mut preview_npcs,
                                &dest_pokemon_data,
                                pokered_data::trainer_headers::get_trainer_headers(transition.new_map),
                                &self.unified_flags,
                            );
                            self.connection_npc_preview = Some(ConnectionNpcPreview {
                                npcs: preview_npcs,
                                step_offset_x,
                                step_offset_y,
                            });
                        }
                    }
                }
                MoveResult::TurnedOnly => {
                    // holdIntermediateDirectionLoop → call NewBattle
                    // (home/overworld.asm:224-234): a completed 180° turn-in-
                    // place ROLLS the wild-encounter check (and burns a repel
                    // step) exactly like a completed step. Record it; the
                    // roll runs after the map borrow ends (same queue as the
                    // on-step check below).
                    self.bump_anim_counter = 0;
                    if self.pending_wild_encounter.is_none() && turn_encounter_check.is_none() {
                        turn_encounter_check = Some((
                            map.id,
                            map.tileset,
                            standing_tile,
                            wild_encounters::encounter_rate_tile(
                                map.tileset, &map.blocks, map.width,
                                self.state.player.x, self.state.player.y,
                            ),
                        ));
                    }
                }
                MoveResult::Blocked(_) => {
                    self.sfx_event = OverworldSfxEvent::Collision;
                    self.bump_anim_counter = self.bump_anim_counter.wrapping_add(1);
                }
                MoveResult::LedgeJump => {
                    self.sfx_event = OverworldSfxEvent::Ledge;
                    self.bump_anim_counter = 0;
                    self.state.walk_counter = 0;
                    self.ledge_jump = Some(presentation::LedgeJumpState::new(
                        self.state.player.x,
                        self.state.player.y,
                        self.state.player.facing,
                    ));
                }
                _ => {
                    self.bump_anim_counter = 0;
                }
            }

            if !warped_or_edge
                && self.active_script_effect.is_none()
                && (self.state.player.x != prev_x || self.state.player.y != prev_y)
            {
                // Existing coord-event check (kept for backward compatibility)
                if let Some(fn_name) = self
                    .map_script_config
                    .coord_event_fn(self.state.player.x, self.state.player.y)
                {
                    let fn_name = fn_name.to_string();
                    if self.script_engine.has_function(&fn_name) {
                        self.script_engine.set_player_position(
                            self.state.player.x as u8,
                            self.state.player.y as u8,
                        );
                        if let Ok(Some(cmd)) = self.script_engine.call_function_no_args(&fn_name) {
                            self.active_script_effect =
                                Some(script_bridge::dispatch_command_with_names(
                                    &cmd,
                                    &self.player_name,
                                    &self.rival_name,
                                    &self.starter_display_name(),
                                ));
                        }
                        self.sync_flags_from_engine();
                    }
                }
            }

            // TriggerManager check (OnStep / OnEnter) — runs every frame
            // regardless of whether the player moved, because OnStep fires
            // each frame the player stands on a trigger tile.
            if self.active_script_effect.is_none() {
                let map_key = script_bridge::map_id_to_script_key(self.state.current_map);
                let triggered = self.trigger_manager.check_triggers(
                    &map_key,
                    self.state.player.x as u32,
                    self.state.player.y as u32,
                );
                for fn_name in &triggered {
                    if self.script_engine.has_function(fn_name) {
                        self.script_engine.set_player_position(
                            self.state.player.x as u8,
                            self.state.player.y as u8,
                        );
                        if let Ok(Some(cmd)) = self.script_engine.call_function_no_args(fn_name) {
                            self.active_script_effect =
                                Some(script_bridge::dispatch_command_with_names(
                                    &cmd,
                                    &self.player_name,
                                    &self.rival_name,
                                    &self.starter_display_name(),
                                ));
                            self.sync_flags_from_engine();
                            break; // Only handle one trigger per frame
                        }
                    }
                }
            }

            if repel_wore_off {
                // `map`'s borrow is dead here; the text replaces this step's
                // encounter roll (already suppressed above).
                self.show_repel_wore_off_message();
            }

            if let Some((map_id, tileset, standing_tile, right_tile)) = encounter_check_data {
                if self.check_wild_encounter_on_step(
                    map_id,
                    tileset,
                    standing_tile,
                    right_tile,
                    self.state.standing_on_warp,
                    self.active_script_effect.is_some(),
                ) {
                    repel_wore_off = true;
                }
            }

            // A completed 180° turn-in-place rolls too (NewBattle after the
            // intermediate-direction loop, home/overworld.asm:224-234).
            if let Some((map_id, tileset, standing_tile, right_tile)) = turn_encounter_check {
                self.check_wild_encounter_on_step(
                    map_id,
                    tileset,
                    standing_tile,
                    right_tile,
                    self.state.standing_on_warp,
                    self.active_script_effect.is_some(),
                );
            }

            // SafariZoneCheckSteps tests the old counter before decrementing.
            if step_completed {
                self.tick_safari_steps();
                if self.safari_eject_pending.is_some() {
                    // SafariZoneCheckSteps jumps straight to WarpFound2 on
                    // timeout, before poison, daycare experience, or battle.
                    return ScreenAction::Continue;
                }
                // Day Care: a deposited Pokémon gains one experience point per
                // overworld step (original IncrementDayCareMonExp, called from
                // the per-step ApplyOutOfBattlePoisonDamage). The exp lives in
                // SaveData, so defer the increment to the app layer.
                self.game_data_requests
                    .push(OverworldGameDataRequest::TickDaycareExp);
                // Poison: every fourth step the poisoned party takes 1 HP of
                // damage (ApplyOutOfBattlePoisonDamage, poison.asm:1-17 — the
                // asm skips ticks while a scripted walk is playing; the port
                // equivalently skips steps that happen mid-script/warp/dialogue
                // or right as a wild battle fires).
                if step_completed {
                    self.poison_step_counter = self.poison_step_counter.wrapping_add(1);
                    if self.poison_step_counter % 4 == 0
                        && self.active_script_effect.is_none()
                        && self.pending_dialogue.is_none()
                        && self.pending_wild_encounter.is_none()
                        && self.pending_warp.is_none()
                    {
                        self.game_data_requests
                            .push(OverworldGameDataRequest::PoisonStep);
                    }
                }
            }
        } else {
            if let Some(dir) = movement_input.direction_pressed() {
                self.state.player.facing = dir;
                let (dx, dy) = player_movement::direction_delta(dir);
                self.state.player.x = (self.state.player.x as i32 + dx as i32).max(0) as u16;
                self.state.player.y = (self.state.player.y as i32 + dy as i32).max(0) as u16;
            }
        }

        // Boulder pushing (TryPushingBoulder): while STRENGTH is active and
        // the player holds the d-pad toward a boulder, slide it one tile.
        // Runs in the normal gameplay path only (dialogue/scripts return
        // earlier), matching the original's RunMapScript call site.
        self.tick_boulder_push(movement_input.direction_pressed());

        // Advance NPC movement every frame (DoMovementForAllSprites).
        // In the original game, NPC movement is frozen while a text box is displayed
        // (wFontLoaded / BIT_FONT_LOADED check in UpdateNPCSprite).
        // run_npc_movement_tick() gates on is_text_ui_active() internally.
        self.run_npc_movement_tick();

        ScreenAction::Continue
    }

    fn is_text_ui_active(&self) -> bool {
        self.pending_dialogue.is_some()
            || self.pending_choice.is_some()
            || self.pending_pokedex_entry.is_some()
            || self.pending_naming_screen.is_some()
    }

    fn run_npc_movement_tick(&mut self) {
        if self.is_text_ui_active() {
            return;
        }
        if let Some(ref map) = self.map_data {
            let rng_value = (self
                .frame_counter
                .wrapping_mul(1103515245)
                .wrapping_add(12345)
                >> 16) as u8;
            let player_dest = if let Some(jump) = self.ledge_jump {
                Some(jump.landing_position())
            } else if let Some(step) = self.field_move_step {
                Some(step.landing_position())
            } else if self.state.player.movement_state != MovementState::Idle {
                // A ledge jump (Jumping) crosses TWO tiles: the landing tile
                // is where the player will be, so that — not the ledge tile
                // one step out — is the destination NPCs must yield to.
                let span = if self.state.player.movement_state == MovementState::Jumping {
                    2
                } else {
                    1
                };
                let (dx, dy) = player_movement::direction_delta(self.state.player.facing);
                Some((
                    (self.state.player.x as i32 + dx as i32 * span).max(0) as u16,
                    (self.state.player.y as i32 + dy as i32 * span).max(0) as u16,
                ))
            } else {
                None
            };
            // The original runs map scripts with random sprite updates
            // halted (UpdateNPCSprite's movement roll only happens while no
            // script owns the frame) — only applymovement-style scripted
            // paths advance. Letting wander NPCs roll during cutscenes let
            // them stroll onto tiles a scripted player walk was about to
            // enter, overlapping the player.
            let frozen = self.active_script_effect.is_some()
                || self.cutscene_manager.is_blocking()
                || !self.scripted_player_path.is_empty()
                || self.trainer_encounter_intro.is_some()
                || self.trainer_intro_text_pending.is_some();
            let mut frozen_slots: Vec<usize> = Vec::new();
            if frozen {
                for (i, n) in self.npc_states.iter_mut().enumerate() {
                    if n.movement_type == NpcMovementType::Wander {
                        n.movement_type = NpcMovementType::Stationary;
                        frozen_slots.push(i);
                    }
                }
            }
            npc_movement::update_npc_movement(
                &mut self.npc_states,
                self.state.player.x,
                self.state.player.y,
                player_dest,
                map.width,
                map.height,
                rng_value,
                &map.blocks,
                map.tileset,
                &collision::PokemonCollisionProvider::new(self.state.current_map, map.tileset),
            );
            for &i in &frozen_slots {
                self.npc_states[i].movement_type = NpcMovementType::Wander;
            }
            self.hasten_followed_npc();
        }
    }

    /// FollowNpc lockstep: the engine paces scripted NPC steps at
    /// NPC_WALK_FRAMES (16f/tile) while the player covers a tile in 8 —
    /// the follower drained each vacated tile in half the leader's stride
    /// and then idled for the remainder (stop-and-go hops, never in step
    /// with Oak). An extra counter decrement per frame halves the followed
    /// NPC's step to 8 frames. The counter still spans 16→0, so the
    /// renderers' 16-unit normalization keeps mapping it onto the full
    /// 16px tile — the sprite simply advances 2px/frame, exactly the
    /// player's pace and walk-animation cadence.
    ///
    /// Only counters still ≥ 2 are decremented: reaching 0 inside the
    /// engine's own tick is what commits the tile and chains the next
    /// step, so an external decrement to 0 would skip the commit.
    fn hasten_followed_npc(&mut self) {
        let mut followed: Option<String> = None;
        if let Some(script_bridge::ScriptEffect::FollowNpc { npc_id, phase, .. }) =
            &self.active_script_effect
        {
            if matches!(phase, script_bridge::FollowNpcPhase::Following { .. }) {
                followed = Some(npc_id.clone());
            }
        }
        let Some(npc_id) = followed else {
            return;
        };
        if let Some(idx) = resolve_npc_index(&npc_id, &self.npc_states, &self.map_script_config) {
            let npc = &mut self.npc_states[idx];
            if npc.walk_counter >= 2 {
                npc.walk_counter -= 1;
            }
        }
    }

    fn advance_scripted_player_path(&mut self) {
        if self.scripted_player_path.is_empty() {
            return;
        }
        if self.state.player.movement_state == MovementState::Idle {
            self.start_next_scripted_player_step();
        } else {
            let step_done = player_movement::advance_step(&mut self.state);
            if step_done && !self.scripted_player_path.is_empty() {
                self.start_next_scripted_player_step();
            }
        }
    }

    fn start_next_scripted_player_step(&mut self) {
        while let Some(&(tx, ty)) = self.scripted_player_path.front() {
            if self.state.player.x == tx && self.state.player.y == ty {
                self.scripted_player_path.pop_front();
                continue;
            }
            if let Some(dir) =
                direction_toward_player(self.state.player.x, self.state.player.y, tx, ty)
            {
                self.state.player.facing = dir;
                self.state.player.movement_state = MovementState::Walking;
                self.state.walk_counter = player_movement::WALK_COUNTER_INIT;
            }
            return;
        }
    }

    fn try_trigger_warp_at_player_position(&mut self) -> bool {
        if self.pending_warp.is_some() || !matches!(self.warp_fade_state, WarpFadeState::Idle) {
            return false;
        }

        let Some(map) = self.map_data.as_ref() else {
            return false;
        };

        let Some(_warp_idx) =
            collision::check_warp_at_position(self.state.player.x, self.state.player.y, map)
        else {
            return false;
        };

        let Some((dest_map, warp_x, warp_y)) = execute_warp(
            map,
            self.state.player.x as u8,
            self.state.player.y as u8,
            self.last_map,
        ) else {
            return false;
        };

        let standing_tile =
            collision::PokemonCollisionProvider::new(map.id, map.tileset)
                .get_tile_at_position(map.tileset, &map.blocks, map.width, self.state.player.x, self.state.player.y);
        if doors_elevators::is_standing_on_door(map.tileset, standing_tile) {
            self.sfx_event = OverworldSfxEvent::GoInside;
        } else {
            self.sfx_event = OverworldSfxEvent::GoOutside;
        }

        let save_last_map = special_terrain::is_outside_map(map.tileset);
        self.pending_warp = Some(PendingWarp {
            dest_map,
            dest_x: warp_x,
            dest_y: warp_y,
            save_last_map,
            // IsPlayerOnDungeonWarp (hidden_events.asm:1-17): stepping on a
            // warp pad/hole sets BIT_DUNGEON_WARP → the arrival plays
            // EnterMapAnim's spin-in. Door warps fade in without it.
            arrival_spin: crate::overworld::special_terrain::check_warp_pad_or_hole(
                map.tileset,
                standing_tile,
            ) != pokered_data::tileset_data::WarpPadOrHoleType::None,
        });
        self.warp_fade_state = WarpFadeState::FadingOut {
            frames_remaining: WARP_FADE_OUT_FRAMES,
        };
        true
    }

    /// `VermilionDock_EraseSSAnne` + `wNumberOfWarps--`
    /// (scripts/VermilionDock.asm:182-224, 122-123): at the end of the
    /// departure the ship's map blocks are replaced with the water block
    /// ($d) and the dock→ship warp is removed from the live map.
    ///
    /// The original fills BG rows 10-21 with the water tile and replaces
    /// the "lower half of the ship" blocks (5..8, 2). The port's
    /// VermilionDock (14×6 blocks) keeps the ship as the bottom block row
    /// (the 0x10/0x12 hull at (0..12, 5)) with the porthole strip at
    /// (5..8, 2) — the same two erase zones, mapped onto the port layout.
    /// Like the original's wOverworldMap edit, the change is transient:
    /// a map reload rebuilds the blocks and warps (the original's
    /// wNumberOfWarps is also reloaded on entry).
    fn apply_ss_anne_departure_erase(&mut self) {
        if self.state.current_map != pokered_data::maps::MapId::VermilionDock {
            return;
        }
        if let Some(map) = self.map_data.as_mut() {
            // Water block: `ld a, $d ; water block` (VermilionDock.asm:200).
            const WATER_BLOCK: u8 = 0x0d;
            // The ship hull (bottom block row) and the porthole strip.
            for bx in 0..=12u8 {
                map.set_block(bx, 5, WATER_BLOCK);
            }
            for bx in 5..=8u8 {
                map.set_block(bx, 2, WATER_BLOCK);
            }
            // wNumberOfWarps--: drop the dock→ship warp (warp_event 14, 2,
            // SS_ANNE_1F, 2) so the player cannot re-board during this visit.
            map.warps.retain(|w| !(w.x == 14 && w.y == 2));
        }
    }

    fn tick_active_effect(
        effect: &mut script_bridge::ScriptEffect,
        a_just_pressed: bool,
        b_just_pressed: bool,
        a_pressed: bool,
        b_pressed: bool,
        up_pressed: bool,
        down_pressed: bool,
        pending_dialogue: &mut Option<BedroomDialogue>,
        pending_choice: &mut Option<script_bridge::PendingChoice>,
        pending_pokedex_entry: &mut Option<PokedexEntryState>,
        pending_naming_screen: &mut Option<crate::naming_screen::NamingScreenState>,
        party_select_requested: &mut bool,
        pending_emotion_bubble: &mut Option<EmotionBubbleState>,
        pending_healing_machine: &mut Option<HealingMachineState>,
        npc_states: &mut [npc_movement::NpcRuntimeState],
        player_state: &PlayerState,
        scripted_player_path: &mut VecDeque<(u16, u16)>,
        map_data: Option<&MapData<G::Tileset>>,
        map_script_config: &MapScriptConfig,
        party_count: u8,
        audio_requests: &mut Vec<OverworldAudioRequest>,
        current_map: MapId,
        sfx_event: &mut OverworldSfxEvent,
        ship_departure: &mut Option<presentation::ShipDepartureState>,
        dialogue_names: &[&str],
        script_music_playing: bool,
        script_sfx_playing: bool,
    ) -> bool {
        match effect {
            script_bridge::ScriptEffect::GivePokemon {
                species,
                nickname,
                flow: Some(flow),
                ..
            } => {
                let child = flow.child.as_mut();
                if Self::tick_active_effect(
                    child,
                    a_just_pressed,
                    b_just_pressed,
                    a_pressed,
                    b_pressed,
                    up_pressed,
                    down_pressed,
                    pending_dialogue,
                    pending_choice,
                    pending_pokedex_entry,
                    pending_naming_screen,
                    party_select_requested,
                    pending_emotion_bubble,
                    pending_healing_machine,
                    npc_states,
                    player_state,
                    scripted_player_path,
                    map_data,
                    map_script_config,
                    party_count,
                    audio_requests,
                    current_map,
                    sfx_event,
                    ship_departure,
                    dialogue_names,
                    script_music_playing,
                    script_sfx_playing,
                ) {
                    let prompt = match flow.child.as_ref() {
                        script_bridge::ScriptEffect::ShowDialogue { text } => Some(text.clone()),
                        _ => None,
                    };
                    let was_choice = matches!(
                        flow.child.as_ref(),
                        script_bridge::ScriptEffect::ShowChoice { .. }
                    );
                    let finished = flow.advance(species, nickname);
                    if !finished
                        && matches!(
                            flow.child.as_ref(),
                            script_bridge::ScriptEffect::ShowChoice { .. }
                        )
                    {
                        // AskName leaves the question visible underneath YES/NO.
                        if let Some(text) = prompt {
                            let mut dialogue = BedroomDialogue::from_message(&text);
                            while dialogue.has_more_pages() {
                                dialogue.advance();
                            }
                            dialogue.skip_to_full_page();
                            *pending_dialogue = Some(dialogue);
                        }
                    } else if was_choice {
                        *pending_dialogue = None;
                    }
                    finished
                } else {
                    false
                }
            }
            script_bridge::ScriptEffect::ReadingMenu { menu } => {
                let child = menu.child.as_mut();
                if Self::tick_active_effect(
                    child,
                    a_just_pressed,
                    b_just_pressed,
                    a_pressed,
                    b_pressed,
                    up_pressed,
                    down_pressed,
                    pending_dialogue,
                    pending_choice,
                    pending_pokedex_entry,
                    pending_naming_screen,
                    party_select_requested,
                    pending_emotion_bubble,
                    pending_healing_machine,
                    npc_states,
                    player_state,
                    scripted_player_path,
                    map_data,
                    map_script_config,
                    party_count,
                    audio_requests,
                    current_map,
                    sfx_event,
                    ship_departure,
                    dialogue_names,
                    script_music_playing,
                    script_sfx_playing,
                ) {
                    menu.advance()
                } else {
                    false
                }
            }
            script_bridge::ScriptEffect::VendingDelivery { frames_elapsed } => {
                // VendingMachineMenu: DelayFrames(2), PlaySound, repeated 60 times.
                *frames_elapsed += 1;
                if *frames_elapsed % 2 == 0 {
                    audio_requests.push(OverworldAudioRequest::PlaySound {
                        sound_id: "SFX_PUSH_BOULDER".to_string(),
                    });
                }
                *frames_elapsed == 120
            }

            script_bridge::ScriptEffect::ShowItemDialogue { text, sound_id, sound_started } => {
                if *sound_started {
                    // Keep the complete found text visible until the sequencer
                    // has finished. A/B cannot close the box during the jingle.
                    if script_sfx_playing || a_pressed {
                        // HoldTextDisplayOpen (home/text_script.asm:98-103)
                        // also keeps automatic text open while A stays held.
                        return false;
                    }
                    *pending_dialogue = None;
                    return true;
                }
                if pending_dialogue.is_none() {
                    *pending_dialogue = Some(script_bridge::text_to_dialogue_with_names(text, dialogue_names));
                    return false;
                }
                let dialogue = pending_dialogue.as_mut().unwrap();
                if !dialogue.waiting_for_input() {
                    dialogue.reveal_next_char_with_buttons(a_pressed || b_pressed);
                }
                if dialogue.waiting_for_input() {
                    if dialogue.has_more_pages() {
                        if a_just_pressed || b_just_pressed {
                            dialogue.advance();
                        }
                    } else {
                        // sound_get_item_1 follows text_far in FoundItemText.
                        audio_requests.push(OverworldAudioRequest::PlaySound {
                            sound_id: sound_id.as_deref().unwrap_or("SFX_GET_ITEM_1").to_string(),
                        });
                        *sound_started = true;
                    }
                }
                false
            }
            script_bridge::ScriptEffect::ShowDialogue { text } => {
                if pending_dialogue.is_none() {
                    let dialogue = script_bridge::text_to_dialogue_with_names(text, dialogue_names);
                    if dialogue.is_done() {
                        return true;
                    }
                    *pending_dialogue = Some(dialogue);
                    false
                } else if pending_dialogue.as_ref().map_or(true, |d| d.is_done()) {
                    *pending_dialogue = None;
                    true
                } else {
                    if let Some(ref mut dlg) = pending_dialogue {
                        if dlg.holding_open() {
                            if !a_pressed || b_just_pressed {
                                *pending_dialogue = None;
                                return true;
                            }
                        } else if !dlg.waiting_for_input() {
                            dlg.reveal_next_char_with_buttons(a_pressed || b_pressed);
                        } else if a_just_pressed || b_just_pressed {
                            if dlg.waiting_for_input() {
                                if dlg.is_last_page() && a_just_pressed {
                                    dlg.start_holding_open();
                                } else if !dlg.advance() {
                                    *pending_dialogue = None;
                                    return true;
                                }
                            }
                            *sfx_event = OverworldSfxEvent::TextAdvance;
                        }
                    }
                    false
                }
            }
            script_bridge::ScriptEffect::ShowChoice {
                options,
                started,
                selected,
            } => {
                if !*started {
                    let mut choice = script_bridge::PendingChoice::new(options.clone());
                    choice.selected = (*selected).min(options.len().saturating_sub(1) as u32);
                    *pending_choice = Some(choice);
                    *started = true;
                    false
                } else if let Some(ref mut choice) = pending_choice {
                    if up_pressed {
                        choice.move_up();
                    } else if down_pressed {
                        choice.move_down();
                    }
                    if a_just_pressed {
                        *selected = choice.selected;
                        *pending_choice = None;
                        true
                    } else if b_just_pressed {
                        // B = cancel = last option (NO)
                        *selected = choice.options.len().saturating_sub(1) as u32;
                        *pending_choice = None;
                        true
                    } else {
                        false
                    }
                } else {
                    // pending_choice was cleared externally — treat as done
                    true
                }
            }
            script_bridge::ScriptEffect::Delay {
                frames: _,
                ref mut frames_remaining,
            } => {
                if *frames_remaining == 0 {
                    return true;
                }
                *frames_remaining -= 1;
                *frames_remaining == 0
            }
            script_bridge::ScriptEffect::PlayShipDeparture { ref mut started } => {
                if !*started {
                    *started = true;
                    *ship_departure = Some(presentation::ShipDepartureState::new());
                    false
                } else if ship_departure.is_some() {
                    // The animation is ticking in the presentation section
                    // above (which returns early); stay blocked until it
                    // completes and clears the state.
                    false
                } else {
                    true
                }
            }
            script_bridge::ScriptEffect::Immediate { .. }
            | script_bridge::ScriptEffect::UnsupportedCommand { .. } => true,
            script_bridge::ScriptEffect::SetJoyIgnore { .. } => true,
            script_bridge::ScriptEffect::ClearJoyIgnore => true,
            script_bridge::ScriptEffect::StartNpcMove { npc_id, path } => {
                if let Some(idx) = resolve_npc_index(npc_id, npc_states, map_script_config) {
                    npc_movement::start_scripted_move(&mut npc_states[idx], path);
                }
                true
            }
            script_bridge::ScriptEffect::MoveNpc {
                npc_id,
                path,
                started,
            } => {
                if !*started {
                    if let Some(idx) = resolve_npc_index(npc_id, npc_states, map_script_config) {
                        npc_movement::start_scripted_move(&mut npc_states[idx], path);
                    }
                    *started = true;
                    false
                } else {
                    let npc_idx = resolve_npc_index(npc_id, npc_states, map_script_config);
                    match npc_idx {
                        Some(idx) => npc_movement::is_scripted_move_done(&npc_states[idx]),
                        None => true,
                    }
                }
            }
            script_bridge::ScriptEffect::AwaitNpcMove { npc_id } => {
                let npc_idx = resolve_npc_index(npc_id, npc_states, map_script_config);
                match npc_idx {
                    Some(idx) => npc_movement::is_scripted_move_done(&npc_states[idx]),
                    None => true,
                }
            }
            script_bridge::ScriptEffect::MovePlayer { path, started } => {
                if !*started {
                    scripted_player_path.clear();
                    for &(x, y) in path.iter() {
                        scripted_player_path.push_back((x as u16, y as u16));
                    }
                    *started = true;
                    false
                } else {
                    scripted_player_path.is_empty()
                        && player_state.movement_state == MovementState::Idle
                }
            }
            script_bridge::ScriptEffect::MovePlayerRelative { steps, started } => {
                if !*started {
                    // Resolve cumulative deltas against the player's live
                    // position into absolute waypoints.
                    scripted_player_path.clear();
                    let mut cx = player_state.x as i32;
                    let mut cy = player_state.y as i32;
                    for &(dx, dy) in steps.iter() {
                        cx += dx as i32;
                        cy += dy as i32;
                        if cx >= 0 && cy >= 0 {
                            scripted_player_path.push_back((cx as u16, cy as u16));
                        }
                    }
                    *started = true;
                    false
                } else {
                    scripted_player_path.is_empty()
                        && player_state.movement_state == MovementState::Idle
                }
            }
            script_bridge::ScriptEffect::StartNpcMoveTo { npc_id, x, y } => {
                if let Some(map) = map_data {
                    if let Some(idx) = resolve_npc_index(npc_id, npc_states, map_script_config) {
                        let start = (npc_states[idx].x, npc_states[idx].y);
                        let target = (*x as u16, *y as u16);
                        if let Some(path) = plan_terrain_path(map, start, target) {
                            if let Some(path_u8) = path_u16_to_u8(&path) {
                                npc_movement::start_scripted_move(&mut npc_states[idx], &path_u8);
                            }
                        }
                    }
                }
                true
            }
            script_bridge::ScriptEffect::MoveNpcTo {
                npc_id,
                x,
                y,
                started,
            } => {
                if !*started {
                    if let Some(map) = map_data {
                        if let Some(idx) = resolve_npc_index(npc_id, npc_states, map_script_config)
                        {
                            let start = (npc_states[idx].x, npc_states[idx].y);
                            let target = (*x as u16, *y as u16);
                            if let Some(path) = plan_terrain_path(map, start, target) {
                                if let Some(path_u8) = path_u16_to_u8(&path) {
                                    npc_movement::start_scripted_move(
                                        &mut npc_states[idx],
                                        &path_u8,
                                    );
                                }
                            }
                        }
                    }
                    *started = true;
                    false
                } else {
                    let npc_idx = resolve_npc_index(npc_id, npc_states, map_script_config);
                    match npc_idx {
                        Some(idx) => npc_movement::is_scripted_move_done(&npc_states[idx]),
                        None => true,
                    }
                }
            }
            script_bridge::ScriptEffect::MovePlayerTo { x, y, started } => {
                if !*started {
                    scripted_player_path.clear();
                    if let Some(map) = map_data {
                        let start = (player_state.x, player_state.y);
                        let target = (*x as u16, *y as u16);
                        if let Some(path) = plan_terrain_path(map, start, target) {
                            for (px, py) in path {
                                scripted_player_path.push_back((px, py));
                            }
                        }
                    }
                    *started = true;
                    false
                } else {
                    scripted_player_path.is_empty()
                        && player_state.movement_state == MovementState::Idle
                }
            }
            script_bridge::ScriptEffect::FollowNpc {
                npc_id,
                target_x,
                target_y,
                phase,
            } => {
                use script_bridge::FollowNpcPhase;
                match phase {
                    FollowNpcPhase::StartNpc => {
                        let mut start_x = 0u16;
                        let mut start_y = 0u16;
                        if let Some(map) = map_data {
                            if let Some(idx) =
                                resolve_npc_index(npc_id, npc_states, map_script_config)
                            {
                                start_x = npc_states[idx].x;
                                start_y = npc_states[idx].y;
                                let target = (*target_x as u16, *target_y as u16);
                                let path = plan_terrain_path_allow_target_step(
                                    map,
                                    (start_x, start_y),
                                    target,
                                )
                                .unwrap_or_else(|| {
                                    plan_straight_path((start_x, start_y), target)
                                });
                                if let Some(path_u8) = path_u16_to_u8(&path) {
                                    npc_movement::start_scripted_move(
                                        &mut npc_states[idx],
                                        &path_u8,
                                    );
                                }
                            }
                        }
                        *phase = FollowNpcPhase::Following {
                            last_npc_x: start_x,
                            last_npc_y: start_y,
                            final_push_done: false,
                        };
                        false
                    }
                    FollowNpcPhase::Following {
                        last_npc_x,
                        last_npc_y,
                        final_push_done,
                    } => {
                        if let Some(idx) = resolve_npc_index(npc_id, npc_states, map_script_config)
                        {
                            let (nx, ny, npc_done) = {
                                let npc = &npc_states[idx];
                                (npc.x, npc.y, npc_movement::is_scripted_move_done(npc))
                            };

                            if nx != *last_npc_x || ny != *last_npc_y {
                                scripted_player_path.push_back((*last_npc_x, *last_npc_y));
                                *last_npc_x = nx;
                                *last_npc_y = ny;
                            }

                            if npc_done && !*final_push_done {
                                let pos = (nx, ny);
                                if scripted_player_path.back() != Some(&pos) {
                                    scripted_player_path.push_back(pos);
                                }
                                // NOTE: the NPC is NOT hidden here — scenes
                                // hide it explicitly (hideObject) if needed;
                                // auto-hiding would freeze any later moveNpc
                                // walk-off, since hidden NPCs don't advance
                                // scripted movement.
                                *final_push_done = true;
                            }
                            let player_done = scripted_player_path.is_empty()
                                && player_state.movement_state == MovementState::Idle;
                            if npc_done && player_done {
                                *phase = FollowNpcPhase::Done;
                                return true;
                            }
                        } else {
                            *phase = FollowNpcPhase::Done;
                            return true;
                        }
                        false
                    }
                    FollowNpcPhase::Done => true,
                }
            }
            script_bridge::ScriptEffect::ShowPokedexEntry { species, started } => {
                if !*started {
                    *pending_pokedex_entry = Some(PokedexEntryState {
                        species: species.clone(),
                        page: 0,
                        total_pages: 0,
                    });
                    *started = true;
                    false
                } else if pending_pokedex_entry.is_none() {
                    true
                } else if a_just_pressed || b_just_pressed {
                    if let Some(ref mut state) = pending_pokedex_entry {
                        let on_last_page =
                            state.total_pages == 0 || state.page + 1 >= state.total_pages;
                        if on_last_page {
                            *pending_pokedex_entry = None;
                            return true;
                        }
                        state.page += 1;
                    }
                    false
                } else {
                    false
                }
            }
            script_bridge::ScriptEffect::NamingScreen {
                species,
                naming_state,
                started,
                result_name,
            } => {
                if !*started {
                    let mut ns = crate::naming_screen::NamingScreenState::new(
                        crate::naming_screen::NamingScreenType::Pokemon,
                    );
                    ns.species = pokered_data::species::Species::from_scene_name(species);
                    *naming_state = Some(ns.clone());
                    *pending_naming_screen = Some(ns);
                    *started = true;
                    false
                } else if result_name.is_some() {
                    true
                } else {
                    pending_naming_screen.is_none()
                }
            }
            script_bridge::ScriptEffect::ChoosePartyPokemon {
                started,
                result_index,
            } => {
                if !*started {
                    // Ask the app layer to open the party selector (it owns the
                    // party). Selection resolves via `update_party_select_input`.
                    *party_select_requested = true;
                    *started = true;
                    false
                } else {
                    // Done once the selection (or cancel) has been recorded.
                    result_index.is_some()
                }
            }
            script_bridge::ScriptEffect::WaitMusic => !script_music_playing,
            script_bridge::ScriptEffect::SetPartyNickname { .. } => true,
            script_bridge::ScriptEffect::ShowEmotionBubble {
                npc_id,
                emotion,
                frames_remaining,
                started,
            } => {
                if !*started {
                    *pending_emotion_bubble = Some(EmotionBubbleState {
                        npc_id: npc_id.clone(),
                        emotion: emotion.clone(),
                        frames_remaining: *frames_remaining,
                    });
                    *started = true;
                    false
                } else if let Some(ref mut bubble) = pending_emotion_bubble {
                    if bubble.frames_remaining == 0 {
                        *pending_emotion_bubble = None;
                        true
                    } else {
                        bubble.frames_remaining -= 1;
                        false
                    }
                } else {
                    true
                }
            }
            script_bridge::ScriptEffect::AnimateHealingMachine {
                phase,
                frames_remaining,
            } => {
                match phase {
                    HealingMachinePhase::FadeOutMusic => {
                        audio_requests.push(OverworldAudioRequest::FadeOutMusic);
                        *pending_healing_machine = Some(HealingMachineState {
                            phase: HealingMachinePhase::FadeOutMusic,
                            frames_remaining: 32,
                            pokeballs_visible: 0,
                            flash_active: false,
                        });
                        *phase = HealingMachinePhase::WaitForFadeOut;
                        *frames_remaining = 32;
                        false
                    }
                    HealingMachinePhase::WaitForFadeOut => {
                        if *frames_remaining == 0 {
                            let total = if party_count == 0 { 0 } else { party_count };
                            *phase = HealingMachinePhase::HealPartyMember {
                                member_index: 0,
                                total_members: total,
                            };
                            *frames_remaining = 30;
                            if total > 0 {
                                audio_requests.push(OverworldAudioRequest::PlaySound {
                                    sound_id: "SFX_HEALING_MACHINE".to_string(),
                                });
                            }
                            if let Some(ref mut state) = pending_healing_machine {
                                state.phase = HealingMachinePhase::HealPartyMember {
                                    member_index: 0,
                                    total_members: total,
                                };
                                state.frames_remaining = 30;
                                state.pokeballs_visible = if total > 0 { 1 } else { 0 };
                            }
                        } else {
                            *frames_remaining -= 1;
                            if let Some(ref mut state) = pending_healing_machine {
                                state.frames_remaining = *frames_remaining;
                            }
                        }
                        false
                    }
                    HealingMachinePhase::HealPartyMember {
                        member_index,
                        total_members,
                    } => {
                        if *frames_remaining == 0 {
                            if *member_index + 1 < *total_members {
                                *member_index += 1;
                                *frames_remaining = 30;
                                audio_requests.push(OverworldAudioRequest::PlaySound {
                                    sound_id: "SFX_HEALING_MACHINE".to_string(),
                                });
                                if let Some(ref mut state) = pending_healing_machine {
                                    state.phase = HealingMachinePhase::HealPartyMember {
                                        member_index: *member_index,
                                        total_members: *total_members,
                                    };
                                    state.frames_remaining = 30;
                                    state.pokeballs_visible = *member_index + 1;
                                }
                            } else {
                                let total = *total_members;
                                *phase = HealingMachinePhase::PlayHealedMusic;
                                if let Some(ref mut state) = pending_healing_machine {
                                    state.phase = HealingMachinePhase::PlayHealedMusic;
                                    state.pokeballs_visible = total;
                                }
                            }
                        } else {
                            *frames_remaining -= 1;
                            if let Some(ref mut state) = pending_healing_machine {
                                state.frames_remaining = *frames_remaining;
                            }
                        }
                        false
                    }
                    HealingMachinePhase::PlayHealedMusic => {
                        audio_requests.push(OverworldAudioRequest::PlayMusic {
                            music_id: "MUSIC_PKMN_HEALED".to_string(),
                        });
                        *phase = HealingMachinePhase::FlashSprite { flashes_remaining: 8 };
                        *frames_remaining = 10;
                        if let Some(ref mut state) = pending_healing_machine {
                            state.phase = HealingMachinePhase::FlashSprite { flashes_remaining: 8 };
                            state.frames_remaining = 10;
                            state.flash_active = true;
                        }
                        false
                    }
                    HealingMachinePhase::FlashSprite { flashes_remaining } => {
                        if *frames_remaining == 0 {
                            if *flashes_remaining > 0 {
                                *flashes_remaining -= 1;
                                *frames_remaining = 10;
                                if let Some(ref mut state) = pending_healing_machine {
                                    state.phase = HealingMachinePhase::FlashSprite {
                                        flashes_remaining: *flashes_remaining,
                                    };
                                    state.frames_remaining = 10;
                                    state.flash_active = !state.flash_active;
                                }
                            } else {
                                *phase = HealingMachinePhase::WaitForMusic;
                                *frames_remaining = 120;
                                if let Some(ref mut state) = pending_healing_machine {
                                    state.phase = HealingMachinePhase::WaitForMusic;
                                    state.frames_remaining = 120;
                                    state.flash_active = false;
                                }
                            }
                        } else {
                            *frames_remaining -= 1;
                            if let Some(ref mut state) = pending_healing_machine {
                                state.frames_remaining = *frames_remaining;
                            }
                        }
                        false
                    }
                    HealingMachinePhase::WaitForMusic => {
                        if *frames_remaining == 0 {
                            *phase = HealingMachinePhase::Done;
                            *pending_healing_machine = None;
                        } else {
                            *frames_remaining -= 1;
                            if let Some(ref mut state) = pending_healing_machine {
                                state.frames_remaining = *frames_remaining;
                            }
                        }
                        false
                    }
                    HealingMachinePhase::Done => {
                        *pending_healing_machine = None;
                        audio_requests.push(OverworldAudioRequest::PlayMapMusic {
                            map: current_map,
                        });
                        true
                    }
                }
            }
            _ => true,
        }
    }

    /// Resume a script suspended on `await game.startBattle(...)`, delivering the
    /// outcome ("win" | "lose" | "draw") as the await result. No-op when no script
    /// is waiting (e.g. sight-engaged trainer battles that were not script-driven).
    pub fn resume_script_after_battle(&mut self, outcome: &str) {
        if !self.script_awaiting_battle {
            return;
        }
        self.script_awaiting_battle = false;
        if let Ok(Some(next_cmd)) = self
            .script_engine
            .signal_done(CommandResult::Text(outcome.to_string()))
        {
            self.active_script_effect = Some(script_bridge::dispatch_command_with_names(
                &next_cmd,
                &self.player_name,
                &self.rival_name,
                &self.starter_display_name(),
            ));
        }
        self.sync_flags_from_engine();
    }

    /// Resume a script suspended on `await game.elevatorMenu(...)`, delivering
    /// the chosen floor index (0-based, or -1 if the player cancelled) as the
    /// await result. No-op when no script is waiting.
    pub fn resume_script_after_elevator(&mut self, floor: i32) {
        if !self.script_awaiting_elevator {
            return;
        }
        self.script_awaiting_elevator = false;
        if floor >= 0 {
            // A floor was chosen: ShakeElevator plays once the elevator warp
            // completes (SilphCoElevatorShakeScript — BIT_CUR_MAP_USED_ELEVATOR).
            self.elevator_shake_pending = true;
        }
        if let Ok(Some(next_cmd)) = self
            .script_engine
            .signal_done(CommandResult::Number(floor as f64))
        {
            self.active_script_effect = Some(script_bridge::dispatch_command_with_names(
                &next_cmd,
                &self.player_name,
                &self.rival_name,
                &self.starter_display_name(),
            ));
        }
        self.sync_flags_from_engine();
    }

    /// Resume a script suspended on `await game.filterBag(...)`, delivering the
    /// chosen item's const name ("" if the player cancelled). No-op when no
    /// script is waiting.
    pub fn resume_script_after_filter_bag(&mut self, item_name: &str) {
        if !self.script_awaiting_filter_bag {
            return;
        }
        self.script_awaiting_filter_bag = false;
        if let Ok(Some(next_cmd)) = self
            .script_engine
            .signal_done(CommandResult::Text(item_name.to_string()))
        {
            self.active_script_effect = Some(script_bridge::dispatch_command_with_names(
                &next_cmd,
                &self.player_name,
                &self.rival_name,
                &self.starter_display_name(),
            ));
        }
        self.sync_flags_from_engine();
    }

    /// Resume a script suspended on `await game.tradePokemon(...)`, delivering
    /// whether the trade happened (the party held the offered mon). Called by
    /// the app after the trade cutscene completes and the party mutation is
    /// applied — or immediately with `false` when the offered mon is absent.
    /// No-op when no script is waiting.
    pub fn resume_script_after_trade(&mut self, traded: bool) {
        if !self.script_awaiting_trade {
            return;
        }
        self.script_awaiting_trade = false;
        if let Ok(Some(next_cmd)) = self.script_engine.signal_done(CommandResult::Bool(traded)) {
            self.active_script_effect = Some(script_bridge::dispatch_command_with_names(
                &next_cmd,
                &self.player_name,
                &self.rival_name,
                &self.starter_display_name(),
            ));
        }
        self.sync_flags_from_engine();
    }

    fn finish_effect(effect: &script_bridge::ScriptEffect) -> CommandResult {
        match effect {
            script_bridge::ScriptEffect::ShowChoice { selected, .. } => {
                CommandResult::Number(*selected as f64)
            }
            script_bridge::ScriptEffect::Immediate { result } => result.clone(),
            script_bridge::ScriptEffect::UnsupportedCommand { .. } => CommandResult::Void,
            script_bridge::ScriptEffect::NamingScreen {
                result_name,
                species,
                ..
            } => {
                let name = result_name
                    .as_ref()
                    .cloned()
                    .unwrap_or_else(|| species.clone());
                CommandResult::Text(name)
            }
            script_bridge::ScriptEffect::ChoosePartyPokemon { result_index, .. } => {
                CommandResult::Number(result_index.unwrap_or(-1) as f64)
            }
            _ => CommandResult::Void,
        }
    }

    fn apply_finished_effect(&mut self, effect: Option<script_bridge::ScriptEffect>) {
        if let Some(eff) = effect {
            match eff {
                script_bridge::ScriptEffect::ShowMoneyBox { amount } => {
                    self.script_money_box = if amount < 0 { None } else { Some(amount as u32) };
                }
                script_bridge::ScriptEffect::ShowCoinBox { amount } => {
                    self.script_coin_box = if amount < 0 { None } else { Some(amount.clamp(0, 9999) as u16) };
                }
                script_bridge::ScriptEffect::UnsupportedCommand { name, reason } => {
                    if let Some(reason) = reason {
                        log::error!(target: "pokered::overworld", "[Script] unsupported host command {name}: {reason}");
                    } else {
                        log::error!(target: "pokered::overworld", "[Script] unsupported host command: {name}");
                    }
                }
                script_bridge::ScriptEffect::SetJoyIgnore { mask } => {
                    self.joy_ignore_mask = mask;
                }
                script_bridge::ScriptEffect::ClearJoyIgnore => {
                    self.joy_ignore_mask = 0;
                }
                script_bridge::ScriptEffect::FaceNpc { npc_id, direction } => {
                    if let Some(idx) =
                        resolve_npc_index(&npc_id, &self.npc_states, &self.map_script_config)
                    {
                        self.npc_states[idx].facing = direction;
                        self.npc_states[idx].scripted_frame = None;
                    }
                }
                script_bridge::ScriptEffect::FacePlayer { direction } => {
                    self.state.player.facing = direction;
                }
                script_bridge::ScriptEffect::ShowObject { object_index } => {
                    if let Some(npc) = self
                        .npc_states
                        .iter_mut()
                        .find(|n| n.npc_index == object_index)
                    {
                        npc.visible = true;
                    }
                }
                script_bridge::ScriptEffect::HideObject { object_index } => {
                    if let Some(npc) = self
                        .npc_states
                        .iter_mut()
                        .find(|n| n.npc_index == object_index)
                    {
                        npc.visible = false;
                    }
                }
                script_bridge::ScriptEffect::ShowObjectByName { toggle_id } => {
                    use pokered_data::toggleable_objects::{
                        set_object_shown, toggle_id_to_bit_index,
                    };
                    if let Some(npc_id) = self.map_script_config.npc_id_by_toggle(&toggle_id) {
                        if let Some(npc) = self.npc_states.iter_mut().find(|n| n.text_id == npc_id)
                        {
                            npc.visible = true;
                        }
                    }
                    // Clear the hidden flag in unified_flags
                    let flag_key = format!("__OBJ_HIDDEN_{}", toggle_id);
                    self.set_flag_live(&flag_key, false);
                    let shown_key = format!("__OBJ_SHOWN_{}", toggle_id);
                    self.set_flag_live(&shown_key, true);
                    // Also update toggleable_object_flags for SRAM persistence
                    if let Some(bit_index) = toggle_id_to_bit_index(&toggle_id) {
                        set_object_shown(&mut self.toggleable_object_flags, bit_index);
                    }
                }
                script_bridge::ScriptEffect::HideObjectByName { toggle_id } => {
                    use pokered_data::toggleable_objects::{
                        set_object_hidden, toggle_id_to_bit_index,
                    };
                    if let Some(npc_id) = self.map_script_config.npc_id_by_toggle(&toggle_id) {
                        if let Some(npc) = self.npc_states.iter_mut().find(|n| n.text_id == npc_id)
                        {
                            npc.visible = false;
                        }
                    }
                    // Update both stores so a later engine sync cannot restore
                    // a stale shown flag loaded from a save or previous map.
                    let flag_key = format!("__OBJ_HIDDEN_{}", toggle_id);
                    self.set_flag_live(&flag_key, true);
                    let shown_key = format!("__OBJ_SHOWN_{}", toggle_id);
                    self.set_flag_live(&shown_key, false);
                    // Also update toggleable_object_flags for SRAM persistence
                    if let Some(bit_index) = toggle_id_to_bit_index(&toggle_id) {
                        set_object_hidden(&mut self.toggleable_object_flags, bit_index);
                    }
                }
                script_bridge::ScriptEffect::PlayMusic { music_id } => {
                    self.audio_requests
                        .push(OverworldAudioRequest::PlayMusic { music_id });
                }
                script_bridge::ScriptEffect::PlaySound { sound_id } => {
                    self.audio_requests
                        .push(OverworldAudioRequest::PlaySound { sound_id });
                }
                script_bridge::ScriptEffect::StopMusic => {
                    self.audio_requests.push(OverworldAudioRequest::StopMusic);
                }
                script_bridge::ScriptEffect::FadeOutMusic => {
                    self.audio_requests
                        .push(OverworldAudioRequest::FadeOutMusic);
                }
                script_bridge::ScriptEffect::StartBattle { trainer_id, rival_triplet_base } => {
                    // The scene runs its own battle flow (gym leaders, rivals):
                    // cancel any parked before-battle text phase so the fight
                    // does not double-fire when the scene's text closes.
                    self.trainer_intro_text_pending = None;
                    self.pending_trainer_battle = Some(PendingTrainerBattle {
                        trainer_id,
                        npc_index: u8::MAX,
                        // Script-driven battles (gym leaders, rivals) show their
                        // own reward/quip text from the .scene.
                        end_battle_text: None,
                        rival_triplet_base,
                    });
                }
                script_bridge::ScriptEffect::StartWildBattle { species, level } => {
                    // Static/legendary battle: queue a catchable wild encounter
                    // for the app to start; the script is suspended (awaiting the
                    // outcome) exactly like StartBattle.
                    let normalized = species
                        .chars()
                        .enumerate()
                        .map(|(i, c)| {
                            if i == 0 {
                                c.to_ascii_uppercase()
                            } else {
                                c.to_ascii_lowercase()
                            }
                        })
                        .collect::<String>();
                    if let Ok(sp) = normalized.parse::<pokered_data::species::Species>() {
                        self.pending_wild_encounter =
                            Some(PendingWildEncounter { species: sp, level, old_man: false, hooked: false });
                    } else {
                        log::warn!(target: "pokered::overworld", "startWildBattle: unknown species '{}'", species);
                    }
                }
                script_bridge::ScriptEffect::OldManTutorial => {
                    // The Old-Man catch tutorial: a Lv5 WEEDLE, auto-played + guaranteed
                    // catch (the app reads `old_man` and sets `battle.is_old_man`). The
                    // script is suspended awaiting the outcome, like StartWildBattle.
                    self.pending_wild_encounter = Some(PendingWildEncounter {
                        species: pokered_data::species::Species::Weedle,
                        level: 5,
                        old_man: true,
                        hooked: false,
                    });
                }
                script_bridge::ScriptEffect::SetNpcPosition { npc_id, x, y } => {
                    if let Some(npc_id) = self.map_script_config.npc_id_by_toggle(&npc_id) {
                        if let Some(npc) = self.npc_states.iter_mut().find(|n| n.text_id == npc_id)
                        {
                            npc.x = x as u16;
                            npc.y = y as u16;
                        }
                    }
                }
                script_bridge::ScriptEffect::SetNpcFrame { npc_id, frame } => {
                    if let Some(idx) =
                        resolve_npc_index(&npc_id, &self.npc_states, &self.map_script_config)
                    {
                        self.npc_states[idx].scripted_frame = Some(frame);
                    }
                }
                script_bridge::ScriptEffect::Heal => {
                    self.heal_requested = true;
                    if self.player_in_purified_zone() {
                        // PokemonTower5FDefaultScript uses the palette fade,
                        // keeps map music playing and holds white for Delay3×2.
                        self.warp_fade_to_white = true;
                        self.warp_fade_state = WarpFadeState::FadingOut {
                            frames_remaining: WARP_FADE_OUT_WHITE_FRAMES,
                        };
                    }
                    // Only the nurse records the recovery destination.
                    // Mom, Tower purification and Silph beds only call HealParty.
                    let is_center = matches!(self.state.current_map,
                        MapId::ViridianPokecenter | MapId::PewterPokecenter
                        | MapId::CeruleanPokecenter | MapId::MtMoonPokecenter
                        | MapId::RockTunnelPokecenter | MapId::VermilionPokecenter
                        | MapId::CeladonPokecenter | MapId::LavenderPokecenter
                        | MapId::FuchsiaPokecenter | MapId::CinnabarPokecenter
                        | MapId::SaffronPokecenter | MapId::IndigoPlateauLobby);
                    if is_center {
                        if let Some(map) = self.last_map {
                            self.game_data_requests.push(OverworldGameDataRequest::SetBlackoutMap { map });
                        }
                    }
                }
                script_bridge::ScriptEffect::GivePokemon {
                    species,
                    nickname,
                    level,
                    flow
                } => {
                    let normalized = species
                        .chars()
                        .enumerate()
                        .map(|(i, c)| if i == 0 { c.to_ascii_uppercase() } else { c.to_ascii_lowercase() })
                        .collect::<String>();
                    if self.party_count >= 6 && self.box_count as usize >= crate::pokemon::pc_box::MONS_PER_BOX {
                        if flow.is_none() {
                            // Defensive direct dispatch; a completed flow has
                            // already displayed BoxIsFullText.
                            self.pending_dialogue = Some(BedroomDialogue::from_message(&self.localize_message("Oops! This Box is\nfull of POKeMON.")));
                        }
                    } else if let Ok(sp) = normalized.parse::<pokered_data::species::Species>() {
                        self.pending_give_pokemon = Some(screen::PendingGivePokemon {
                            species: sp,
                            level,
                            nickname: nickname.clone(),
                        });
                    }
                }
                script_bridge::ScriptEffect::SetPartyNickname { index, nickname } => {
                    // Ignore an empty name (a cancelled naming screen) so the
                    // Pokémon keeps its current nickname. The app layer owns the
                    // party, so surface the write as a pending request.
                    if !nickname.is_empty() {
                        self.pending_set_nickname = Some((index, nickname));
                    }
                }
                script_bridge::ScriptEffect::GiveItem { item_id, quantity } => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::GiveItem {
                            item: item_id,
                            quantity,
                        });
                }
                script_bridge::ScriptEffect::TradePokemon {
                    offered,
                    received,
                    nickname,
                } => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::TradePokemon {
                            offered,
                            received,
                            nickname,
                        });
                }
                script_bridge::ScriptEffect::TakeItem { item_id, quantity } => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::TakeItem {
                            item: item_id,
                            quantity,
                        });
                }
                script_bridge::ScriptEffect::GiveMoney { amount } => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::GiveMoney { amount });
                }
                script_bridge::ScriptEffect::TakeMoney { amount } => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::TakeMoney { amount });
                }
                script_bridge::ScriptEffect::GiveCoins { amount } => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::GiveCoins { amount });
                }
                script_bridge::ScriptEffect::TakeCoins { amount } => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::TakeCoins { amount });
                }
                script_bridge::ScriptEffect::DepositDaycare { index } => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::DepositDaycare { index });
                }
                script_bridge::ScriptEffect::WithdrawDaycare => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::WithdrawDaycare);
                }
                script_bridge::ScriptEffect::PlayCry { species } => {
                    self.audio_requests
                        .push(OverworldAudioRequest::PlayCry { species });
                }
                script_bridge::ScriptEffect::GiveBadge { badge } => {
                    self.game_data_requests
                        .push(OverworldGameDataRequest::GiveBadge { badge });
                }
                script_bridge::ScriptEffect::ReplaceTileBlock { x, y, block_id } => {
                    // Mutate the live block grid in place. Collision + rendering
                    // read `blocks` every frame, so no re-render/invalidation is
                    // needed.
                    if let Some(map) = self.map_data.as_mut() {
                        map.set_block(x, y, block_id);
                    }
                }
                script_bridge::ScriptEffect::WarpTo { map, x, y } => {
                    // Scripted warpTo (elevator floors, Hall of Fame, etc.):
                    // queue a fade-out warp exactly like a door/edge transition.
                    if let Some(dest_map) =
                        pokered_data::map_data_loader::resolve_map_id(&map)
                    {
                        // Same rule as door warps: only outside maps update the
                        // Escape Rope/DIG return point, so warps from interior
                        // maps don't clobber last_map/last_map_entry.
                        let save_last_map = self
                            .map_data
                            .as_ref()
                            .map(|m| special_terrain::is_outside_map(m.tileset))
                            .unwrap_or(false);
                        self.pending_warp = Some(PendingWarp {
                            dest_map,
                            dest_x: x,
                            dest_y: y,
                            save_last_map,
                            // Script warps (elevator floors, Hall of Fame)
                            // use the plain fade — no EnterMapAnim.
                            arrival_spin: false,
                        });
                        self.warp_fade_state = WarpFadeState::FadingOut {
                            frames_remaining: WARP_FADE_OUT_FRAMES,
                        };
                        self.sfx_event = OverworldSfxEvent::GoOutside;
                    } else {
                        log::warn!(
                            target: "pokered::overworld",
                            "[Script] warpTo: unknown map '{}'",
                            map
                        );
                    }
                }
                script_bridge::ScriptEffect::FadeScreen { .. } => {}
                script_bridge::ScriptEffect::OpenShop { items } => {
                    self.pending_shop = Some(items);
                }
                script_bridge::ScriptEffect::OpenSlots { lucky } => {
                    // No explicit argument → the machine is lucky when the
                    // sign that fired this script is the per-map-entry lucky
                    // roll (GameCornerSelectLuckySlotMachine).
                    let lucky = lucky.unwrap_or_else(|| self.resolve_default_lucky_slots());
                    self.pending_slots = Some(lucky);
                }
                script_bridge::ScriptEffect::ElevatorMenu { floors } => {
                    self.pending_elevator = Some(floors);
                }
                script_bridge::ScriptEffect::FilterBag { item_ids } => {
                    self.pending_filter_bag = Some(item_ids);
                }
                script_bridge::ScriptEffect::ShowDiploma => {
                    self.pending_diploma = true;
                }
                script_bridge::ScriptEffect::OpenPc { kind } => {
                    self.pending_pc = Some(kind);
                }
                script_bridge::ScriptEffect::LinkStart => {
                    self.link_start_requested = true;
                }
                script_bridge::ScriptEffect::HallOfFameCeremony => {
                    self.pending_hof_ceremony = true;
                }
                _ => {}
            }
        }
    }

    pub(crate) fn load_map_script(&mut self, map_id: MapId) {
        self.load_map_script_ex(map_id, true);
    }

    /// `load_map_script` with an on-load fire switch: frame-level
    /// snapshot restore (agent M5) rebuilds functions/triggers through
    /// this path but must NOT fire `@load` (the restored storyline state
    /// is authoritative; re-firing would double-apply its effects).
    pub(crate) fn load_map_script_ex(&mut self, map_id: MapId, fire_on_load: bool) {
        self.wild_data_state.load_map(map_id);
        self.sync_flags_from_engine();

        let map_key = script_bridge::map_id_to_script_key(map_id);
        log::info!(target: "pokered::overworld", "[Script] Loading map script for {:?} (key: {})", map_id, map_key);
        // The engine is recreated per map; carry the selected script language
        // ("en"/"zh") over so a LanguageSelect choice survives map transitions
        // (bedroom → downstairs: mom's `@t` dialogue must stay Chinese).
        let script_lang = self.script_engine.script_lang().unwrap_or("en").to_string();
        // Drop the previous map's interpreter, pending effect and bindings
        // before deserializing the next AST. On GBA, retaining the old scene
        // while materializing both the shared and target scenes exceeds EWRAM
        // during the Pallet Town → Oak's Lab escort transition.
        self.script_engine = super::native_script::OverworldScriptEngine::new();
        // VermilionCity_Script randomizes only the first index at city entry.
        if fire_on_load && map_id == MapId::VermilionCity {
            self.first_lock_trash_can = self.next_rng_u8() & 0x0e;
        }
        self.script_engine.set_gym_trash_indices(self.first_lock_trash_can, self.second_lock_trash_can);
        self.script_queries_need_seed = true;
        self.script_engine.set_lang(&script_lang);
        self.active_script_effect = None;
        self.script_money_box = None;
        self.script_coin_box = None;
        self.map_script_config = MapScriptConfig::default();

        #[cfg(feature = "script-boa")]
        match &mut self.script_engine {
            super::native_script::OverworldScriptEngine::Boa(engine) => {
                if let Some(shared_source) = self.script_loader.get_script("shared/pokecenter") {
                    log::info!(target: "pokered::overworld", "[Script] Loading shared/pokecenter module ({} bytes)", shared_source.len());
                    match engine.load_shared_module("pokecenter.js", shared_source) {
                        Ok(()) => log::info!(target: "pokered::overworld", "[Script] Shared pokecenter module loaded OK"),
                        Err(e) => log::warn!(target: "pokered::overworld", "[Script] Shared pokecenter module FAILED: {}", e),
                    }
                } else {
                    log::warn!(target: "pokered::overworld", "[Script] No shared/pokecenter module found in loader");
                }

                if let Some(source) = self.script_loader.get_script(&map_key) {
                    log::info!(target: "pokered::overworld", "[Script] Loading {} script ({} bytes)", map_key, source.len());
                    match engine.load_script(source) {
                        Ok(()) => log::info!(target: "pokered::overworld", "[Script] {} script loaded OK", map_key),
                        Err(e) => log::warn!(target: "pokered::overworld", "[Script] {} script FAILED: {}", map_key, e),
                    }
                } else {
                    log::warn!(target: "pokered::overworld", "[Script] No script found for key '{}'", map_key);
                }
            }
        }

        #[cfg(not(feature = "script-boa"))]
        {
            let map_ast = self.scene_ast_provider.get_scene(&map_key).cloned();
            let disk_mode = self.scene_ast_provider.disk_mode;
            if let super::native_script::OverworldScriptEngine::Native(engine) =
                &mut self.script_engine
            {
                match map_ast {
                    Some(scene) => {
                        let storyline_count = scene.storylines.len();
                        engine.load_map_owned(&map_key, scene);
                        log::info!(target: "pokered::overworld", "[NativeScript] Loaded AST for {} ({} storylines)", map_key, storyline_count);
                    }
                    None if disk_mode => log::warn!(target: "pokered::overworld", "[NativeScript] No disk scene AST found for key '{}'", map_key),
                    None => {
                        let count = engine.load_embedded_map(
                            &map_key,
                            pokered_data::embedded_scenes::scene_functions_for_map(&map_key),
                        );
                        log::info!(target: "pokered::overworld", "[NativeScript] Registered {} lazy functions for {}", count, map_key);
                    }
                }
            }
        }

        self.map_script_config =
            screen::load_map_script_config(&self.script_loader, &map_key);

        #[cfg(not(feature = "script-boa"))]
        {
            let requires_shared =
                if let super::native_script::OverworldScriptEngine::Native(engine) =
                    &self.script_engine
                {
                    self.map_script_config
                        .on_load()
                        .is_some_and(|name| !engine.has_function(name))
                        || self.map_script_config.npcs.iter().any(|binding| {
                            binding
                                .talk
                                .as_deref()
                                .is_some_and(|name| !engine.has_function(name))
                        })
                        || self
                            .map_script_config
                            .signs
                            .iter()
                            .any(|binding| !engine.has_function(&binding.talk))
                        || self
                            .map_script_config
                            .coord_events
                            .iter()
                            .any(|binding| !engine.has_function(&binding.trigger))
                } else {
                    false
                };

            if requires_shared {
                let shared_ast = self
                    .scene_ast_provider
                    .get_scene("shared/pokecenter")
                    .cloned();
                let disk_mode = self.scene_ast_provider.disk_mode;
                if let super::native_script::OverworldScriptEngine::Native(engine) =
                    &mut self.script_engine
                {
                    if let Some(scene) = &shared_ast {
                        engine.register_shared_scene(scene);
                    } else if !disk_mode {
                        engine.register_embedded_shared(
                            "shared/pokecenter",
                            pokered_data::embedded_scenes::scene_functions_for_map(
                                "shared/pokecenter",
                            ),
                        );
                    }
                }
            }
        }

        log::info!(target: "pokered::overworld", "[Script] Config for {}: {} NPCs, {} signs, {} coord_events",
            map_key,
            self.map_script_config.npcs.len(),
            self.map_script_config.signs.len(),
            self.map_script_config.coord_events.len(),
        );

        self.script_engine
            .seed_flags(&self.unified_flags.to_hashmap());

        if fire_on_load {
            if let Some(fn_name) = self.map_script_config.on_load() {
                log::info!(target: "pokered::overworld", "[Script] on_load function: {}", fn_name);
                if self.script_engine.has_function(fn_name) {
                    log::info!(target: "pokered::overworld", "[Script] Calling on_load: {}", fn_name);
                    self.script_engine
                        .set_player_position(self.state.player.x as u8, self.state.player.y as u8);
                    if let Ok(Some(cmd)) = self.script_engine.call_function_no_args(fn_name) {
                        self.active_script_effect = Some(script_bridge::dispatch_command_with_names(
                            &cmd,
                            &self.player_name,
                            &self.rival_name,
                            &self.starter_display_name(),
                        ));
                    }
                    self.sync_flags_from_engine();
                } else {
                    log::warn!(target: "pokered::overworld", "[Script] on_load function '{}' not found in module", fn_name);
                }
            }
        }

        // ── Build triggers from config + script exports ─────────────
        self.setup_triggers_for_map(map_id);

        crate::debug_log::flush();
    }

    /// Populates the [`TriggerManager`] with entries derived from the current
    /// map's `script_config.json` and detected JS function-name patterns.
    ///
    /// The existing script system (`load_map_script`, `coord_event_fn`,
    /// `npc_talk_fn`, `on_load`) continues to work unchanged — the trigger
    /// manager runs in parallel as an additional unified dispatch layer.
    pub(super) fn setup_triggers_for_map(&mut self, map_id: MapId) {
        use dotzuki_engine::metatile::TriggerType;
        use dotzuki_engine::trigger_manager::Trigger;

        let map_key = script_bridge::map_id_to_script_key(map_id);
        // The script engine/config below only own the current map. Keeping
        // other maps' bindings made the trigger Vec grow with every visited
        // map until its next allocation exhausted the GBA heap. Remove all
        // old bindings, retaining capacity and the previous-player position
        // so same-map reloads preserve OnEnter edge detection.
        loop {
            let old_map = self.trigger_manager.all_triggers().next()
                .map(|trigger| trigger.map_id.clone());
            let Some(old_map) = old_map else { break };
            self.trigger_manager.remove_triggers_for_map(&old_map);
        }

        // 1. Coord events → OnStep triggers
        for ce in &self.map_script_config.coord_events {
            if self.script_engine.has_function(&ce.trigger) {
                let id = format!("coord_{}", ce.name);
                self.trigger_manager.add_trigger(Trigger::single_tile(
                    id,
                    map_key.clone(),
                    TriggerType::OnStep,
                    ce.position.0 as u32,
                    ce.position.1 as u32,
                    ce.trigger.clone(),
                    ce.one_shot,
                ));
            }
        }

        // A locked door cannot receive OnStep; Card Key interactions target
        // its solid tiles from the adjoining corridor.
        let card_key_doors: &[(u32, u32, &str)] = match self.state.current_map {
            MapId::SilphCo3F => &[(4, 4, "cardKeyDoor1"), (8, 4, "cardKeyDoor2")],
            MapId::SilphCo11F => &[(3, 6, "cardKeyDoor")],
            _ => &[],
        };
        for &(bx, by, handler) in card_key_doors {
            if !self.script_engine.has_function(handler) { continue; }
            for (x, y) in [(bx * 2, by * 2), (bx * 2 + 1, by * 2),
                           (bx * 2, by * 2 + 1), (bx * 2 + 1, by * 2 + 1)] {
                self.trigger_manager.add_trigger(Trigger::single_tile(
                    format!("card_key_door_{x}_{y}"), map_key.clone(),
                    TriggerType::OnInteract, x, y, handler.to_string(), false,
                ));
            }
        }

        // Mansion hidden events are statue interactions, not walkable floor
        // triggers. Keep the original coordinates as the facing target.
        let mansion_statues: &[(u32, u32, &str)] = match self.state.current_map {
            MapId::PokemonMansion1F => &[(2, 5, "coordSwitch")],
            MapId::PokemonMansion3F => &[(10, 5, "secretSwitch")],
            MapId::PokemonMansionB1F => &[(20, 3, "coordSwitchA"), (18, 25, "coordSwitchB")],
            _ => &[],
        };
        for &(x, y, handler) in mansion_statues {
            if self.script_engine.has_function(handler) {
                self.trigger_manager.add_trigger(Trigger::single_tile(
                    format!("mansion_statue_{x}_{y}"), map_key.clone(),
                    TriggerType::OnInteract, x, y, handler.to_string(), false,
                ));
            }
        }

        // Cinnabar Gym quiz machines are facing-up hidden interactions
        // (hidden_events.asm CINNABAR_GYM: PrintCinnabarQuiz), not walkable
        // floor and not NPCs — bind OnInteract at the machine tiles.
        let cinnabar_quiz_machines: &[(u32, u32, &str)] = match self.state.current_map {
            MapId::CinnabarGym => &[
                (15, 7, "quizMachine1"),
                (10, 1, "quizMachine2"),
                (9, 7, "quizMachine3"),
                (9, 13, "quizMachine4"),
                (1, 13, "quizMachine5"),
                (1, 7, "quizMachine6"),
            ],
            _ => &[],
        };
        for &(x, y, handler) in cinnabar_quiz_machines {
            if self.script_engine.has_function(handler) {
                self.trigger_manager.add_trigger(Trigger::single_tile(
                    format!("cinnabar_quiz_{x}_{y}"), map_key.clone(),
                    TriggerType::OnInteract, x, y, handler.to_string(), false,
                ));
            }
        }

        // 2. on_load / enterMap → OnEnter trigger at player position
        if let Some(fn_name) = self.map_script_config.on_load() {
            if self.script_engine.has_function(fn_name) {
                self.trigger_manager.add_trigger(Trigger::single_tile(
                    format!("enter_{}", fn_name),
                    map_key.clone(),
                    TriggerType::OnEnter,
                    self.state.player.x as u32,
                    self.state.player.y as u32,
                    fn_name.to_string(),
                    true,
                ));
            }
        }

        // NPC dialogue is dispatched by try_interact at the NPC's live position.
        // Fixed coordinate triggers would bypass trainer battle handoff and still
        // talk to NPCs after they move away or become hidden.

        // 4. Sign talk functions → OnInteract triggers at sign positions
        for sign_cfg in &self.map_script_config.signs {
            if self.script_engine.has_function(&sign_cfg.talk) {
                if let Some(map) = &self.map_data {
                    if let Some(sign) = map.signs.iter().find(|s| s.text_id == sign_cfg.id) {
                        self.trigger_manager.add_trigger(Trigger::single_tile(
                            format!("sign_talk_{}", sign_cfg.id),
                            map_key.clone(),
                            TriggerType::OnInteract,
                            sign.x as u32,
                            sign.y as u32,
                            sign_cfg.talk.clone(),
                            false,
                        ));
                    }
                }
            }
        }

        log::info!(target: "pokered::overworld", "[Trigger] Built {} triggers for {}", self.trigger_manager.len(), map_key);
    }

    fn try_call_script_npc_talk(&mut self, text_id: u8) -> bool {
        if let Some(fn_name) = self.map_script_config.npc_talk_fn(text_id) {
            log::info!(target: "pokered::overworld", "[Script] NPC talk: text_id={}, fn_name={}", text_id, fn_name);
            if self.script_engine.has_function(fn_name) {
                log::info!(target: "pokered::overworld", "[Script] Calling {}", fn_name);
                // NPC scripts never run on a sign: clear any stale sign
                // context so `openSlots()` cannot inherit a lucky mapping.
                self.active_sign_text_id = None;
                self.script_engine
                    .set_player_position(self.state.player.x as u8, self.state.player.y as u8);
                if let Ok(Some(cmd)) = self.script_engine.call_function_no_args(fn_name) {
                    self.active_script_effect = Some(script_bridge::dispatch_command_with_names(
                        &cmd,
                        &self.player_name,
                        &self.rival_name,
                        &self.starter_display_name(),
                    ));
                    self.sync_flags_from_engine();
                    crate::debug_log::flush();
                    return true;
                }
                self.sync_flags_from_engine();
            } else {
                log::warn!(target: "pokered::overworld", "[Script] Function '{}' not found in module, falling back to JSON text", fn_name);
            }
        } else {
            log::info!(target: "pokered::overworld", "[Script] NPC talk: text_id={}, no script function mapped", text_id);
        }
        crate::debug_log::flush();
        false
    }

    fn try_call_script_sign_talk(&mut self, text_id: u8) -> bool {
        if let Some(fn_name) = self.map_script_config.sign_talk_fn(text_id) {
            if self.script_engine.has_function(fn_name) {
                // Remember which sign fired so `openSlots()` (no explicit
                // argument) can resolve against the lucky-machine roll.
                self.active_sign_text_id = Some(text_id);
                self.script_engine
                    .set_player_position(self.state.player.x as u8, self.state.player.y as u8);
                if let Ok(Some(cmd)) = self.script_engine.call_function_no_args(fn_name) {
                    self.active_script_effect = Some(script_bridge::dispatch_command_with_names(
                        &cmd,
                        &self.player_name,
                        &self.rival_name,
                        &self.starter_display_name(),
                    ));
                    self.sync_flags_from_engine();
                    return true;
                }
                self.sync_flags_from_engine();
            }
        }
        false
    }

    /// Resolve `openSlots()` without an explicit lucky flag: the machine is
    /// lucky when the sign that fired the script is the one rolled for this
    /// map visit (`lucky_slot_machine_sign`).
    pub(crate) fn resolve_default_lucky_slots(&self) -> bool {
        self.active_sign_text_id.is_some()
            && self.active_sign_text_id == self.lucky_slot_machine_sign
    }

    fn npc_face_player(&mut self, npc_index: u8) {
        let face_dir = player_movement::opposite_direction(self.state.player.facing);
        if let Some(npc) = self
            .npc_states
            .iter_mut()
            .find(|n| n.npc_index == npc_index)
        {
            npc.facing = face_dir;
        }
    }

    fn try_show_npc_json_text(&mut self, text_id: u8) -> bool {
        if let Some(text_pages) = get_npc_text_from_json(self.state.current_map, text_id) {
            if !text_pages.is_empty() {
                let pages = self.localize_text_pages(&text_pages);
                self.pending_dialogue = Some(BedroomDialogue::from_text_pages(
                    &pages,
                    &self.player_name,
                    &self.rival_name,
                    &self.starter_display_name(),
                ));
                return true;
            }
        }
        false
    }

    pub(crate) fn player_in_purified_zone(&self) -> bool {
        self.state.current_map == MapId::PokemonTower5F
            && (10..=11).contains(&self.state.player.x)
            && (8..=9).contains(&self.state.player.y)
    }

    pub(crate) fn check_wild_encounter_on_step(
        &mut self,
        map_id: MapId,
        tileset: G::Tileset,
        standing_tile: u8,
        right_tile: u8,
        standing_on_warp: bool,
        has_script_effect: bool,
    ) -> bool {        use crate::battle::wild::{EncounterContext, WildEncounterRandoms};
        use pokered_data::event_flags::EventFlag;
        use rand::Rng;

        // PokemonTower5FDefaultScript sets BIT_NO_BATTLES throughout the
        // purified zone. No encounter RNG or Repel steps are consumed there.
        if map_id == MapId::PokemonTower5F && self.player_in_purified_zone() {
            return false;
        }

        // Original MtMoonB2F_Script: once the Super Nerd is beaten, wild
        // battles are disabled inside the fossil area (MtMoonB2FFossilAreaCoords:
        // x 11-14, y 5-8) via wStatusFlags4 BIT_NO_BATTLES.
        if map_id == MapId::MtMoonB2F
            && (11..=14).contains(&(self.state.player.x as u8))
            && (5..=8).contains(&(self.state.player.y as u8))
            && EventFlag::from_name("EVENT_BEAT_MT_MOON_EXIT_SUPER_NERD")
                .map_or(false, |f| self.unified_flags.check(f))
        {
            return false;
        }

        // The encounter-check gate (the classic TryDoWildEncounter call
        // conditions): only steps that may actually roll consume a REPEL
        // tick (wild_encounters.asm:19-25). The >0 → 0 transition is
        // returned so the caller replaces this step's roll with the
        // "wore off" text (.lastRepelStep).
        let roll_gated =
            !standing_on_warp && !has_script_effect && self.state.encounter_cooldown == 0;
        let mut wore_off = false;
        if roll_gated {
            if self.state.repel_steps > 0 {
                self.state.repel_steps -= 1;
                if self.state.repel_steps == 0 {
                    wore_off = true;
                }
            }
        }
        if wore_off {
            // .lastRepelStep: the "wore off" step never rolls an encounter.
            return true;
        }

        let encounter_roll = self.rng.gen_range(0u8..=255);
        let slot_roll = self.rng.gen_range(0u8..=255);

        let randoms = WildEncounterRandoms {
            encounter_roll,
            slot_roll,
        };

        let context = EncounterContext {
            repel_active: self.state.repel_steps > 0,
            // Gen-1 repel compares wild level against the LEAD (first) party
            // member's level. The OverworldScreen does not own the full party,
            // so the app layer keeps `party_lead_level` in sync from save data.
            party_lead_level: self.party_lead_level,
        };

        let result = wild_encounters::check_wild_encounter_with_tables(
            map_id,
            tileset,
            standing_tile,
            right_tile,
            &self.wild_data_state.grass,
            &self.wild_data_state.water,
            &randoms,
            &context,
            standing_on_warp,
            has_script_effect,
            self.state.encounter_cooldown,
        );

        if let crate::battle::wild::WildEncounterResult::Encounter { level, species } = result {
            self.pending_wild_encounter = Some(PendingWildEncounter { species, level, old_man: false, hooked: false });
        }
        wore_off
    }

    pub(crate) fn sync_flags_from_engine(&mut self) {
        (self.first_lock_trash_can, self.second_lock_trash_can) = self.script_engine.gym_trash_indices();
        let engine_flags = self.script_engine.get_all_flags();
        self.unified_flags.merge_from(&engine_flags);
        if self.safari_game_active && !self.unified_flags.get_flag("EVENT_IN_SAFARI_ZONE") {
            self.end_safari_game();
        }
    }

    /// Safari Zone step accounting, run once per completed step. Decrements the
    /// step counter while inside the zone. The original permits the step that
    /// changes 1 to 0 and ends the game on the following completed step.
    fn tick_safari_steps(&mut self) {
        if !self.safari_game_active {
            return;
        }
        if !pokered_data::map_flags::is_safari_zone_map(self.state.current_map) {
            return;
        }
        if self.safari_steps > 0 {
            self.safari_steps -= 1;
            return;
        }
        // Eject on an already empty step counter. Only fire when nothing else is
        // mid-flight (a wild battle just triggered, an active script, or an open
        // text box); the check re-runs on the next step, so the eject is not lost.
        if self.pending_wild_encounter.is_none()
            && self.active_script_effect.is_none()
            && self.pending_dialogue.is_none()
            && self.safari_eject_pending.is_none()
        {
            self.trigger_safari_game_over();
        }
    }

    /// End the Safari game: show the announcer's "game over" line and queue the
    /// eject warp back to the gate (fired once the message is dismissed).
    fn trigger_safari_game_over(&mut self) {
        // SafariGameOverText omits TimesUpText when there are no balls left.
        // Preserve that distinction before end_safari_game clears counters.
        let timed_out = self.safari_balls != 0;
        self.end_safari_game();
        self.set_flag_live("EVENT_SAFARI_GAME_OVER", true);
        self.audio_requests.push(OverworldAudioRequest::StopMusic);
        self.audio_requests.push(OverworldAudioRequest::PlaySound {
            sound_id: "SFX_SAFARI_ZONE_PA".to_string(),
        });
        let mut pages = Vec::new();
        if timed_out {
            let text = self.localize_message("PA: Ding-dong!\n\nTime's up!");
            pages.extend_from_slice(screen::BedroomDialogue::from_message(&text).pages());
        }
        let text = self.localize_message("PA: Your SAFARI\nGAME is over!");
        pages.extend_from_slice(screen::BedroomDialogue::from_message(&text).pages());
        self.pending_dialogue = Some(screen::BedroomDialogue::from_pages(pages));
        self.safari_eject_pending = Some(PendingWarp {
            dest_map: MapId::SafariZoneGate,
            dest_x: screen::SAFARI_GATE_RETURN_X,
            dest_y: screen::SAFARI_GATE_RETURN_Y,
            save_last_map: false,
            // Plain fade transition back to the gate.
            arrival_spin: false,
        });
    }
}

#[cfg(test)]
mod safari_timer_tests {
    use super::*;
    use pokered_data::impl_traits::PokemonRedData;

    fn screen_at(map: MapId) -> OverworldScreen<PokemonRedData> {
        OverworldScreen::new(map, None, PokemonRedData)
    }

    fn warp_to(ow: &mut OverworldScreen<PokemonRedData>, dest: MapId) {
        ow.pending_warp = Some(PendingWarp {
            dest_map: dest,
            dest_x: 0,
            dest_y: 0,
            save_last_map: false,
            arrival_spin: false,
        });
        ow.commit_pending_warp();
    }

    #[test]
    fn entering_zone_arms_the_game() {
        let mut ow = screen_at(MapId::SafariZoneGate);
        assert!(!ow.is_safari_game_active());
        warp_to(&mut ow, MapId::SafariZoneCenter);
        assert!(ow.is_safari_game_active());
        assert_eq!(ow.safari_steps_remaining(), screen::SAFARI_ZONE_STEP_COUNT);
        assert_eq!(ow.safari_balls_remaining(), screen::SAFARI_ZONE_BALL_COUNT);
    }

    #[test]
    fn gate_return_preserves_steps_and_balls_until_player_quits() {
        let mut ow = screen_at(MapId::SafariZoneGate);
        warp_to(&mut ow, MapId::SafariZoneCenter);
        assert!(ow.is_safari_game_active());
        ow.tick_safari_steps();
        ow.use_safari_ball();
        let allowance = (ow.safari_steps_remaining(), ow.safari_balls_remaining());
        warp_to(&mut ow, MapId::SafariZoneGate);
        assert!(ow.is_safari_game_active());
        ow.tick_safari_steps(); // the gate does not count steps
        warp_to(&mut ow, MapId::SafariZoneCenter);
        assert_eq!(
            (ow.safari_steps_remaining(), ow.safari_balls_remaining()),
            allowance
        );
        warp_to(&mut ow, MapId::SafariZoneGate);
        ow.script_engine.set_flag("EVENT_IN_SAFARI_ZONE", false); // Leaving early? YES
        ow.sync_flags_from_engine();
        assert!(!ow.is_safari_game_active());
        assert_eq!(ow.safari_steps_remaining(), 0);
        assert_eq!(ow.safari_balls_remaining(), 0);
        warp_to(&mut ow, MapId::SafariZoneCenter); // a newly paid hunt
        assert_eq!(ow.safari_steps_remaining(), screen::SAFARI_ZONE_STEP_COUNT);
        assert_eq!(ow.safari_balls_remaining(), screen::SAFARI_ZONE_BALL_COUNT);
    }

    #[test]
    fn leaving_facility_ends_hunt_and_cannot_resurrect_flag() {
        let mut ow = screen_at(MapId::SafariZoneGate);
        warp_to(&mut ow, MapId::SafariZoneCenter);
        warp_to(&mut ow, MapId::FuchsiaCity);
        ow.sync_flags_from_engine();
        assert!(!ow.is_safari_game_active());
        assert!(!ow.unified_flags.get_flag("EVENT_IN_SAFARI_ZONE"));
    }

    #[test]
    fn each_step_decrements_the_counter() {
        let mut ow = screen_at(MapId::SafariZoneGate);
        warp_to(&mut ow, MapId::SafariZoneCenter);
        let before = ow.safari_steps_remaining();
        ow.tick_safari_steps();
        assert_eq!(ow.safari_steps_remaining(), before - 1);
    }

    #[test]
    fn zero_steps_ends_game_and_queues_eject() {
        let mut ow = screen_at(MapId::SafariZoneGate);
        warp_to(&mut ow, MapId::SafariZoneCenter);
        ow.safari_steps = 1;
        ow.tick_safari_steps();
        assert_eq!(ow.safari_steps_remaining(), 0);
        assert!(ow.is_safari_game_active(), "the 1-to-0 step is permitted");
        assert!(ow.pending_dialogue.is_none());
        assert!(ow.safari_eject_pending.is_none());
        ow.tick_safari_steps();
        assert!(!ow.is_safari_game_active());
        assert!(ow.pending_dialogue.is_some());
        ow.sync_flags_from_engine();
        assert!(ow.unified_flags.get_flag("EVENT_SAFARI_GAME_OVER"));
        assert!(!ow.unified_flags.get_flag("EVENT_IN_SAFARI_ZONE"));
        let warp = ow.safari_eject_pending.take().expect("eject queued");
        assert_eq!(warp.dest_map, MapId::SafariZoneGate);
        let (gate, _) = crate::overworld::map_data_loading::load_full_map_data_concrete(MapId::SafariZoneGate);
        let arrival = &gate.warps[3];
        assert_eq!((warp.dest_x, warp.dest_y), (arrival.x, arrival.y),
            "SafariZoneGameOver uses the fourth original gate warp");
        ow.pending_warp = Some(warp);
        ow.commit_pending_warp();
        assert!(ow.active_script_effect.is_some(), "gate starts the farewell");
        assert!(!ow.unified_flags.get_flag("EVENT_SAFARI_GAME_OVER"));
        assert!(!ow.unified_flags.get_flag("EVENT_IN_SAFARI_ZONE"));
    }

    #[test]
    fn zero_balls_ends_game() {
        let mut ow = screen_at(MapId::SafariZoneGate);
        warp_to(&mut ow, MapId::SafariZoneCenter);
        ow.safari_balls = 0;
        let before = (ow.state.player.x, ow.state.player.y);
        ow.update_frame(OverworldInput::new(false, false, false, false, false, false, false, false));
        assert_eq!((ow.state.player.x, ow.state.player.y), before);
        assert!(!ow.is_safari_game_active());
        assert!(ow.unified_flags.get_flag("EVENT_SAFARI_GAME_OVER"));
        assert!(ow.safari_eject_pending.is_some());
    }

    #[test]
    fn safari_announcement_distinguishes_timeout_from_empty_balls() {
        for balls in [0, 1] {
            let mut ow = screen_at(MapId::SafariZoneCenter);
            ow.start_safari_game();
            ow.safari_balls = balls;
            ow.audio_requests.clear();
            ow.trigger_safari_game_over();
            let pages = ow.pending_dialogue.as_ref().unwrap().pages();
            let text = pages.iter().map(|p| format!("{}\n{}", p.line1, p.line2))
                .collect::<Vec<_>>().join("\n");
            assert_eq!(text.contains("Time's up!"), balls != 0);
            assert_eq!(text.contains("Ding-dong!"), balls != 0);
            assert!(text.ends_with("PA: Your SAFARI\nGAME is over!"));
            assert!(matches!(ow.audio_requests.first(), Some(OverworldAudioRequest::StopMusic)));
            assert!(matches!(ow.audio_requests.get(1), Some(OverworldAudioRequest::PlaySound {sound_id}) if sound_id == "SFX_SAFARI_ZONE_PA"));
        }
    }

    #[test]
    fn using_balls_counts_down() {
        let mut ow = screen_at(MapId::SafariZoneGate);
        warp_to(&mut ow, MapId::SafariZoneCenter);
        assert_eq!(ow.use_safari_ball(), screen::SAFARI_ZONE_BALL_COUNT - 1);
    }

    #[test]
    fn no_decrement_outside_zone() {
        let mut ow = screen_at(MapId::SafariZoneGate);
        // Manually pretend a game is active but we are on a non-zone map.
        ow.start_safari_game();
        let before = ow.safari_steps_remaining();
        ow.tick_safari_steps();
        assert_eq!(ow.safari_steps_remaining(), before);
    }
}

#[cfg(test)]
mod object_visibility_tests {
    use super::*;
    #[test]
    fn latest_object_visibility_survives_engine_merge_and_reentry() {
        let mut screen = OverworldScreen::new(MapId::CeruleanCity, None, pokered_data::impl_traits::PokemonRedData);
        let toggle = "CERULEAN_RIVAL";
        for visible in [true, false, true, false] {
            let effect = if visible {
                script_bridge::ScriptEffect::ShowObjectByName { toggle_id: toggle.into() }
            } else {
                script_bridge::ScriptEffect::HideObjectByName { toggle_id: toggle.into() }
            };
            screen.apply_finished_effect(Some(effect));
            screen.sync_flags_from_engine();
            screen.apply_hidden_object_flags();
            assert_eq!(screen.unified_flags.get_flag(&format!("__OBJ_SHOWN_{toggle}")), visible);
            assert_eq!(screen.unified_flags.get_flag(&format!("__OBJ_HIDDEN_{toggle}")), !visible);
            let id = screen.map_script_config.npc_id_by_toggle(toggle).unwrap();
            assert_eq!(screen.npc_states.iter().find(|n| n.text_id == id).unwrap().visible, visible);
        }
    }
}

#[cfg(test)]
mod late_fidelity_tests {
    use super::*;
    use pokered_data::{impl_traits::PokemonRedData, tilesets::TilesetId};

    fn idle() -> OverworldInput {
        OverworldInput::new(false, false, false, false, false, false, false, false)
    }

    #[test]
    fn fidelity_purified_zone_rearms_without_consuming_repel_or_encounter_rng() {
        let mut screen = OverworldScreen::new(MapId::PokemonTower5F, None, PokemonRedData);
        screen.state.player.x = 10;
        screen.state.player.y = 8;
        screen.run_on_load();
        screen.set_flag_live("EVENT_IN_PURIFIED_ZONE", true);
        screen.state.repel_steps = 10;
        // A tile/turn would otherwise roll the indoor cemetery encounter.
        for _ in 0..100 {
            assert!(!screen.check_wild_encounter_on_step(MapId::PokemonTower5F, TilesetId::Cemetery, 0, 0, false, false));
        }
        assert_eq!(screen.state.repel_steps, 10);
        assert!(screen.pending_wild_encounter.is_none());
        screen.update_frame(idle());
        assert!(screen.unified_flags.get_flag("EVENT_IN_PURIFIED_ZONE"));
        screen.state.player.x = 9;
        screen.update_frame(idle());
        assert!(!screen.unified_flags.get_flag("EVENT_IN_PURIFIED_ZONE"));
        assert!(!screen.script_engine.get_flag("EVENT_IN_PURIFIED_ZONE"));
        // Re-enter the same floor and run the actual coordinate handler again.
        screen.state.player.x = 10;
        let command = screen.script_engine.call_function_no_args("coordPurifiedZone").unwrap().unwrap();
        assert_eq!(command, dotzuki_engine_script::ScriptCommand::Heal);
        screen.sync_flags_from_engine();
        assert!(screen.unified_flags.get_flag("EVENT_IN_PURIFIED_ZONE"));
    }

    #[test]
    fn fidelity_purified_heal_fades_to_white_holds_six_frames_and_keeps_music() {
        let mut screen = OverworldScreen::new(MapId::PokemonTower5F, None, PokemonRedData);
        screen.state.player.x = 10;
        screen.state.player.y = 8;
        screen.apply_finished_effect(Some(script_bridge::ScriptEffect::Heal));
        assert!(screen.heal_requested);
        assert!(screen.warp_fade_to_white);
        assert!(screen.pending_warp.is_none());
        assert!(!screen.audio_requests.iter().any(|a| matches!(a, OverworldAudioRequest::StopMusic | OverworldAudioRequest::FadeOutMusic)));
        for _ in 0..WARP_FADE_OUT_WHITE_FRAMES {
            screen.update_frame(idle());
        }
        assert_eq!(screen.warp_fade_state, WarpFadeState::BlackScreen);
        for _ in 0..5 {
            screen.update_frame(idle());
            assert_eq!(screen.warp_fade_state, WarpFadeState::BlackScreen);
        }
        screen.update_frame(idle());
        assert_eq!(screen.warp_fade_state, WarpFadeState::FadingIn { frames_remaining: WARP_FADE_IN_FRAMES });
        for _ in 0..WARP_FADE_IN_FRAMES {
            screen.update_frame(idle());
        }
        assert_eq!(screen.warp_fade_state, WarpFadeState::Idle);
        assert!(!screen.warp_fade_to_white);
    }

    #[test]
    fn fidelity_lance_intro_reaches_the_original_coordinate_and_closes_door() {
        let mut screen = OverworldScreen::new(MapId::LancesRoom, None, PokemonRedData);
        screen.state.player.x = 24;
        screen.state.player.y = 16;
        screen.run_on_load();
        for _ in 0..600 {
            screen.update_frame(idle());
        }
        assert_eq!((screen.state.player.x, screen.state.player.y), (6, 11));
        assert!(screen.unified_flags.get_flag("EVENT_LANCES_ROOM_LOCK_DOOR"));
        assert!(screen.script_engine.is_idle());
        let map = screen.map_data.as_ref().unwrap();
        assert_eq!(map.blocks[6 * map.width as usize + 2], 114);
        assert_eq!(map.blocks[6 * map.width as usize + 3], 115);
    }
}

#[cfg(test)]
mod ground_pickup_fidelity_tests {
    use super::*;
    use pokered_data::impl_traits::PokemonRedData;
    use pokered_data::items::ItemId;
    use pokered_data::npc_data::get_map_npcs;
    use pokered_data::toggleable_objects::{is_object_hidden, toggle_id_to_bit_index};

    fn input(a: bool) -> OverworldInput {
        OverworldInput::new(false, false, false, false, a, false, false, false)
    }

    fn finish_dialogue(ow: &mut OverworldScreen<PokemonRedData>) -> usize {
        let mut item_jingles = 0;
        for frame in 0..320 {
            if let Some(dialogue) = ow.pending_dialogue.as_mut() {
                dialogue.skip_to_full_page();
            }
            ow.update_frame(input(frame % 2 == 1));
            item_jingles += ow
                .audio_requests
                .iter()
                .filter(|request| {
                    matches!(request,
                OverworldAudioRequest::PlaySound { sound_id } if sound_id == "SFX_GET_ITEM_1")
                })
                .count();
            if ow.active_script_effect.is_none() && ow.pending_dialogue.is_none() {
                break;
            }
        }
        assert!(
            ow.active_script_effect.is_none(),
            "pickup script must finish: {:?}",
            ow.active_script_effect
        );
        assert!(ow.pending_dialogue.is_none(), "pickup dialogue must close");
        ow.update_frame(input(false));
        item_jingles
    }

    fn full_bag_without(item: ItemId) -> Vec<String> {
        (1..=pokered_data::items::NUM_ITEMS)
            .map(ItemId::from_id)
            .filter(|candidate| *candidate != item)
            .take(20)
            .map(|candidate| candidate.const_name())
            .collect()
    }

    fn verify_pickup(map: MapId, index: usize, press_a: bool) {
        let data = &get_map_npcs(map)[index];
        let expected = ItemId::from_id(data.item_id);
        let mut ow = OverworldScreen::new(map, None, PokemonRedData);
        // Isolate the ball from trainer sight and unrelated automatic NPCs.
        for (i, npc) in ow.npc_states.iter_mut().enumerate() {
            npc.visible = i == index;
        }
        let toggle = ow
            .map_script_config
            .npcs
            .iter()
            .find(|npc| npc.id == data.text_id)
            .unwrap()
            .toggle_id
            .as_ref()
            .unwrap()
            .clone();
        let bit = toggle_id_to_bit_index(&toggle).expect("every ball has its original SRAM bit");
        ow.state.player.x = data.x as u16;
        ow.state.player.y = data.y as u16 + 1;
        ow.state.player.facing = Direction::Up;
        if map == MapId::ViridianGym {
            // The tile south of Revive is an arrow; talk from its west side.
            ow.state.player.x = data.x as u16 - 1;
            ow.state.player.y = data.y as u16;
            ow.state.player.facing = Direction::Right;
        }
        let bag = full_bag_without(expected);
        ow.seed_script_query_state(0, &bag, 0, 0, 0, 0, &[], 0, 0, 0);
        let before_flags = ow.script_flags();
        ow.audio_requests.clear();
        if press_a {
            ow.update_frame(input(true));
        } else {
            assert!(
                ow.try_call_script_npc_talk(data.text_id),
                "{map:?} npc {} handler",
                data.text_id
            );
        }
        let failed_jingles = finish_dialogue(&mut ow);
        assert!(
            ow.npc_states[index].visible,
            "{map:?} npc {} must survive full bag",
            data.text_id
        );
        assert!(
            !is_object_hidden(ow.toggleable_object_flags(), bit),
            "failed pickup must preserve SRAM bit"
        );
        for (flag, enabled) in ow.script_flags() {
            if enabled && flag.starts_with("EVENT_GOT_") {
                assert_eq!(
                    before_flags.get(&flag),
                    Some(&true),
                    "failed pickup set {flag}"
                );
            }
        }
        assert_eq!(
            failed_jingles, 0,
            "full bag must not play the found-item jingle"
        );
        ow.game_data_requests.clear();
        ow.audio_requests.clear();
        // Free one bag slot and retry the same ball, then verify its byte item.
        ow.seed_script_query_state(0, &bag[..19], 0, 0, 0, 0, &[], 0, 0, 0);
        if press_a {
            ow.update_frame(input(true));
        } else {
            assert!(ow.try_call_script_npc_talk(data.text_id));
        }
        let success_jingles = finish_dialogue(&mut ow);
        let given: Vec<_> = ow
            .game_data_requests
            .iter()
            .filter_map(|request| match request {
                OverworldGameDataRequest::GiveItem { item, quantity } => {
                    Some((ItemId::from_const_name(item), *quantity))
                }
                _ => None,
            })
            .collect();
        assert_eq!(
            given,
            vec![(Some(expected), 1)],
            "{map:?} npc {} reward",
            data.text_id
        );
        assert_eq!(
            success_jingles, 1,
            "successful pickup must play exactly one found-item jingle"
        );
        assert!(
            !ow.npc_states[index].visible,
            "successful pickup must hide the ball"
        );
        assert!(
            is_object_hidden(ow.toggleable_object_flags(), bit),
            "successful pickup must persist SRAM bit"
        );
        let mut reloaded = OverworldScreen::new(map, None, PokemonRedData);
        reloaded.set_script_flags(ow.script_flags());
        reloaded.set_toggleable_object_flags(*ow.toggleable_object_flags());
        reloaded.apply_hidden_object_flags();
        assert!(
            !reloaded.npc_states[index].visible,
            "{map:?} npc {} must stay hidden on reload",
            data.text_id
        );
    }

    #[test]
    fn every_original_ground_ball_preserves_failure_and_persists_success() {
        let mut count = 0;
        for id in 0..248u8 {
            let Some(map) = MapId::from_u8(id) else {
                continue;
            };
            for (index, npc) in get_map_npcs(map).iter().enumerate() {
                if npc.item_id != 0 {
                    verify_pickup(map, index, false);
                    count += 1;
                }
            }
        }
        assert_eq!(count, 104);
    }

    #[test]
    fn item_pickup_a_button_path_handles_full_bag_wrong_tm_and_missing_handlers() {
        for (map, npc_id) in [
            (MapId::Route2, 1),
            (MapId::MtMoon1F, 13),
            (MapId::MtMoonB2F, 8),
            (MapId::PowerPlant, 10),
            (MapId::ViridianGym, 11),
        ] {
            let index = get_map_npcs(map)
                .iter()
                .position(|npc| npc.text_id == npc_id)
                .unwrap();
            verify_pickup(map, index, true);
        }
    }

    #[test]
    fn found_text_prints_before_sound_waits_for_completion_and_closes_without_a() {
        let mut ow = OverworldScreen::new(MapId::Route2, None, PokemonRedData);
        ow.seed_script_query_state(0, &[], 0, 0, 0, 0, &[], 0, 0, 0);
        assert!(ow.try_call_script_npc_talk(1));
        for _ in 0..200 {
            ow.update_frame(input(false));
            if ow.audio_requests.iter().any(|request| {
                matches!(request,
                OverworldAudioRequest::PlaySound { sound_id } if sound_id == "SFX_GET_ITEM_1")
            }) {
                break;
            }
        }
        let dialogue = ow
            .pending_dialogue
            .as_ref()
            .expect("found text stays during sound");
        assert_eq!(
            dialogue.char_index(),
            dialogue.total_chars(),
            "print precedes jingle"
        );
        assert!(
            !ow.dialogue_needs_button(),
            "automatic item text has no prompt arrow"
        );
        assert!(matches!(
            ow.active_script_effect,
            Some(script_bridge::ScriptEffect::ShowItemDialogue {
                sound_started: true,
                ..
            })
        ));
        // Simulate the same sequencer status sampled by the native frontend.
        ow.script_sfx_playing = true;
        for frame in 0..20 {
            ow.update_frame(input(frame % 2 == 0));
            assert!(
                ow.pending_dialogue.is_some(),
                "A cannot close a playing fanfare"
            );
        }
        let snap = crate::snapshot::OverworldSnapshot::capture(&ow);
        ow.pending_dialogue = None;
        ow.active_script_effect = None;
        snap.restore_into(&mut ow);
        assert!(matches!(
            ow.active_script_effect,
            Some(script_bridge::ScriptEffect::ShowItemDialogue {
                sound_started: true,
                ..
            })
        ));
        ow.update_frame(input(false));
        assert!(
            ow.pending_dialogue.is_some(),
            "restored pending sound must still block"
        );
        ow.script_sfx_playing = false;
        ow.update_frame(input(true));
        assert!(
            ow.pending_dialogue.is_some(),
            "original HoldTextDisplayOpen waits for A release"
        );
        ow.update_frame(input(false));
        assert!(
            ow.pending_dialogue.is_none(),
            "sound end closes without an A press"
        );
        assert!(ow.active_script_effect.is_none());
    }
}

#[cfg(test)]
mod fidelity_systems_healing_tests {
    use super::*;
    use pokered_data::impl_traits::PokemonRedData;
    #[test]
    #[cfg(not(feature = "script-boa"))]
    fn suspended_npc_trade_keeps_connect_text_advancing_without_reemitting_trade() {
        let mut ow=OverworldScreen::new(MapId::Route2TradeHouse,None,PokemonRedData);
        ow.reload_scene_source("Route2TradeHouse",r#"game_scene Route2TradeHouse {
    @storyline("tradeProbe") {
        traded = tradePokemon("ABRA", "MR_MIME", "MARCEL")
        @if (traded) {
            setFlag("EVENT_TRADED_FOR_MARCEL")
        }
    }
}"#).unwrap();
        let command=ow.script_engine.call_function_no_args("tradeProbe").unwrap().unwrap();
        ow.active_script_effect=Some(script_bridge::dispatch_command_with_names(&command,"RED","BLUE",""));
        let neutral=OverworldInput::new(false,false,false,false,false,false,false,false);
        ow.update_frame(neutral);
        assert!(ow.script_awaiting_trade);
        assert_eq!(ow.game_data_requests.len(),1);
        ow.game_data_requests.clear();
        ow.pending_dialogue=Some(BedroomDialogue::from_message("Okay, connect the\ncable like so!"));
        for _ in 0..10 { ow.update_frame(neutral); }
        assert!(ow.active_script_effect.is_none());
        assert!(ow.game_data_requests.is_empty());
        assert!(ow.pending_dialogue.as_ref().unwrap().char_index()>0);
        ow.pending_dialogue=None;
        ow.resume_script_after_trade(true);
        for _ in 0..4 { ow.update_frame(neutral); }
        assert!(ow.unified_flags.get_flag("EVENT_TRADED_FOR_MARCEL"));
    }
    #[test]
    fn nurses_alone_record_blackout_destination() {
        for map in [MapId::ViridianPokecenter,MapId::PewterPokecenter,MapId::CeruleanPokecenter,MapId::MtMoonPokecenter,MapId::RockTunnelPokecenter,MapId::VermilionPokecenter,MapId::CeladonPokecenter,MapId::LavenderPokecenter,MapId::FuchsiaPokecenter,MapId::CinnabarPokecenter,MapId::SaffronPokecenter,MapId::IndigoPlateauLobby] {
            let mut ow=OverworldScreen::new(map,None,PokemonRedData); ow.last_map=Some(MapId::CeruleanCity);
            ow.apply_finished_effect(Some(script_bridge::ScriptEffect::Heal));
            assert!(ow.heal_requested,"{map:?}");
            assert!(ow.game_data_requests.iter().any(|r| matches!(r,OverworldGameDataRequest::SetBlackoutMap { map:MapId::CeruleanCity })),"{map:?}");
        }
        for map in [MapId::RedsHouse1F,MapId::PokemonTower5F,MapId::SilphCo9F,MapId::SafariZoneEastRestHouse,MapId::SafariZoneWestRestHouse,MapId::SafariZoneNorthRestHouse] {
            let mut ow=OverworldScreen::new(map,None,PokemonRedData); ow.last_map=Some(MapId::SaffronCity);
            ow.apply_finished_effect(Some(script_bridge::ScriptEffect::Heal));
            assert!(ow.heal_requested,"{map:?}");
            assert!(!ow.game_data_requests.iter().any(|r| matches!(r,OverworldGameDataRequest::SetBlackoutMap { .. })),"{map:?}");
        }
    }
    #[test]
    fn failed_full_box_gift_never_queues_pokemon() {
        let mut ow=OverworldScreen::new(MapId::CeladonMansionRoofHouse,None,PokemonRedData);
        ow.party_count=6;ow.box_count=20;
        ow.apply_finished_effect(Some(script_bridge::ScriptEffect::GivePokemon { species:"Eevee".to_string(), nickname:None,level:25, flow:None }));
        assert!(ow.pending_give_pokemon.is_none());assert!(ow.pending_dialogue.is_some());
    }
}

#[cfg(test)]
mod vending_delivery_fidelity_tests {
    use super::*;
    use pokered_data::impl_traits::PokemonRedData;
    #[test]
    fn delivery_restarts_push_boulder_sound_sixty_times_two_frames_apart() {
        let mut ow = OverworldScreen::new(MapId::CeladonMartRoof, None, PokemonRedData);
        ow.active_script_effect =
            Some(script_bridge::ScriptEffect::VendingDelivery { frames_elapsed: 0 });
        let neutral = OverworldInput::new(false, false, false, false, false, false, false, false);
        ow.audio_requests.clear();
        let mut total = 0;
        for frame in 1..=120 {
            ow.update_frame(neutral);
            let count = ow
                .audio_requests
                .iter()
                .filter(|request| {
                    matches!(request,
                OverworldAudioRequest::PlaySound { sound_id } if sound_id == "SFX_PUSH_BOULDER")
                })
                .count();
            assert_eq!(
                count,
                usize::from(frame % 2 == 0),
                "delivery sound at frame {frame}"
            );
            total += count;
            assert_eq!(ow.active_script_effect.is_none(), frame == 120);
        }
        assert_eq!(total, 60);
    }
}

#[cfg(test)]
mod field_typing_input_fidelity_tests {
    use super::*;
    use pokered_data::impl_traits::PokemonRedData;

    #[test]
    fn short_held_ab_matches_original_letter_wait_without_scroll_sound() {
        // Original Safari worker, wOptions=3; first letter is relative frame 0.
        // A/B held at relative 10,11: glyph counts from PrintLetterDelay hooks.
        let expected = [1,1,1,2,2,2,3,3,3,4,4,5,6,6,6,7,7,7,8];
        for scripted in [false, true] {
            for b in [false, true] {
                let mut ow = OverworldScreen::new(MapId::RedsHouse2F, None, PokemonRedData);
                let idle = OverworldInput::new(false,false,false,false,false,false,false,false);
                for _ in 0..120 { ow.update_frame(idle); }
                ow.set_text_delay_frames(3);
                let mut dialogue = BedroomDialogue::from_message("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                dialogue.set_text_delay_frames(3);
                ow.pending_dialogue = Some(dialogue);
                if scripted {
                    ow.active_script_effect = Some(script_bridge::ScriptEffect::ShowDialogue { text: "ABCDEFGHIJKLMNOPQRSTUVWXYZ".into() });
                }
                // Textbox preparation owns sprite work; find first glyph rather
                // than claiming DisplayTextID's still-unmatched absolute entry.
                for _ in 0..120 {
                    ow.update_frame(idle);
                    if ow.pending_dialogue.as_ref().unwrap().char_index() == 1 { break; }
                }
                assert_eq!(ow.pending_dialogue.as_ref().unwrap().char_index(),1);
                for t in 1..expected.len() {
                    let held = (10..12).contains(&t);
                    ow.update_frame(OverworldInput::new(false,false,false,false,held && !b,held && b,false,false));
                    assert_eq!(ow.pending_dialogue.as_ref().unwrap().char_index(),expected[t],"scripted={scripted},B={b},relative={t}");
                    assert_eq!(ow.sfx_event,OverworldSfxEvent::None,"typing is not ManualTextScroll");
                    assert!(!ow.pending_dialogue.as_ref().unwrap().waiting_for_input());
                }
                // A long hold accelerates one glyph per tick, without closing
                // the fully printed page until a fresh button press.
                for _ in 0..40 { ow.update_frame(OverworldInput::new(false,false,false,false,!b,b,false,false)); }
                assert_eq!(ow.pending_dialogue.as_ref().unwrap().char_index(),26);
                assert!(ow.pending_dialogue.as_ref().unwrap().waiting_for_input());
                assert!(!ow.pending_dialogue.as_ref().unwrap().holding_open());
                ow.update_frame(idle);
                ow.update_frame(OverworldInput::new(false,false,false,false,true,false,false,false));
                assert_eq!(ow.sfx_event,OverworldSfxEvent::TextAdvance);
                assert!(ow.pending_dialogue.as_ref().unwrap().holding_open());
            }
        }
    }
}
