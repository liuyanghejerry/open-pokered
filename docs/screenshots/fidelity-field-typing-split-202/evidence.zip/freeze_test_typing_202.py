from pathlib import Path
import re,shutil,hashlib,json,subprocess,os
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-202-typing-checkout';out=r/'audit-202-native-a3-immutable';out.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();log=(r/'audit-202-native-build-a3.log').read_text();bs={}
for name,label in [('pokered_core','core-tests'),('pokered_app','app-tests')]:
 src=Path(re.search(r'Executable unittests src/lib.rs \(([^\n]*'+name+r'-[^\n]*)\)',log).group(1));shutil.copy2(src,out/label);bs[label]=sha(out/label)
files=subprocess.check_output(['git','diff','master','--name-only'],cwd=wt,text=True).splitlines();m={'base':subprocess.check_output(['git','rev-parse','master'],cwd=wt,text=True).strip(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip(),'binaries':bs,'sources':{p:sha(wt/p) for p in files},'scope':'heldAB gradualtyping/noScrollSound+lastglyphwait only; capture has realGame and retained/full ownerpixels; noquestionretention orinnerPrintText auto-return prerequisites'};(out/'manifest.json').write_text(json.dumps(m,indent=2))
env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib')
for label in ['core-tests','app-tests']:
 with (r/f'audit-202-{label}-a3.log').open('w') as f:subprocess.run([str(out/label),'--test-threads=4'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(label,'PASS')
