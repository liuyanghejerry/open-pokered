from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile

root = Path('/home/jerry/develop/open-pokered')
r = root / '.task-tmp/fidelity-39-plus'
wt = root / '.task-tmp/fidelity-202-typing-checkout'
dest = wt / 'docs/screenshots/fidelity-field-typing-split-202'
dest.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
native = json.loads((r / 'audit-202-native-a3-immutable/manifest.json').read_text())
for name, digest in native['sources'].items():
    assert sha(wt / name) == digest, name
for case, frame in [('a', 14), ('b', 14), ('idle', 89)]:
    for side, label in [('master', 'before'), ('native', 'after')]:
        shutil.copy2(r / f'audit-202-{side}-{case}-a3-1/frame-{frame:04}.png', dest / f'{case}-{label}.png')
with zipfile.ZipFile(dest / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for side in ['master', 'native']:
        for case in ['idle', 'a', 'b']:
            a = r / f'audit-202-{side}-{case}-a3-1'
            b = r / f'audit-202-{side}-{case}-a3-2'
            for p in a.iterdir():
                if p.suffix in ['.png', '.json']:
                    assert p.read_bytes() == (b / p.name).read_bytes(), p
            for repeat in [1, 2]:
                d = r / f'audit-202-{side}-{case}-a3-{repeat}'
                for p in d.iterdir():
                    if p.suffix in ['.png', '.json']: z.write(p, str(p.relative_to(r)))
                p = r / (d.name + '.log'); z.write(p, p.name)
        p = r / f'audit-202-{side}-a3-immutable/manifest.json'; z.write(p, str(p.relative_to(r)))
    for name in ['audit-202-native-build-a2.log', 'audit-202-native-build-a3.log', 'audit-202-master-build-a3.log', 'audit-202-core-tests-a3.log', 'audit-202-app-tests-a3.log', 'audit-202-repeat-and-source-count-verification.json', 'audit-202-original-count-revalidation.json', 'audit-202-capture-helper.rs', 'prepare_typing_202.py', 'freeze_test_typing_202.py', 'record_typing_202_a3.py', 'package_typing_202.py']:
        z.write(r / name, name)
    for name in native['sources']: z.write(wt / name, 'final-source/' + name)
    old = root / '.task-tmp/fidelity-91-plus-checkout/docs/screenshots/fidelity-field-typing-160/evidence.zip'
    with zipfile.ZipFile(old) as src:
        for name in src.namelist():
            if name.startswith('audit-160-original-typing-') and Path(name).suffix in ['.png', '.json', '.log']:
                z.writestr('historical-original/' + name, src.read(name))
    ref = Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
    for name in ['home/print_text.asm', 'home/joypad2.asm', 'scripts/SafariZoneGate.asm']:
        z.write(ref / name, 'original-source/' + name)
verification = {
    'capture_master': '7d5fb20fb27ba4b4b301c34a4aff5729f3db22f5',
    'current_base': subprocess.check_output(['git', 'rev-parse', 'origin/master'], cwd=wt, text=True).strip(),
    'native': native,
    'master': json.loads((r / 'audit-202-master-a3-immutable/manifest.json').read_text()),
    'tests': {'core': 2709, 'app': 190, 'app_ignored': 17},
    'fixture_sha256': sha(r / 'safari-147-source-setup/safari-one-step.sav'),
    'recording': '3 cases * 2 sides * 2 repetitions * 145 frames = 1740 PNG; complete raw JSON and PNG repeats byte exact without masks; retained/full pixel comparison on every frame',
    'source_comparison': json.loads((r / 'audit-202-original-count-revalidation.json').read_text()),
    'files': {p.name: sha(p) for p in dest.iterdir() if p.suffix in ['.png', '.zip']},
}
(dest / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
(dest / 'README.md').write_text('''# Field typing controls: standalone split 202

Only held A/B gradual printing and the final letter delay are repaired. Short A/B
while a field message is printing previously completed the entire page and emitted
TextAdvance. It now shortens letter waits to one frame without scrolling or closing
the page. Finishing a page includes its last letter's 1/3/5-frame speed wait.
Direct/scripted/automatic-item/nested gift/reading-menu paths share these controls.
Unit tests cover A/B, script/non-script, no scroll sound and release before closing.

Core2709 and app190 pass, with17 app capture tests intentionally ignored. The
owned capture runs real CONTINUE from controlled original SRAM, ends the fixture
Safari session, warps to the information worker at(3,4), reseeds field RNG1 after
loading, faces left and uses Medium text speed. Trigger A at t0 is released at t1;
the two-frame A/B pulse is at t12/13 and released at t14. Idle has no second pulse.
Same inputs and frame numbers are used on actual master7d5fb20 and the repair.
Master gets30 characters at the pulse; repair gets6 at t14. Master displays the
ready arrow at t89; repair waits through the last glyph until t92.

All145 frames of all three cases on both sides were repeated twice. All1740PNG
and full raw JSON repeats match byte-for-byte without masks. Every frame compares
retained rendering against a complete draw at every pixel. The original160 raw
recordings were independently re-read: first19 glyph counts match the repair
relative to the first glyph; original Medium final glyph wait is3 frames. Original
first glyph is t24 and native t2: absolute entry CPU/font/PPU timing is not claimed.
Native still needs acknowledgement before the following choice; original inner
PrintText automatic return is a separate pending fix. Question retention, global
NoDelay call sites, dialogue initialization/closing, movements and PC flows are
excluded. No font/layout change or global RNG/audio-waveform parity is claimed.

Native frozen tests/captures are pinned to d02b558 with master7d5fb20. The later
merge of master25c56ca adds the independent quantity fix; all three typing/capture
source SHA256 values remain unchanged (asserted when packaging). Current-head CI
must independently validate that combination, including unchanged GBA budgets.
Evidence contains original-only historical records, primary assembly, fresh raw
recordings, frozen binary/source hashes and tests. Failed a2 capture-helper import
build log is retained as a diagnostic; passing a3 supersedes it. No ROM or binary
is distributed in the archive.
''')
print('packaged', len(list(dest.iterdir())), 'files', (dest / 'evidence.zip').stat().st_size)
