from pathlib import Path
import re,shutil,hashlib,json,subprocess,os
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';before=root/'.task-tmp/fidelity-202-typing-before-checkout';after=root/'.task-tmp/fidelity-202-typing-checkout';f=r/'audit-202-master-a3-immutable';f.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();log=(r/'audit-202-master-build-a3.log').read_text();src=Path(re.search(r'Executable unittests src/lib.rs \(([^\n]*pokered_app-[^\n]*)\)',log).group(1));shutil.copy2(src,f/'app-tests');name='crates/pokered-app/src/game.rs';prefix=subprocess.check_output(['git','show','HEAD:'+name],cwd=before);assert (before/name).read_bytes().startswith(prefix);(f/'manifest.json').write_text(json.dumps({'base':'7d5fb20fb27ba4b4b301c34a4aff5729f3db22f5','binary':sha(f/'app-tests'),'capture_source':sha(before/name),'production_prefix_sha256':hashlib.sha256(prefix).hexdigest(),'scope':'actualmaster production intact, identical capturehelper appended'},indent=2))
fixed=json.loads((r/'audit-202-fixed-pulse.json').read_text());first=fixed['first_glyph'];pulse=fixed['pulse'];expected=[1,1,1,2,2,2,3,3,3,4,4,5,6,6,6,7,7,7,8];idle_expected=[1,1,1,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7];result={}
for side,cwd,binary in [('master',before,f/'app-tests'),('native',after,r/'audit-202-native-a3-immutable/app-tests')]:
 result[side]={}
 for case in ['idle','a','b']:
  for n in [1,2]:
   out=r/f'audit-202-{side}-{case}-a3-{n}';out.mkdir(exist_ok=True);env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',FIDELITY_TYPING_CAPTURE_202=str(out),FIDELITY_SAFARI_SRAM=str(r/'safari-147-source-setup/safari-one-step.sav'),FIDELITY_TYPING_FIXED_PULSE=str(pulse));env.pop('FIDELITY_TYPING_B',None);env.pop('FIDELITY_TYPING_PULSE',None)
   if case!='idle':env['FIDELITY_TYPING_PULSE']='1'
   if case=='b':env['FIDELITY_TYPING_B']='1'
   with (r/f'{out.name}.log').open('w') as log:subprocess.run([str(binary),'capture_typing_pulse_202','--ignored','--nocapture'],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  a=r/f'audit-202-{side}-{case}-a3-1';b=r/f'audit-202-{side}-{case}-a3-2'
  for p in a.iterdir():
   if p.suffix in ['.png','.json']:assert p.read_bytes()==(b/p.name).read_bytes(),p
  rows=json.loads((a/'frames.json').read_text());assert next(x['first_letter'] for x in rows if x['first_letter'] is not None)==first
  counts=[rows[first+i]['letters'] for i in range(19)];sounds=[rows[first+i]['sfx'] for i in range(19)];assert [rows[t]['input_bits'] for t in range(145)]==[json.loads((r/f'audit-202-native-{case}-a3-1/frames.json').read_text())[t]['input_bits'] for t in range(145)] if side=='native' else True
  if side=='native':assert counts==(idle_expected if case=='idle' else expected),(side,case,counts);assert all(x=='None' for x in sounds),(side,case,sounds)
  result[side][case]={'first19counts':counts,'first19sounds':sounds,'complete_frame':next(x['t'] for x in rows if x['overworld'].get('pending_dialogue',{} ) and x['overworld']['pending_dialogue'].get('waiting_for_input')),'frames':145,'repeat':'allPNG/fullrawJSONbyteexact'}
  print(side,case,counts,'sounds',sorted(set(sounds)))
for case in ['idle','a','b']:
 a=json.loads((r/f'audit-202-master-{case}-a3-1/frames.json').read_text());b=json.loads((r/f'audit-202-native-{case}-a3-1/frames.json').read_text());assert [x['input_bits'] for x in a]==[x['input_bits'] for x in b]
(r/'audit-202-repeat-and-source-count-verification.json').write_text(json.dumps({'fixed':fixed,'source_relative19counts':{'pulse':expected,'idle':idle_expected},'cases':result,'pixel_owner':'all recordedframes compare retained/fullpackedpixels on bothsides','scope':'sourcefirstglyphrelativecounttable, not originalabsolutePPU/framealignment; actualmaster/native use samefixedinputs/frames'},indent=2)+'\n')
