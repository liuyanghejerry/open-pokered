from pathlib import Path
import json,hashlib,shutil,subprocess,zipfile
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';base=root/'.task-tmp/fidelity-93-master-before';ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c');out=w/'docs/screenshots/fidelity-offer-questions-163';out.mkdir(parents=True,exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());helper=(r/'offer-163-capture-helper.rs').read_bytes()
for tree,head in [(base,'31b1eda3112514d6bc803af559ec7f7c9e20374f'),(w,'abe1398662441f6768f64cab3e9763cc8cacede2')]:
 old=subprocess.check_output(['git','show',head+':crates/pokered-app/src/game.rs'],cwd=tree);new=(tree/'crates/pokered-app/src/game.rs').read_bytes();boundary=old.index(b'#[cfg(test)]\nmod session_guard_tests');assert old[:boundary]==new[:boundary];assert new.endswith(helper)
for f,n in [('audit-163-core-tests-final.log',2739),('audit-163-data-tests-final.log',262),('audit-163-app-final-tests.log',213),('audit-163-agent-tests-final.log',54)]:assert f'{n} passed; 0 failed' in (r/f).read_text()
gba=load(r/'audit-163-gba-provenance-final.json');assert all(h(w/s)==sha for s,sha in gba['sources'].items());c=(r/'audit-163-gba-compare-final.log').read_text();assert len([x for x in c.splitlines() if ' -> ' in x])==31 and 'within the configured regression budget' in c
archives={};cases={}
def archive(name,entries):
 manifest={name:h(p) for name,p in entries.items()};p=out/name
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
  for name,source in sorted(entries.items()):z.write(source,name)
  z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(p) as z:
  for name,sha in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
 assert p.stat().st_size<95*1024*1024
 archives[p.name]=dict(sha256=h(p),files=len(manifest)+1,bytes=p.stat().st_size)
for case,menu in [('old',189),('good',234),('super',216),('chairman',446)]:
 entries={}
 for side in ['before','after']:
  p=r/f'audit-163-{side}-{case}-final-1';q=r/f'audit-163-{side}-{case}-final-2';assert sorted(x.name for x in p.iterdir())==sorted(x.name for x in q.iterdir());assert all(x.read_bytes()==(q/x.name).read_bytes() for x in p.iterdir())
  for trial in [1,2]:
   p=r/f'audit-163-{side}-{case}-final-{trial}'
   for f in p.iterdir():entries[str(f.relative_to(r))]=f
   log=r/f'audit-163-{side}-{case}-final-{trial}.log';assert '1 passed' in log.read_text();entries[log.name]=log
  shutil.copy2(r/f'audit-163-{side}-{case}-final-1/frame-1100.png',out/f'{case}-{side}.png')
 a=load(r/f'audit-163-after-{case}-final-1/frames.json');b=load(r/f'audit-163-before-{case}-final-1/frames.json');assert [x['input_bits'] for x in a]==[x['input_bits'] for x in b];assert next(x['t'] for x in a if x['overworld']['pending_choice'])==menu;assert a[1100]['overworld']['pending_choice']['options']==['YES','NO'] and b[1100]['overworld']['pending_choice'] is None;cases[case]=dict(native_choice_initialized=menu,paired_frame=1100,repeat_all_files_byte_exact=True,identical_inputs=True)
 archive(f'evidence-{case}.zip',entries)
entries={}
for p in r.glob('audit-163-*'):
 if p.is_file() and p.suffix in ['.log','.json','.txt']:entries[p.name]=p
for s in gba['sources']:entries['source/'+s]=w/s
entries['baseline-source/game.rs']=base/'crates/pokered-app/src/game.rs';entries['tools/offer_capture.rs']=r/'offer-163-capture-helper.rs';entries['tools/package_offers_163.py']=r/'stats-59-tools/package_offers_163.py'
for m in ['VermilionOldRodHouse','FuchsiaGoodRodHouse','Route12SuperRodHouse','PokemonFanClub']:
 for d in ['scripts','text']:entries[f'reference-source/{d}/{m}.asm']=ref/d/f'{m}.asm'
archive('evidence-shared.zip',entries)
for name,source in [('gba-provenance.json','audit-163-gba-provenance-final.json'),('gba-result.json','audit-163-gba-result-final.json'),('gba-compare.log','audit-163-gba-compare-final.log'),('source-questions.json','audit-163-source-questions.json')]:shutil.copy2(r/source,out/name)
v=dict(base='31b1eda3112514d6bc803af559ec7f7c9e20374f',parent='abe1398662441f6768f64cab3e9763cc8cacede2',base_binary_sha256=h(r/'audit-163-offer-before-final-immutable/pokered_app'),final_binary_sha256=h(r/'audit-163-offer-after-final-immutable/pokered_app'),helper_sha256=h(r/'offer-163-capture-helper.rs'),SRAM_sha256=h(r/'safari-147-source-setup/safari-one-step.sav'),cases=cases,archives=archives,tests='core2739,data262,app213/29ignored,agent54,GBA31 unchanged budget and25finalsourceSHA',images={p.name:h(p) for p in out.glob('*.png')},scope=['Original evidence is disassembly/source only for these four new call sites; no original emulator/LCD timing equivalence claimed.','Native before/after same continued SRAM and controlled first-visit setup: clear four obtained flags and remove Bicycle/BikeVoucher in both; not an ordinary untouched SRAM mainline.','Native inputs from after pilot replayed exactly on master; master stuck at earlier paragraph under these controls, not matched absolute text-entry/printing cadence.','Rejected short-single-frame A recordings did not trigger dialogue; intermediate chairman recording entered revisit because source SRAM had bicycle. Those local records retained and logs archived, never counted as successful.','New test initially held A continuously during automatic item jingle; corrected driver releases A while waiting for final item text, preserving original HoldTextDisplayOpen behavior.','Existing draft gates and finalm49 plus independentSave/Continue still incomplete.'])
(out/'verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(out/'README.md').write_text('''# 三种钓竿及会长问句（163）

原作三个垂钓大师的“Do you like to fish?”和会长开场问句都由内层 PrintText 打印，以 DONE 返回，紧接 YesNoChoice。复刻先前需要额外按键结束问句；四处改用 printFieldText。会长后续长故事明确以 PROMPT 结束，因此仍须玩家按键后才能 GiveItem，自行车兑换券的发放流程保持该等待。

实际输入回归覆盖四处 YES/NO、物品/事件标志、对话收尾无残留，并在会长故事末页空等 12 帧证明不会提前发券。领取音效期间释放 A，遵循 HoldTextDisplayOpen；失败的初版测试重复按住 A 导致领取窗口保持，已修正测试驱动，没有取消音效或弱化窗口检查。

四处前后都实际 Continue 同一 SRAM，再受控清除四个已获得标志并移除自行车/兑换券、warp 到对应 NPC 下方。两版设置及辅助录制代码完全一致；Medium=3、初始 Up 0..19，A 20..39，后续只确认非最后页。最终输入由修复版先生成，再原样回放两边。第 1100 帧分别为 old/good/super/chairman 前后图；各两次 1200 帧的 PNG/输入/原始状态逐字节一致。master 停在前一段文字，不能据此宣称相同文字入口时刻或原作 LCD 时序。

三种钓竿菜单分别在 189/234/216 帧出现，会长在 446；修复版无需结束问句的额外 A。原作这四处本批仅核对汇编和终结指令，没有新增原作模拟器录制，明确不声称 CPU/LCD 帧一致。

核心 2739、数据 262、应用 213、语义分析 54 项通过；29 个录制辅助测试按需运行，本批每次录制明确运行 1 项。GBA 31 项通过原预算，25 个最终源文件哈希一致，基线不变。各场景 evidence-*.zip 含两边各两次完整 PNG/状态/输入和 SHA256 清单，evidence-shared.zip 含源代码、原作汇编、工具、CI/测试/失败日志及清单。首轮一帧 A 没触发对话、随后会长因自行车进入重访；这些记录本地保留，日志归档，未作为成功结果。

完整文字会话、其他文本调用点、原有草稿门槛及最终 m01..m49/独立 SAVE/CONTINUE 尚未完成。
''');print(json.dumps(v,ensure_ascii=False))
