from pathlib import Path
import json,os
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';side=os.environ.get('FIDELITY_205_SIDE','native')
a=r/f'audit-205-{side}-idle-a3-1';b=r/f'audit-205-{side}-idle-a3-2';pngs=sorted(a.glob('*.png'));assert len(pngs)==145
assert all(p.read_bytes()==(b/p.name).read_bytes() for p in pngs);assert (a/'frames.json').read_bytes()==(b/'frames.json').read_bytes()
rows=json.loads((a/'frames.json').read_text());assert len(rows)==145;assert [x['input_bits'] for x in rows]==[1]+[0]*144
first=next(x['first_letter'] for x in rows if x['first_letter'] is not None);choices=[x['t'] for x in rows if x['overworld']['pending_choice'] is not None]
if side=='native':
 assert choices and choices[0]-first==91,(first,choices[:1]);assert next(x['t'] for x in rows if isinstance(x['overworld']['active_script_effect'],dict) and 'ShowChoice' in x['overworld']['active_script_effect'])-first==90
 assert all(x['overworld']['pending_choice']['selected']==0 for x in rows if x['overworld']['pending_choice'] is not None)
else:assert not choices;assert rows[-1]['overworld']['pending_dialogue']['waiting_for_input']
report={'side':side,'first_letter':first,'first_choice':choices[0] if choices else None,'choice_effect_entry':next((x['t'] for x in rows if isinstance(x['overworld']['active_script_effect'],dict) and 'ShowChoice' in x['overworld']['active_script_effect']),None),'frames_per_repeat':145,'all_png_full_raw_json_byte_exact':True,'each_frame_retained_full_pixels_identical':True,'input':'A at0 release1; 144 idle frames thereafter','scope':'Controlled original SRAM realContinue then controlled gate worker warp; no natural map traversal or absolute PPU/entry/font timing claim'}
(r/f'audit-205-{side}-idle-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
