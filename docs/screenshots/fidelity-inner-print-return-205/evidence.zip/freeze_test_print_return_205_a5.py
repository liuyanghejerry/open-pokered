from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-205-print-return-checkout';out=r/'audit-205-native-a5-immutable';out.mkdir()
log=(r/'audit-205-native-build-a5.log').read_text();assert 'Finished' in log and 'error:' not in log
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bins={}
for name,label in [('pokered_core','core-tests'),('pokered_app','app-tests'),('pokered_data','data-tests')]:
 paths=re.findall(r'Executable unittests src/lib.rs \(([^\n]*'+name+r'-[^\n]*)\)',log);assert len(paths)==1,paths;src=Path(paths[0]);assert src.is_absolute();shutil.copy2(src,out/label);bins[label]=sha(out/label)
files=[f for f in subprocess.check_output(['git','diff','origin/master','--name-only'],cwd=w,text=True).splitlines() if f.startswith('crates/')];assert len(files)==11
manifest={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'base':subprocess.check_output(['git','rev-parse','origin/master'],cwd=w,text=True).strip(),'sources':{p:sha(w/p) for p in files},'binaries':bins,'target':'dedicated audit205 target after syncing 2a35, all source additions and unchanged exact dependency sources rebuilt as needed','scope':'master2a35+205 PrintFieldText+agent semantics; dependencies152+153+154+156 merged'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib')
for label in bins:
 with (r/f'audit-205-{label}-a5.log').open('w') as f:proc=subprocess.run([str(out/label),'--test-threads=4'],cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(label,proc.returncode,flush=True);assert proc.returncode==0,label
