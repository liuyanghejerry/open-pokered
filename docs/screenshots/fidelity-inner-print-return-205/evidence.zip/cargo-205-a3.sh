#!/bin/bash
case "$PWD" in
  /home/jerry/develop/open-pokered/.task-tmp/fidelity-*) ;;
  *) echo "Refusing fidelity build outside its explicit worktree: $PWD" >&2; exit 64 ;;
esac
export TMPDIR=/home/jerry/develop/open-pokered/.task-tmp/fidelity-18-27
export CARGO_INCREMENTAL=0 LD_LIBRARY_PATH=/tmp/pokered-build-lib
export PATH=/home/jerry/.local/share/starheir-build/sysroot/usr/bin:$PATH
export PKG_CONFIG_PATH=/home/jerry/.local/share/starheir-build/sysroot/usr/lib/x86_64-linux-gnu/pkgconfig
export CARGO_HOME=/tmp/fidelity-cargo-home
export CARGO_PROFILE_DEV_OPT_LEVEL=2 CARGO_PROFILE_DEV_DEBUG=0
exec cargo "$@" --offline --target-dir /home/jerry/develop/open-pokered/.task-tmp/fidelity-205-fresh-a3-target -j4
