from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-205-print-return-checkout';out=r/'audit-205-native-a3-immutable';out.mkdir()
log=(r/'audit-205-native-build-a3.log').read_text();assert 'Finished' in log and 'error:' not in log
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bins={}
for name,label in [('pokered_core','core-tests'),('pokered_app','app-tests'),('pokered_data','data-tests')]:
 paths=re.findall(r'Executable unittests src/lib.rs \(([^\n]*'+name+r'-[^\n]*)\)',log);assert len(paths)==1,paths;src=Path(paths[0]);assert src.is_absolute();shutil.copy2(src,out/label);bins[label]=sha(out/label)
files=subprocess.check_output(['git','diff','origin/master','--name-only'],cwd=w,text=True).splitlines();assert len(files)==10
manifest={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'base':subprocess.check_output(['git','rev-parse','origin/master'],cwd=w,text=True).strip(),'sources':{p:sha(w/p) for p in files},'binaries':bins,'target':'independent clean audit205 a3 target; no shared build artifacts','scope':'currentmaster6d99+205 PrintFieldText; dependencies152+153+154 merged'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib')
for label in bins:
 with (r/f'audit-205-{label}-a3.log').open('w') as f:proc=subprocess.run([str(out/label),'--test-threads=4'],cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(label,proc.returncode,flush=True);assert proc.returncode==0,label
