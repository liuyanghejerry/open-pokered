from pathlib import Path
import json,hashlib,zipfile,shutil
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';w=r/'.task-tmp/fidelity-91-plus-checkout';d=w/'docs/screenshots/fidelity-boulder-counter-139';d.mkdir(parents=True,exist_ok=True)
files=['crates/pokered-core/src/overworld/field_moves.rs','crates/pokered-core/src/overworld/presentation.rs','crates/pokered-core/src/overworld/tests_field_moves.rs','crates/pokered-core/tests/fixtures/boulder-counter-139.json']
manifest=dict(parent='5de6ba9a688444455f3076d73843d37cb01c6a57',sources={p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in files},native_binary_sha256=hashlib.sha256((r/'.task-tmp/fidelity-18-27/target/debug/deps/pokered_app-823b1783d030defc').read_bytes()).hexdigest(),source='fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c',changes='MoveSprite queues without starting NPC walk counter; field walker updates every two HW frames; last RedrawMapView wait resumes NPC update in same hardware frame; walking phase serialized separately from LCD presentation.',captures='Three201-frame scenarios, each twice. Unshifted original primary105 repeats and native138/139 repeats. All603 after PNGs byte-identical previous5de captures, so this increment is pure logic and changes no on-screen frame.',scope='Controlled placements and actual Continue/Strength/Down inputs. Ordinary travel reachability not established. 1F/2F1 logical coordinates/counter/event flags exact all201frames each. 2F2 still17state differences and27RGBframes; this shared walking correction removes a previous counter delay that partly cancelled unmodelled CPU/OAM latency. Remaining CPU/script/OAM clocks must be fixed before merge.')
(d/'provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['victory-139-state-comparison-1f.json','victory-139-state-comparison-2f1.json','victory-139-state-comparison-2f2.json','victory-139-native-comparison.json','victory-138-cycle-report.json','victory-139-core-oracle-a2.log','victory-139-full-core-lib-tests.log','victory-139-regression-verification.json','victory-139-gba-result.json','victory-139-gba-compare.log','victory-139-gba-provenance.json']:
 shutil.copyfile(b/name,d/name)
with zipfile.ZipFile(d/'recordings.zip','w',zipfile.ZIP_DEFLATED) as z:
 entries={};objects=set()
 def add(path,label):
  data=path.read_bytes();digest=hashlib.sha256(data).hexdigest();obj='objects/'+digest+path.suffix
  entries[str(label)]={'object':obj,'sha256':digest,'bytes':len(data)}
  if obj not in objects:z.writestr(obj,data);objects.add(obj)
 for c in ['1f','2f1','2f2']:
  for trial in [1,2]:
   for stage in ['victory-139-native','victory-138-native','victory-105-source-held16','victory-138-source-cycles']:
    folder=b/f'{stage}-{c}-{trial}'
    for p in sorted(folder.iterdir()):
     if p.suffix in ['.png','.json']:add(p,p.relative_to(b))
 for p in files:add(w/p,'tested-source/'+p)
 for p in ['generate_boulder_counter_139.py','record_victory_native_139.py','compare_victory_139.py','probe_victory_cycles_138.py','seal_boulder_counter_139.py']:
  add(b/'stats-59-tools'/p,'tools/'+p)
 for name in ['victory-139-full-core-app-tests.log','victory-139-core-boulder-tests.log','victory-139-core-oracle-a1.log','victory-139-core-oracle-a2.log','victory-139-gba-timer.log','victory-139-gba-build.log']:
  add(b/name,'validation/'+name)
 z.writestr('manifest.json',json.dumps(entries,indent=2)+'\n')
(d/'README.md').write_text('''# 推石头的逻辑行走时钟

原作 `MoveSprite` 只排入方向，后续 `TryWalking` 才写行走计数16。复刻此前在排队时提前写16，并从 LCD 动画帧推导计数，导致两个已匹配画面的场景仍有逻辑计数差异。现在独立保存两硬件帧之间的 NPC 行走等待，地图重绘最后一次 DelayFrame 返回后在同一帧继续更新 NPC。旧调试快照缺少新字段时仍可解码，并在恢复更新时推导旧计数的下一次更新阶段。

直接原作回归有两组201帧，共402帧，验证坐标、行走计数和机关标志。另有实际游戏 Continue、Strength 菜单和 Down 输入的三组201帧录制，各重复两次，JSON/PNG均一致；第一层和第二层第一机关的上述逻辑状态全部与原作一致。

完整core/app回归：80组共3661项通过、0失败、57项忽略；独立核心库2730项通过。GBA构建完成，31项计时与未修改的基线比较通过，六个生产文件在原生和GBA检出中逐字节一致。

本次是纯逻辑修改。全部603个新增录制画面与父提交5de的相同场景、输入和硬件帧 PNG 字节一致，因此无新增屏幕差异；整个PR的视觉前后图仍见其他目录。

尚未完成：第二层第二机关仍有17个逻辑状态差异和27个RGB错帧；源于尚未建模的 CPU 工作跨 VBlank 与 OAM/脚本时序。这次修正消除了旧计数延迟对该差异的部分抵消，不代表第二机关已修复。原作两个2F暂存场景实际均用slot11（原生index10），不能用此前slot3/slot11说法实现补丁。原作设定包含受控玩家/视图指针和NPC位置，实际普通步行到场仍未证明。完整主线、其他移动/图形恢复门禁仍待验证，PR保持草稿。

原作提交、原生源文件与二进制哈希、完整原始录制和工具见 provenance.json / recordings.zip。归档按SHA256去重；manifest.json列出每个原始路径对应的objects文件和哈希，保留两次录制全部内容。原作历史记录虽复用 Sprite05 JSON 键，录制脚本按场景实际解析到slot5或slot11；新增周期诊断使用真实槽号，未平移任何帧。
''')
print(d, (d/'recordings.zip').stat().st_size)
