from pathlib import Path
from PIL import Image
import numpy as np,json
b=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');result={}
for case in ['1f','2f1','2f2']:
 a=b/f'victory-139-native-{case}-1';repeat=b/f'victory-139-native-{case}-2';c=b/f'victory-105-source-held16-{case}-1';srepeat=b/f'victory-105-source-held16-{case}-2';bad=[]
 assert (a/'frames.json').read_bytes()==(repeat/'frames.json').read_bytes();assert (c/'frames.json').read_bytes()==(srepeat/'frames.json').read_bytes()
 for t in range(-1,200):
  n=f'frame-{t+1:04}.png';assert (a/n).read_bytes()==(repeat/n).read_bytes();assert (c/n).read_bytes()==(srepeat/n).read_bytes();left=np.array(Image.open(a/n).convert('RGB'));right=np.array(Image.open(c/n).convert('RGB'));ys,xs=np.where(np.any(left!=right,axis=2))
  if len(xs):bad.append(dict(t=t,pixels=len(xs),bbox=[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())]))
 result[case]=dict(repeat_exact=True,bad_frames=bad)
 print(case,'bad',len(bad),bad[:5],flush=True)
(b/'victory-139-native-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
