from pathlib import Path
import os,subprocess,json
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';exe=r/'.task-tmp/fidelity-18-27/target/debug/deps/pokered_app-823b1783d030defc';wt=r/'.task-tmp/fidelity-91-plus-checkout'
for case in ['1f','2f1','2f2']:
 for trial in [1,2]:
  out=b/f'victory-139-native-{case}-{trial}'
  env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(r/'.task-tmp/fidelity-18-27'),FIDELITY_DUST_CAPTURE=str(out),FIDELITY_DUST_SRAM=str(b/'dust-93-warp-setup/seafoam-valid.sav'),FIDELITY_DUST_SCENARIO=f'victory-switch{case}',FIDELITY_DUST_DIRECTION='down')
  with (b/f'victory-139-native-{case}-{trial}.log').open('w') as f:result=subprocess.run([str(exe),'game::link_stats_cry_fidelity_tests::capture_actual_boulder_dust_raw_93','--exact','--ignored','--nocapture','--test-threads=1'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
  assert result.returncode==0,(case,trial,result.returncode)
  rows=json.loads((out/'frames.json').read_text());assert len(rows)==201;print(case,trial,next(r['t'] for r in rows if r['switch']),flush=True)
