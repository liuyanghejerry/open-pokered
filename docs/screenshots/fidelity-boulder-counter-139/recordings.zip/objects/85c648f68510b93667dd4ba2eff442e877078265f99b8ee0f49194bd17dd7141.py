exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
b=root/'.task-tmp/fidelity-39-plus'
routines=['VBlank','PrepareOAMData','UpdateSprites','_UpdateSprites.updateCurrentSprite','UpdateNPCSprite','CheckSpriteAvailability','InitializeSpriteStatus','UpdateSpriteMovementDelay','UpdateSpriteInWalkingAnimation','NotYetMoving','TryWalking','MoveSprite','ReplaceTileBlock','RedrawMapView','DelayFrame']
for case in ['1f','2f1','2f2']:
 for trial in [1,2]:
  setup=b/f'victory-95-source-setup-{case}';out=b/f'victory-138-source-cycles-{case}-{trial}';out.mkdir(exist_ok=True)
  p=PyBoy(str(setup/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'pretrigger.state').read_bytes()));events=[];now=[-1];npc=5 if case=='1f' else 11;event=0x917 if case=='1f' else (0x538 if case=='2f1' else 0x53f)
  def get(n):return int(p.memory[symbols[n][1]])
  def hook(name):
   current=get('hCurrentSpriteOffset');base=symbols['wSpriteStateData1'][1]+current;second=symbols['wSpriteStateData2'][1]+current
   events.append(dict(t=now[0],routine=name,cycles=p._cycles(),LY=int(p.memory[0xff44]),VB=get('hVBlankOccurred'),current=current,status=int(p.memory[base+1]),image=int(p.memory[base+2]),raw_y=int(p.memory[base+4]),raw_x=int(p.memory[base+6]),remaining=int(p.memory[second]),delay=int(p.memory[second+8])))
  missing=[]
  for name in routines:
   if name not in symbols:missing.append(name);continue
   p.hook_register(*symbols[name],hook,name)
  for t in range(-1,41):
   now[0]=t
   if t==0:p.button_press('down')
   if t==16:p.button_release('down')
   if t>=0:p.tick(1)
   n=f'frame-{t+1:04}.png';p.screen.image.save(out/n)
   assert (out/n).read_bytes()==(b/f'victory-105-source-held16-{case}-1'/n).read_bytes(),(case,t,'hook capture differs')
   events.append(dict(t=t,routine='tick_end',cycles=p._cycles(),LY=int(p.memory[0xff44]),frame_count=p.frame_count,boulder_slot=npc,boulder={key:get(f'wSprite{npc:02}StateData{part}{key}') for part,key in [(1,'MovementStatus'),(1,'YPixels'),(1,'XPixels'),(2,'MapX'),(2,'MapY'),(2,'WalkAnimationCounter')]},switch=bool(p.memory[symbols['wEventFlags'][1]+event//8]&(1<<(event%8)))))
  (out/'events.json').write_text(json.dumps(events,indent=2)+'\n');(out/'provenance.json').write_text(json.dumps(dict(missing_symbols=missing,source='fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c',state_sha256=hashlib.sha256((setup/'pretrigger.state').read_bytes()).hexdigest(),rom_sha256=hashlib.sha256((setup/'reference.gbc').read_bytes()).hexdigest(),input='Down held0..15/released16',cycles='PyBoy._cycles absolute CPU clock',screenshots='42 unshifted PNGs identical original held16 primary run'),indent=2)+'\n');p.stop(save=False)
  if trial==2:assert (out/'events.json').read_bytes()==(b/f'victory-138-source-cycles-{case}-1/events.json').read_bytes()
  print(case,trial,'42 original frames exact; cycle trace deterministic',flush=True)
