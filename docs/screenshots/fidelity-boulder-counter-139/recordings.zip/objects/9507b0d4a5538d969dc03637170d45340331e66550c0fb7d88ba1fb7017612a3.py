from pathlib import Path
import json,hashlib
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';out=r/'.task-tmp/fidelity-91-plus-checkout/crates/pokered-core/tests/fixtures/boulder-counter-139.json';out.parent.mkdir(exist_ok=True)
cases=[]
for c,npc in [('1f',5),('2f1',11)]:
 p=b/f'victory-105-source-held16-{c}-1/frames.json';assert p.read_bytes()==(b/f'victory-105-source-held16-{c}-2/frames.json').read_bytes();rows=json.loads(p.read_text());trace=[]
 for e in rows:
  s=e['state'];trace.append([e['t'],s['wSprite05StateData2MapX']-4,s['wSprite05StateData2MapY']-4,s['wSprite05StateData2WalkAnimationCounter'],int(e['switch'])])
 cases.append(dict(case=c,source_slot=npc,columns=['hardware_t','x','y','walk_counter','switch'],source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),trace=trace))
out.write_text(json.dumps(dict(source='pret/pokered fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c',scope='Original105 controlled placements; actual Strength and Down0..15/release16. Logical state only. Native MoveSprite starts3 for both; source starts3/2, so this fixture does not prove initialization CPU/OAM timing. Source files retain Sprite05 key alias but recorder resolves to slots5/11.',cases=cases),separators=(',',':'))+'\n')
print(out)
