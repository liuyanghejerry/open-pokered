from pathlib import Path
import json,numpy as np
from PIL import Image
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';sheet=np.array(Image.open(r/'.task-tmp/stats-59-reference-sgvaaq/gfx/sprites/youngster.png').convert('L'));templates=[]
for pose,y in [('stand',0),('step',48)]:
 for flip in [False,True]:
  a=sheet[y:y+16,:16]
  if flip:a=a[:,::-1]
  templates.append((pose,flip,np.where(a==85,170,np.where(a==170,255,a)),a!=255))
result={}
for moving,src in [(True,'npc-135-finishing-walk-source-valid')]:
 a=b/f'npc-135-walk-{moving}-after-1';repeat=b/f'npc-135-walk-{moving}-after-2';source=b/f'{src}-1';rows=json.loads((a/'frames.json').read_text());assert (a/'frames.json').read_bytes()==(repeat/'frames.json').read_bytes();bad=[];poses=[];rgb_bad=[]
 for t in range(-1,19):
  n=f'frame-{t+1:04}.png';assert (a/n).read_bytes()==(repeat/n).read_bytes();found=[]
  for folder in [source,a]:
   image=np.array(Image.open(folder/n).convert('L'));matches=[]
   for y in range(20,65):
    roi=image[y:y+16,48:64]
    for pose,flip,sprite,mask in templates:
     if np.array_equal(roi[mask],sprite[mask]):matches.append((y,pose,flip))
   found.append(matches)
  if not np.array_equal(np.array(Image.open(source/n).convert('RGB'))[20:72,48:64],np.array(Image.open(a/n).convert('RGB'))[20:72,48:64]):rgb_bad.append(t)
  poses.append(dict(t=t,source=found[0],native=found[1]))
  if found[0]!=found[1]:bad.append(t)
 result[str(moving)]=dict(frames=20,opaque_pose_mismatch=bad,rgb_strip_mismatch=rgb_bad,poses=poses)
 print(moving,'bad',bad,flush=True)
(b/'npc-135-ready-visual-verification.json').write_text(json.dumps(result,indent=2)+'\n')
