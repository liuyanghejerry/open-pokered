from pathlib import Path
import json,hashlib
p=Path(__file__).parent
for name,sha in json.loads((p/'sha256.json').read_text()).items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==sha,name
for case in ['end','top','hysteresis','mark_visible','mark_offscreen','mark_preview']:
 s=json.loads((p/f'source/{case}/trial1.json').read_text());n=json.loads((p/f'native/after/{case}/trial1.json').read_text());assert len(s)==len(n)==1101
 for t in range(200,1101):
  assert (n[t]['cursor'],n[t]['scroll'],n[t]['marked'])==(s[t]['cursor']+s[t]['scroll'],s[t]['scroll'],s[t]['marked']-1 if s[t]['marked'] else None)
  assert n[t]['renderer_scroll']==n[t]['scroll']
 for kind in ['source', 'native/before', 'native/after']:
  a=p/f'{kind}/{case}/trial1.json';b=p/f'{kind}/{case}/trial2.json';assert a.read_bytes()==b.read_bytes()
 assert all(x['bag']==s[0]['bag']for x in s)
 assert all(x['bag']==n[0]['bag']and x['cached_equals_full']and not x['ordinary_save_exists']for x in n)
print('PASS6 repeated cases: Source window901frames, inventory/cache1101frames')
