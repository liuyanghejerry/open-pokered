from pathlib import Path
import json,re,hashlib,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-278-pokedex-page-scroll-checkout';out=w/'docs/screenshots/fidelity-pokedex-page-scroll-281';base='a908e9081d00e3792e8b7ad312f12895f4c1309e';sha=lambda b:hashlib.sha256(b).hexdigest();files={};cases=[]
proof=json.loads((r/'audit-278-promoted-master-before-equivalence.json').read_text());assert proof['master']==base and proof['entire_crates_tree_equal']
tests=json.loads((r/'audit-281-dex-all-unit-and-integration-results-a1.json').read_text());assert tests['all_pass'] and tests['every_binary_completed'] and len(tests['results'])==78
cli=json.loads((r/'audit-281-dex-cli-regression-results.json').read_text());assert cli['base']==base and cli['fresh_m01_m03'] and cli['separate_process_s07_save_continue']
def pair(prefix,source=False):
 a=r/(prefix+'-1');b=r/(prefix+'-2');assert sorted(p.name for p in a.iterdir())==sorted(p.name for p in b.iterdir());assert all(p.read_bytes()==(b/p.name).read_bytes() for p in a.iterdir())
 for d in [a,b]:
  rows=json.loads((d/'frames.json').read_text())
  if not source:assert all(x['bag']==rows[0]['bag'] and not x['owned_save_exists'] for x in rows) and not (d/'owned.sav').exists()
  for p in d.iterdir():assert p.suffix in ['.png','.json'];files[str(p.relative_to(r))]=p
 return json.loads((a/'frames.json').read_text()),a
for case,scroll in [('right-one',7),('right-four',18),('right-four-left',0)]:
 rows,src=pair(f'audit-276-original-dex-{case}-a3',True);assert (rows[-1]['cursor'],rows[-1]['scroll'],rows[-1]['max_seen'])==(0,scroll,25)
 before,bd=pair(f'audit-281-master-dex-{case}-a1');after,ad=pair(f'audit-281-native-dex-{case}-a1');cases.append({'case':case,'seen':25,'source_scroll':scroll,'source_cursor_row':0,'both_sides_two_repeats_byte_exact':True,'native_bag_unchanged_no_auto_save':True})
for count,row,scroll in [(8,0,1),(25,6,7),(6,5,0)]:
 rows,src=pair(f'audit-278-original-dex-right-one-max-{count}-row-{row}-a1',True);assert (rows[-1]['cursor'],rows[-1]['scroll'],rows[-1]['max_seen'])==(row,scroll,count)
 before,bd=pair(f'audit-281-master-dex-right-one-max-{count}-row-{row}-a1');after,ad=pair(f'audit-281-native-dex-right-one-max-{count}-row-{row}-a1');end=190+24*row
 if row:assert (bd/f'frame-{end:03}.png').read_bytes()==(ad/f'frame-{end:03}.png').read_bytes(),'row6 and short-list controls preserve existing correct view'
 cases.append({'case':'right-one','seen':count,'initial_row':row,'source_scroll':scroll,'source_cursor_row':row,'both_sides_two_repeats_byte_exact':True,'native_bag_unchanged_no_auto_save':True,'correct_control_endpoint_frame_preserved':bool(row)})
rows,_=pair('audit-278-original-dex-right-both-max-25-row-0-a1',True);assert (rows[-1]['cursor'],rows[-1]['scroll'])==(0,7)
for name in ['audit-278-promoted-master-before-equivalence.json','audit-278-pokedex-core-targeted-build-a3.log','audit-278-targeted-a2-terminal-qualified.json','audit-281-dex-all-tests-build-a1.log','audit-281-dex-all-unit-and-integration-results-a1.json','audit-281-dex-all-tests-a1-immutable/manifest.json','audit-281-dex-cli-build-a1.log','audit-281-dex-cli-immutable/manifest.json','audit-281-dex-cli-regression-results.json','audit-281-dex-cli-regression-run.log','audit-281-master-dex-page-scroll.log','audit-281-master-dex-boundary-controls.log','audit-281-native-dex-page-scroll.log','audit-281-native-dex-boundary-controls.log','record_pokedex_page_scroll_before_281.py','record_pokedex_page_scroll_after_281.py','record_pokedex_boundaries_281.py','freeze_run_dex_all_tests_281.py','freeze_run_dex_cli_281.py','stats-59-tools/probe_pokedex_page_scroll_276_a3.py','stats-59-tools/probe_pokedex_page_scroll_278.py','package_pokedex_page_scroll_281.py']:
 p=r/name;assert p.exists(),name;files[name]=p
for x in tests['results']:files[x['log']]=r/x['log']
files['candidate-source/crates/pokered-core/src/pokedex_screen.rs']=w/'crates/pokered-core/src/pokedex_screen.rs'
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['engine/menus/pokedex.asm','home/window.asm','home/joypad2.asm']:files['original-source/'+name]=ref/name
out.mkdir(parents=True,exist_ok=False);png={};blobs=set()
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  data=p.read_bytes()
  if p.suffix=='.png':
   h=sha(data);png[name]=h
   if h not in blobs:blobs.add(h);z.writestr('png-blobs/'+h+'.png',data)
  else:z.writestr(name,data)
 z.writestr('png-files.json',json.dumps(png,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for name,case,t in [('first','right-one',190),('last','right-four',190),('left','right-four-left',166)]:
 for side,label in [('master','before'),('native','after')]:shutil.copy2(r/f'audit-281-{side}-dex-{case}-a1-1/frame-{t:03}.png',out/f'{name}-{label}.png')
for side,label in [('master','before'),('native','after')]:shutil.copy2(r/f'audit-281-{side}-dex-right-one-max-8-row-0-a1-1/frame-190.png',out/f'short-last-{label}.png')
total=[0,0,0]
for x in tests['results']:
 m=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored',x['summary']);assert m
 for i in range(3):total[i]+=int(m[i+1])
v={'base':base,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip(),'tests':{'programs':78,'pass':total[0],'fail':total[1],'ignore':total[2]},'cases':cases,'right_over_left_priority':'actual original double-key control + core test; existing TCP timeline supports one button per frame, not a claimed native double-key recording','data_entry_species_verified_in_core':'last page row0 selects Rattata019 rather than prior Pikachu025','cache_safety':'existing PokedexVisualKey includes scroll and rejects cursor-only redraw when scroll differs; renderer unchanged, no new cache/full frame test claimed','PNG':len(png),'archive_roundtrip_byte_exact':True,'archive_sha256':sha((out/'evidence.zip').read_bytes()),'archive_bytes':(out/'evidence.zip').stat().st_size,'scope':'Horizontal window paging and cursor-row retention only. Controlled actual START->POKEDEX fixtures, not natural playthrough. Native numeric dex cursor getter absent; paired visible labels/cursor and core assertions are evidence. Divider/layout, held repeat/guards/combined direction priority and wider gameplay/story continue under audit.'}
(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
