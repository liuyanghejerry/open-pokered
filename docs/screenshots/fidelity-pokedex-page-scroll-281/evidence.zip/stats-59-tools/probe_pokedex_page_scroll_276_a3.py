exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state';case=os.environ.get('DEX_SCROLL_CASE_276','right-one')
for repeat in [1,2]:
 out=r/f'audit-276-original-dex-{case}-a3-{repeat}';out.mkdir(exist_ok=False)
 p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]]);a=symbols['wPokedexSeen'][1]
 for n in range(symbols['wPokedexSeenEnd'][1]-a):p.memory[a+n]=0
 for n in range(25):p.memory[a+n//8]=int(p.memory[a+n//8])|(1<<(n%8))
 for n in range(symbols['wPokedexOwnedEnd'][1]-symbols['wPokedexOwned'][1]):p.memory[symbols['wPokedexOwned'][1]+n]=0
 p.memory[symbols['wBattleAndStartSavedMenuItem'][1]]=0
 cues={'ShowPokedexMenu':None};now=[-1];events=[];held=None;rows=[]
 def hook(n):
  if n in cues and cues[n] is None:cues[n]=now[0]
  events.append({'t':now[0],'routine':n,'cursor':get('wCurrentMenuItem'),'scroll':get('wListScrollOffset'),'joy7':get('hJoy7')})
 for n in ['ShowPokedexMenu','HandlePokedexListMenu','HandleMenuInput']:p.hook_register(*symbols[n],hook,n)
 for t in range(900):
  now[0]=t;key='start' if t in [0,1] else ('a' if t in [70,71] else None);anchor=cues['ShowPokedexMenu']
  if anchor is not None:
   key=None;offset=t-anchor
   times=[70] if case=='right-one' else [70,94,118,142]
   if offset in times:key='right'
   if case=='right-four-left' and offset in [166,190,214,238]:key='left'
  if key!=held:
   if held:p.button_release(held)
   if key:p.button_press(key)
   held=key
  p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png');rows.append({'t':t,'input':key,'cues':dict(cues),'cursor':get('wCurrentMenuItem'),'scroll':get('wListScrollOffset'),'max_seen':get('wDexMaxSeenMon')})
  if anchor is not None and t>=anchor+(270 if case=='right-four-left' else 190):break
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
 assert cues['ShowPokedexMenu'] is not None,(case,events[-10:])
 expected={'right-one':7,'right-four':18,'right-four-left':0}[case];assert rows[-1]['cursor']==0 and rows[-1]['scroll']==expected,(case,rows[-1])
 if repeat==2:
  other=r/f'audit-276-original-dex-{case}-a3-1';assert all(p.read_bytes()==(other/p.name).read_bytes() for p in out.iterdir())
 print(case,repeat,rows[-1],flush=True)
