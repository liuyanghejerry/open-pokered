from pathlib import Path
import sys,os,json,socket,subprocess,hashlib
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-278-pokedex-page-scroll-checkout';sys.path.insert(0,str(w/'scripts'));from debug_drive import DebugClient
binary=r/'audit-281-dex-cli-immutable/pokered-app';m=json.loads((binary.parent/'manifest.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==m['binary']
for case in ['right-one','right-four','right-four-left']:
 for repeat in [1,2]:
  out=r/f'audit-281-native-dex-{case}-a1-{repeat}';out.mkdir(exist_ok=False)
  with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
  log=(r/(out.name+'.log')).open('w');p=subprocess.Popen([str(binary),'--scripts-dir',str(w/'crates/pokered-data/maps'),'run','--headless','--debug-port',str(port),'--speed','0','--skip-intro','--no-audio','--seed','42','--save',str(out/'owned.sav'),'--snapshot',str(r/'audit-276-native-dex25-private-snapshot.json'),'--lang','en'],cwd=w,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib'),stdout=log,stderr=subprocess.STDOUT);d=None
  try:
   d=DebugClient(port=port)
   def drive(keys):q=d.cmd(cmd='press_timeline',buttons=keys,advance=True);assert q.get('ok'),q
   q=d.cmd(cmd='set_flag',name='EVENT_GOT_POKEDEX',value=True);assert q.get('ok');q=d.cmd(cmd='warp',map='ViridianPokecenter',x=13,y=4);assert q.get('ok');drive([None]*120+['start']+[None]*120+['a']+[None]*20)
   assert 'dex' in d.state()['screen'].lower(),d.state()
   rows=[];end=270 if case=='right-four-left' else 190
   for t in range(end+1):
    key=None;times=[70] if case=='right-one' else [70,94,118,142]
    if t in times:key='right'
    if case=='right-four-left' and t in [166,190,214,238]:key='left'
    if t:drive([key])
    state=d.state();assert 'dex' in state['screen'].lower();assert not (out/'owned.sav').exists()
    if t in [0,20,70,74,94,118,142,166,190,214,238,270]:assert d.cmd(cmd='capture_frame',path=str(out/f'frame-{t:03}.png')).get('ok')
    rows.append({'t':t,'input':key,'state':state,'bag':d.cmd(cmd='get_bag'),'owned_save_exists':False})
   assert all(x['bag']==rows[0]['bag'] for x in rows);(out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n')
  finally:
   if d:d.close()
   p.terminate()
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   log.close()
  if repeat==2:
   other=r/f'audit-281-native-dex-{case}-a1-1';assert all(p.read_bytes()==(other/p.name).read_bytes() for p in out.iterdir())
  print(case,repeat,'controlled actual START POKEDEX and arrow input recorded',flush=True)
