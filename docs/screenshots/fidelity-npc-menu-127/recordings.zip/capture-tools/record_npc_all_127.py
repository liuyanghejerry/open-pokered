import os,subprocess,json,pathlib
root=pathlib.Path('/home/jerry/develop/open-pokered');wt=root/'.task-tmp/fidelity-91-plus-checkout';base=root/'.task-tmp/fidelity-39-plus'
exe=root/'.task-tmp/fidelity-18-27/target/debug/deps/pokered_app-823b1783d030defc'
for variant in ['outside','boxed','offscreen']:
 for build in ['before','after']:
  for bike in [False]:
   for direction in ['down']:
    for trial in [1,2]:
     out=base/f'npc-127-{variant}-{build}-{trial}'
     exe=root/('.task-tmp/fidelity-39-plus/unoptimized-target/debug/deps/pokered_app-ff0279f3644dd22e' if build=='before' else '.task-tmp/fidelity-18-27/target/debug/deps/pokered_app-823b1783d030defc')
     wt=root/('.task-tmp/fidelity-93-master-before' if build=='before' else '.task-tmp/fidelity-91-plus-checkout')
     env=dict(os.environ,FIDELITY_NPC_FONT_CASE="close",FIDELITY_MENU_BG_PORTION="2",FIDELITY_RETAINED_CAPTURE="1",LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(root/'.task-tmp/fidelity-18-27'),FIDELITY_MOVEMENT_CAPTURE=str(out),FIDELITY_MOVEMENT_SRAM=str(base/'movement-91-road-setup/road.sav'),FIDELITY_MOVEMENT_X='20',FIDELITY_MOVEMENT_Y='30',FIDELITY_MOVEMENT_BIKE=str(bike).lower(),FIDELITY_MOVEMENT_DIRECTION=direction,FIDELITY_MOVEMENT_HOLD='16' if bike else '32',FIDELITY_MOVEMENT_START_HOLD='40')
     if variant=='boxed':env['FIDELITY_NPC_BOXED']='1'
     if variant=='offscreen':env['FIDELITY_NPC_OFFSCREEN']='1'
     with (base/f'npc-127-{variant}-{build}-{trial}.log').open('w') as log:
      result=subprocess.run([str(exe),'game::link_stats_cry_fidelity_tests::capture_actual_walk_bike_raw_91','--exact','--ignored','--nocapture','--test-threads=1'],cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT)
     assert result.returncode==0, (bike,direction,trial,result.returncode)
     rows=json.loads((out/'frames.json').read_text());assert len(rows)==101;assert any(r["screen"]=="StartMenu" for r in rows)
     print(variant,build,trial,rows[-1]['x'],rows[-1]['y'],flush=True)
