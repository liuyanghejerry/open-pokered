    fn capture_actual_walk_bike_raw_91() {
        run_link_save_fixture(|| {
            let dir = std::path::PathBuf::from(std::env::var("FIDELITY_MOVEMENT_CAPTURE").unwrap());
            std::fs::create_dir_all(&dir).unwrap();
            let path = dir.join("fixture.sav");
            std::fs::write(&path, std::fs::read(std::env::var("FIDELITY_MOVEMENT_SRAM").unwrap()).unwrap()).unwrap();
            let mut g = PokemonGame::new_with_options(
                GameVersion::Red, Some(path), None, None, false, None, false, true,
                #[cfg(feature="debug-server")] None,
            );
            let idle = InputState::new();
            let mut saw_main_menu = false;
            for frame in 0..2000 {
                saw_main_menu |= g.state.screen == GameScreen::MainMenu;
                if g.state.screen == GameScreen::Overworld { break; }
                let advance = button(GbButton::A);
                g.update(if frame % 20 == 19 { &advance } else { &idle });
            }
            assert!(saw_main_menu);
            assert_eq!(g.state.screen, GameScreen::Overworld);
            let start_x=std::env::var("FIDELITY_MOVEMENT_X").unwrap_or_else(|_|"23".into()).parse::<u16>().unwrap();
            let start_y=std::env::var("FIDELITY_MOVEMENT_Y").unwrap_or_else(|_|"29".into()).parse::<u16>().unwrap();
            assert_eq!((g.overworld.state.player.x,g.overworld.state.player.y), (start_x,start_y));
            assert_eq!(g.overworld.state.player.facing,pokered_core::overworld::Direction::Down);
            let pc_case=std::env::var("FIDELITY_INPUT_PC_CASE").ok();
            if pc_case.is_some() {
                g.overworld.warp_to_map(MapId::ViridianPokecenter,13,4);
                for _ in 0..120 {g.update(&idle);}
                g.update(&button(GbButton::Down));g.update(&button(GbButton::Down));
                for _ in 0..120 {g.update(&idle);}
                assert_eq!((g.overworld.state.player.x,g.overworld.state.player.y),(13,5));
                // Original preparation turns Up without walking; native turn
                // timing remains a separate open audit, so stage this facing.
                g.overworld.state.player.facing=pokered_core::overworld::Direction::Up;
                let mut controlled=g.save_data.game_data.clone();
                controlled.player_last_stop_direction=8;controlled.player_moving_direction=0;
                g.overworld.restore_system_save_state(&controlled);
            }
            let bike=std::env::var("FIDELITY_MOVEMENT_BIKE").is_ok_and(|s|s=="true");
            if bike {
                let mut held_start=button(GbButton::Start);
                g.update(&held_start);held_start.begin_frame();g.update(&held_start);
                for _ in 0..23 {g.update(&idle);}
                assert_eq!(g.state.screen,GameScreen::StartMenu);
                for _ in 0..7 {
                    if g.start_menu.current_item()==pokered_core::start_menu::StartMenuItem::Item {break;}
                    g.update(&button(GbButton::Down));for _ in 0..3 {g.update(&idle);}
                }
                g.update(&button(GbButton::A));g.update(&idle);
                assert_eq!(g.state.screen,GameScreen::Bag);
                for _ in 0..21 {
                    if g.bag_screen.items().get(g.bag_screen.cursor()).is_some_and(|(id,_)|*id==pokered_data::items::ItemId::Bicycle) {break;}
                    g.update(&button(GbButton::Down));g.update(&idle);
                }
                assert_eq!(g.bag_screen.items()[g.bag_screen.cursor()].0,pokered_data::items::ItemId::Bicycle);
                g.update(&button(GbButton::A));g.update(&idle);
                g.update(&button(GbButton::A));g.update(&idle);
                for t in 0..1000 {
                    if g.state.screen==GameScreen::Overworld && g.overworld.pending_dialogue.is_none() {break;}
                    let advance=button(GbButton::A);g.update(if t%20==19 {&advance} else {&idle});
                }
                assert_eq!(g.overworld.state.player.transport,dotzuki_engine::overworld::types::TransportMode::Biking);
            }
            let trigger=if pc_case.is_some() {GbButton::Up} else {match std::env::var("FIDELITY_MOVEMENT_DIRECTION").unwrap_or_else(|_|"left".into()).as_str() {
                "left"=>GbButton::Left,"right"=>GbButton::Right,
                "up"=>GbButton::Up,"down"=>GbButton::Down,_=>panic!("unsupported direction"),
            }};
            g.overworld.set_rng_seed(0);
            for _ in 0..120 { g.update(&idle); }
            let npc_font_case = std::env::var_os("FIDELITY_NPC_FONT_CASE").is_some();
            if npc_font_case {
                assert_eq!(g.overworld.state.current_map, MapId::ViridianCity);
                let npc = &mut g.overworld.npc_states[0];
                assert_eq!(npc.sprite_id, 4);
                npc.x = if std::env::var_os("FIDELITY_NPC_OFFSCREEN").is_some() { start_x+7 } else if std::env::var_os("FIDELITY_NPC_BOXED").is_some() { start_x+2 } else { start_x-1 };
                npc.y=start_y-1; npc.facing=pokered_core::overworld::Direction::Down;
                npc.walk_counter=12; npc.delay_counter=if std::env::var_os("FIDELITY_NPC_BOXED").is_some() {27} else {54}; npc.visible=true;
                for _ in 0..4 {g.update(&idle);}
            }
            let duration=std::env::var("FIDELITY_MOVEMENT_HOLD").unwrap_or_else(|_|"16".into()).parse::<i32>().unwrap();
            let start_hold=std::env::var("FIDELITY_MOVEMENT_START_HOLD").ok().map(|s|s.parse::<i32>().unwrap());
            let mut input = InputState::new();
            let mut retained_session = crate::render::session::RenderSession::new();
            let mut retained_fb = FrameBuffer::new(RenderConfig::new(160,144),Rgba::WHITE);
            let mut records = Vec::new();
            for t in -1i32..100 {
                if t >= 0 {
                    input.begin_frame();
                    if t == 0 && !npc_font_case { input.press(trigger); }
                    if t == duration { input.release(trigger); }
                    if let Some(hold)=start_hold {
                        let opening=if npc_font_case {0} else {5};
                        if t==opening {input.press(GbButton::Start);}
                        if t==opening+hold {input.release(GbButton::Start);}
                    }
                    if npc_font_case {
                        if t==50 {input.press(GbButton::B);}
                        if t==52 {input.release(GbButton::B);}
                    }
                    if let Some(case)=pc_case.as_deref() {
                        let hold=if case=="a-short" {1} else {40};
                        if t==5 {input.press(GbButton::A);if case=="a-start-held" {input.press(GbButton::Start);}}
                        if t==5+hold {input.release(GbButton::A);if case=="a-start-held" {input.release(GbButton::Start);}}
                    }
                    g.update(&input);
                }
                let saved=g.build_save_data();
                let mut fb = FrameBuffer::new(RenderConfig::new(160,144), Rgba::WHITE);
                if std::env::var_os("FIDELITY_RETAINED_CAPTURE").is_some() {
                    retained_session.render(&mut g, &mut retained_fb,
                        &mut |_,_,_,_,_,_| {});
                    retained_fb.save_png(&dir.join(format!("frame-{:04}.png",t+1))).unwrap();
                } else {
                    g.draw(&mut fb); fb.save_png(&dir.join(format!("frame-{:04}.png", t+1))).unwrap();
                }
                records.push(serde_json::json!({"t":t,"frame":g.frame_count,"input_bits":input.raw_current(),
                    "npc":if npc_font_case {serde_json::to_value(&g.overworld.npc_states[0]).unwrap()} else {serde_json::Value::Null},
                    "screen":format!("{:?}",g.state.screen),"map":g.overworld.state.current_map as u8,
                    "x":g.overworld.state.player.x,"y":g.overworld.state.player.y,
                    "facing":format!("{:?}",g.overworld.state.player.facing),
                    "movement":format!("{:?}",g.overworld.state.player.movement_state),
                    "last_stop":saved.game_data.player_last_stop_direction,"moving_direction":saved.game_data.player_moving_direction,
                    "pc_phase":g.pc_screen.as_ref().map(|p|format!("{:?}",p.phase())),
                    "pending_pc":g.overworld.pending_pc.is_some(),
                    "walk_counter":g.overworld.state.walk_counter,"transport":format!("{:?}",g.overworld.state.player.transport),"party":g.save_data.party}));
            }
            std::fs::write(dir.join("frames.json"),serde_json::to_string_pretty(&records).unwrap()).unwrap();
        });
    }
