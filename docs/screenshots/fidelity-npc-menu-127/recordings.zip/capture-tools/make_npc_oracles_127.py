from pathlib import Path
import json,numpy as np
from PIL import Image
r=Path('/home/jerry/develop/open-pokered'); b=r/'.task-tmp/fidelity-39-plus'; dest=r/'.task-tmp/fidelity-91-plus-checkout/crates/pokered-app/tests/fixtures'
sheet=np.array(Image.open(r/'.task-tmp/stats-59-reference-sgvaaq/gfx/sprites/youngster.png').convert('L'));templates=[]
for frame,y in [(0,0),(3,48)]:
 for flip in [False,True]:
  a=sheet[y:y+16,:16]
  if flip:a=a[:,::-1]
  templates.append((frame,flip,np.where(a==85,170,np.where(a==170,255,a)),a!=255))
for case,folder,x in [('outside','npc-126-font-delay-source-controlled',48),('boxed','npc-127-font-boxed-delay-source-controlled',96),('offscreen','npc-125-font-offscreen-source-controlled',176)]:
 rows=json.loads((b/f'{folder}-1/frames.json').read_text());assert rows==json.loads((b/f'{folder}-2/frames.json').read_text())
 oracle=[]
 for row in rows[:101]:
  t=row['t'];name=f'frame-{t+1:04}.png';assert (b/f'{folder}-1'/name).read_bytes()==(b/f'{folder}-2'/name).read_bytes()
  image=np.array(Image.open(b/f'{folder}-1'/name).convert('L'));matches=[]
  if x<160:
   for y in range(40,70):
    roi=image[y:y+16,x:x+16]
    for frame,flip,sprite,mask in templates:
     if np.array_equal(roi[mask],sprite[mask]):matches.append((y,frame,flip))
  # The standing sprite is symmetrical: choose the unflipped equivalent.
  unique={ (y,f) for y,f,flip in matches };assert len(unique)<=1,(case,t,matches)
  raw=row['wSprite01StateData1ImageIndex']
  entry=dict(t=t,remaining=row['wSprite01StateData2WalkAnimationCounter'],phase=row['wSprite01StateData1AnimFrameCounter'],intra=row['wSprite01StateData1IntraAnimFrameCounter'],raw_image=255 if raw==255 else raw-32,lcd_visible=bool(matches))
  if matches:
   y,f,flip=matches[0];entry.update(lcd_y=y,lcd_frame=f,lcd_flip=flip)
  oracle.append(entry)
 delay=next((row.get('wSprite01StateData2MovementDelay') for row in rows if row['t']==95),None)
 obj=dict(reference='pret/pokered fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c',scope=f'Controlled ViridianCity NPC slot1; {case}, counter12 phase1 intra0; four hardware priming frames, START0..39 B50..51; native preloaded future wait maps to original completion delay; first walk completion only',future_delay=delay or 54,frames=oracle)
 (dest/f'npc-field-font-{case}-127.json').write_text(json.dumps(obj,indent=2)+'\n');print(case,'delay',delay,'visible frames',sum(row['lcd_visible'] for row in oracle))
