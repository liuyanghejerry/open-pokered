from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';f=r/'.task-tmp/fidelity-91-plus-checkout/crates/pokered-app/tests/fixtures'
sheet=np.array(Image.open(r/'.task-tmp/stats-59-reference-sgvaaq/gfx/sprites/youngster.png').convert('L'));templates=[]
for frame,y in [(0,0),(3,48)]:
 for flip in [False,True]:
  a=sheet[y:y+16,:16]
  if flip:a=a[:,::-1]
  templates.append((frame,flip,np.where(a==85,170,np.where(a==170,255,a)),a!=255))
result={}
for case,x in [('outside',48),('boxed',96),('offscreen',176)]:
 oracle=json.loads((f/f'npc-field-font-{case}-127.json').read_text())['frames'];mismatches=[]
 for build in ['before','after']:
  a=b/f'npc-127-{case}-{build}-1';c=b/f'npc-127-{case}-{build}-2'
  assert (a/'frames.json').read_bytes()==(c/'frames.json').read_bytes()
  for png in a.glob('*.png'):assert png.read_bytes()==(c/png.name).read_bytes()
 for row in oracle:
  t=row['t'];image=np.array(Image.open(b/f'npc-127-{case}-after-1'/f'frame-{t+1:04}.png').convert('L'));matches=[]
  if x<160:
   for y in range(40,70):
    roi=image[y:y+16,x:x+16]
    for frame,flip,sprite,mask in templates:
     if np.array_equal(roi[mask],sprite[mask]):matches.append((y,frame,flip))
  expected=[] if not row['lcd_visible'] else [(row['lcd_y'],row['lcd_frame'],row['lcd_flip'])]
  if bool(matches)!=bool(expected) or (expected and expected[0] not in matches):mismatches.append(dict(t=t,expected=expected,actual=matches))
 result[case]=dict(frames=101,repeat_exact=True,opaque_pose_mismatches=mismatches)
 assert not mismatches,(case,mismatches[:3])
# Full RGB on the NPC strip outside the menu, including transparent footprint.
a=b/'npc-127-outside-after-1';c=b/'npc-126-font-delay-source-controlled-1'
bad=[]
for t in range(-1,100):
 name=f'frame-{t+1:04}.png';left=np.array(Image.open(a/name).convert('RGB'))[40:76,48:64];right=np.array(Image.open(c/name).convert('RGB'))[40:76,48:64]
 if not np.array_equal(left,right):bad.append(t)
result['outside']['full_strip_rgb_mismatches']=bad;assert not bad,bad
(b/'npc-127-native-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
