exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/movement-91-road-setup'
for bike in [False,True]:
 for hold in [1,40]:
  for trial in [1,2]:
   out=root/f'.task-tmp/fidelity-39-plus/movement-98-start-hook-reference-{bike}-{hold}-{trial}';out.mkdir(exist_ok=True);p=PyBoy(str(setup/'road.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);src=root/f'.task-tmp/fidelity-39-plus/movement-91-road-reference-{bike}-1/pretrigger.state';p.load_state(io.BytesIO(src.read_bytes()));rows=[];events=[];now=[-1];
   for routine in ['DisplayTextID','DisplayStartMenu','DrawStartMenu','CloseStartMenu']:
    p.hook_register(*symbols[routine],lambda name:events.append({'t':now[0],'frame':p.frame_count,'routine':name,'text_id':int(p.memory[symbols['hTextID'][1]])}),routine)
   for t in range(-1,100):
    now[0]=t
    if t==0:p.button_press('down')
    if t==5:p.button_press('start')
    if t==5+hold:p.button_release('start')
    if t==32:p.button_release('down')
    if t>=0:p.tick(1)
    p.screen.image.save(out/f'frame-{t+1:04}.png');rows.append({'t':t,'frame':p.frame_count,'oam':list(p.memory[0xfe00:0xfea0]),'state':{n:int(p.memory[symbols[n][1]]) for n in ['wCurMap','wXCoord','wYCoord','wWalkCounter','wPlayerDirection','wPlayerMovingDirection','hSCX','hSCY','hJoyHeld','hJoyPressed']}})
   (out/'frames.json').write_text(json.dumps(rows,indent=2));(out/'events.json').write_text(json.dumps(events,indent=2));p.stop(save=False);print(bike,hold,trial,events,flush=True)
