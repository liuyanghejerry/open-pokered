import os,subprocess,json
from pathlib import Path
root=Path('/home/jerry/develop/open-pokered');a=root/'.task-tmp/fidelity-39-plus'
for variant in ['master-before']:
 for bike in [False,True]:
  for hold in [1,40]:
   for trial in [1,2]:
    out=a/f'clock-91-matched-road-{variant}-{bike}-{hold}-{trial}'
    env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',FIDELITY_MOVEMENT_CAPTURE=str(out),FIDELITY_MOVEMENT_SRAM=str(a/'movement-91-road-setup/road.sav'),FIDELITY_MOVEMENT_X='20',FIDELITY_MOVEMENT_Y='30',FIDELITY_MOVEMENT_DIRECTION='down',FIDELITY_MOVEMENT_HOLD='32',FIDELITY_MOVEMENT_START_HOLD=str(hold),FIDELITY_MOVEMENT_BIKE=str(bike).lower())
    res=subprocess.run([str(a/f'input-98-{variant}-driver'),'capture_actual_walk_bike_raw_91','--ignored','--nocapture','--test-threads=1'],cwd=root/('.task-tmp/fidelity-91-plus-checkout' if variant=='clock-first' else '.task-tmp/fidelity-93-master-before'),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (a/f'{out.name}.log').write_text(res.stdout)
    assert res.returncode==0 and '1 passed' in res.stdout,res.stdout[-1500:]
    rows=json.loads((out/'frames.json').read_text());menu=next((r for r in rows if r['screen']=='StartMenu'),None)
    print(variant,bike,hold,trial,None if menu is None else {k:menu[k] for k in ['t','x','y','movement','walk_counter']},flush=True)
