from pathlib import Path
p=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout/crates/pokered-app/src/render/session.rs');s=p.read_text();old='''                let start = pc.message_page() * 4;
                for line in pc.message_lines().iter().skip(start).take(4) {''';new='''                hash_u32(&mut visual_hash, pc.message_visible_chars() as u32);
                // Authored CONT pages overlap and PARA has its own range.
                // Source text can stay unchanged while visible letters grow.
                for line in pc.message_page_lines() {''';assert s.count(old)==1;s=s.replace(old,new,1);needle='''            }
            PcPhase::MainMenu => {''';start=s.index('impl PcVisualKey {');pos=s.index(needle,start);extra='''                if let Some(underlay) = pc.message_underlay() {
                    hash_byte(&mut visual_hash, underlay as u8);
                    match underlay {
                        PcPhase::BillsMenu => {
                            hash_u32(&mut visual_hash, pc.bills_menu().cursor() as u32);
                            hash_u32(&mut visual_hash, game.save_data.pc_storage.current_box_index() as u32);
                        }
                        PcPhase::MonList => {
                            hash_byte(&mut visual_hash, pc.mon_mode() as u8);
                            hash_u32(&mut visual_hash, pc.mon_cursor() as u32);
                            match pc.mon_mode() {
                                MonListMode::Deposit => {
                                    for mon in game.save_data.party.iter() { hash_pc_mon(&mut visual_hash, mon); }
                                }
                                MonListMode::Withdraw | MonListMode::Release => {
                                    for mon in game.save_data.pc_storage.current_box().iter() { hash_pc_mon(&mut visual_hash, mon); }
                                }
                            }
                        }
                        PcPhase::ItemList => {
                            hash_byte(&mut visual_hash, pc.item_mode() as u8);
                            hash_u32(&mut visual_hash, pc.item_list_cursor() as u32);
                            match pc.item_mode() {
                                ItemListMode::Deposit => hash_pc_inventory(&mut visual_hash, &game.save_data.game_data.bag),
                                ItemListMode::Withdraw | ItemListMode::Toss => hash_pc_inventory(&mut visual_hash, &game.save_data.game_data.pc_items),
                            }
                        }
                        _ => unreachable!(),
                    }
                }
''';s=s[:pos]+extra+s[pos:];p.write_text(s)
