from pathlib import Path
p=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-93-master-before/crates/pokered-app/src/render/session.rs');s=p.read_text();marker='    #[test]\n    fn slots_retained_cursor_frames_match_full_draw_for_every_bet() {';new='''    #[test]
    #[ignore = "actual master cached PC comparison"]
    fn capture_master_pc_cache_178() {
        use dotzuki_app::InputState;
        use pokered_core::pc_screen::{PcEntry, PcOpenContext, PcScreen};
        let mut game = PokemonGame::new(GameVersion::Red);
        game.audio = None;
        game.state.screen = GameScreen::PC;
        game.state.config.language = Lang::En;
        let open = PcOpenContext { met_bill: true, has_pokedex: true,
            beaten_league: false, player_name: "RED".into(), hof_teams: Vec::new() };
        game.pc_screen = Some(PcScreen::new(PcEntry::PokemonCenter, &open));
        let mut session = RenderSession::new();
        let mut retained = FrameBuffer::new(RenderConfig::new(160, 144), Rgba::WHITE);
        let mut scroll = |_: &mut [u8], _: usize, _: usize, _: i32, _: i32, _: u8| {};
        for _ in 0..=10 {
            game.update(&InputState::new());
            session.render(&mut game, &mut retained, &mut scroll);
            let mut full = FrameBuffer::new(RenderConfig::new(160, 144), Rgba::WHITE);
            game.draw(&mut full);
            for y in 0..144 { for x in 0..160 {
                assert_eq!(retained.get_pixel(x, y), full.get_pixel(x, y));
            } }
        }
        let dir = std::path::PathBuf::from(std::env::var("FIDELITY_PC_CACHE_CAPTURE").unwrap());
        std::fs::create_dir_all(&dir).unwrap();
        retained.save_png(&dir.join("retained-frame-0010.png")).unwrap();
    }

''';assert marker in s and 'fn capture_master_pc_cache_178' not in s;s=s.replace(marker,new+marker,1);p.write_text(s)
