from pathlib import Path
import hashlib,json,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';perf=Path('/home/jerry/develop/open-pokered-perf118');out=w/'docs/screenshots/fidelity-pc-cache-178';out.mkdir(parents=True,exist_ok=True);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
for pkg,count in [('core',2750),('data',263),('app',223),('agent',54),('audio',99)]:assert f'{count} passed; 0 failed;' in (r/f'audit-178-suite-{pkg}-a1.log').read_text()
for group in ['after','master']:
 a=r/f'audit-178-cache-{group}-a1-1';b=r/f'audit-178-cache-{group}-a1-2';names=sorted(p.name for p in a.iterdir());assert names==sorted(p.name for p in b.iterdir());assert all((a/n).read_bytes()==(b/n).read_bytes() for n in names)
for trial in [1,2]:assert '1 passed; 0 failed;' in (r/f'audit-178-cache-after-a1-{trial}.log').read_text();assert '1 passed; 0 failed;' in (r/f'audit-178-cache-master-a1-{trial}.log').read_text()
state=load(r/'audit-178-cache-before-a2/state.json');assert state['first_mismatch']=={'frame':2,'phase':'Message','chars':1,'x':8,'y':115};assert state['visible_chars']==3
assert (r/'audit-178-cache-before-a2/retained-frame-0010.png').read_bytes()!=(r/'audit-178-cache-before-a2/full-frame-0010.png').read_bytes()
assert (r/'audit-178-cache-after-a1-1/retained-frame-0010.png').read_bytes()==(r/'audit-178-cache-after-a1-1/full-frame-0010.png').read_bytes()
for name,path in [('master-before.png','audit-178-cache-master-a1-1/retained-frame-0010.png'),('cached-bug-before.png','audit-178-cache-before-a2/retained-frame-0010.png'),('cached-after.png','audit-178-cache-after-a1-1/retained-frame-0010.png')]:shutil.copy2(r/path,out/name)
m=load(r/'audit-178-gba-source-manifest-a1.json');assert len(m['sources'])==59 and all(h(w/n)==sha==h(perf/n) for n,sha in m['sources'].items());compare=(r/'audit-178-gba-compare-a1.log').read_text();assert compare.count(' -> ')==31 and compare.count('regressed from')==2
n='crates/pokered-app/src/render/session.rs';current=(w/n).read_text();before=subprocess.check_output(['git','show','aa663990d72d8dd0ccdb1c7bd5274bf8082f8265:'+n],cwd=w,text=True);marker='#[cfg(test)]\nmod session_tests';before_full=before.split(marker)[0]+marker+current.split(marker)[1];(r/'audit-178-before-production-with-capture-test.rs').write_text(before_full)
entries={}
for pat in ['audit-178-*.log','audit-178-*.json','audit-178-*.rs']:
 for p in r.glob(pat):entries[p.name]=p
for group in ['audit-178-cache-before-a2','audit-178-cache-after-a1-1','audit-178-cache-after-a1-2','audit-178-cache-master-a1-1','audit-178-cache-master-a1-2']:
 for p in (r/group).iterdir():
  if p.is_file():entries[str(p.relative_to(r))]=p
for name in ['audit-178-master-a1-immutable','audit-178-after-a1-immutable']:entries[name+'/manifest.json']=r/name/'manifest.json'
for name in ['fix_pc_cache_178.py','capture_cache_repro_178.py','add_master_cache_capture_178.py','freeze_run_pc_178.py','stage_pc_gba_178.py','package_pc_cache_178.py']:entries['tools/'+name]=r/'stats-59-tools'/name
entries['current-source/'+n]=w/n
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
v={'parent_head':'aa663990d72d8dd0ccdb1c7bd5274bf8082f8265','master_head':'31b1eda3112514d6bc803af559ec7f7c9e20374f','source_hash':h(w/n),'before_source_with_same_capture_test_hash':h(r/'audit-178-before-production-with-capture-test.rs'),'captures':'same PC constructor, Game owner update frames0..10, idle input, English RED; master/current cache is compared with full draw; two master/after copies byte-exact','native':{'core':2750,'data':263,'app':223,'app_ignored':33,'agent':54,'audio':99},'before':state,'after':load(r/'audit-178-cache-after-a1-1/state.json'),'owning_regression':'2 complete after runs; opening→Bill access→CHANGE BOX CONT/PARA; all160x144 retained pixels match full draw after everyGame update; idle reuse remains','gba':{'sources':59,'metrics':31,'status':'FAILED2 original budget metrics; unchanged budget','oak_draw_avg':3008,'movement_draw_peak':3122},'archive':{'bytes':archive.stat().st_size,'sha256':h(archive),'entries':len(entries)},'remaining':['GBA performance original budget','PC quantity/menu/list text and original CONT physical scroll/PCM','global text init/close/arrow','movement17logical/27RGB','exact final mainline+independentSAVE-CONTINUE']};(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(v['archive'])
