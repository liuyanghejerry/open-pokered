from pathlib import Path
p=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout/crates/pokered-app/src/render/session.rs');s=p.read_text();s=s.replace('''        let mut glyph_seen = false;
        for frame in 0..900 {''','''        let mut glyph_seen = false;
        let mut first_mismatch = None;
        for frame in 0..900 {''',1)
s=s.replace('''                    assert_eq!(retained.get_pixel(x, y), full.get_pixel(x, y),
                        "PC retained frame {frame}, phase {phase:?}, chars {chars}, at ({x}, {y})");''','''                    if retained.get_pixel(x, y) != full.get_pixel(x, y) && first_mismatch.is_none() {
                        first_mismatch = Some((frame, phase, chars, x, y));
                    }''',1)
s=s.replace('''            if warning_frame.is_some_and(|cue| frame >= cue + 60) {''','''            if frame == 10 {
                if let Ok(dir) = std::env::var("FIDELITY_PC_CACHE_CAPTURE") {
                    let dir = std::path::PathBuf::from(dir);
                    std::fs::create_dir_all(&dir).unwrap();
                    retained.save_png(&dir.join("retained-frame-0010.png")).unwrap();
                    full.save_png(&dir.join("full-frame-0010.png")).unwrap();
                    std::fs::write(dir.join("state.json"), serde_json::to_string_pretty(
                        &serde_json::json!({"frame":frame,"phase":format!("{:?}",game.pc_screen.as_ref().unwrap().phase()),
                            "visible_chars":chars,"first_mismatch":first_mismatch.map(|(f,p,c,x,y)|
                                serde_json::json!({"frame":f,"phase":format!("{p:?}"),"chars":c,"x":x,"y":y}))})).unwrap()).unwrap();
                }
            }
            if frame >= 10 { assert_eq!(first_mismatch, None, "retained PC frame differs from full draw"); }
            if warning_frame.is_some_and(|cue| frame >= cue + 60) {''',1)
p.write_text(s)
