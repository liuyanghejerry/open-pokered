from pathlib import Path
import re,sys,shutil,json,hashlib,subprocess,os
from concurrent.futures import ThreadPoolExecutor
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');rev=sys.argv[1];s=(r/f'audit-178-native-after-build-{rev}.log').read_text();assert 'Finished `test`' in s;d=r/f'audit-178-after-{rev}-immutable';d.mkdir(exist_ok=True);manifest={}
for m in re.finditer(r'Executable unittests src/lib.rs \(([^)]+/pokered_(core|data|app|agent|audio)-[a-f0-9]+)\)',s):
 p=Path(m[1]);target=d/f'pokered_{m[2]}';shutil.copy2(p,target);manifest[m[2]]={'source_binary':str(p),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
assert len(manifest)==5;(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def run(pkg):
 log=r/f'audit-178-suite-{pkg}-{rev}.log'
 with log.open('w') as f:x=subprocess.run([str(d/f'pokered_{pkg}'),'--test-threads=4'],stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib'),cwd='/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout')
 print(pkg,x.returncode,[v for v in log.read_text().splitlines() if v.startswith('test result:')],flush=True);return x.returncode
with ThreadPoolExecutor(max_workers=4) as pool:codes=list(pool.map(run,manifest))
raise SystemExit(max(codes))
