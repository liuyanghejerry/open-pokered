from pathlib import Path
import re,subprocess
root=Path('/home/jerry/develop/open-pokered');wt=root/'.task-tmp/fidelity-201-choice-question-checkout'
p=wt/'crates/pokered-core/src/snapshot.rs';s=p.read_text();s=re.sub(r'<<<<<<< ours\n(.*?)=======\n.*?>>>>>>> theirs\n',lambda m:m[1].replace('            pending_choice,','            last_script_dialogue, pending_choice,'),s,flags=re.S);p.write_text(s)
p=wt/'crates/pokered-core/src/overworld/update.rs';s=p.read_text();replacement='''        let action = self.update_frame_inner(input);
        if self.script_engine.is_idle()
            && self.active_script_effect.is_none()
            && self.pending_choice.is_none()
        {
            self.last_script_dialogue = None;
        }
        action
    }

    fn update_frame_inner(&mut self, input: OverworldInput) -> ScreenAction {
''';s=re.sub(r'<<<<<<< ours\n.*?>>>>>>> theirs\n',lambda m:replacement,s,count=1,flags=re.S);assert '<<<<<<<' not in s;p.write_text(s)
source=subprocess.check_output(['git','show','dacc5cc:crates/pokered-app/src/game.rs'],cwd=root,text=True)
a=source.index('    #[test]\n    fn safari_information_choice_keeps_question_across_json_restore_and_replaces_it');b=source.index('\n}\n\n#[cfg(all(test, not(target_os = "none")))]\nmod choice_question_capture_158',a);tests=source[a:b]
p=wt/'crates/pokered-app/src/game.rs';s=p.read_text();pos=s.index('mod link_stats_cry_fidelity_tests');end=s.index('\n}\n',pos);s=s[:end]+'\n'+tests+s[end:]
# Gameplay observability must read the same display state, without introducing other recorder changes.
s=s.replace('.pending_dialogue\n            .as_ref()\n            .and_then(|d| d.get_display_text())','.displayed_field_dialogue()\n            .and_then(|d| d.get_display_text())',1)
capstart=source.index('#[cfg(all(test, not(target_os = "none")))]\nmod choice_question_capture_158');capture=source[capstart:];capture=capture.replace('_158','_201').replace('FIDELITY_CHOICE_CAPTURE','FIDELITY_CHOICE_CAPTURE_201')
# The existing full raw snapshots are retained; separate visible-state observations make the precise repeat claim explicit.
capture=capture.replace('let mut rows = Vec::new();','let mut rows = Vec::new();\n            let mut observations = Vec::new();',1)
needle='                if t == 120 { assert!(g.overworld.pending_choice.is_some(),"choice must be open at same hardware frame"); }'
obs='''                observations.push(serde_json::json!({"t":t,"input_bits":input.raw_current(),
                    "screen":format!("{:?}",g.state.screen),
                    "player":[g.overworld.state.player.x,g.overworld.state.player.y],
                    "dialogue":g.overworld.pending_dialogue.as_ref().map(|d|d.get_display_text()),
                    "choice":g.overworld.pending_choice,
                    "visible_question":VISIBLE_DIALOGUE_EXPR.map(|d|d.get_display_text())}));
'''.replace('VISIBLE_DIALOGUE_EXPR','g.overworld.displayed_field_dialogue()')
capture=capture.replace(needle,obs+needle);capture=capture.replace('            std::fs::write(dir.join("frames.json")','            std::fs::write(dir.join("observations.json"),serde_json::to_string_pretty(&observations).unwrap()).unwrap();\n            std::fs::write(dir.join("frames.json")',1)
s+='\n'+capture;p.write_text(s);(root/'.task-tmp/fidelity-39-plus/audit-201-capture-helper.rs').write_text(capture)
(wt/'gfx').symlink_to(root/'gfx',target_is_directory=True)
