exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
b=root/'.task-tmp/fidelity-39-plus';setup=b/'safari-147-source-setup'
for trial in [1,2]:
 out=b/f'audit-157-original-choice-{trial}';out.mkdir(exist_ok=True);p=PyBoy(str(setup/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'pretrigger.state').read_bytes()));p.memory[symbols['wNumSafariBalls'][1]]=0
 for t in range(701):
  if t>=100 and t%30==10:p.button_press('a')
  if t>=100 and t%30==12:p.button_release('a')
  p.tick(1)
 get=lambda name:int(p.memory[symbols[name][1]])
 assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(156,4,3)
 def move(button,name,target):
  p.button_press(button)
  for _ in range(160):
   p.tick(1)
   if get(name)==target:break
  else:raise AssertionError((button,name,target,get(name)))
  p.button_release(button);p.tick(30)
 move('down','wYCoord',4);move('left','wXCoord',3)
 p.button_press('left');p.tick(8);p.button_release('left');p.tick(8)
 assert (get('wXCoord'),get('wYCoord'))==(3,4)
 events=[];now=[-1];choice=[False]
 def hook(name):
  events.append(dict(t=now[0],routine=name,cycles=p._cycles(),HL=int(p.register_file.HL)))
  if name=='YesNoChoice':choice[0]=True
 for name in ['DisplayTextID','DisplayTextIDInit','PrintText','YesNoChoice','CloseTextDisplay']:p.hook_register(*symbols[name],hook,name)
 for t in range(700):
  now[0]=t
  if t%30==0:p.button_press('a')
  if t%30==2:p.button_release('a')
  p.tick(1)
  if choice[0]:
   p.button_release('a');p.tick(20);break
 else:raise AssertionError('no YesNoChoice')
 p.screen.image.save(out/'choice.png');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');(out/'tilemap.hex').write_text(bytes(p.memory[symbols['wTileMap'][1]:symbols['wTileMap'][1]+360]).hex()+'\n');(out/'state.json').write_text(json.dumps({n:get(n) for n in ['wCurMap','wXCoord','wYCoord','wCurrentMenuItem','wFontLoaded']},indent=2)+'\n');p.stop(save=False)
 if trial==2:
  for f in out.iterdir():assert f.read_bytes()==(b/'audit-157-original-choice-1'/f.name).read_bytes(),f
 print(trial,events,flush=True)
