from pathlib import Path
import json,hashlib,shutil,zipfile,io
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-201-choice-question-checkout';dest=wt/'docs/screenshots/fidelity-choice-question-split-201';dest.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for side in ['master','native']:
 a=r/f'audit-201-{side}-capture-a{2 if side == "native" else 1}-1';b=r/f'audit-201-{side}-capture-a{2 if side == "native" else 1}-2'
 for p in a.iterdir():
  if p.suffix in ['.json','.png']:assert p.read_bytes()==(b/p.name).read_bytes(),p
 shutil.copy2(a/'frame-0121.png',dest/('before.png' if side=='master' else 'after.png'))
with zipfile.ZipFile(dest/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 with zipfile.ZipFile(root/'.task-tmp/fidelity-91-plus-checkout/docs/screenshots/fidelity-choice-question-158/evidence.zip') as old:
  with zipfile.ZipFile(io.BytesIO(old.read('audit-157-choice-evidence.zip'))) as ref:
   for n in ref.namelist():
    if n.startswith(('audit-157-original-choice','stats-59-tools/probe_dialogue_choice_original')) and Path(n).suffix in ['.png','.json','.log','.py','.txt']:z.writestr('historical-original/'+n,ref.read(n))
 for side in ['master','native']:
  for repeat in [1,2]:
   base=r/f'audit-201-{side}-capture-a{2 if side == "native" else 1}-{repeat}'
   for p in base.iterdir():
    if p.suffix in ['.png','.json']:z.write(p,str(p.relative_to(r)))
   p=r/f'{base.name}.log';z.write(p,p.name)
  p=r/f'audit-201-{side}-a{2 if side == "native" else 1}-immutable/manifest.json';z.write(p,str(p.relative_to(r)))
  p=r/f'audit-201-{side}-raw-repeat-differences{"-a2" if side == "native" else ""}.json';z.write(p,p.name)
 for name in ['audit-201-native-build-a1.log','audit-201-native-build-a2.log','audit-201-master-build-a1.log','audit-201-core-tests-a1.log','audit-201-app-tests-a2.log','audit-201-source.patch','audit-201-capture-helper.rs','prepare_choice_question_201.py','freeze_test_choice_201.py','package_choice_question_201.py']:
  p=r/name;z.write(p,name)
 m=json.loads((r/'audit-201-native-a2-immutable/manifest.json').read_text())
 for name in m['sources']:z.write(wt/name,'final-source/'+name)
 ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
 for name in ['scripts/SafariZoneGate.asm','scripts/Museum1F.asm','engine/menus/text_box.asm','home/yes_no.asm']:
  if (ref/name).exists():z.write(ref/name,'original-source/'+name)
verify={'base':'506e19bea8cf0d40eb7a4f8ecfebc8213c59b590','native':m,'master':json.loads((r/'audit-201-master-a1-immutable/manifest.json').read_text()),'fixture_sha256':sha(r/'safari-147-source-setup/safari-one-step.sav'),'tests':{'core':2707,'app':192,'app_ignored':15},'repeat':'each side152PNG+frames.json(full raw snapshots)+observations.json byteexact across2repetitions; all608PNG retained, no masking','screens':'same t120/frame0121, identicalContinue fixture/setup/inputs; no font/layoutchange','files':{p.name:sha(p) for p in dest.iterdir() if p.suffix in ['.png','.zip']}}
(dest/'verification.json').write_text(json.dumps(verify,indent=2)+'\n');(dest/'README.md').write_text('''# Retain questions during choices: standalone split 201

Directly based on master506e19b. Seven production files cover completed field
text display ownership, direct/nested choice detection, rendering/cache gates,
debug/FrameRecorder display observation and backwards-compatible snapshot state. Incoming
movement, NPC sprite/font gates and field-clock dependencies were excluded.
The thin update wrapper only clears retained state at conversation completion.

Original Safari information worker calls PrintText then YesNoChoice. The latter
saves/restores its own menu tiles, leaving the question in the lower window.
The repair keeps the final text page through that choice, without allowing the
retained display text to consume A/B as an active dialogue. New dialogue,
answered/cancelled choice and completed scripts clear it. CUT's existing retained
text is still handled independently. Legacy JSON defaults the new field to None;
missing historical question content cannot be recreated from an older snapshot.

Actual Safari YES/A and NO/B branches verify preserved question, pre-answer JSON
restore, replacement text, final cleanup and every-frame cached/full pixel equality.
Museum verifies its multipage question survives the money-box command. Final
native suites pass core2707/app192 (15app intentionally ignored). Core sources
and frozen core binary remain unchanged from a1; final appa2 reruns its full
suite/captures after adding the matching FrameRecorder observation. GBA must pass
this independent PR's exact-head build/performance CI without budget changes.

Screenshot baseline is actual master506e19b with identical capture helper appended
and production prefix verified unchanged. Both sides load the original controlled
SRAM through real CONTINUE, explicitly end that fixture's Safari game and warp to
information worker position(3,4), reseed field RNG1 after load, faceLeft, then use
A at t0/80 and release at2/82. Frame0121/t120 has the same YES/NO choice and selected0:
master has no question; repair displays “Hi! Is it your first time / here?”. Each
side records152 frames and repeats twice. Every PNG, full raw frames.json and
visible observations.json matches byte-for-byte within each side, without masks.
All608PNG, all raw JSON, logs, source/binary hashes and differences reports retained.
Observed repeat equality does not prove globally seeded RNG or original CPU timing.

Historical157 original recordings/probe and primary assembly establish source
behavior; original footage uses a different interaction timeline, not an absolute
same-frame original/native comparison. Older broad-branch Native/GBA claims excluded.
This controlled interaction is not paid admission, a last-ball or fresh mainline
proof. General PrintText initialization/closing timing, NPC presentation and further
story callers remain separate audits. No ROM or executable is published.
''');print('packaged',len(list(dest.iterdir())),'files', (dest/'evidence.zip').stat().st_size,'archive bytes')
