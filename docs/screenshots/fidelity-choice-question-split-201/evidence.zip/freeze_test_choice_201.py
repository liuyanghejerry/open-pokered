from pathlib import Path
import re,shutil,hashlib,json,subprocess,os
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-201-choice-question-checkout';out=r/'audit-201-native-a1-immutable';out.mkdir(exist_ok=True);log=(r/'audit-201-native-build-a1.log').read_text();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bs={}
for name,label in [('pokered_core','core-tests'),('pokered_app','app-tests')]:
 src=Path(re.search(r'Executable unittests src/lib.rs \(([^\n]*'+name+r'-[^\n]*)\)',log).group(1));shutil.copy2(src,out/label);bs[label]=sha(out/label)
changed=subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=wt,text=True).splitlines();sources={p:sha(wt/p) for p in changed};(out/'manifest.json').write_text(json.dumps({'base':'506e19b','binaries':bs,'sources':sources,'scope':'retained question state/choice lifecycle/snapshot/display observation only; nofieldmovement,sprite orPCfoundations'},indent=2))
env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib')
for label in ['core-tests','app-tests']:
 with (r/f'audit-201-{label}-a1.log').open('w') as f:
  result=subprocess.run([str(out/label),'--test-threads=4'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(label,'exit',result.returncode)
