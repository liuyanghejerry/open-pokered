from pathlib import Path
import sys,os,json,socket,subprocess
root=Path('/home/jerry/develop/open-pokered');w=root/'.task-tmp/fidelity-185-quantity-checkout';r=root/'.task-tmp/fidelity-39-plus';sys.path.insert(0,str(w/'scripts'));from debug_drive import DebugClient
tag=os.environ.get('FIDELITY_PC_TAG','before-a1');binary=Path(os.environ.get('FIDELITY_PC_BIN',str(r/'audit-185-debug-cli-a1-immutable/pokered-app')));snapshot=Path(os.environ.get('FIDELITY_PC_SNAPSHOT',str(r/'audit-181-native-pc-slow-four-snapshot.json')));expected=int(os.environ.get('FIDELITY_PC_EXPECTED_QUANTITY_FRAME','48'))
mode=os.environ.get('FIDELITY_PC_MODE','withdraw');original_tag=os.environ.get('FIDELITY_PC_ORIGINAL_TAG','a1');moves={'withdraw':0,'deposit':1,'toss':2}[mode]
original=json.loads((r/'audit-185-original-quantity-1/frames.json').read_text());cues=original[-1]['cues'];select=cues['DisplayListMenuID']+70;controls=[v['input'] for v in original[select:]]
for trial in [1,2]:
 out=r/f'audit-185-native-quantity-after-{trial}';assert not out.exists();out.mkdir()
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib');log=(r/f'audit-185-native-quantity-after-{trial}.log').open('w');p=subprocess.Popen([str(binary),'--scripts-dir',os.environ.get('FIDELITY_PC_MAPS',str(r/'audit-179-fresh-context/crates/pokered-data/maps')),'run','--headless','--debug-port',str(port),'--speed','0','--skip-intro','--no-audio','--seed','42','--save',str(out/'isolated.sav'),'--snapshot',str(snapshot),'--lang','en'],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT);d=None
 try:
  d=DebugClient(port=port)
  def drive(keys):
   v=d.cmd(cmd='press_timeline',buttons=keys,advance=True);assert v.get('ok'),v
  v=d.cmd(cmd='warp',map='ViridianPokecenter',x=13,y=4);assert v.get('ok'),v
  drive([None]*120+['up']*20+[None]*20+['a']*20+[None]*20)
  def reach(target):
   for _ in range(500):
    if d.state().get('pc_phase')==target:return
    drive(['a',None])
   raise AssertionError((target,d.state()))
  reach('MainMenu');drive(['down',None,'a',None]);reach('ItemMenu');drive(['down',None]*moves);drive(['a',None]);reach('ItemList');drive([None]*70)
  before_bag=d.cmd(cmd='get_bag');assert before_bag.get('ok'),before_bag
  (out/'inventory-before.json').write_text(json.dumps(before_bag,indent=2)+'\n')
  (out/'preselect-state.json').write_text(json.dumps(d.state(),indent=2)+'\n');rows=[]
  for t,key in enumerate(controls):
   drive([key]);v=d.state();response=d.cmd(cmd='capture_frame',path=str(out/f'frame-{t:04}.png'));assert response.get('ok'),response;rows.append({'t':t,'input':key,'state':v})
  after_bag=d.cmd(cmd='get_bag');assert after_bag.get('ok'),after_bag;assert next(v['qty'] for v in before_bag['data'] if v['item']=='Potion')==4,before_bag;assert next(v['qty'] for v in after_bag['data'] if v['item']=='Potion')==5,after_bag
  (out/'inventory-after.json').write_text(json.dumps(after_bag,indent=2)+'\n')
  (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');print(trial,'quantity first frame',[v['t'] for v in rows if v['state'].get('pc_phase')=='ItemQuantity'][:1],flush=True);assert [v['t'] for v in rows if v['state'].get('pc_phase')=='ItemQuantity'][0]==expected
 finally:
  if d:d.close()
  p.terminate()
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait()
  log.close()
 if trial==2:
  old=r/'audit-185-native-quantity-after-1';files=sorted(v.name for v in out.iterdir() if v.suffix in ['.png','.json']);assert files==sorted(v.name for v in old.iterdir() if v.suffix in ['.png','.json']);assert all((out/f).read_bytes()==(old/f).read_bytes() for f in files)
