from pathlib import Path
w=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-185-quantity-checkout')
p=w/'crates/pokered-core/src/pc_screen.rs';s=p.read_text();a=s.index('    fn update_item_quantity(');b=s.index('\n    fn exec_item_move',a);part=s[a:b];old='''        if input.up && self.item_qty < *have {
            self.item_qty += 1;
        } else if input.down && self.item_qty > 1 {
            self.item_qty -= 1;
        }
        if input.b {''';assert part.count(old)==1;part=part.replace(old,'''        // DisplayChooseQuantityMenu: A, B, UP, DOWN in that order;
        // quantities wrap between 1 and the selected stack's maximum.
        if !input.a && !input.b {
            if input.up {
                self.item_qty = if self.item_qty >= *have { 1 } else { self.item_qty + 1 };
            } else if input.down {
                self.item_qty = if self.item_qty <= 1 { *have } else { self.item_qty - 1 };
            }
        }
        if input.b && !input.a {''');s=s[:a]+part+s[b:];p.write_text(s)
p=w/'crates/pokered-core/src/bag_screen.rs';s=p.read_text();a=s.index('    fn update_toss_quantity(');b=s.index('\n}',a);part=s[a:b];old='''        if input.up && qty < have {
            qty += 1;
        } else if input.down && qty > 1 {
            qty -= 1;
        }''';assert part.count(old)==1;part=part.replace(old,'''        // Shared original quantity menu wraps and gives A priority over
        // B/directions, so a chord cannot alter the confirmed amount.
        if !input.a && !input.b {
            if input.up {
                qty = if qty >= have { 1 } else { qty + 1 };
            } else if input.down {
                qty = if qty <= 1 { have } else { qty - 1 };
            }
        }''').replace('        if input.b {','        if input.b && !input.a {',1);s=s[:a]+part+s[b:];s=s.replace('fn toss_quantity_caps_at_held()', 'fn toss_quantity_wraps_held_boundary_on_repeated_presses()');old='''        for _ in 0..10 {
            s.update_frame(BagScreenInput { up: true, ..Default::default() });
        }
        assert_eq!(s.phase(), BagPhase::TossQuantity { qty: 2 });''';assert s.count(old)==1;s=s.replace(old,old.replace('qty: 2','qty: 1'));p.write_text(s)
p=w/'crates/pokered-core/src/items/shop.rs';s=p.read_text();old='''        let engine_input = EngineMenuInput {
            up: input.up,
            down: input.down,
            confirm: input.a,
            cancel: input.b,
        };''';assert s.count(old)==1;s=s.replace(old,'''        // Gen I's shared quantity chooser tests A before B and directions.
        // Keep the generic mart's other menu policies at their existing boundary.
        let quantity_menu = matches!(self.0.phase,
            MartPhase::Buy(BuyMenuState::Quantity { .. })
                | MartPhase::Sell(SellMenuState::Quantity { .. }));
        let direction_allowed = !quantity_menu || (!input.a && !input.b);
        let engine_input = EngineMenuInput {
            up: input.up && direction_allowed,
            down: input.down && direction_allowed,
            confirm: input.a,
            cancel: input.b && (!quantity_menu || !input.a),
        };''');p.write_text(s)
p=w/'crates/pokered-app/src/render/session.rs';s=p.read_text();a=s.index('    fn pc_item_questions_retained_frames_match_full_draw()');b=s.index('\n    #[test]',a);part=s[a:b];old='''                    stage = 3; Some(GbButton::B)
                } else { None };''';assert part.count(old)==1;part=part.replace(old,'''                    stage = 3; Some(GbButton::Down)
                } else if stage == 3 && phase == PcPhase::ItemQuantity {
                    assert_eq!(pc.item_qty(), 4);
                    stage = 4; Some(GbButton::Up)
                } else if stage == 4 && phase == PcPhase::ItemQuantity {
                    assert_eq!(pc.item_qty(), 1);
                    stage = 5; Some(GbButton::B)
                } else { None };''').replace('if stage == 3 && pc.phase() == PcPhase::ItemList','if stage == 5 && pc.phase() == PcPhase::ItemList');s=s[:a]+part+s[b:];p.write_text(s)
