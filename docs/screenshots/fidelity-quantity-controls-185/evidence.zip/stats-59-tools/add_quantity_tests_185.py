from pathlib import Path
w=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-185-quantity-checkout')
p=w/'crates/pokered-core/src/pc_screen.rs';s=p.read_text();n='    fn open_ctx() -> PcOpenContext {';assert s.count(n)==1;s=s.replace(n,'''    #[test]
    fn source_quantity_pc_wraps_both_boundaries_without_moving_stock() {
        for mode in [ItemListMode::Withdraw, ItemListMode::Deposit, ItemListMode::Toss] {
            for have in [1, 4, 99] {
                let mut w = World::new();
                w.bag.add_item(ItemId::Potion, have).unwrap();
                w.pc_items.add_item(ItemId::Potion, have).unwrap();
                let mut s = PcScreen::new(PcEntry::PlayersPc, &open_ctx());
                s.item_mode = mode;
                s.phase = PcPhase::ItemQuantity;
                s.item_qty = 1;
                s.update_frame(DOWN, &mut w.ctx());
                assert_eq!(s.item_qty(), have, "DOWN from1 mode{mode:?}");
                s.update_frame(UP, &mut w.ctx());
                assert_eq!(s.item_qty(), 1, "UP frommax mode{mode:?}");
                s.update_frame(B, &mut w.ctx());
                assert_eq!(w.bag.item_quantity(ItemId::Potion), have);
                assert_eq!(w.pc_items.item_quantity(ItemId::Potion), have);
            }
        }
    }

    #[test]
    fn source_quantity_pc_confirm_precedes_cancel_and_directions() {
        for mode in [ItemListMode::Withdraw, ItemListMode::Deposit, ItemListMode::Toss] {
            for b in [false, true] {
                let mut w = World::new();
                w.bag.add_item(ItemId::Potion, 4).unwrap();
                w.pc_items.add_item(ItemId::Potion, 4).unwrap();
                let mut s = PcScreen::new(PcEntry::PlayersPc, &open_ctx());
                s.item_mode = mode;
                s.phase = PcPhase::ItemQuantity;
                s.item_qty = 1;
                s.update_frame(MenuInput { a: true, b, up: true, down: true }, &mut w.ctx());
                assert_eq!(s.item_qty(), 1, "A keeps chosen quantity mode{mode:?} B{b}");
                assert_eq!(s.phase(), PcPhase::Message);
                match mode {
                    ItemListMode::Withdraw => {
                        assert_eq!(w.pc_items.item_quantity(ItemId::Potion), 3);
                        assert_eq!(w.bag.item_quantity(ItemId::Potion), 5);
                    }
                    ItemListMode::Deposit => {
                        assert_eq!(w.pc_items.item_quantity(ItemId::Potion), 5);
                        assert_eq!(w.bag.item_quantity(ItemId::Potion), 3);
                    }
                    ItemListMode::Toss => {
                        assert_eq!(s.msg_next, AfterMessage::TossConfirm);
                        assert_eq!(w.pc_items.item_quantity(ItemId::Potion), 4);
                        assert_eq!(w.bag.item_quantity(ItemId::Potion), 4);
                    }
                }
            }
        }
    }

'''+n);p.write_text(s)
p=w/'crates/pokered-core/src/bag_screen.rs';s=p.read_text();n='    fn toss_quantity_caps_at_held() {';assert s.count(n)==1;s=s.replace('    #[test]\n'+n,'''    #[test]
    fn source_quantity_bag_wraps_both_boundaries() {
        for have in [1, 4, 99] {
            let mut s = BagScreenState::new(vec![(ItemId::Potion, have)]);
            s.phase = BagPhase::TossQuantity { qty: 1 };
            s.update_frame(BagScreenInput { down: true, ..Default::default() });
            assert_eq!(s.phase(), BagPhase::TossQuantity { qty: have });
            s.update_frame(BagScreenInput { up: true, ..Default::default() });
            assert_eq!(s.phase(), BagPhase::TossQuantity { qty: 1 });
            assert_eq!(s.selected_item(), Some((ItemId::Potion, have)));
        }
    }

    #[test]
    fn source_quantity_bag_confirm_precedes_cancel_and_directions() {
        for b in [false, true] {
            let mut s = BagScreenState::new(vec![(ItemId::Potion, 4)]);
            s.phase = BagPhase::TossQuantity { qty: 1 };
            let result = s.update_frame(BagScreenInput {
                a: true, b, up: true, down: true, ..Default::default()
            });
            assert_eq!(result, BagScreenAction::TossItem {
                item: ItemId::Potion, index: 0, quantity: 1
            });
            assert_eq!(s.phase(), BagPhase::Browsing);
        }
    }

    #[test]
'''+n);p.write_text(s)
p=w/'crates/pokered-core/src/items/shop_tests.rs';s=p.read_text();s+='''

#[test]
fn source_quantity_mart_confirm_precedes_cancel_and_directions() {
    for sell in [false, true] {
        for b in [false, true] {
            let mut mart = MartState::new(ShopInventory::new(vec![ItemId::Potion]));
            let mut bag = Inventory::new_bag();
            bag.add_item(ItemId::Potion, 4).unwrap();
            let mut player = player_data(1000, bag);
            mart.phase = if sell {
                MartPhase::Sell(SellMenuState::Quantity { item_index: 0, quantity: 1, max_quantity: 4 })
            } else {
                MartPhase::Buy(BuyMenuState::Quantity { item_index: 0, quantity: 1 })
            };
            mart.update_frame(MenuInput { a: true, b, up: true, down: true }, &mut player);
            if sell {
                assert!(matches!(mart.phase, MartPhase::Sell(SellMenuState::Confirm { quantity: 1, .. })));
            } else {
                assert!(matches!(mart.phase, MartPhase::Buy(BuyMenuState::Confirm { quantity: 1, .. })));
            }
            assert_eq!(player.money, 1000);
            assert_eq!(player.bag.item_quantity(ItemId::Potion), 4);
        }
    }
}
''';p.write_text(s)
