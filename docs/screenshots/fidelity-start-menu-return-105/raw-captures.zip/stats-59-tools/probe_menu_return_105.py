exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/victory-100-source-setup-3f-hole';summary=[]
for trial in [1,2]:
 p=PyBoy(str(setup/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'pretrigger.state').read_bytes()));events=[];rows=[];now=[-1]
 def hook(name):
  event={'t':now[0],'routine':name,'a':p.register_file.A,'held':int(p.memory[symbols['hJoyHeld'][1]])}
  if not events or event!=events[-1]:events.append(event)
 for name in ['PlaySound','Joypad','DisplayTextID','DrawStartMenu','RedisplayStartMenu','StartMenu_Pokemon']:
  p.hook_register(*symbols[name],hook,name)
 for t in range(230):
  now[0]=t
  for at,key,pressed in [(0,'right',True),(16,'right',False),(71,'start',True),(111,'start',False),(120,'a',True),(122,'a',False),(170,'b',True),(172,'b',False)]:
   if t==at:(p.button_press if pressed else p.button_release)(key)
  p.tick(1)
  rows.append({'t':t,'current_item':int(p.memory[symbols['wCurrentMenuItem'][1]]),'held':int(p.memory[symbols['hJoyHeld'][1]]),'pressed':int(p.memory[symbols['hJoyPressed'][1]])})
 p.stop(save=False);summary.append({'trial':trial,'events':events,'rows':rows})
 print(trial,[e for e in events if e['routine']!='Joypad' or 165<=e['t']<=185],flush=True)
(root/'.task-tmp/fidelity-39-plus/menu-105-source-return.json').write_text(json.dumps(summary,indent=2))
