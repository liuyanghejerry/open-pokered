import os,subprocess,json
from pathlib import Path
r=Path('/home/jerry/develop/open-pokered');a=r/'.task-tmp/fidelity-39-plus'
for variant in ['before','after']:
 for trial in [1,2]:
  out=a/f'input-101-menu-{variant}-{trial}';env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',FIDELITY_DUST_SRAM=str(a/'dust-93-warp-setup/seafoam-valid.sav'),FIDELITY_DUST_CAPTURE=str(out),FIDELITY_DUST_MENU_RETURN='true')
  p=subprocess.run([str(a/f'input-101-menu-{variant}-driver'),'capture_actual_boulder_dust_raw_93','--ignored','--nocapture','--test-threads=1'],cwd=r/('.task-tmp/fidelity-101-menu-before-checkout' if variant=='before' else '.task-tmp/fidelity-91-plus-checkout'),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (a/f'{out.name}.log').write_text(p.stdout);assert p.returncode==0 and '1 passed' in p.stdout,p.stdout[-1500:]
  rows=json.loads((out/'frames.json').read_text());print(variant,trial,'everPush',any(x['push_frame'] is not None for x in rows),'initialStone',rows[0]['npcs'][0],'finalStone',rows[-1]['npcs'][0],flush=True)
