exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/dust-93-valid-setup'
for trial in [1,2]:
 out=root/f'.task-tmp/fidelity-39-plus/input-101-menu-source-{trial}';out.mkdir(exist_ok=True)
 p=PyBoy(str(setup/'dust-reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'actual-strength-prepush.state').read_bytes()));p.tick(120);events=[];now=[-100]
 for name in ['MoveSprite','DrawStartMenu','CloseStartMenu','TryWalking']:
  p.hook_register(*symbols[name],lambda name:events.append({'t':now[0],'routine':name}),name)
 p.button_press('start');p.button_press('down');p.tick(2);p.button_release('start');p.button_release('down');p.tick(60)
 now[0]=-8;p.button_press('b');p.tick(2);p.button_release('b');p.tick(6)
 rows=[]
 for t in range(-1,200):
  now[0]=t
  if t>=0:p.tick(1)
  p.screen.image.save(out/f'frame-{t+1:04}.png');rows.append({'t':t,'state':{n:int(p.memory[symbols[n][1]]) for n in ['wCurMap','wXCoord','wYCoord','wWalkCounter','hJoyHeld','wMiscFlags','wSprite01StateData2MapX','wSprite01StateData2MapY']}})
 (out/'events.json').write_text(json.dumps(events,indent=2));(out/'frames.json').write_text(json.dumps(rows,indent=2));p.stop(save=False);print(trial,events,flush=True)
