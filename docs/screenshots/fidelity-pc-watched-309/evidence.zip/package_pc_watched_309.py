from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-308-pc-item-watched-input-checkout';docs=wt/'docs/screenshots/fidelity-pc-watched-309';items={}
def add(p):
 assert p.suffix in ['.json','.png','.py','.rs','.log'];items[str(p.relative_to(r))]=p
for d in r.glob('audit-309-original-*-list-select-*-three-items-a1-*'):
 for p in d.iterdir():
  if p.suffix in ['.json','.png']:add(p)
for c in ['qty_second','marked_qty_second','scrolled_qty']:
 for i in [1,2]:
  for p in (r/f'audit-307-original-withdraw-list-select-{c}-three-items-a1-{i}').iterdir():
   if p.suffix in ['.json','.png']:add(p)
  for p in (r/f'audit-309-followup8-a{i}/withdraw-{c}').iterdir():
   if p.suffix in ['.json','.png']:add(p)
for prefix in ['audit-309-watched-master','audit-309-fidelity-pc-watched-input-host','audit-309-select15','audit-309-select-held4']:
 for i in [1,2]:
  for p in (r/f'{prefix}-a{i}').rglob('*'):
   if p.is_file() and p.suffix in ['.json','.png']:add(p)
for p in (r/'audit-309-ui-save-a1').rglob('*'):
 if p.name in ['save-verification.json','reload-verification.json']:add(p)
for name in ['audit-309-case-schedules.json','audit-309-source-native-controls-summary.json','audit-309-native-repeat-file-verification.json','audit-309-ui-save-continue-summary.json','audit-309-watched-full-regression-summary.json','audit-309-watched-all-unit-and-integration-results-a1.json','audit-309-watched-cli-regression-results.json','audit-309-deferred-clock-counterexamples.json','audit-309-core-default-tests-a1.log','capture_pc_watched_input_309.rs','capture_pc_select_save_host_300.rs','capture_pc_select_held_host_303.rs','capture_pc_item_followup_306.rs','compare_pc_watched_309.py','package_pc_watched_309.py','freeze_run_pc_watched_all_tests_309.py','freeze_run_pc_watched_cli_309.py']:add(r/name)
for name in ['probe_pc_watched_input_309.py','probe_pc_item_followup_307_extra.py']:add(r/'stats-59-tools'/name)
manifest={'base':'6f1d09b74082a39dd403738d3f95c42578029a9f','tested_code':'5931fb619203f0c00a5a8f42a64f1cdc05e680d8','sources':{'crates/pokered-core/src/pc_screen.rs':hashlib.sha256((wt/'crates/pokered-core/src/pc_screen.rs').read_bytes()).hexdigest()},'files':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(items.items())}}
archive=docs/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(items.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,digest in manifest['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==digest
record={'paths':len(items),'archive_bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'roundtrip_verified':True,'excluded':['ROM','SRAM','whole game snapshot','emulator state','executables']};(r/'audit-309-public-archive-verification.json').write_text(json.dumps(record,indent=2)+'\n');print(record,flush=True)
