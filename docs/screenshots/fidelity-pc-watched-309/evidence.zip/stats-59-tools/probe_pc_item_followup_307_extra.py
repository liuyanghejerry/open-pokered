exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state'
mode=os.environ.get('FIDELITY_PC_MODE','withdraw');speed=int(os.environ.get('FIDELITY_PC_SPEED','5'));key=os.environ.get('PC_QUESTION_KEY_239','b');offset=int(os.environ.get('PC_QUESTION_OFFSET_239','2'));duration=int(os.environ.get('PC_HOLD_DURATION_254','10'));case=os.environ.get('PC_ITEM_FOLLOWUP_CASE_307','swap');tag=f'list-select-{case}-three-items-a1';moves={'withdraw':0,'deposit':1,'toss':2}[mode];interference='none'
for trial in [1,2]:
 out=r/f'audit-307-original-{mode}-{tag}-{trial}';assert not out.exists();out.mkdir()
 p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]]);now=[-1];events=[];cues={n:None for n in ['PCMainMenu','PlayerPCMenu','DisplayListMenuID','DisplayChooseQuantityMenu']};need=[False];ack_until=-1;last_ack=-100;held=None
 assert get('wNumBoxItems')==1
 if tag!='a1':
  p.memory[symbols['wOptions'][1]]=(get('wOptions')&0xf0)|speed
  count=1 if case.startswith('one_') else 2 if case.startswith('two_') else 3
  values=[0x14,4,0x0b,3,0x04,2][:count*2]+[0xff]
  for num,items in [('wNumBagItems','wBagItems'),('wNumBoxItems','wBoxItems')]:
   p.memory[symbols[num][1]]=count
   a=symbols[items][1]
   for i,v in enumerate(values):p.memory[a+i]=v
 def hook(n):
  if n in cues and cues[n] is None:cues[n]=now[0]
  if n=='WaitForTextScrollButtonPress':need[0]=True
  events.append({'t':now[0],'routine':n,'cycles':p._cycles(),'no_delay':bool(get('wStatusFlags5')&0x40),'cursor':get('wCurrentMenuItem'),'swap_slot':get('wMenuItemToSwap'),'list_scroll':get('wListScrollOffset'),'frame_counter':get('hFrameCounter'),'held':get('hJoyHeld'),'pressed':get('hJoyPressed'),'last':get('hJoyLast'),'joy6':get('hJoy6'),'joy7':get('hJoy7'),'bag_items':[int(p.memory[symbols['wBagItems'][1]+i]) for i in range(7)],'pc_items':[int(p.memory[symbols['wBoxItems'][1]+i]) for i in range(7)]})
 for n in list(cues)+['PlayerPC','PlayerPCWithdraw','PrintText','WaitForTextScrollButtonPress','RemoveItemFromInventory','AddItemToInventory','PrintLetterDelay','HandleMenuInput','JoypadLowSensitivity','HandleItemListSwapping']:
  assert n in symbols,n;p.hook_register(*symbols[n],hook,n)
 rows=[]
 for t in range(2400):
  now[0]=t;key='a' if t<2 else None
  m=cues['PCMainMenu'];pc=cues['PlayerPCMenu'];li=cues['DisplayListMenuID'];qty=cues['DisplayChooseQuantityMenu']
  if m is not None and pc is None:
   if m+70<=t<m+72:key='down'
   if m+94<=t<m+96:key='a'
  if pc is not None and li is None:
   for n in range(moves):
    if pc+70+n*24<=t<pc+72+n*24:key='down'
   if pc+70+moves*24<=t<pc+72+moves*24:key='a'
  if need[0] and held is None and t-last_ack>=20 and qty is None:
   need[0]=False;ack_until=t+2;last_ack=t
  if t<ack_until:key='a'
  text_events=[e for e in events if e['routine']=='PrintText' and pc is not None and e['t']>=pc]
  schedule={'qty_second': [(70, 'down', 2), (110, 'a', 2), (190, 'b', 2)], 'marked_qty_second': [(70, 'down', 2), (110, 'select', 2), (150, 'a', 2), (230, 'b', 2)], 'scrolled_qty': [(70, 'down', 2), (110, 'down', 2), (150, 'down', 2), (190, 'up', 2), (230, 'a', 2), (310, 'b', 2)], 'down_held': [(70, 'down', 80)], 'up_held': [(70, 'down', 2), (110, 'down', 2), (150, 'up', 80)]}
  anchor=None if pc is None else pc+70+moves*24
  if anchor is not None:
   for at,button,n in schedule[case]:
    if anchor+at<=t<anchor+at+n:key=button
  if key!=held:
   if held:
    for k in held.split('-'):p.button_release(k)
   if key:
    for k in key.split('-'):p.button_press(k)
   held=key
  p.tick(1);
  if anchor is not None and t-anchor in [0,4,17,18,19,20,40,70,72,74,100,110,150,152,156,190,350,500]:p.screen.image.save(out/f'frame-{t:04}.png')
  rows.append({'t':t,'input':key,'no_delay':bool(get('wStatusFlags5')&0x40),'cues':dict(cues),'cursor':get('wCurrentMenuItem'),'swap_slot':get('wMenuItemToSwap'),'list_scroll':get('wListScrollOffset'),'frame_counter':get('hFrameCounter'),'held':get('hJoyHeld'),'pressed':get('hJoyPressed'),'last':get('hJoyLast'),'joy6':get('hJoy6'),'joy7':get('hJoy7'),'bag_items':[int(p.memory[symbols['wBagItems'][1]+i]) for i in range(7)],'pc_items':[int(p.memory[symbols['wBoxItems'][1]+i]) for i in range(7)]})
  text_events=[e for e in events if e['routine']=='PrintText' and cues['PlayerPCMenu'] is not None and e['t']>=cues['PlayerPCMenu']]
  if anchor is not None and t>=anchor+500:break
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
 assert cues['PlayerPCMenu'] is not None
 print(trial,cues,'source event count',len(events),flush=True)
 if trial==2:
  old=r/f'audit-307-original-{mode}-{tag}-1';assert sorted(f.name for f in out.iterdir())==sorted(f.name for f in old.iterdir());assert all(f.read_bytes()==(old/f.name).read_bytes() for f in out.iterdir())
