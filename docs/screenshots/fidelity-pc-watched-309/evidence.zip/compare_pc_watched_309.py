from pathlib import Path
import json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');results=[]
def stock(raw):
 out=[]
 for i in range(0,len(raw),2):
  if raw[i]==255:break
  out.append([{20:'Potion',11:'Antidote',4:'PokeBall'}[raw[i]],raw[i+1]])
 return out
for mode,moves in [('withdraw',0),('deposit',1),('toss',2)]:
 for c in json.loads((r/'audit-309-case-schedules.json').read_text()):
  d=r/f'audit-309-original-{mode}-list-select-{c}-three-items-a1-1';fs=json.loads((d/'frames.json').read_text());anchor=fs[-1]['cues']['PlayerPCMenu']+70+24*moves;src={f['t']-anchor:f for f in fs if f['t']>=anchor};a=r/f'audit-309-fidelity-pc-watched-input-host-a1/{mode}-{c}';b=r/f'audit-309-fidelity-pc-watched-input-host-a2/{mode}-{c}';after=json.loads((a/'frames.json').read_text());before=json.loads((r/f'audit-309-watched-master-a1/{mode}-{c}/frames.json').read_text());assert (a/'frames.json').read_bytes()==(b/'frames.json').read_bytes();mismatch=[f['t'] for f in after if (f['cursor'],f['scroll'])!=(src[f['t']]['cursor']+src[f['t']]['list_scroll'],src[f['t']]['list_scroll'])];inventory=[f['t'] for f in after if f['bag']!=stock(src[f['t']]['bag_items']) or f['pc']!=stock(src[f['t']]['pc_items'])];sq=src[500]['cues']['DisplayChooseQuantityMenu']-anchor;nq=next(f['t'] for f in after if f['phase']=='ItemQuantity');bq=next((f['t'] for f in before if f['phase']=='ItemQuantity'),None);bad=[f['t'] for f in before if (f['cursor'],f['scroll'])!=(src[f['t']]['cursor']+src[f['t']]['list_scroll'])];assert not mismatch and not inventory and sq==nq;assert bad or sq!=bq
  results.append({'mode':mode,'case':c,'frames':501,'cursor_scroll_source_equal_every_frame':True,'inventory_source_equal_every_frame':True,'source_quantity_frame':sq,'after_quantity_frame':nq,'before_quantity_frame':bq,'before_cursor_mismatches':len(bad),'cache_full_equal_every_frame':all(f['cached_equals_full'] for f in after),'SAVE_absent':all(not f['ordinary_save_exists'] for f in after),'repeats_equal':True})
for name,prior in [('select15','audit-305-select-original-host-a1'),('select-held4','audit-305-select-held-host-a1')]:
 for d in sorted((r/f'audit-309-{name}-a1').iterdir()):
  assert(d/'frames.json').read_bytes()==(r/f'audit-309-{name}-a2'/d.name/'frames.json').read_bytes();assert(d/'frames.json').read_bytes()==(r/prior/d.name/'frames.json').read_bytes();results.append({'control':name,'case':d.name,'entire_frame_record_equals_previous_source_verified':True,'repeat_bytes_equal':True})
for c in ['qty_second','marked_qty_second','scrolled_qty']:
 rows=json.loads((r/f'audit-307-original-withdraw-list-select-{c}-three-items-a1-1/frames.json').read_text());a=rows[-1]['cues']['PlayerPCMenu']+70;src={f['t']-a:f for f in rows if f['t']>=a};n=json.loads((r/f'audit-309-followup8-a1/withdraw-{c}/frames.json').read_text());assert all((f['cursor'],f['scroll'])==(src[f['t']]['cursor']+src[f['t']]['list_scroll'],src[f['t']]['list_scroll']) and f['bag']==stock(src[f['t']]['bag_items']) and f['pc']==stock(src[f['t']]['pc_items']) and f['cached_equals_full'] and not f['ordinary_save_exists'] for f in n);assert(r/f'audit-309-followup8-a1/withdraw-{c}/frames.json').read_bytes()==(r/f'audit-309-followup8-a2/withdraw-{c}/frames.json').read_bytes();results.append({'control':'quantity_cancel','case':c,'source_cursor_scroll_inventory_every_frame_equal':True,'cache_full_equal_every_frame':True,'repeat_bytes_equal':True})
assert len(results)==34;(r/'audit-309-source-native-controls-summary.json').write_text(json.dumps(results,indent=2)+'\n');print('PASS12 source/actual new cases +19 unchanged source-verified SELECT controls +3 source quantity-cancel controls')
