from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-298-pc-item-select-checkout';head='0b7331f84f20b7514dfcbd2cc0c445555bd92fde';base='a7d4731291ab16a0449ce2698063a57717902e8e';sha=lambda b:hashlib.sha256(b).hexdigest();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==head;files={}
def add(p,name=None):
 assert p.is_file();assert p.suffix in ['.png','.json','.log','.rs','.py','.asm'];files[name or str(p.relative_to(r))]=p
for prefix in ['audit-305-select-before-common-host','audit-305-select-original-host','audit-305-select-held-host']:
 a,b=[r/(prefix+'-a'+str(n))for n in [1,2]]
 paths=sorted(p.relative_to(a)for p in a.rglob('*')if p.is_file());assert paths==sorted(p.relative_to(b)for p in b.rglob('*')if p.is_file());assert all((a/p).read_bytes()==(b/p).read_bytes()for p in paths)
 for d in [a,b]:
  for p in d.rglob('*'):
   if p.is_file():add(p)
assert(root/'.task-tmp/fidelity-299-select-before-host-tool/src/main.rs').read_bytes()==(root/'.task-tmp/fidelity-299-select-after-host-tool/src/main.rs').read_bytes()
old=json.loads((r/'audit-299-select-original-native-15-summary.json').read_text());prefixes=[x['original_prefix']for x in old]+[f'audit-303-original-withdraw-list-select-{x}-three-items-a1'for x in ['select_held','downselect_held','select_held_newdown','marked_downselect_held']];assert len(prefixes)==19
for prefix in prefixes:
 a,b=[r/(prefix+'-'+str(n))for n in [1,2]];names=sorted(p.name for p in a.iterdir());assert names==sorted(p.name for p in b.iterdir());assert all((a/n).read_bytes()==(b/n).read_bytes()for n in names)
 for d in [a,b]:
  for p in d.iterdir():add(p)
summary=json.loads((r/'audit-305-select-full-regression-summary.json').read_text());assert(summary['source_head'],summary['base'],summary['passed'],summary['failed'])==(head,base,3703,0);cli=json.loads((r/'audit-305-select-cli-regression-results.json').read_text());assert cli['head']==head and cli['base']==base and cli['fresh_m01_m03']and cli['separate_process_s07_save_continue'];save=json.loads((r/'audit-305-select-15-ui-save-reload-summary.json').read_text());assert len(save['cases'])==15 and save['head']==head
for n in ['audit-305-select-full-regression-summary.json','audit-305-select-all-unit-and-integration-results-a1.json','audit-305-select-all-tests-a1-immutable/manifest.json','audit-305-select-all-tests-build-a1.log','audit-305-select-cli-build-a1.log','audit-305-select-cli-regression-results.json','audit-305-select-cli-regression-run.log','audit-305-select-cli-immutable/manifest.json','audit-305-select-15-ui-save-reload-summary.json','audit-305-select-held-source-native-comparison.json','audit-305-select-original15-source-native-comparison.json','audit-305-select-held-host-immutable/manifest.json','audit-305-select-original-host-immutable/manifest.json','audit-303-select-held-core-before-a1.log','audit-304-select-repeat-core-after-a1.log','audit-304-select-all-default-core-after-a1.log','capture_pc_select_save_host_300.rs','capture_pc_select_held_host_303.rs','freeze_run_pc_select_all_tests_305.py','freeze_run_pc_select_cli_305.py','package_pc_select_305.py','stats-59-tools/probe_pc_select_controls_268.py','stats-59-tools/probe_pc_select_duplicate_slots_269.py','stats-59-tools/probe_pc_select_extra_controls_299.py','stats-59-tools/probe_pc_select_held_controls_303.py']:
 p=r/n
 if not p.exists()and n.endswith('probe_pc_select_controls_268.py'):continue
 add(p)
for x in json.loads((r/'audit-305-select-all-unit-and-integration-results-a1.json').read_text())['results']:add(r/x['log'])
for n in ['crates/pokered-core/src/pc_screen.rs','crates/pokered-app/src/render/pc.rs','crates/pokered-app/src/render/session.rs']:add(w/n,'candidate-source/'+n)
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for n in ['home/list_menu.asm','home/joypad2.asm','engine/menus/swap_items.asm']:add(ref/n,'original-source/'+n)
out=w/'docs/screenshots/fidelity-pc-select-305';out.mkdir(parents=True,exist_ok=False);blobs=set();png={}
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name,p in files.items():
  data=p.read_bytes()
  if p.suffix=='.png':
   h=sha(data);png[name]=h
   if h not in blobs:z.writestr('png-blobs/'+h+'.png',data);blobs.add(h)
  else:z.writestr(name,data)
 z.writestr('png-files.json',json.dumps(png,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip')as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png'if name in png else name)==p.read_bytes()
for name,case,frame in [('mark','withdraw-swap',110),('deposit','deposit-swap',190),('merge','withdraw-merge',190),('overflow','withdraw-overflow',190)]:
 for side,prefix in [('before','audit-305-select-before-common-host-a1'),('after','audit-305-select-original-host-a1')]:shutil.copy2(r/prefix/case/f'frame-{frame:03}.png',out/f'{name}-{side}.png')
v={'base':base,'tested_head':head,'tests':summary,'cases':19,'source_and_native_repeats':2,'inventory_every_frame_matches_original':True,'four_held_cases_cursor_scroll_every_frame_matches':True,'all19_cached_equals_full_every_frame':True,'ordinary_ui_save_separate_process_continue_cases':15,'same_before_after_helper_source_sha256':sha((root/'.task-tmp/fidelity-299-select-after-host-tool/src/main.rs').read_bytes()),'helper_feature_fixed':'after-only public mark getter for record; before records none','archive_roundtrip_byte_exact':True,'archive_sha256':sha((out/'evidence.zip').read_bytes()),'archive_bytes':(out/'evidence.zip').stat().st_size,'PNG_paths':len(png),'deduplicated_PNG':len(blobs),'scope':'PC SELECT sorting and held SELECT30/5 repeat,20/6 protected waits. General directional held repeat without SELECT, initial item-list sampling guards, other redraw guards and whole-game fidelity remain under audit; original PPU exact frame rendering not claimed.'};(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
(out/'README.md').write_text('''# Player PC SELECT sorting

Based on actual master a7d4731 after the independent SRAM import fix #175. Withdraw, Deposit and Toss item lists support SELECT marking and physical-slot sorting. Different items swap; same-kind quantities merge into the second slot, capped at 99 with excess in the first. Same-slot and CANCEL selections retain the mark; B exits and quantity cancellation clears it. Sorting preserves the other inventory and does not invoke ordinary SAVE.

SELECT uses the original 30-frame first hold delay and 5-frame repeat counter. The counter advances through the 20-frame sorting guard and 6-frame list reload. Same-slot SELECT repeats also reload for six frames, discarding short keys inside that guard. Cached rendering retains the first slot's hollow arrow when the active cursor moves away.

19 original emulator scenarios and actual native host scenarios repeat twice byte exactly. Inventory matches the original at every recorded frame; final list cursor/scroll match for the 15 tap/control scenarios, and cursor/scroll match at every frame for the 4 held scenarios. Native fixtures use public PokemonGame/PcScreen constructors, persistent InputState and actual Game.update; full Game.draw is compared with cached RenderSession every frame. These are controlled PC fixtures, not natural boot/playthroughs. Before/after use identical helper source; the after-only fixed feature reads the public marked-slot getter for recording. Optional SAVE and reload paths are disabled for the comparison captures.

Four actual-master/candidate screenshot pairs show marking, Deposit sorting, duplicate-slot merge and quantity overflow at matching menu frames. Full debug app/core regression: 78 frozen programs, 3703 passed, 0 failed, 76 ignored. Fresh CLI m01–m03 and separate-process s07 pass. Fifteen controlled sorting scenarios exit the PC using B, open START/SAVE and save with A; a separate process uses actual CONTINUE prompts from a controlled MainMenu and verifies both inventories' physical order and quantities. Private SRAM/flags remain local.

The archive contains deduplicated PNG frames, controlled input/inventory records, scripts, source excerpts and full regression logs, verified byte exactly after packaging. It contains no ROM, SRAM, emulator state, private save snapshot or executable. PNG paths reconstruct via png-files.json and png-blobs.

General directional held repeat without SELECT, initial item-list sampling guards, other redraw guards and broader story/function coverage remain under separate audit. Source PPU-exact visual timing and whole-game equivalence are not claimed. Fonts, Chinese, pinyin IME and dialogue layout remain outside the goal.
''');print(json.dumps(v),flush=True)
