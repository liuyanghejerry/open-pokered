from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess,re
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-91-plus-checkout';base=root/'.task-tmp/fidelity-93-master-before';out=wt/'docs/screenshots/fidelity-choice-question-158';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
master='31b1eda3112514d6bc803af559ec7f7c9e20374f';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip()==master
original=subprocess.check_output(['git','show',master+':crates/pokered-app/src/game.rs'],cwd=base,text=True);before=(base/'crates/pokered-app/src/game.rs').read_text();assert before.split('\n#[cfg(test)]\n')[0]==original.split('\n#[cfg(test)]\n')[0]
assert subprocess.check_output(['git','diff','--name-only'],cwd=base,text=True).splitlines()==['crates/pokered-app/src/game.rs']
helper=(r/'choice-158-capture-helper.rs').read_text();assert helper in before;assert helper in (wt/'crates/pokered-app/src/game.rs').read_text()
rows={}
for kind in ['master','final-native']:
 a=r/f'choice-158-{kind}-1';b=r/f'choice-158-{kind}-2';rows[kind]=json.loads((a/'frames.json').read_text());assert (a/'frames.json').read_bytes()==(b/'frames.json').read_bytes();assert (a/'fixture.sav').read_bytes()==(b/'fixture.sav').read_bytes()
 for t in range(152):assert (a/f'frame-{t:04}.png').read_bytes()==(b/f'frame-{t:04}.png').read_bytes()
assert [(x['t'],x['input_bits']) for x in rows['master']]==[(x['t'],x['input_bits']) for x in rows['final-native']]
for kind,data in rows.items():
 row=data[121];assert row['t']==120;ow=row['overworld'];assert (ow['state']['current_map'],ow['state']['player']['x'],ow['state']['player']['y'])==('SafariZoneGate',3,4);assert ow['pending_choice']['options']==['YES','NO'];assert ow['pending_dialogue'] is None
 if kind=='final-native':assert ow['last_script_dialogue']['pages'][0]=={'line1':'Hi! Is it your first time','line2':'here?'}
for name,source in [('before.png','choice-158-master-1/frame-0121.png'),('after.png','choice-158-final-native-1/frame-0121.png'),('original-reference.png','audit-157-original-choice-1/choice.png')]:shutil.copyfile(r/source,out/name)
files=[]
for kind in ['master','final-native','native','a4-native']:
 for trial in [1,2]:files+=list((r/f'choice-158-{kind}-{trial}').iterdir())
files += list(r.glob('choice-158-*.log'))+list(r.glob('choice-158-gba-*.json'))
files += [r/'choice-158-capture-helper.rs',r/'audit-157-choice-evidence.zip',r/'audit-157-text-sessions-evidence.zip',r/'stats-59-tools/probe_dialogue_choice_157.py',r/'stats-59-tools/probe_dialogue_choice_original_157.py',Path(__file__)]
# Preserve exact build inputs (and failed candidates' logs) without storing huge executables.
names=['crates/pokered-core/src/overworld/screen.rs','crates/pokered-core/src/overworld/update.rs','crates/pokered-core/src/overworld/script_bridge.rs','crates/pokered-core/src/snapshot.rs','crates/pokered-app/src/game.rs','crates/pokered-app/src/render/overworld.rs','crates/pokered-app/src/render/mod.rs'];source_hashes={name:sha(wt/name) for name in names}
app=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-18-27/target/debug/deps/pokered_app-823b1783d030defc');basebin=r/'unoptimized-target/debug/deps/pokered_app-ff0279f3644dd22e'
verification={'parent_head':'35632e8b8c5500e8b87fbb47c06e127ff6e47b91','master':master,'source_hashes':source_hashes,'app_binary_sha256':sha(app),'master_binary_sha256':sha(basebin),'master_production_prefix_verified':True,'helper_byte_identical':True,'helper_sha256':sha(r/'choice-158-capture-helper.rs'),'save_sha256':sha(r/'safari-147-source-setup/safari-one-step.sav'),'captures':{'groups':4,'frames_each':152,'pngs':608,'raw_json_repeat_exact':True,'png_repeat_exact':True,'same_input_and_frame_schedule':True,'matched_screenshot_frame':120},'core_tests':2736,'app_tests':208,'ignored_capture_helpers':26,'coverage':['actual Safari YES/A and NO/B','question retained through JSON restore','legacy JSON defaults','new answer replaces question and no leak after script end','Museum multi-page last question survives intermediate money-box command','actual Safari cached/full frames compared during question handoff and completion'],'scope':'controlled real SRAM Continue then end hunt and warp to valid counter (3,4); original reaches same counter by real movement from controlled return; not normal paid admission, last-ball battle or current mainline proof','limits':['generic DisplayTextID initialization/CloseTextDisplay and absolute schedule still incomplete','earlier Victory Road, party restore, FollowNpc/spinner and other draft gates remain','final-head fresh m01-m49, independent CONTINUE and all22 completedCI required']}
manifest={}
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):
  name=str(p.relative_to(r));data=p.read_bytes();manifest[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
 for name in names:
  data=(wt/name).read_bytes();key='final-source/'+name;manifest[key]=hashlib.sha256(data).hexdigest();z.writestr(key,data)
 z.writestr('sha256.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip') as z:
 for name,value in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==value
verification['archive_sha256']=sha(out/'evidence.zip');verification['archive_files']=len(manifest);(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(out/'README.md').write_text('''# 选项菜单保留问题文字\n\nSafari 信息员的问题在复刻弹出 YES/NO 时消失，原作的 `PrintText -> YesNoChoice` 保留问题。共享 ShowDialogue 结束时，现在保存最后一页的显示状态；直接或嵌套选项菜单显示它，不让这份保留文本再次消费 A/B。选择完成、新台词开始或脚本结束会清除旧状态。JSON 快照包含该状态，旧 JSON 缺字段时按 None 兼容。原先没有保存的问题内容无法从旧快照凭空恢复。\n\n前/后图均用原作一步额度 SRAM 通过真实 CONTINUE，随后明确结束狩猎并 warp 到有效柜台位置 `(3,4)`。固定 RNG=1，面朝左；相同硬件帧输入在 0/80 按 A，2/82 松开，截图为第 120 帧。前图来自实际 master `31b1eda3112514d6bc803af559ec7f7c9e20374f`，只添加同一录制测试辅助代码，生产前缀与 git 原文件一致。后图为最终修复源码。前/后各两次、每次 152 帧；608 PNG 和完整原始 JSON 重复逐字节一致，无状态字段掩码。原作参考图来自另一条真实移动/交互录制，保留原始例程调用和图块数据，不能当作绝对同帧比较。\n\n实际游戏回归验证 Safari YES/A、NO/B 的台词分支、选择前 JSON 恢复、结束后不残留；博物馆多页售票问题保留最后一页，中间显示金钱框也不丢失。Safari 的交接和完成过程逐帧比较缓存/完整绘制。渲染缓存门禁读取同一份实际显示状态，避免把保留的问题当成无叠加层画面。CUT 的既有保留文本不参与新增的选择生命周期门禁。\n\n最终核心 2,736 项、应用 208 项测试通过；26 个捕获辅助测试默认忽略。GBA 发布构建及原阈值下性能结果见附属文件。`evidence.zip` 内保留录制、源数据、源码、构建/测试日志和早期候选日志，每个条目 SHA-256 打包后全部重新验算。早期候选或失败命令不计入最终验证。\n\n本次修复问题内容保留；通用对话初始化、完整关闭恢复及绝对调度仍待修复。原作 Safari 广播内部多次 PrintText 共用第一次 DisplayTextIDInit，门房告别另开一次，不能每换段文字重复加等待。本受控场景不是正常入场、最后一球战斗或最终主线通关证明。字体、中文、拼音输入法和对话框布局差异按用户要求排除；不宣称原作全帧像素一致。\n''')
print(json.dumps({'archive_files':len(manifest),'archive_sha256':verification['archive_sha256'],'archive_bytes':(out/'evidence.zip').stat().st_size}))
