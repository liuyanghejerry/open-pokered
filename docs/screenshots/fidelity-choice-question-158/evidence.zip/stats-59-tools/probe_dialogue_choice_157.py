import pathlib,sys,json,shutil
root=pathlib.Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-91-plus-checkout';sys.path.insert(0,str(wt/'scripts'))
from playthrough import Game,m01_boot,m02_oak_speech
for trial in [1,2]:
 out=r/f'audit-157-final-native-choice-{trial}';out.mkdir(exist_ok=True);g=Game(binary=r/'audit-155-cli-immutable/pokered-app',seed=1);trace=[]
 try:
  m01_boot(g);m02_oak_speech(g)
  assert g.d.cmd(cmd='warp',map='SafariZoneGate',x=3,y=4)['ok'];g.wait('control_ready',600)
  g.tap('left',8);g.tap('a',8)
  for _ in range(100):
   state=g.st();trace.append(state)
   if state['choice'] is not None:break
   g.step(30)
   if g.st()['choice'] is None:g.tap('a',8)
  else:raise AssertionError('no choice')
  g.step(20);state=g.st();assert state['choice']['options']==['YES','NO'];assert state['dialogue_state'] is None
  assert g.d.cmd(cmd='capture_frame',path=str(out/'choice.png'))['ok']
  (out/'choice-state.json').write_text(json.dumps(state,indent=2)+'\n');(out/'trace.json').write_text(json.dumps(trace,indent=2)+'\n')
  print(trial,'YES/NO shown but dialogue_state=None',flush=True)
 finally:shutil.copyfile(g.run_dir/'game.log',out/'game.log');g.close()
