#[cfg(all(test, not(target_os = "none")))]
mod choice_question_capture_158 {
    use super::*;
    #[test]
    #[ignore = "controlled SRAM Continue, identical inputs and hardware frames"]
    fn capture_choice_question_158() {
        std::thread::Builder::new().stack_size(16 * 1024 * 1024).spawn(|| {
            let dir = std::path::PathBuf::from(std::env::var("FIDELITY_CHOICE_CAPTURE").unwrap());
            std::fs::create_dir_all(&dir).unwrap();
            let save = dir.join("fixture.sav");
            std::fs::copy(std::env::var("FIDELITY_SAFARI_SRAM").unwrap(), &save).unwrap();
            let mut g = PokemonGame::new_with_options(GameVersion::Red, Some(save), None, None,
                false, None, false, true, #[cfg(feature = "debug-server")] None);
            g.state.config.language = pokered_core::game_state::Lang::En;
            g.state.config.text_speed = pokered_core::game_state::TextSpeed::Fast;
            let idle = InputState::new();
            let mut a = InputState::new(); a.press(GbButton::A);
            let mut saw_menu = false;
            for t in 0..2000 {
                saw_menu |= g.state.screen == GameScreen::MainMenu;
                if g.state.screen == GameScreen::Overworld { break; }
                g.update(if t % 20 == 19 { &a } else { &idle });
            }
            assert!(saw_menu);
            assert_eq!(g.state.screen, GameScreen::Overworld);
            // Diagnostic endpoint, not paid admission or last-ball proof.
            g.overworld.end_safari_game();
            g.overworld.warp_to_map(MapId::SafariZoneGate, 3, 4);
            g.overworld.set_rng_seed(1);
            for _ in 0..120 { g.update(&idle); }
            let mut left = InputState::new(); left.press(GbButton::Left);
            for _ in 0..8 { g.update(&left); }
            for _ in 0..8 { g.update(&idle); }
            assert_eq!((g.overworld.state.player.x,g.overworld.state.player.y),(3,4));
            let mut input = InputState::new();
            let mut rows = Vec::new();
            for t in -1i32..151 {
                if t >= 0 {
                    input.begin_frame();
                    if t == 0 || t == 80 { input.press(GbButton::A); }
                    if t == 2 || t == 82 { input.release(GbButton::A); }
                    g.update(&input);
                }
                let mut fb = FrameBuffer::new(dotzuki_engine::render_config::RenderConfig::new(160,144), pokered_renderer::Rgba::WHITE);
                g.draw(&mut fb);
                fb.save_png(&dir.join(format!("frame-{:04}.png",t+1))).unwrap();
                rows.push(serde_json::json!({"t":t,"input_bits":input.raw_current(),"screen":format!("{:?}",g.state.screen),
                    "overworld":pokered_core::snapshot::OverworldSnapshot::capture(&g.overworld)}));
                if t == 120 { assert!(g.overworld.pending_choice.is_some(),"choice must be open at same hardware frame"); }
            }
            std::fs::write(dir.join("frames.json"),serde_json::to_string_pretty(&rows).unwrap()).unwrap();
        }).unwrap().join().unwrap();
    }
}
