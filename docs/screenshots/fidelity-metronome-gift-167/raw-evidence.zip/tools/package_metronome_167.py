from pathlib import Path
import hashlib,json,re,shutil,zipfile
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';base=root/'.task-tmp/fidelity-93-master-before';out=w/'docs/screenshots/fidelity-metronome-gift-167';ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());gba=load(r/'audit-167-gba-provenance-a1.json');assert len(gba['sources'])==40 and all(h(w/f)==sha for f,sha in gba['sources'].items())
tests={}
for pkg,count,ignored in [('core',2741,0),('data',262,0),('app',213,31),('agent',54,0)]:
 text=(r/f'audit-167-{pkg}-tests-a1.log').read_text();assert f'test result: ok. {count} passed; 0 failed; {ignored} ignored;' in text;tests[pkg]={'passed':count,'ignored':ignored}
audit=load(r/'audit-167-reward-flow-audit.json');audit['cases'][0]['status']='Migrated and actual native success/full-bag/repeat/sound/snapshot/outer-confirmation test PASS. Source-only original evidence; no original emulator recording for this NPC.'
(r/'audit-167-reward-flow-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');shutil.copy2(r/'audit-167-reward-flow-audit.json',out/'remaining-gift-source-audit.json')
for src,dest in [('audit-167-gba-provenance-a1.json','gba-provenance.json'),('audit-167-gba-result-a1.json','gba-result.json'),('audit-167-gba-compare-a1.log','gba-compare.log')]:shutil.copy2(r/src,out/dest)
entries={}
for side in ['master31','after-a1']:
 for trial in [1,2]:
  d=r/f'audit-167-cue-{side}-metronome-{trial}'
  for f in d.iterdir():entries['raw/'+str(f.relative_to(r))]=f
  f=r/f'audit-167-cue-{side}-metronome-{trial}.log';entries['logs/'+f.name]=f
for f in gba['sources']:entries['native-source/'+f]=w/f
entries['native-source/crates/pokered-agent/src/semantics/extract.rs']=w/'crates/pokered-agent/src/semantics/extract.rs';entries['master-helper/game.rs']=base/'crates/pokered-app/src/game.rs'
for name in ['audit-167-build-a1.log','audit-167-master31-build-a1.log','audit-167-metronome-a1.log','audit-167-core-tests-a1.log','audit-167-data-tests-a1.log','audit-167-app-tests-a1.log','audit-167-agent-tests-a1.log','audit-167-gba-build-a1.log','audit-167-gba-record-a1.log','audit-167-gba-timer-a1.log','audit-167-gba-compare-a1.log','audit-167-gba-provenance-a1.json','audit-167-gba-result-a1.json','audit-167-cue-summary.json','audit-167-reward-flow-audit.json']:
 entries['evidence/'+name]=r/name
for case in audit['cases']:
 for prefix in ['scripts','text']:
  f=ref/prefix/(case['map']+'.asm');assert f.exists();entries['original-source/'+str(f.relative_to(ref))]=f
for name in ['data/text/text_1.asm','engine/events/oaks_aide.asm','home/text.asm','home/text_script.asm','home/joypad2.asm','home/window.asm','macros/scripts/text.asm','data/maps/objects/CinnabarLabMetronomeRoom.asm']:
 entries['original-source/'+name]=ref/name
entries['tools/package_metronome_167.py']=Path(__file__);entries['tools/cargo.sh']=r/'cargo.sh';entries['tools/run_receipt_cues_166.py']=r/'stats-59-tools/run_receipt_cues_166.py'
manifest={k:h(p) for k,p in entries.items()};zpath=out/'raw-evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for k,p in sorted(entries.items()):z.write(p,k)
 z.writestr('SHA256.json',json.dumps(manifest,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(zpath) as z:assert all(hashlib.sha256(z.read(k)).hexdigest()==sha for k,sha in manifest.items())
assert zpath.stat().st_size<95*1024*1024
v={'parent':'f049295415fb3f75af2a66fa4e2a7fe720e9d73f','base':'31b1eda3112514d6bc803af559ec7f7c9e20374f','tests':tests,'native_feature_scope':'default features for pokered-core/data/app/agent; this app test binary excludes debug-server-only tests, unlike batch166 feature-union binary. CI remains an independent exact-head requirement.','sources':gba['sources'],'cue_summary':load(r/'audit-167-cue-summary.json'),'archive':{'bytes':zpath.stat().st_size,'entries':len(entries),'sha256':h(zpath)},'gba_metrics':31,'original_evidence':'ASM caller, far texts, and shared text routines only; no new original-emulator recording or absolute frame/pixel/audio parity claim.','limitations':['Remaining eleven audited native gift handlers still pending migration and actual reproduction.','Existing PR draft gates including full text initialization/closure, sprite work and final m01..49/independent SAVE-CONTINUE remain.']}
(out/'verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(out/'README.md').write_text('''# TM35 gift session (batch 167)

CinnabarLabMetronomeRoom scientist 1 now keeps the entire reward interaction in its inner text session: introductory PARA, PROMPT acknowledgement before GiveItem, full GetItem1 fanfare before EVENT_GOT_TM35, then an outer fresh A/B acknowledgement. Holding A keeps the final window until release. Full bags preserve the bag and flag and produce no receipt/fanfare; repeat talks show the METRONOME explanation without another gift. Existing dialogue wording is preserved.

Original evidence is source-only: scripts/CinnabarLabMetronomeRoom.asm, text/CinnabarLabMetronomeRoom.asm, and home/text.asm. This batch adds no original-emulator timing claim.

## Before / after

Both fixtures use Bulbasaur, English, player (7,3) below authored scientist (7,2), actual Up/A interaction, PCM audio, and stationary NPC homes. Before is production master 31b1eda (only cfg(test) helpers added); after is this PR. Each side is recorded twice with all PNGs, initial snapshots, selected per-frame state, audio channels, and input bits byte-identical. Independent interaction prefixes reach the first reward SoundStarted cue; the following 261 input bits are identical. Screens show cue-relative HW150: before absolute frame397, after absolute frame396. The difference demonstrates master auto-dismissal versus the retained receipt/fresh outer confirmation. It does not assert absolute prefix/init/close timing equality.

![前](https://raw.githubusercontent.com/liuyanghejerry/open-pokered/fix/fidelity-overworld-cadence-91/docs/screenshots/fidelity-metronome-gift-167/metronome-before.png)

![后](https://raw.githubusercontent.com/liuyanghejerry/open-pokered/fix/fidelity-overworld-cadence-91/docs/screenshots/fidelity-metronome-gift-167/metronome-after.png)

## Validation and remaining audit

Default-feature suites: core2741, data262, app213 (31 ignored), agent54; all passed. The new actual NPC regression covers intro gating, bag-full and repeat behavior, exact independent PCM jingle duration, B/Down during sound, JSON snapshot restore during sound without replay, source flag timing, idle retained receipt, and A-hold/release closure. This app binary does not include debug-server-only cases; full CI remains required. Forty copied source SHA256s match the GBA perf checkout; all 31 metrics pass the unchanged original baseline budget.

raw-evidence.zip contains the four complete native recordings, source files, original source audit files, build/test/GBA logs and SHA256 manifest. See verification.json for archive checksum and cue-summary.json for frame-level details. Selected per-frame state is not a full runtime snapshot per frame.

remaining-gift-source-audit.json records caller and far-text flow for all twelve remaining candidates. Only TM35 is migrated in this batch. Bill requires TX_PROMPT_BUTTON without ProtectedDelay3; Copycat additionally sets outer-skip-wait and delays doll removal/flag until explicit no-arrow inner WAIT_BUTTON. Shared aides print the success promise and wait before GiveItem even when the bag is full. These eleven migrations, previous PR draft gates, and final mainline/SAVE-CONTINUE checks remain open.
''')
print(zpath.stat().st_size,h(zpath),len(entries))
