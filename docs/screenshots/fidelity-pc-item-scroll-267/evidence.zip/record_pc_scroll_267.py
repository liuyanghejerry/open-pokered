from pathlib import Path
import sys,os,json,socket,subprocess,hashlib
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-258-pc-item-scroll-checkout';sys.path.insert(0,str(w/'scripts'));from debug_drive import DebugClient
kind=sys.argv[1];assert kind=='native';binary=r/('audit-251-boundaries-cli-immutable' if kind=='master' else 'audit-267-scroll-cli-immutable')/'pokered-app';manifest=json.loads((binary.parent/'manifest.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['binary'];snapshot=r/'audit-255-native-three-pc-items-private-snapshot.json'
for case in ['down','return']:
 for repeat in [1,2]:
  out=r/f'audit-267-{kind}-scroll-{case}-{repeat}';out.mkdir(exist_ok=False)
  with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
  log=(r/(out.name+'.log')).open('w');p=subprocess.Popen([str(binary),'--scripts-dir',str(w/'crates/pokered-data/maps'),'run','--headless','--debug-port',str(port),'--speed','0','--skip-intro','--no-audio','--seed','42','--save',str(out/'owned.sav'),'--snapshot',str(snapshot),'--lang','en'],cwd=w,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib'),stdout=log,stderr=subprocess.STDOUT);d=None
  try:
   d=DebugClient(port=port)
   def drive(keys):q=d.cmd(cmd='press_timeline',buttons=keys,advance=True);assert q.get('ok'),q
   q=d.cmd(cmd='warp',map='ViridianPokecenter',x=13,y=4);assert q.get('ok');drive([None]*120+['up']*20+[None]*20+['a']*20+[None]*20)
   for _ in range(500):
    if d.state().get('pc_phase')=='MainMenu':break
    drive(['a',None])
   assert d.state().get('pc_phase')=='MainMenu';drive(['down',None,'a',None]);last=None
   for _ in range(500):
    if d.state().get('pc_phase')=='ItemQuestion':break
    key='a' if last is None else None;drive([key]);last=key
   assert d.state().get('pc_phase')=='ItemQuestion';drive([None]*80+['a']+[None]*3);assert d.state().get('pc_phase')=='ItemList';rows=[];end=190 if case=='down' else 220
   for t in range(end+1):
    key='down' if any(70+n*24<=t<72+n*24 for n in range(3)) else None
    if case=='return' and any(150+n*24<=t<152+n*24 for n in range(2)):key='up'
    if t:drive([key])
    state=d.state();assert not (out/'owned.sav').exists();q=d.cmd(cmd='capture_frame',path=str(out/f'frame-{t:03}.png')) if t in [0,20,70,71,94,95,118,119,150,151,174,175,190,220] else {'ok':True};assert q.get('ok');rows.append({'t':t,'input':key,'state':state,'bag':d.cmd(cmd='get_bag'),'owned_save_exists':False})
   assert d.state()['pc_phase']=='ItemList';assert all(x['bag']==rows[0]['bag'] for x in rows)
   if case=='return':
    equals_first_down=(out/'frame-220.png').read_bytes()==(out/'frame-070.png').read_bytes();assert equals_first_down==(kind=='master')
   (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n')
  finally:
   if d:d.close()
   p.terminate()
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   log.close()
  if repeat==2:
   old=r/f'audit-267-{kind}-scroll-{case}-1';files=sorted(q.name for q in out.iterdir() if q.suffix in ['.png','.json']);assert all((out/q).read_bytes()==(old/q).read_bytes() for q in files)
 print(kind,case,'two repeats byte exact',flush=True)
