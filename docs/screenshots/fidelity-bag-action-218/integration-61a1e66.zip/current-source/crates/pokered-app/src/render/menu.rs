use crate::alloc_prelude::*;
use pokered_core::bag_screen::{BagPhase, BagScreenState};
use pokered_core::game_state::Lang;
use pokered_core::items::{BuyMenuState, BuyResult, MartPhase, MartState, SellMenuState, SellResult,
};
use pokered_core::main_menu::MainMenuState;
use pokered_core::options_menu::OptionsMenuState;
use pokered_core::party_screen::{PartyScreenPhase, PartyScreenState};
use pokered_core::save_menu::{SaveMenuState, YesNoChoice};
use pokered_core::start_menu::StartMenuState;
use pokered_core::stats_screen::{StatsPage, StatsScreenState};
use pokered_data::impl_traits::PokemonRenderData;
use pokered_data::lang_data;
use pokered_data::mon_party_icons::{icon_for_species, IconKind};
use pokered_data::ui_layout::schema::{BAG_DEFAULT_LAYOUT, MAIN_DEFAULT_LAYOUT, MART_CONFIRM_LAYOUT, MART_MAIN_MENU_LAYOUT, MART_QUANTITY_LAYOUT, MART_RESULT_DIALOG_LAYOUT, OPTIONS_DEFAULT_LAYOUT, PARTY_DEFAULT_LAYOUT, PARTY_ENTRY_LAYOUT, SAVE_ASK_PROMPT_LAYOUT, SAVE_DEFAULT_LAYOUT, START_DEFAULT_LAYOUT, STATS_PAGE1_LAYOUT, STATS_PAGE2_LAYOUT, };
use pokered_renderer::mon_icon::{draw_mon_icon, icon_y_offset, load_mon_icon_tiles, party_icon_frame, IconFrame};
use pokered_renderer::palette::GRAYSCALE_SPRITE_PALETTE;
use pokered_renderer::party_hp_bar::draw_party_hp_bar;
use pokered_renderer::resource::ResourceManager;
use pokered_renderer::{FrameBuffer, TILE_SIZE};
use pokered_ui::backends::FrameBufferPainter;
use pokered_ui::{menus, InkColor, Rgba, Painter, TilePos, TileRect, Ui};

use super::{blit_front_pic, species_to_sprite_name};

pub fn draw_main_menu(state: &MainMenuState, fb: &mut FrameBuffer, lang: Lang) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    let mut ui = Ui::new(&mut painter);
    menus::main::draw(state, &MAIN_DEFAULT_LAYOUT, &mut ui, lang);
}

/// Repaint only the changed cursor cells of an already-rendered title menu.
pub fn redraw_main_menu_cursor(
    previous_cursor: usize,
    current_cursor: usize,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    menus::main::redraw_cursor(previous_cursor, current_cursor, &mut painter, lang);
}

pub fn draw_start_menu(state: &StartMenuState, player_name: &str, fb: &mut FrameBuffer, lang: Lang) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    let mut ui = Ui::new(&mut painter);
    menus::start::draw(state, player_name, &START_DEFAULT_LAYOUT, &mut ui, lang);
}

/// Repaint only the changed cursor cells of an already-rendered START menu.
pub fn redraw_start_menu_cursor(
    item_count: usize,
    previous_cursor: usize,
    current_cursor: usize,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    menus::start::redraw_cursor(
        item_count,
        previous_cursor,
        current_cursor,
        &START_DEFAULT_LAYOUT,
        &mut painter,
    );
}

pub fn draw_options_menu(state: &OptionsMenuState, fb: &mut FrameBuffer, lang: Lang) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    let mut ui = Ui::new(&mut painter);
    menus::options::draw(state, &OPTIONS_DEFAULT_LAYOUT, &mut ui, lang);
}

/// Return the absolute tile position of the options screen's visible cursor.
pub fn options_menu_cursor_position(state: &OptionsMenuState, lang: Lang) -> (u32, u32) {
    let pos = menus::options::cursor_spec(state, lang).0;
    (pos.tx, pos.ty)
}

pub fn options_menu_cursor_spec(state: &OptionsMenuState, lang: Lang) -> (u32, u32, char) {
    let (pos, glyph) = menus::options::cursor_spec(state, lang);
    (pos.tx, pos.ty, glyph)
}

/// Repaint only the changed cursor cells of an already-rendered options screen.
pub fn redraw_options_menu_cursor(
    previous: (u32, u32, char),
    current: (u32, u32, char),
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    menus::options::redraw_cursor(
        (pokered_ui::TilePos::new(previous.0, previous.1), previous.2),
        (pokered_ui::TilePos::new(current.0, current.1), current.2),
        &mut painter,
        lang,
    );
}

pub fn draw_save_menu(state: &SaveMenuState, fb: &mut FrameBuffer, lang: Lang) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    let mut ui = Ui::new(&mut painter);
    menus::save::draw(state, &SAVE_DEFAULT_LAYOUT, &SAVE_ASK_PROMPT_LAYOUT, &mut ui, lang);
}

/// Repaint only the changed YES/NO cursor cells of an already-rendered save prompt.
pub fn redraw_save_menu_cursor(
    previous: YesNoChoice,
    current: YesNoChoice,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    menus::save::redraw_cursor(previous, current, &mut painter);
}

/// Draws the party screen with real Pokémon icons composited on top of the
/// text UI.
///
/// `resources` is optional so this function still renders a usable screen
/// in headless tests / contexts where no `ResourceManager` is available.
/// In that case icon space is left blank.
///
/// `frame_counter` is the free-running game-loop frame index, used to
/// animate the *selected* mon's icon between Frame1 and Frame2 (matching
/// the original game's `AnimatePartyMon` behavior).
pub fn draw_party_screen(
    state: &PartyScreenState,
    resources: Option<&mut ResourceManager>,
    frame_counter: u64,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    {
        let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
        let mut ui = Ui::new(&mut painter);
        menus::party::draw_entries(state, &PARTY_DEFAULT_LAYOUT, &mut ui, lang);
    }

    if let Some(rm) = resources {
        let cursor = state.cursor();
        const ICON_X_PX: u32 = 8;
        let layout = &pokered_data::ui_layout::schema::PARTY_ENTRY_LAYOUT;
        let row_height = layout.cursors[0].row_step * TILE_SIZE;
        let hp_bar = layout
            .dynamic_labels
            .iter()
            .find(|(key, _)| *key == "hp_bar")
            .map(|(_, label)| label)
            .expect("party layout has an HP bar anchor");

        for (i, pokemon) in state.party().iter().enumerate() {
            let kind = icon_for_species(pokemon.species);
            let frame = if i == cursor {
                party_icon_frame(frame_counter, pokemon.hp, pokemon.max_hp)
            } else {
                IconFrame::Frame1
            };
            match load_mon_icon_tiles(rm, kind, frame) {
                Ok(tiles) => {
                    let y = (i as u32) * row_height+ icon_y_offset(kind, frame);
                    draw_mon_icon(fb, tiles, ICON_X_PX, y, &GRAYSCALE_SPRITE_PALETTE);
                }
                Err(e) => {
                    log::warn!(
                        "party screen: failed to load icon for {:?}: {}",
                        pokemon.species,
                        e
                    );
                }
            }

            let hp_bar_y = (i as u32) * row_height + hp_bar.ty * TILE_SIZE + 4;
            if let Err(e) = draw_party_hp_bar(
                fb,
                rm,
                hp_bar.tx * TILE_SIZE,
                hp_bar_y,
                pokemon.hp,
                pokemon.max_hp,
            ) {
                log::warn!(
                    "party screen: failed to draw HP bar for {:?}: {}",
                    pokemon.species,
                    e
                );
            }
        }
    }
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    menus::party::draw_overlay(state, &mut Ui::new(&mut painter), lang);
}
fn selected_party_icon_frame(state: &PartyScreenState, counter: u64) -> IconFrame {
    state
        .party_member(state.cursor())
        .map_or(IconFrame::Frame1, |pokemon| {
            party_icon_frame(counter, pokemon.hp, pokemon.max_hp)
        })
}


fn clear_top_level_party_icon_at(party_index: usize, fb: &mut FrameBuffer) {
    const ICON_X_PX: u32 = 8;
    const ICON_SIZE_PX: u32 = 16;
    let row_height = PARTY_ENTRY_LAYOUT.cursors[0].row_step * TILE_SIZE;
    let icon_y = party_index as u32 * row_height;
    fb.fill_rect(
        ICON_X_PX,
        icon_y,
        ICON_SIZE_PX,
        ICON_SIZE_PX + 1,
        pokered_renderer::Rgba::WHITE,
    );
}

fn draw_top_level_party_icon_at(
    state: &PartyScreenState,
    party_index: usize,
    frame: IconFrame,
    resources: Option<&mut ResourceManager>,
    fb: &mut FrameBuffer,
) {
    const ICON_X_PX: u32 = 8;
    let row_height = PARTY_ENTRY_LAYOUT.cursors[0].row_step * TILE_SIZE;
    let icon_y = party_index as u32 * row_height;
    let (Some(pokemon), Some(rm)) = (state.party_member(party_index), resources) else {
        return;
    };
    let kind = icon_for_species(pokemon.species);
    if let Ok(tiles) = load_mon_icon_tiles(rm, kind, frame) {
        draw_mon_icon(
            fb,
            tiles,
            ICON_X_PX,
            icon_y+ icon_y_offset(kind, frame),
            &GRAYSCALE_SPRITE_PALETTE,
        );
    }
}

/// Repaint the selected icon when its 16-frame animation phase changes.
pub fn redraw_top_level_party_icon(
    state: &PartyScreenState,
    frame_counter: u64,
    resources: Option<&mut ResourceManager>,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    clear_top_level_party_icon_at(state.cursor(), fb);
    draw_top_level_party_icon_at(
        state,
        state.cursor(),
        selected_party_icon_frame(state, frame_counter),
        resources,
        fb,
    );

    // The switch-target hint can cover the bottom party row. The complete
    // renderer draws overlays after icons, so restore that ordering here too.
    if matches!(state.phase(), PartyScreenPhase::SwitchTarget { .. }) {
        let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
        menus::party::draw_overlay(state, &mut Ui::new(&mut painter), lang);
    }
}

/// Repaint the two affected list rows when the selected party member moves.
pub fn redraw_top_level_party_selection(
    state: &PartyScreenState,
    previous_cursor: usize,
    frame_counter: u64,
    mut resources: Option<&mut ResourceManager>,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let current_cursor = state.cursor();
    let cursor_defs = PARTY_ENTRY_LAYOUT.cursors.as_ref();
    let cursor_position = |row: usize| {
        TilePos::new(
            cursor_defs[0].tx,
            cursor_defs[0].base_ty + row as u32 * cursor_defs[0].row_step,
        )
    };
    let previous_position = cursor_position(previous_cursor);
    let current_position = cursor_position(current_cursor);
    let source_index = match state.phase() {
        PartyScreenPhase::SwitchTarget { source_index } => Some(source_index),
        _ => None,
    };

    clear_top_level_party_icon_at(previous_cursor, fb);
    clear_top_level_party_icon_at(current_cursor, fb);
    {
        let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
        for position in [previous_position, current_position] {
            painter.draw_pixel_rect(
                position.tx * TILE_SIZE,
                position.ty * TILE_SIZE,
                TILE_SIZE,
                TILE_SIZE + 1,
                pokered_ui::Rgba::INK_WHITE,
            );
        }
        if source_index == Some(previous_cursor) && previous_cursor != current_cursor {
            let source = &cursor_defs[1];
            painter.draw_glyph(
                previous_position,
                source.glyph,
                pokered_ui::Rgba::INK_DARK_GRAY,
            );
        }
        let selected = &cursor_defs[0];
        painter.draw_glyph(
            current_position,
            selected.glyph,
            pokered_ui::Rgba::INK_BLACK,
        );
    }

    draw_top_level_party_icon_at(
        state,
        previous_cursor,
        IconFrame::Frame1,
        resources.as_deref_mut(),
        fb,
    );
    draw_top_level_party_icon_at(
        state,
        current_cursor,
        selected_party_icon_frame(state, frame_counter),
        resources,
        fb,
    );

    if matches!(state.phase(), PartyScreenPhase::SwitchTarget { .. }) {
        let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
        menus::party::draw_overlay(state, &mut Ui::new(&mut painter), lang);
    }
}

/// Repaint only the changed cursor cells of an action/choose-move overlay.
pub fn redraw_top_level_party_overlay_cursor(
    state: &PartyScreenState,
    previous_cursor: u8,
    current_cursor: u8,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let Some(previous) = menus::party::overlay_cursor_position(state, previous_cursor, lang) else {
        return;
    };
    let Some(current) = menus::party::overlay_cursor_position(state, current_cursor, lang) else {
        return;
    };
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    painter.draw_pixel_rect(
        previous.tx * TILE_SIZE,
        previous.ty * TILE_SIZE,
        TILE_SIZE,
        TILE_SIZE + 1,
        pokered_ui::Rgba::INK_WHITE,
    );
    painter.draw_glyph(current, '▶', pokered_ui::Rgba::INK_BLACK);
}

/// Draw the stats/details screen. Renders the text UI (name, level, HP
/// bar + numbers, status, stats box, types, moves, EXP) via the
/// pokered-ui stats renderer, then composites the mon front sprite (page 1)
/// on top when `resources` is available.
pub fn draw_stats_screen(
    state: &StatsScreenState,
    resources: Option<&mut ResourceManager>,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    if state.entry_frame().is_some_and(|f| (1..18).contains(&f)) {
        fb.clear(Rgba::WHITE);
        return;
    }
    {
        let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
        let mut ui = Ui::new(&mut painter);
        menus::stats::draw(state, &STATS_PAGE1_LAYOUT, &STATS_PAGE2_LAYOUT, &mut ui, lang, &PokemonRenderData::new(lang == Lang::Zh));
    }

    if let Some(frame) = state.entry_frame() {
        if frame == 18 {
            for y in 0..24 { for x in 0..160 { fb.set_pixel(x,y,Rgba::WHITE); } }
        }
        if frame <= state.entry_cry_frame() { return; }
    }
    let Some(rm) = resources else {
        return;
    };

    let pokemon = state.pokemon();

    let species_display = format!("{}", pokemon.species);
    let sprite_name = species_to_sprite_name(&species_display);
    let drew_front = if let Ok(cached) = rm.load_pokemon_front(&sprite_name) {
        // StatusScreen uses LoadFlippedFrontSpriteByMonIndex; StatusScreen2
        // retains that same 7x7 buffer, including its bottom/side padding.
        blit_front_pic(fb, cached, 8, 0, true);
        true
    } else {
        false
    };

    if !drew_front {
        let kind = icon_for_species(pokemon.species);
        if let Ok(tiles) = load_mon_icon_tiles(rm, kind, IconFrame::Frame1) {
            draw_mon_icon(fb, tiles, 8, 0, &GRAYSCALE_SPRITE_PALETTE);
        }
    }
    let parts = state.entry_picture_parts();
    if parts != 3 {
        for y in 0..56 {
            let visible = if y < 48 { parts & 1 != 0 } else { parts & 2 != 0 };
            if !visible { for x in 8..64 { fb.set_pixel(x,y,Rgba::WHITE); } }
        }
    }

}

pub(super) fn mart_list_scroll(cursor: usize, count: usize, lang: Lang) -> usize {
    let list_visible = if lang == Lang::Zh { 3 } else { 4 };
    cursor.saturating_sub(list_visible - 1).min(count.saturating_sub(list_visible))
}

pub(super) fn mart_main_cursor_position(index: usize) -> (u32, u32) {
    let rect = MART_MAIN_MENU_LAYOUT.menu_box.rect;
    let cursor = &MART_MAIN_MENU_LAYOUT.cursor;
    (rect.tx + 1 + cursor.tx, rect.ty + 1 + cursor.base_ty + index as u32 * cursor.row_step)
}

pub(super) fn mart_list_cursor_position(index: usize, scroll: usize, lang: Lang, sell: bool) -> (u32, u32) {
    use pokered_data::ui_layout::schema::{MART_BUY_ITEMS_WITH_MONEY_LAYOUT, MART_SELL_ITEMS_WITH_MONEY_LAYOUT};
    let (rect, cursor) = if sell {
        (MART_SELL_ITEMS_WITH_MONEY_LAYOUT.list_box.rect, &MART_SELL_ITEMS_WITH_MONEY_LAYOUT.cursor)
    } else {
        (MART_BUY_ITEMS_WITH_MONEY_LAYOUT.list_box.rect, &MART_BUY_ITEMS_WITH_MONEY_LAYOUT.cursor)
    };
    let extra_row = if lang == Lang::Zh { 1 } else { 0 };
    let row_step = if lang == Lang::Zh { 3 } else { cursor.row_step };
    (rect.tx + 1 + cursor.tx, rect.ty + extra_row + 1 + cursor.base_ty + (index - scroll) as u32 * row_step)
}

pub fn draw_mart(state: &MartState, player_money: u32, bag_items: &[(pokered_data::items::ItemId, u32)], fb: &mut FrameBuffer, lang: Lang) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    let mut ui = Ui::new(&mut painter);
    // Names and prices occupy separate rows: four English or three Chinese
    // entries fit. RenderSession uses these same viewport/cursor helpers.
    match &state.phase {
        MartPhase::MainMenu { cursor } => {
            menus::mart::draw_main_with_money(cursor.position(), player_money, &MART_MAIN_MENU_LAYOUT, &mut ui, lang);
        }
        MartPhase::Buy(bs) => match bs {
            BuyMenuState::SelectItem { cursor } => {
                menus::mart::draw_buy_items_with_money(
                    state.inventory.items(),
                    *cursor,
                    mart_list_scroll(*cursor, state.inventory.items().len(), lang),
                    player_money,
                    &pokered_data::ui_layout::schema::MART_BUY_ITEMS_WITH_MONEY_LAYOUT,
                    &mut ui,
                    lang,
                    &PokemonRenderData::new(lang == Lang::Zh),
                );
            }
            BuyMenuState::Quantity { item_index, quantity } => {
                if let Some(item_id) = state.inventory.get(*item_index) {
                    if let Some(data) = pokered_data::item_data::get_item_data(item_id) {
                        let total = data.price as u32 * *quantity as u32;
                        let item_name = if lang == Lang::Zh {
                            pokered_data::lang_data::item_name(item_id, true)
                        } else {
                            data.name
                        };
                        menus::mart::draw_quantity(item_name, *quantity, data.price as u32, total, player_money, &MART_QUANTITY_LAYOUT, lang, &mut ui);
                    }
                }
            }
            BuyMenuState::Confirm { item_index, quantity, selected } => {
                if let Some(item_id) = state.inventory.get(*item_index) {
                    if let Some(data) = pokered_data::item_data::get_item_data(item_id) {
                        let total = data.price as u32 * *quantity as u32;
                        let item_name = if lang == Lang::Zh {
                            pokered_data::lang_data::item_name(item_id, true)
                        } else {
                            data.name
                        };
                        let msg = if lang == Lang::Zh {
                            format!("{}？\n总共${}。\n可以吗？", item_name, total)
                        } else {
                            format!("{}?\nThat will be\n${}. OK?", item_name, total)
                        };
                        let choice = match selected {
                            pokered_core::items::ConfirmChoice::Yes => menus::mart::ConfirmChoice::Yes,
                            pokered_core::items::ConfirmChoice::No => menus::mart::ConfirmChoice::No,
                        };
                        menus::mart::draw_confirm(lang, &msg, choice, &MART_CONFIRM_LAYOUT, &mut ui);
                    }
                }
            }
            BuyMenuState::Result { dialogue, .. } => {
                let lines = buy_result_lines(dialogue, lang == Lang::Zh);
                menus::mart::draw_result_dialog(&lines, &MART_RESULT_DIALOG_LAYOUT, &mut ui);
            }
        },
        MartPhase::Sell(ss) => match ss {
            SellMenuState::SelectItem { cursor } => {
                // CANCEL is the entry after the last bag item.
                let entries = bag_items.len() + 1;
                menus::mart::draw_sell_items_with_money(
                    bag_items,
                    *cursor,
                    mart_list_scroll(*cursor, entries, lang),
                    player_money,
                    &pokered_data::ui_layout::schema::MART_SELL_ITEMS_WITH_MONEY_LAYOUT,
                    &mut ui,
                    lang,
                    &PokemonRenderData::new(lang == Lang::Zh),
                );
            }
            SellMenuState::Quantity { item_index, quantity, max_quantity } => {
                if let Some((item_id, _owned)) = bag_items.get(*item_index) {
                    if let Some(data) = pokered_data::item_data::get_item_data(*item_id) {
                        let price = (data.price as u32) / 2;
                        let total = price * *quantity as u32;
                        let item_name = if lang == Lang::Zh {
                            pokered_data::lang_data::item_name(*item_id, true)
                        } else {
                            data.name
                        };
                        menus::mart::draw_quantity(item_name, *quantity, price, total, player_money, &MART_QUANTITY_LAYOUT, lang, &mut ui);
                    }
                }
                let _ = max_quantity;
            }
            SellMenuState::Confirm { item_index, quantity, max_quantity, selected } => {
                if let Some((item_id, _owned)) = bag_items.get(*item_index) {
                    if let Some(data) = pokered_data::item_data::get_item_data(*item_id) {
                        let price = (data.price as u32) / 2;
                        let total = price * *quantity as u32;
                        let msg = if lang == Lang::Zh {
                            format!("我可以支付\n${}。\n可以吗？", total)
                        } else {
                            format!("I can pay you\n${} for that.", total)
                        };
                        let choice = match selected {
                            pokered_core::items::ConfirmChoice::Yes => menus::mart::ConfirmChoice::Yes,
                            pokered_core::items::ConfirmChoice::No => menus::mart::ConfirmChoice::No,
                        };
                        menus::mart::draw_confirm(lang, &msg, choice, &MART_CONFIRM_LAYOUT, &mut ui);
                    }
                }
                let _ = max_quantity;
            }
            SellMenuState::Result { dialogue, .. } => {
                let lines = sell_result_lines(dialogue, lang == Lang::Zh);
                menus::mart::draw_result_dialog(&lines, &MART_RESULT_DIALOG_LAYOUT, &mut ui);
            }
        },
        MartPhase::Exiting => {}
    }
}

/// Repaint only the changed `▶` cells of an already-rendered mart screen.
pub fn redraw_mart_cursor(
    previous: (u32, u32),
    current: (u32, u32),
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    painter.draw_pixel_rect(previous.0 * 8, previous.1 * 8, 8, 9, pokered_ui::Rgba::INK_WHITE);
    painter.draw_glyph(
        TilePos::new(current.0, current.1),
        '▶',
        pokered_ui::Rgba::INK_BLACK,
    );
}

fn buy_result_lines(result: &BuyResult, is_zh: bool) -> Vec<&'static str> {
    if is_zh {
        match result {
            BuyResult::Success { .. } => vec!["谢谢惠顾！", "欢迎再来！"],
            BuyResult::NotEnoughMoney => vec!["你的钱", "不够！"],
            BuyResult::BagFull => vec!["你的包包满了！"],
            BuyResult::InvalidItem => vec!["那个道具", "不存在！"],
        }
    } else {
        match result {
            BuyResult::Success { .. } => vec!["Thank you!", "Come again!"],
            BuyResult::NotEnoughMoney => vec!["You don't have", "enough money!"],
            BuyResult::BagFull => vec!["Your bag is full!"],
            BuyResult::InvalidItem => vec!["That item doesn't", "exist!"],
        }
    }
}

fn sell_result_lines(result: &SellResult, is_zh: bool) -> Vec<&'static str> {
    if is_zh {
        match result {
            SellResult::Success { .. } => vec!["谢谢惠顾！", "欢迎再来！"],
            SellResult::Unsellable => vec!["我不能买", "那个道具。"],
            SellResult::NotInBag => vec!["你没有", "那个道具！"],
            SellResult::InvalidItem => vec!["那个道具", "不存在！"],
        }
    } else {
        match result {
            SellResult::Success { .. } => vec!["Thank you!", "Come again!"],
            SellResult::Unsellable => vec!["I can't buy", "that item."],
            SellResult::NotInBag => vec!["You don't have", "that item!"],
            SellResult::InvalidItem => vec!["That item doesn't", "exist!"],
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use pokered_core::bag_screen::{BagScreenInput, BagScreenState};
    use pokered_core::game_state::SaveFileSummary;
    use pokered_core::start_menu::{StartMenuInput, StartMenuState};
    use pokered_core::options_menu::{
        BattleAnimation, BattleStyle, GameOptions, OptionsMenuState, OptionsRow, TextSpeed,
    };
    use pokered_core::save_menu::{SavePhase, SaveScreenInfo};
    use pokered_core::party_screen::{PartyScreenInput, PartyScreenState};
    use pokered_core::pokemon::stats::create_pokemon;
    use pokered_data::items::ItemId;
    use pokered_data::species::Species;
    use pokered_renderer::resource::AssetRoot;
    use pokered_renderer::Rgba;

    fn assert_framebuffers_equal(actual: &FrameBuffer, expected: &FrameBuffer) {
        assert_eq!(actual.width(), expected.width());
        assert_eq!(actual.height(), expected.height());
        for y in 0..actual.height() {
            for x in 0..actual.width() {
                assert_eq!(
                    actual.get_pixel(x, y),
                    expected.get_pixel(x, y),
                    "framebuffer mismatch at ({x}, {y})",
                );
            }
        }
    }

    #[test]
    fn main_menu_cursor_repaint_matches_a_fresh_menu_for_every_transition() {
        let save = SaveFileSummary {
            player_name: b"RED".to_vec(),
            badges: 0,
            pokedex_owned: 0,
            play_time_hours: 0,
            play_time_minutes: 0,
            play_time_seconds: 0,
            player_id: 0,
        };
        for language in [Lang::En, Lang::Zh] {
            for save_summary in [None, Some(save.clone())] {
                let state = MainMenuState::new(save_summary);
                for previous_cursor in 0..state.item_count() {
                    for current_cursor in 0..state.item_count() {
                        if previous_cursor == current_cursor {
                            continue;
                        }
                        let mut previous = state.clone();
                        previous.cursor = previous_cursor;
                        let mut current = state.clone();
                        current.cursor = current_cursor;
                        let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);

                        let mut actual = FrameBuffer::new(config, Rgba::BLACK);
                        draw_main_menu(&previous, &mut actual, language);
                        redraw_main_menu_cursor(
                            previous_cursor,
                            current_cursor,
                            &mut actual,
                            language,
                        );

                        let mut expected = FrameBuffer::new(config, Rgba::BLACK);
                        draw_main_menu(&current, &mut expected, language);
                        assert_framebuffers_equal(&actual, &expected);
                    }
                }
            }
        }
    }

    #[test]
    fn start_menu_cursor_repaint_matches_a_fresh_menu_for_every_transition() {
        let input_down = StartMenuInput {
            up: false,
            down: true,
            a: false,
            b: false,
            start: false,
        };
        for language in [Lang::En, Lang::Zh] {
            for (has_pokedex, has_pokemon) in [(false, false), (true, true)] {
                let state = StartMenuState::new(has_pokedex, has_pokemon, false);
                for previous_cursor in 0..state.item_count() {
                    for current_cursor in 0..state.item_count() {
                        if previous_cursor == current_cursor {
                            continue;
                        }
                        let mut previous = state.clone();
                        for _ in 0..previous_cursor {
                            previous.update_frame(input_down);
                        }
                        let mut current = state.clone();
                        for _ in 0..current_cursor {
                            current.update_frame(input_down);
                        }
                        let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);

                        let mut actual = FrameBuffer::new(config, Rgba::BLACK);
                        draw_start_menu(&previous, "RED", &mut actual, language);
                        redraw_start_menu_cursor(
                            state.item_count(),
                            previous_cursor,
                            current_cursor,
                            &mut actual,
                            language,
                        );

                        let mut expected = FrameBuffer::new(config, Rgba::BLACK);
                        draw_start_menu(&current, "RED", &mut expected, language);
                        assert_framebuffers_equal(&actual, &expected);
                    }
                }
            }
        }
    }

    #[test]
    fn options_cursor_repaint_matches_a_fresh_menu_for_every_visible_transition() {
        let state = |row, text_speed, battle_animation, battle_style| {
            let mut state = OptionsMenuState::new(GameOptions {
                text_speed,
                battle_animation,
                battle_style,
            });
            state.row = row;
            state
        };
        let states = [
            state(
                OptionsRow::TextSpeed,
                TextSpeed::Fast,
                BattleAnimation::On,
                BattleStyle::Shift,
            ),
            state(
                OptionsRow::TextSpeed,
                TextSpeed::Medium,
                BattleAnimation::On,
                BattleStyle::Shift,
            ),
            state(
                OptionsRow::TextSpeed,
                TextSpeed::Slow,
                BattleAnimation::On,
                BattleStyle::Shift,
            ),
            state(
                OptionsRow::BattleAnimation,
                TextSpeed::Medium,
                BattleAnimation::On,
                BattleStyle::Shift,
            ),
            state(
                OptionsRow::BattleAnimation,
                TextSpeed::Medium,
                BattleAnimation::Off,
                BattleStyle::Shift,
            ),
            state(
                OptionsRow::BattleStyle,
                TextSpeed::Medium,
                BattleAnimation::On,
                BattleStyle::Shift,
            ),
            state(
                OptionsRow::BattleStyle,
                TextSpeed::Medium,
                BattleAnimation::On,
                BattleStyle::Set,
            ),
            state(
                OptionsRow::Cancel,
                TextSpeed::Medium,
                BattleAnimation::On,
                BattleStyle::Shift,
            ),
        ];
        let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);

        for language in [Lang::En, Lang::Zh] {
            for previous in &states {
                for current in &states {
                    let previous_spec = menus::options::cursor_spec(previous, language);
                    let current_spec = menus::options::cursor_spec(current, language);
                    let previous_pos = previous_spec.0;
                    let current_pos = current_spec.0;
                    if previous_pos == current_pos
                        || !menus::options::can_redraw_cursor(
                            previous.options,
                            previous.row,
                            current.options,
                            current.row,
                        )
                    {
                        continue;
                    }

                    let mut actual = FrameBuffer::new(config, Rgba::BLACK);
                    draw_options_menu(previous, &mut actual, language);
                    redraw_options_menu_cursor(
                        (previous_pos.tx, previous_pos.ty, previous_spec.1),
                        (current_pos.tx, current_pos.ty, current_spec.1),
                        &mut actual,
                        language,
                    );

                    let mut expected = FrameBuffer::new(config, Rgba::BLACK);
                    draw_options_menu(current, &mut expected, language);
                    assert_framebuffers_equal(&actual, &expected);
                }
            }
        }
    }

    #[test]
    fn save_cursor_repaint_matches_a_fresh_prompt_in_both_directions() {
        for language in [Lang::En, Lang::Zh] {
            for phase in [SavePhase::AskSave, SavePhase::ConfirmOverwrite] {
                for (previous, current) in [
                    (YesNoChoice::Yes, YesNoChoice::No),
                    (YesNoChoice::No, YesNoChoice::Yes),
                ] {
                    let make_state = |cursor| SaveMenuState {
                        phase: phase.clone(),
                        cursor,
                        info: SaveScreenInfo {
                            player_name: "RED".into(),
                            num_badges: 3,
                            pokedex_owned: 42,
                            play_time_hours: 12,
                            play_time_minutes: 34,
                        },
                        has_previous_save: false,
                        is_different_player: false,
                        sfx_event: pokered_core::save_menu::SaveSfxEvent::None,
                    };
                    let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);

                    let mut actual = FrameBuffer::new(config, Rgba::BLACK);
                    draw_save_menu(&make_state(previous), &mut actual, language);
                    redraw_save_menu_cursor(previous, current, &mut actual, language);

                    let mut expected = FrameBuffer::new(config, Rgba::BLACK);
                    draw_save_menu(&make_state(current), &mut expected, language);
                    assert_framebuffers_equal(&actual, &expected);
                }
            }
        }
    }

    fn top_level_party() -> PartyScreenState {
        PartyScreenState::new(vec![
            create_pokemon(Species::Bulbasaur, 20, [0xFF, 0xFF]).unwrap(),
            create_pokemon(Species::Charmander, 20, [0xFF, 0xFF]).unwrap(),
            create_pokemon(Species::Squirtle, 20, [0xFF, 0xFF]).unwrap(),
            create_pokemon(Species::Pikachu, 20, [0xFF, 0xFF]).unwrap(),
            create_pokemon(Species::Pidgey, 20, [0xFF, 0xFF]).unwrap(),
            create_pokemon(Species::Rattata, 20, [0xFF, 0xFF]).unwrap(),
        ])
    }

    fn party_input(up: bool, down: bool, a: bool) -> PartyScreenInput {
        PartyScreenInput {
            up,
            down,
            a,
            b: false,
        }
    }

    #[test]
    fn top_level_party_icon_repaint_matches_fresh_draws_in_browsing_and_switch_hint() {
        let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);
        let root = AssetRoot::auto_detect().expect("test graphics");
        let mut resources = ResourceManager::new(root);

        for language in [Lang::En, Lang::Zh] {
            let browsing = top_level_party();
            let mut actual = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&browsing, Some(&mut resources), 0, &mut actual, language);
            redraw_top_level_party_icon(
                &browsing,
                16,
                Some(&mut resources),
                &mut actual,
                language,
            );
            let mut expected = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&browsing, Some(&mut resources), 16, &mut expected, language);
            assert_framebuffers_equal(&actual, &expected);

            // Select the bottom row, then enter SWITCH so its icon overlaps
            // the hint overlay. Incremental animation must restore the hint.
            let mut switching = top_level_party();
            for _ in 0..5 {
                switching.update_frame(party_input(false, true, false));
            }
            switching.update_frame(party_input(false, false, true));
            switching.update_frame(party_input(false, true, false));
            switching.update_frame(party_input(false, false, true));
            assert!(matches!(
                switching.phase(),
                PartyScreenPhase::SwitchTarget { source_index: 5 }
            ));

            let mut actual = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&switching, Some(&mut resources), 0, &mut actual, language);
            redraw_top_level_party_icon(
                &switching,
                16,
                Some(&mut resources),
                &mut actual,
                language,
            );
            let mut expected = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&switching, Some(&mut resources), 16, &mut expected, language);
            assert_framebuffers_equal(&actual, &expected);
        }
    }

    #[test]
    fn top_level_party_selection_repaint_matches_fresh_draws() {
        let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);
        let root = AssetRoot::auto_detect().expect("test graphics");
        let mut resources = ResourceManager::new(root);

        for language in [Lang::En, Lang::Zh] {
            for previous_cursor in 0..6 {
                for down in [false, true] {
                    if (!down && previous_cursor == 0) || (down && previous_cursor == 5) {
                        continue;
                    }
                    let mut state = top_level_party();
                    for _ in 0..previous_cursor {
                        state.update_frame(party_input(false, true, false));
                    }
                    let mut actual = FrameBuffer::new(config, Rgba::BLACK);
                    draw_party_screen(&state, Some(&mut resources), 0, &mut actual, language);
                    state.update_frame(party_input(!down, down, false));
                    redraw_top_level_party_selection(
                        &state,
                        previous_cursor,
                        16,
                        Some(&mut resources),
                        &mut actual,
                        language,
                    );

                    let mut expected = FrameBuffer::new(config, Rgba::BLACK);
                    draw_party_screen(&state, Some(&mut resources), 16, &mut expected, language);
                    assert_framebuffers_equal(&actual, &expected);
                }
            }

            // In SWITCH mode the old source row changes from the selected
            // arrow to the diamond marker when the cursor leaves it.
            let mut switching = top_level_party();
            switching.update_frame(party_input(false, false, true));
            switching.update_frame(party_input(false, true, false));
            switching.update_frame(party_input(false, false, true));
            let mut actual = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&switching, Some(&mut resources), 0, &mut actual, language);
            switching.update_frame(party_input(false, true, false));
            redraw_top_level_party_selection(
                &switching,
                0,
                16,
                Some(&mut resources),
                &mut actual,
                language,
            );
            let mut expected = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&switching, Some(&mut resources), 16, &mut expected, language);
            assert_framebuffers_equal(&actual, &expected);
        }
    }

    #[test]
    fn top_level_party_overlay_cursor_repaint_matches_fresh_draws() {
        let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);
        let root = AssetRoot::auto_detect().expect("test graphics");
        let mut resources = ResourceManager::new(root);

        for language in [Lang::En, Lang::Zh] {
            let mut action = top_level_party();
            action.update_frame(party_input(false, false, true));
            let mut actual = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&action, Some(&mut resources), 0, &mut actual, language);
            action.update_frame(party_input(false, true, false));
            redraw_top_level_party_icon(
                &action,
                16,
                Some(&mut resources),
                &mut actual,
                language,
            );
            redraw_top_level_party_overlay_cursor(&action, 0, 1, &mut actual, language);
            let mut expected = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&action, Some(&mut resources), 16, &mut expected, language);
            assert_framebuffers_equal(&actual, &expected);

            let mut choose = PartyScreenState::new_for_move_choice(
                top_level_party().party().to_vec(),
                0,
            );
            let mut actual = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&choose, Some(&mut resources), 0, &mut actual, language);
            choose.update_frame(party_input(false, true, false));
            redraw_top_level_party_icon(
                &choose,
                16,
                Some(&mut resources),
                &mut actual,
                language,
            );
            redraw_top_level_party_overlay_cursor(&choose, 0, 1, &mut actual, language);
            let mut expected = FrameBuffer::new(config, Rgba::BLACK);
            draw_party_screen(&choose, Some(&mut resources), 16, &mut expected, language);
            assert_framebuffers_equal(&actual, &expected);
        }
    }

    #[test]
    fn bag_overlays_leave_clear_pixels_above_the_bottom_border() {
        for lang in [Lang::En, Lang::Zh] {
            let mut state = bag_at(0);
            state.update_frame(BagScreenInput {
                a: true,
                ..BagScreenInput::none()
            });
            let mut fb = FrameBuffer::new(
                dotzuki_engine::render_config::RenderConfig::new(160, 144),
                Rgba::WHITE,
            );
            draw_bag(&state, &mut fb, lang);
            for y in 136..138 {
                for x in 104..152 {
                    assert_eq!(
                        fb.get_pixel(x, y),
                        Some(Rgba::WHITE),
                        "action menu gutter ({x},{y})"
                    );
                }
            }
            // The longest English machine name stresses both width and row spacing.
            for machine in 0xc4..=0xfa {
                fb.clear(Rgba::WHITE);
                let mut painter = FrameBufferPainter::new(&mut fb).with_lang(lang);
                menus::bag::draw_machine_prompt(
                    ItemId::from_id(machine),
                    Some(1),
                    &mut Ui::new(&mut painter),
                    lang,
                );
                for y in 136..138 {
                    for x in 16..152 {
                        assert_eq!(
                            fb.get_pixel(x, y),
                            Some(Rgba::WHITE),
                            "machine {machine} gutter ({x},{y})"
                        );
                    }
                }
            }
        }
    }

    fn bag_at(cursor: usize) -> BagScreenState {
        let mut state = BagScreenState::new(vec![
            (ItemId::Potion, 5),
            (ItemId::Antidote, 2),
            (ItemId::PokeBall, 12),
            (ItemId::PokeFlute, 1),
            (ItemId::Bicycle, 1),
            (ItemId::Potion, 8),
            (ItemId::Antidote, 4),
            (ItemId::PokeBall, 20),
        ]);
        for _ in 0..cursor {
            state.update_frame(BagScreenInput {
                down: true,
                ..BagScreenInput::none()
            });
        }
        state
    }

    #[test]
    fn top_level_bag_list_cursor_repaint_matches_a_fresh_bag() {
        for language in [Lang::En, Lang::Zh] {
            for (previous_cursor, down) in [(0, true), (1, false), (4, true), (5, false)] {
                let mut state = bag_at(previous_cursor);
                let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);
                let mut actual = FrameBuffer::new(config, Rgba::BLACK);
                draw_bag(&state, &mut actual, language);
                let previous = top_level_bag_cursor_position(state.items().len(), state.cursor());

                state.update_frame(BagScreenInput {
                    up: !down,
                    down,
                    ..BagScreenInput::none()
                });
                let current = top_level_bag_cursor_position(state.items().len(), state.cursor());
                assert_eq!(
                    top_level_bag_viewport_offset(state.items().len(), previous_cursor),
                    top_level_bag_viewport_offset(state.items().len(), state.cursor()),
                );
                redraw_top_level_bag_cursor(previous, current, &mut actual, language);

                let mut expected = FrameBuffer::new(config, Rgba::BLACK);
                draw_bag(&state, &mut expected, language);
                assert_framebuffers_equal(&actual, &expected);
            }
        }
    }

    #[test]
    fn top_level_bag_swap_and_action_cursors_match_fresh_draws() {
        for language in [Lang::En, Lang::Zh] {
            let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);

            let mut swap = bag_at(0);
            swap.update_frame(BagScreenInput {
                select: true,
                ..BagScreenInput::none()
            });
            let mut actual = FrameBuffer::new(config, Rgba::BLACK);
            draw_bag(&swap, &mut actual, language);
            let previous = top_level_bag_cursor_position(swap.items().len(), swap.cursor());
            swap.update_frame(BagScreenInput {
                down: true,
                ..BagScreenInput::none()
            });
            let current = top_level_bag_cursor_position(swap.items().len(), swap.cursor());
            redraw_top_level_bag_cursor(previous, current, &mut actual, language);
            let mut expected = FrameBuffer::new(config, Rgba::BLACK);
            draw_bag(&swap, &mut expected, language);
            assert_framebuffers_equal(&actual, &expected);

            let mut action = bag_at(0);
            action.update_frame(BagScreenInput {
                a: true,
                ..BagScreenInput::none()
            });
            let mut actual = FrameBuffer::new(config, Rgba::BLACK);
            draw_bag(&action, &mut actual, language);
            action.update_frame(BagScreenInput {
                down: true,
                ..BagScreenInput::none()
            });
            redraw_top_level_bag_action_cursor(0, 1, &mut actual, language);
            let mut expected = FrameBuffer::new(config, Rgba::BLACK);
            draw_bag(&action, &mut expected, language);
            assert_framebuffers_equal(&actual, &expected);
        }
    }

    #[test]
    fn top_level_bag_quantity_repaint_matches_a_fresh_draw() {
        for language in [Lang::En, Lang::Zh] {
            let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);
            let mut state = bag_at(0);
            state.update_frame(BagScreenInput {
                a: true,
                ..BagScreenInput::none()
            });
            state.update_frame(BagScreenInput {
                down: true,
                ..BagScreenInput::none()
            });
            state.update_frame(BagScreenInput {
                a: true,
                ..BagScreenInput::none()
            });

            let mut actual = FrameBuffer::new(config, Rgba::BLACK);
            draw_bag(&state, &mut actual, language);
            state.update_frame(BagScreenInput {
                up: true,
                ..BagScreenInput::none()
            });
            redraw_top_level_bag_quantity(1, 2, &mut actual, language);

            let mut expected = FrameBuffer::new(config, Rgba::BLACK);
            draw_bag(&state, &mut expected, language);
            assert_framebuffers_equal(&actual, &expected);

            // Crossing the two/three-digit boundary must also erase the
            // trailing digit when moving back from x100 to x99.
            let mut state = BagScreenState::new(vec![(ItemId::Potion, 100)]);
            state.update_frame(BagScreenInput {
                a: true,
                ..BagScreenInput::none()
            });
            state.update_frame(BagScreenInput {
                down: true,
                ..BagScreenInput::none()
            });
            state.update_frame(BagScreenInput {
                a: true,
                ..BagScreenInput::none()
            });
            for _ in 1..100 {
                state.update_frame(BagScreenInput {
                    up: true,
                    ..BagScreenInput::none()
                });
            }
            let mut actual = FrameBuffer::new(config, Rgba::BLACK);
            draw_bag(&state, &mut actual, language);
            state.update_frame(BagScreenInput {
                down: true,
                ..BagScreenInput::none()
            });
            redraw_top_level_bag_quantity(100, 99, &mut actual, language);
            let mut expected = FrameBuffer::new(config, Rgba::BLACK);
            draw_bag(&state, &mut expected, language);
            assert_framebuffers_equal(&actual, &expected);
        }
    }

    fn mart_state(stock: &[ItemId], phase: MartPhase) -> MartState {
        let mut state = MartState::new(pokered_core::items::shop::ShopInventory::new(
            stock.to_vec(),
        ));
        state.phase = phase;
        state
    }

    fn assert_mart_cursor_repaint(
        previous: MartState,
        current: MartState,
        previous_pos: (u32, u32),
        current_pos: (u32, u32),
        bag: &[(ItemId, u32)],
        language: Lang,
    ) {
        let config = dotzuki_engine::render_config::RenderConfig::new(160, 144);
        let mut actual = FrameBuffer::new(config, Rgba::BLACK);
        draw_mart(&previous, 12_345, bag, &mut actual, language);
        redraw_mart_cursor(previous_pos, current_pos, &mut actual, language);

        let mut expected = FrameBuffer::new(config, Rgba::BLACK);
        draw_mart(&current, 12_345, bag, &mut expected, language);
        assert_framebuffers_equal(&actual, &expected);
    }

    #[test]
    fn mart_cursor_geometry_uses_the_drawn_original_boxes() {
        assert_eq!(mart_main_cursor_position(0), (1, 1));
        assert_eq!(mart_main_cursor_position(2), (1, 5));
        for sell in [false, true] {
            assert_eq!(mart_list_cursor_position(0, 0, Lang::En, sell), (5, 4));
            assert_eq!(mart_list_cursor_position(3, 0, Lang::En, sell), (5, 10));
            assert_eq!(mart_list_cursor_position(0, 0, Lang::Zh, sell), (5, 5));
            assert_eq!(mart_list_cursor_position(2, 0, Lang::Zh, sell), (5, 11));
        }
        assert_eq!(mart_list_scroll(4, 5, Lang::En), 1);
        assert_eq!(mart_list_scroll(3, 5, Lang::Zh), 1);
    }

    #[test]
    fn mart_cursor_repaint_matches_fresh_draws_for_all_local_transitions() {
        use pokered_core::items::shop::{ConfirmChoice, MartTopChoice, ShopInventory};

        let stock = [
            ItemId::PokeBall,
            ItemId::Potion,
            ItemId::Antidote,
            ItemId::PokeBall,
            ItemId::Potion,
        ];
        let bag = [
            (ItemId::Potion, 3),
            (ItemId::Antidote, 2),
            (ItemId::PokeBall, 12),
        ];

        for language in [Lang::En, Lang::Zh] {
            let top_choices = [
                MartTopChoice::Buy,
                MartTopChoice::Sell,
                MartTopChoice::Quit,
            ];
            for (previous_cursor, previous_choice) in top_choices.iter().enumerate() {
                for (current_cursor, current_choice) in top_choices.iter().enumerate() {
                    if previous_cursor == current_cursor {
                        continue;
                    }
                    assert_mart_cursor_repaint(
                        mart_state(
                            &stock,
                            MartPhase::MainMenu {
                                cursor: *previous_choice,
                            },
                        ),
                        mart_state(
                            &stock,
                            MartPhase::MainMenu {
                                cursor: *current_choice,
                            },
                        ),
                        mart_main_cursor_position(previous_cursor),
                        mart_main_cursor_position(current_cursor),
                        &bag,
                        language,
                    );
                }
            }

            for previous_cursor in 0..stock.len() {
                for current_cursor in 0..stock.len() {
                    if previous_cursor == current_cursor {
                        continue;
                    }
                    let previous_scroll = mart_list_scroll(previous_cursor, stock.len(), language);
                    let current_scroll = mart_list_scroll(current_cursor, stock.len(), language);
                    // A changed viewport is a full popup redraw in RenderSession.
                    if previous_scroll != current_scroll {
                        continue;
                    }
                    assert_mart_cursor_repaint(
                        mart_state(
                            &stock,
                            MartPhase::Buy(BuyMenuState::SelectItem {
                                cursor: previous_cursor,
                            }),
                        ),
                        mart_state(
                            &stock,
                            MartPhase::Buy(BuyMenuState::SelectItem {
                                cursor: current_cursor,
                            }),
                        ),
                        mart_list_cursor_position(previous_cursor, previous_scroll, language, false),
                        mart_list_cursor_position(current_cursor, current_scroll, language, false),
                        &bag,
                        language,
                    );
                }
            }

            // The sell list has one extra CANCEL row after the bag items.
            for previous_cursor in 0..=bag.len() {
                for current_cursor in 0..=bag.len() {
                    if previous_cursor == current_cursor {
                        continue;
                    }
                    let previous_scroll = mart_list_scroll(previous_cursor, bag.len() + 1, language);
                    let current_scroll = mart_list_scroll(current_cursor, bag.len() + 1, language);
                    if previous_scroll != current_scroll {
                        continue;
                    }
                    assert_mart_cursor_repaint(
                        mart_state(
                            &stock,
                            MartPhase::Sell(SellMenuState::SelectItem {
                                cursor: previous_cursor,
                            }),
                        ),
                        mart_state(
                            &stock,
                            MartPhase::Sell(SellMenuState::SelectItem {
                                cursor: current_cursor,
                            }),
                        ),
                        mart_list_cursor_position(previous_cursor, previous_scroll, language, true),
                        mart_list_cursor_position(current_cursor, current_scroll, language, true),
                        &bag,
                        language,
                    );
                }
            }

            let confirm_y = |choice| match (language, choice) {
                (_, ConfirmChoice::Yes) => 9,
                (Lang::En, ConfirmChoice::No) => 10,
                (Lang::Zh, ConfirmChoice::No) => 11,
            };
            for sell in [false, true] {
                for (previous, current) in [
                    (ConfirmChoice::Yes, ConfirmChoice::No),
                    (ConfirmChoice::No, ConfirmChoice::Yes),
                ] {
                    let phase = |selected| {
                        if sell {
                            MartPhase::Sell(SellMenuState::Confirm {
                                item_index: 0,
                                quantity: 2,
                                max_quantity: 3,
                                selected,
                            })
                        } else {
                            MartPhase::Buy(BuyMenuState::Confirm {
                                item_index: 0,
                                quantity: 2,
                                selected,
                            })
                        }
                    };
                    let mut previous_state = MartState::new(ShopInventory::new(stock.to_vec()));
                    previous_state.phase = phase(previous);
                    let mut current_state = MartState::new(ShopInventory::new(stock.to_vec()));
                    current_state.phase = phase(current);
                    assert_mart_cursor_repaint(
                        previous_state,
                        current_state,
                        (15, confirm_y(previous)),
                        (15, confirm_y(current)),
                        &bag,
                        language,
                    );
                }
            }
        }
    }
}

/// Overworld ITEM bag (Start menu → ITEM): the item list, plus a USE / TOSS /
/// CANCEL menu or the TOSS-quantity prompt when an item is selected.
pub fn draw_bag(state: &BagScreenState, fb: &mut FrameBuffer, lang: Lang) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    let mut ui = Ui::new(&mut painter);
    let rd = PokemonRenderData::new(false);
    menus::bag::draw(state.items(), state.cursor(), &BAG_DEFAULT_LAYOUT, &mut ui, &rd);

    match state.phase() {
        BagPhase::SwapFrom { row } => {
            // ▷ marker on the swap row (SwapItemsInMenu's select cursor),
            // drawn through a borderless overlay box at the list's left edge.
            let y = row.saturating_sub(state.scroll()) as u32;
            ui.text_box(
                TileRect::new(
                    BAG_DEFAULT_LAYOUT.list.rect.tx.saturating_sub(1),
                    BAG_DEFAULT_LAYOUT.list.rect.ty + 1 + y,
                    1,
                    1,
                ),
                InkColor::White,
                false,
                |frame| {
                    frame.label(0, 0, "▷", InkColor::Black);
                },
            );
        }
        BagPhase::ActionMenu { cursor } => {
            let is_zh = lang == Lang::Zh;
            // Keep the existing Chinese font spacing; the English two-entry
            // popup uses the original USE_TOSS_MENU_TEMPLATE coordinates.
            let (rect, label_x, first_row, cursor_x) = if is_zh {
                (TileRect::new(11, 9, 9, 9), 2, 1, 1)
            } else {
                (TileRect::new(13, 10, 7, 5), 1, 0, 0)
            };
            ui.text_box(rect, InkColor::Black, true, |frame| {
                for (i, opt) in ["USE", "TOSS"].iter().enumerate() {
                    frame.label(label_x, first_row + i as u32 * 2, lang_data::ui_label(opt, is_zh), InkColor::Black);
                }
                if let Some(c) = &BAG_DEFAULT_LAYOUT.list.cursor {
                    frame.cursor_glyph_at(cursor_x, first_row + cursor as u32 * 2, c.glyph, c.color);
                }
            });
        }
        BagPhase::TossQuantity { qty } => {
            ui.text_box(TileRect::new(4, 11, 15, 7), InkColor::Black, true, |frame| {
                let prompt = if lang == Lang::Zh { "扔掉几个？" } else { "TOSS HOW MANY?" };
                frame.label(2, 1, prompt, InkColor::Black);
                frame.label(2, 3, &format!("x{:02}", qty), InkColor::Black);
            });
        }
        BagPhase::MachineBoot { item } => {
            menus::bag::draw_machine_prompt(item, None, &mut ui, lang);
        }
        BagPhase::MachineTeach { item, cursor } => {
            menus::bag::draw_machine_prompt(item, Some(cursor), &mut ui, lang);
        }
        BagPhase::TossQuestion { .. } | BagPhase::TossConfirm { .. } | BagPhase::TossWait { .. }
        | BagPhase::TossResult { .. } | BagPhase::TossRejected | BagPhase::FieldMessage { .. } => {
            if let Some(dialogue) = state.toss_dialogue() {
                if let Some((top, bottom)) = dialogue.get_display_text() {
                    let text = if bottom.is_empty() { top } else { format!("{}\n{}", top, bottom) };
                    menus::dialog::draw_paginated(
                        &text, state.toss_arrow_visible(),
                        &pokered_data::ui_layout::schema::DIALOG_DEFAULT_LAYOUT, &mut ui, lang,
                    );
                }
            }
            let cursor = match state.phase() {
                BagPhase::TossConfirm { cursor, .. } | BagPhase::TossWait { cursor, .. } => Some(cursor),
                _ => None,
            };
            if let Some(cursor) = cursor {
                ui.text_box(TileRect::new(14, 7, 6, 7), InkColor::Black, true, |frame| {
                    frame.label(2, 1, lang_data::ui_label("YES", lang == Lang::Zh), InkColor::Black);
                    frame.label(2, 3, lang_data::ui_label("NO", lang == Lang::Zh), InkColor::Black);
                    if let Some(c) = &BAG_DEFAULT_LAYOUT.list.cursor {
                        frame.cursor_glyph_at(1, 1 + cursor as u32 * 2, c.glyph, c.color);
                    }
                });
            }
        }
        BagPhase::Browsing => {}
    }
}

pub fn top_level_bag_viewport_offset(item_count: usize, cursor: usize) -> usize {
    menus::bag::viewport_offset(item_count, cursor, &BAG_DEFAULT_LAYOUT)
}

pub fn top_level_bag_cursor_position(item_count: usize, cursor: usize) -> TilePos {
    menus::bag::cursor_position(item_count, cursor, &BAG_DEFAULT_LAYOUT)
}

/// Repaint only the changed list cursor cells of an already-rendered bag.
pub fn redraw_top_level_bag_cursor(
    previous: TilePos,
    current: TilePos,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    menus::bag::redraw_cursor(previous, current, &mut painter);
}

/// Repaint only the changed USE/TOSS/CANCEL cursor cells.
pub fn redraw_top_level_bag_action_cursor(
    previous: u8,
    current: u8,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    let position = |cursor| TilePos::new(if lang == Lang::Zh { 13 } else { 14 }, 11 + cursor as u32 * 2);
    let old = position(previous);
    painter.draw_pixel_rect(old.tx * 8, old.ty * 8, 8, 9, pokered_ui::Rgba::INK_WHITE);
    painter.draw_glyph(position(current), '▶', pokered_ui::Rgba::INK_BLACK);
}

/// Repaint only the changed `xNN` value of the toss-quantity prompt.
pub fn redraw_top_level_bag_quantity(
    previous: u32,
    current: u32,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let mut painter = FrameBufferPainter::new(fb).with_lang(lang);
    let position = TilePos::new(7, 15);
    let text_width = |qty| format!("x{:02}", qty).chars().count() as u32 * 8;
    painter.draw_pixel_rect(
        position.tx * 8,
        position.ty * 8,
        text_width(previous).max(text_width(current)),
        10,
        pokered_ui::Rgba::INK_WHITE,
    );
    painter.draw_text(
        position,
        &format!("x{:02}", current),
        pokered_ui::Rgba::INK_BLACK,
    );
}
