from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-218-bag-action-checkout';d=wt/'docs/screenshots/fidelity-bag-action-218';d.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((r/'audit-218-native-a3-immutable/manifest.json').read_text())
for name,h in m['sources'].items():assert sha((wt/name).read_bytes())==h
for name,case,frame in [('options','down-down',4),('cursor','down-down',16),('toss','down-down',30),('priority','up-down',30)]:
 for side,tag,label in [('master','a1','before'),('native','a3','after')]:shutil.copy2(r/f'audit-218-{side}-capture-{tag}-1/{case}/frame-{frame:04}.png',d/f'{name}-{label}.png')
files={}
for side,tag in [('master','a1'),('native','a3')]:
 for trial in [1,2]:
  p=r/f'audit-218-{side}-capture-{tag}-{trial}'
  for f in p.rglob('*'):
   if f.is_file():files[str(f.relative_to(r))]=f
for case in ['down-down','up','down-up','up-down','ab','down-a']:
 for trial in [1,2]:
  p=r/f'audit-218-original-bag-action-{case}-a1-{trial}'
  for f in p.rglob('*'):
   if f.is_file():files[str(f.relative_to(r))]=f
for p in r.iterdir():
 if p.is_file() and p.name.startswith('audit-218-') and p.suffix in ['.log','.json','.txt','.rs']:files[p.name]=p
for name in ['record_bag_action_218.py','package_bag_action_218.py','stats-59-tools/probe_bag_action_218.py']:files[name]=r/name
for side,tag in [('master','a1'),('native','a3')]:
 p=r/f'audit-218-{side}-{tag}-immutable/manifest.json';files[str(p.relative_to(r))]=p
for name in m['sources']:files['final-source/'+name]=wt/name
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['engine/menus/start_sub_menus.asm','data/text_boxes.asm','home/window.asm']:files['original-source/'+name]=ref/name
pngs={};blobs={}
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  b=p.read_bytes()
  if p.suffix=='.png':
   h=sha(b);pngs[name]=h
   if h not in blobs:blobs[h]=b;z.writestr('png-blobs/'+h+'.png',b)
  else:z.writestr(name,b)
 z.writestr('png-files.json',json.dumps(pngs,indent=2))
assert len(pngs)==7344,len(pngs)
with zipfile.ZipFile(d/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+pngs[name]+'.png' if name in pngs else name)==p.read_bytes(),name
v={'base':m['base'],'source_manifest':m,'tests':{'core':2722,'app':198,'app_ignored':22},'PNG':len(pngs),'archive_all_files_roundtrip_byte_exact':True,'archive_sha256':sha((d/'evidence.zip').read_bytes())};(d/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
(d/'README.md').write_text('''# Bag USE/TOSS selection, independent repair 218

Actual master 59d519f has an extra CANCEL row and processes simultaneous UP+DOWN
as DOWN at the top. The original USE_TOSS template has exactly USE and TOSS,
maximum cursor 1, no wrap, and HandleMenuInput gives UP priority even at the top.
The repair changes only action selection and its full/cached rendering. B still
cancels; action A+B still gives B priority. Quantity B already returns to the
list and is unchanged. English rectangle (13,10)..(19,14), labels X15 and cursor
X14 at rows 11/13 follow the primary template. Existing Chinese rectangle and
font spacing are preserved. Fonts, translations and wider menu flows are outside
this change. Production changes touch core/bag_screen.rs and app/render/menu.rs;
app/game.rs only adds an actual Game regression/capture helper.

The original controlled pre-PC emulator fixture uses Potion3 and real START,
item selection, then six input cases: down-down, up, down-up, up-down, A+B and
down+A. Each records 370 frames twice: 4440 PNG and full raw state/hooks repeat
byte exact. The maximum remains 1; down-down/down+A open quantity1; UP+DOWN stays
at USE; A+B returns to the list. This is not natural traversal or a claim of
absolute original CPU/PPU to native frame/pixel equivalence.

Baseline production is actual master59d519f, with the byte-identical helper only
appended to Game; its original production prefix hash is recorded. Candidate
source eb72e7d is frozen and its three file hashes checked before packaging.
Independent targets/builds avoid stale shared artifacts. Both sides use the
same actual Game, seed42, English/Medium, injured Bulbasaur5/Potion3, collision-
checked Viridian Center floor4,4 warmed120 frames, and direct Bag entry. Six
cases each capture121 frames twice on each side (2904 PNG). All PNG and full
JSON repeat byte exact; every frame asserts retained/full drawing pixel equality.
Baseline owner test fails with cursor2 rather than1. Final full core2722 and
app198 tests pass (22 opt-in helpers ignored). Before/after screenshots use the
same state/input/frame: initial menu4, cursor16, toss result30, UP+DOWN result30.

Initial a1 full tests exposed a stale cached cursor coordinate; both full and
partial coordinates were corrected, without weakening pixel equality. The a2
integration build exposed an incomplete test-module delimiter, corrected by
keeping both complete owner modules. All failed logs remain in the evidence;
a3 build and full tests pass. The archive includes primary assembly, scripts,
full raw records, source/hash manifests and logs. PNGs are SHA256 deduplicated
losslessly; all7344 original PNG paths and all other files are read back and
compared byte-for-byte. No ROM, SRAM, emulator state or executable is published.
Current-head CI and unchanged GBA performance gates must pass before merge.
''')
print(json.dumps({'png':len(pngs),'archive_bytes':(d/'evidence.zip').stat().st_size,'roundtrip':True}))
