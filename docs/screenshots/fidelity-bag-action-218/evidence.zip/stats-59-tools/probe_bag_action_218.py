exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state'
case=os.environ.get('FIDELITY_ACTION_CASE','down-down')
item=0x14
stock=3
for trial in [1,2]:
 out=r/f'audit-218-original-bag-action-{case}-a1-{trial}';assert not out.exists();out.mkdir()
 p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]])
 p.memory[symbols['wNumBagItems'][1]]=1
 a=symbols['wBagItems'][1];p.memory[a]=item;p.memory[a+1]=stock;p.memory[a+2]=0xff
 for n in ['wBattleAndStartSavedMenuItem','wBagSavedMenuItem','wListScrollOffset']:p.memory[symbols[n][1]]=0
 p.memory[symbols['wOptions'][1]]=(get('wOptions')&0xf0)|3
 if case=='coins':
  p.memory[symbols['wPlayerCoins'][1]]=0x04;p.memory[symbols['wPlayerCoins'][1]+1]=0x20
 now=[-1];events=[];cues={n:None for n in ['DrawStartMenu','StartMenu_Item','StartMenu_Item.choseItem','StartMenu_Item.useOrTossItem','UseItem']};lists=[];wait=[None]
 def hook(n):
  if n in cues and cues[n] is None:cues[n]=now[0]
  if n=='DisplayListMenuID':lists.append(now[0])
  if n=='WaitForTextScrollButtonPress':wait[0]=now[0]
  events.append({'t':now[0],'routine':n,'cycles':p._cycles(),'cursor':get('wCurrentMenuItem'),'max':get('wMaxMenuItem'),'wrapping':get('wMenuWrappingEnabled'),'textbox':get('wTextBoxID'),'result':get('wActionResultOrTookBattleTurn'),'transport':get('wWalkBikeSurfState'),'A':int(p.register_file.A)})
 for n in list(cues)+['DisplayListMenuID','WaitForTextScrollButtonPress','DisplayTextBoxID','PrintText','CloseStartMenu','PlaySound']:
  assert n in symbols,n;p.hook_register(*symbols[n],hook,n)
 held=set();rows=[];start_items=None
 for t in range(1200):
  now[0]=t;keys={'start'} if t<2 else set();m=cues['DrawStartMenu'];li=cues['StartMenu_Item'];action=cues['StartMenu_Item.choseItem']
  if m is not None and li is None:
   if start_items is None and t>=m+40:start_items=2 if get('wMaxMenuItem')==7 else 1
   if start_items is not None:
    for n in range(start_items):
     if m+70+n*24<=t<m+72+n*24:keys={'down'}
    if m+70+start_items*24<=t<m+72+start_items*24:keys={'a'}
  if li is not None and action is None and li+70<=t<li+72:keys={'a'}
  if action is not None and cues['UseItem'] is None:
   if action+40<=t<action+42:
    keys={'down'} if case in ['down-down','down-up','down-a'] else {'up'} if case=='up' else {'up','down'} if case=='up-down' else set()
   if action+64<=t<action+66:
    keys={'down'} if case=='down-down' else {'up'} if case=='down-up' else set()
   if action+90<=t<action+92:keys={'a','b'} if case=='ab' else {'a','down'} if case=='down-a' else {'a'}
  use=cues['UseItem']
  # Action selection only: do not acknowledge/use/toss beyond its first destination.
  if wait[0] is not None and wait[0]+20<=t<wait[0]+22:keys={'a'}
  for key in held-keys:p.button_release(key)
  for key in keys-held:p.button_press(key)
  held=keys;p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png')
  rows.append({'t':t,'input':sorted(keys),'cues':dict(cues),'lists':list(lists),'cursor':get('wCurrentMenuItem'),'max':get('wMaxMenuItem'),'wrapping':get('wMenuWrappingEnabled'),'textbox':get('wTextBoxID'),'result':get('wActionResultOrTookBattleTurn'),'transport':get('wWalkBikeSurfState'),'stock':int(p.memory[symbols['wBagItems'][1]+1]),'map':get('wCurMap')})
  if action is not None and t>=action+160:break
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
 assert action is not None
 assert not any(e['routine']=='CloseStartMenu' for e in events)
 assert any(e['routine']=='DisplayTextBoxID' and e['textbox']==6 for e in events),'ordinary item USE/TOSS popup present'
 assert rows[-1]['stock']==stock
 print('keyframes', [(q['t'],q['cursor'],q['max'],q['wrapping'],q['textbox']) for q in rows if q['t'] in [action+39,action+55,action+80,action+110,action+150]],flush=True)
 print(case,trial,cues,'lists',lists,'frames',len(rows),flush=True)
 if trial==2:
  old=r/f'audit-218-original-bag-action-{case}-a1-1'
  assert sorted(p.name for p in out.iterdir())==sorted(p.name for p in old.iterdir())
  assert all(p.read_bytes()==(old/p.name).read_bytes() for p in out.iterdir())
