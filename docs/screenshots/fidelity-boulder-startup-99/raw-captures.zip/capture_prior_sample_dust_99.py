import os,subprocess,json
from pathlib import Path
r=Path('/home/jerry/develop/open-pokered');a=r/'.task-tmp/fidelity-39-plus';results=[]
for direction in ['down','up','left','right']:
 for i in [1,2]:
  env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',FIDELITY_DUST_SRAM=str(a/'dust-93-warp-setup/seafoam-valid.sav'),FIDELITY_DUST_CAPTURE=str(a/f'dust-99-prior-sample-{direction}-{i}'),FIDELITY_DUST_DIRECTION=direction)
  p=subprocess.run([str(a/'dust-99-prior-sample-driver'),'capture_actual_boulder_dust_raw_93','--ignored','--nocapture','--test-threads=1'],cwd=r/'.task-tmp/fidelity-91-plus-checkout',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (a/f'dust-99-prior-sample-{direction}-{i}.log').write_text(p.stdout);ok=p.returncode==0 and '1 passed' in p.stdout;results.append({'direction':direction,'trial':i,'capture_pass':ok});print(direction,i,ok,p.stdout[-600:] if not ok else '',flush=True)
(a/'dust-99-prior-sample-capture-summary.json').write_text(json.dumps(results,indent=2)+'\n')
