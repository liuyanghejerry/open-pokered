exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/dust-93-valid-setup'
for trial in [1,2]:
 out=root/f'.task-tmp/fidelity-39-plus/dust-99-startup-reference-{trial}';out.mkdir(exist_ok=True)
 p=PyBoy(str(setup/'dust-reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'actual-strength-prepush.state').read_bytes()));p.tick(120);rows=[];events=[];now=[-1]
 for name in ['AnimateBoulderDust','WriteCutOrBoulderDustAnimationOAMBlock','GetMoveBoulderDustFunctionPointer','TryWalking','TryPushingBoulder','RunMapScript','MoveSprite','RunNPCMovementScript','UpdateSprites','UpdateNPCSprite','JoypadOverworld','Joypad']:
  p.hook_register(*symbols[name],lambda ctx: events.append({'t':now[0],'routine':ctx,'frame':p.frame_count,'held':int(p.memory[symbols['hJoyHeld'][1]]),'misc':int(p.memory[symbols['wMiscFlags'][1]]),'status5':int(p.memory[symbols['wStatusFlags5'][1]])}),name)
 for t in range(-1,200):
  now[0]=t
  if t==0:p.button_press('down')
  if t==16:p.button_release('down')
  if t>=0:p.tick(1)
  p.screen.image.save(out/f'frame-{t+1:04}.png')
  rows.append({'t':t,'frame':p.frame_count,'palette':int(p.memory[0xff49]),'oam':list(p.memory[0xfe00:0xfea0]),'shadow_oam':list(p.memory[0xc300:0xc3a0]),'state':{n:int(p.memory[symbols[n][1]]) for n in ['wCurMap','wXCoord','wYCoord','wWalkCounter','wIsInBattle','wPlayerDirection','wPlayerMovingDirection','hSCX','hSCY','hJoyHeld','wSprite01StateData2MapY','wSprite01StateData2MapX','wSprite01StateData2WalkAnimationCounter','wSprite01StateData1YPixels','wMiscFlags']}})
 (out/'frames.json').write_text(json.dumps(rows,indent=2));(out/'events.json').write_text(json.dumps(events,indent=2));p.stop(save=False);print(trial,events,flush=True)
