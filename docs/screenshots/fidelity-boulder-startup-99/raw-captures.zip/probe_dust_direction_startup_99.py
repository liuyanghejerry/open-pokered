exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/dust-93-valid-setup';summary=[]
for direction in ['up','left','right']:
 for trial in [1,2]:
  src=root/f'.task-tmp/fidelity-39-plus/dust-93-reference-{direction}-1';out=root/f'.task-tmp/fidelity-39-plus/dust-99-source-{direction}-{trial}';out.mkdir(exist_ok=True)
  p=PyBoy(str(setup/'dust-reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((src/'pretrigger.state').read_bytes()));events=[];now=[-1]
  for name in ['JoypadOverworld','TryPushingBoulder','MoveSprite','TryWalking','AnimateBoulderDust']:
   p.hook_register(*symbols[name],lambda name:events.append({'t':now[0],'routine':name,'held':int(p.memory[symbols['hJoyHeld'][1]]),'misc':int(p.memory[symbols['wMiscFlags'][1]])}),name)
  for t in range(-1,200):
   now[0]=t
   if t==0:p.button_press(direction)
   if t==16:p.button_release(direction)
   if t>=0:p.tick(1)
   p.screen.image.save(out/f'frame-{t+1:04}.png')
  (out/'events.json').write_text(json.dumps(events,indent=2));p.stop(save=False)
  exact=all((out/f'frame-{i:04}.png').read_bytes()==(src/f'frame-{i:04}.png').read_bytes() for i in range(201));assert exact
  summary.append({'direction':direction,'trial':trial,'201PNG_matches_prior':exact,'startup':[e for e in events if e['t']<8 or e['routine']=='AnimateBoulderDust']});print(summary[-1],flush=True)
(root/'.task-tmp/fidelity-39-plus/dust-99-source-direction-summary.json').write_text(json.dumps(summary,indent=2))
