from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-224-pc-confirm-wait-checkout';d=wt/'docs/screenshots/fidelity-pc-confirm-wait-224';d.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((r/'audit-224-pc-native-a3-immutable/manifest.json').read_text())
for name,h in m['sources'].items():assert sha((wt/name).read_bytes())==h,name
files={}
for side in ['master','native']:
 tag='a4' if side=='master' else 'a3'
 for rep in [1,2]:
  p=r/f'audit-224-pc-{side}-capture-{tag}-{rep}'
  for f in p.rglob('*'):
   if f.is_file():files[str(f.relative_to(r))]=f
  files[p.name+'.log']=r/(p.name+'.log')
 for name in [f'audit-224-pc-{side}-{tag}-immutable/manifest.json',f'audit-224-pc-{side}-verification.json',f'audit-224-pc-{side}-build-{tag}.log']:files[name]=r/name
for context in ['change','release','toss','oak']:
 for case in ['yes','yes-a','yes-b','yes-down','no','ab','up-a','down-a']:
  for rep in [1,2]:
   p=r/f'audit-224-original-pc-{context}-{case}-a1-{rep}'
   for f in p.iterdir():
    if f.is_file():files[str(f.relative_to(r))]=f
for name in ['audit-224-original-delay-verification-a2.json','audit-224-pc-combo-source-batch-a1.log','run_pc_confirm_combo_source_224.py','audit-224-candidate-current-master-source-verification.json','audit-224-original-confirm-hold-pixels.json','audit-224-pc-source-batch-a1.log','audit-224-pc-master-owner-negative-a1.log','audit-224-pc-master-owner-negative-a2.log','audit-224-pc-master-freeze-capture.log','audit-224-pc-master-freeze-capture-a2.log','audit-224-pc-master-premature-effects.json','audit-224-pc-core-tests-a1.log','audit-224-pc-app-tests-a1.log','audit-224-pc-core-tests-a2.log','audit-224-pc-app-tests-a2.log','audit-224-pc-core-tests-a3.log','audit-224-pc-app-tests-a3.log','audit-224-pc-master-owner-negative-a4.log','audit-224-pc-master-freeze-capture-a4.log','freeze_record_pc_before_224_a3.py','freeze_record_pc_before_224_a4.py','freeze_test_224_a3.py','record_pc_native_224_a3.py','audit-224-pc-native-build-a1.log','audit-224-pc-master-build-a1.log','audit-224-pc-confirm-delay-owner-helper.rs','freeze_record_pc_before_224.py','freeze_record_pc_before_224_a2.py','freeze_test_224.py','freeze_test_224_a2.py','record_pc_native_224.py','package_pc_wait_224.py','stats-59-tools/probe_pc_confirm_delay_224.py','run_pc_confirm_source_224.py']:files[name]=r/name
for name in m['sources']:files['final-source/'+name]=wt/name
files['actual-master-game-with-test-only-helpers.rs']=root/'.task-tmp/fidelity-223-menu-before-checkout/crates/pokered-app/src/game.rs'
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['home/yes_no.asm','engine/menus/text_box.asm','home/window.asm','engine/pokemon/bills_pc.asm','engine/menus/save.asm','engine/menus/oaks_pc.asm','engine/menus/players_pc.asm']:files['original-source/'+name]=ref/name
png={};blobs=set()
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  b=p.read_bytes()
  if p.suffix=='.png':
   h=sha(b);png[name]=h
   if h not in blobs:blobs.add(h);z.writestr('png-blobs/'+h+'.png',b)
  else:z.writestr(name,b)
 z.writestr('png-files.json',json.dumps(png,indent=2))
assert len(png)==76096,len(png)
with zipfile.ZipFile(d/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for name,context,case,frame in [('change','change','yes-down',100),('release','release','yes-b',95),('toss','toss','yes',95),('oak','oak','yes-a',100),('up-a','release','up-a',95),('down-a','change','down-a',95)]:
 for side,label in [('master','before'),('native','after')]:
  tag='a4' if side=='master' else 'a3'
  shutil.copy2(r/f'audit-224-pc-{side}-capture-{tag}-1/{context}-{case}/frame-{frame:04}.png',d/f'{name}-{label}.png')
v={'master_before':'4abcafa2b1ebc06912b0edd4db1d18f32aba460a','frozen_parent_equivalent_tree':m['base'],'source_hashes':m,'PNG':len(png),'every_archive_file_roundtrip_bytes_equal':True,'archive_sha256':sha((d/'evidence.zip').read_bytes())};(d/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
(d/'README.md').write_text('''# PC protected confirmation hold, isolated audit224

DisplayTwoOptionMenu calls DelayFrames15 before restoring tiles and returning
on YES, NO and B cancellation. Original controlled PC inputs in four contexts
(Change Box, Release, PC Toss and Oak rating), eight cases each, repeated twice:
UP40, optional NO64, A/A+B90, interference A/B/DOWN100, relative to choice cue.
All32 cases restore at105 exactly15 after acceptance. Release/Potion mutation
and DisplayDexRating occur105 for YES, never early and not for NO/A+B. All
51648 original PNG and complete raw state/hooks repeat byte-exact. Full rendered
frame80 equals95 in all20 YES/NO/A+B/UP+A/DOWN+A context combinations: the held cursor is
not redrawn to NO even when B already sets the raw cursor byte to1. These are
controlled seeded data and real menu input, not natural acquisition/traversal.

Current master4abcafa returns/commits at90: DOWN100 changes the next box cursor,
A100 can choose the box and save prematurely, B100 can dismiss the receipt.
Fix: two private PcScreen fields hold the prior drawn phase/cursor for15 ticks,
ignore all intervening input and return the frozen B-priority decision once.
Direction+A freezes the old drawn cursor independently of the changed choice,
matching primary HandleMenuInput (moves raw selection before returning watched
keys, without another PlaceMenuCursor). Eight inputs/context include these two
combined-button cases; default tests and timing are not substituted for them.
Transactions, cry queuing, rating and cancellation therefore happen105. Shared
Game uses this same core state machine. No new production renderer/GUI/audio
or save-format code. Existing effect tests explicitly advance15, retaining
all stock/no-save/no-release assertions; cached/full test covers actual YES/NO
cursor movements in all contexts. Existing default/priority owner uses the
source105 boundary, not its previously immediate90 boundary. Dedicated core
once-only/input/timing test and actual Game32-case owner guard the new behavior.

PR163 has merged as master4abcafa. The entire tracked tree of frozen native
parent8a765b7 equals master4abcafa, and all candidate source hashes still match.
This is now an independent master fix; own final CI must pass before merging.
Before is actual master4abcafa production with only identical cfg(test) helpers added,
compiled independently; UP40 explicitly selects YES on both sides, isolating
this wait from the separate default fix. Both sides use collision-checked real
Viridian Center13,4 PC event, Exeggutor13 party/box, PC Potion4, Dex flag,
seed42/English/Medium, then genuine menus. Each32cases x191frames x2 repeats
on each side =24448 native/master PNG. Every frame compares cached/full pixels;
all PNG and complete JSON are byte-exact within side. Positive owner holds
phase90..104, stock changes105, early A cannot flip rating or save, early DOWN
cannot choose another box. Master negative fails immediate phase90. Paired
images use same fixture/input/relative frame95 or100, including
UP+A held NO but committed YES and DOWN+A held YES but returned NO; defaults already match after merged PR163; this PR changes only the hold.

Initial master a1 capture completed but failed the exact-repeat verifier:
uncontrolled default-save loading after the premature A100 save polluted the
next fixture. All failed logs/PNG/JSON and private default SRAM remain in the
workspace. Final a4 master/a3 native uses a new explicit unique owned save path per case via
new_with_options(no audio), asserts initially empty party/box, and records
owned_save_exists. Old change/yes-a first writes100; candidate never writes
in these inputs. Private SRAM/flags are removed after each completed case and
never archived. Every final case starts fresh, preserving the same real save
operation rather than disabling saves or masking the observed side effect.

Evidence ZIP retains76096 valid original/master/candidate PNG paths losslessly
as SHA256 blobs, complete raw state/hooks, primary assembly, source/binary hash
manifests, scripts and full diagnostic/regression logs. Every archived file is
read back and compared byte-for-byte. No ROM, emulator state, SRAM or executable
is published. Native core2725/app202 pass(26 opt-in captures ignored). These
probes prove this controlled acceptance/hold/commit boundary, not absolute
originalCPU/PPU alignment, natural mainline traversal, full SAVE/CONTINUE,
PC paragraph/typing/cry-length/audio order, global repeat or layout fidelity;
those audits remain open. Do not replace this scope proof with a broad PC claim.
''');print({'PNG':len(png),'bytes':(d/'evidence.zip').stat().st_size,'roundtrip':True})
