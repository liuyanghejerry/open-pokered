from pathlib import Path
import subprocess,hashlib,json,shutil,os,re
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-223-menu-before-checkout';out=r/'audit-224-pc-master-a1-immutable';out.mkdir(exist_ok=False);log=(r/'audit-224-pc-master-build-a1.log').read_text();assert 'Finished `test` profile' in log;p=re.findall(r'Executable .*?\((/[^\n]+)\)',log);assert len(p)==1;shutil.copy2(p[0],out/'app');base='591480e6244d74318cf490bbe0b7f2a0ebb0f2df';name='crates/pokered-app/src/game.rs';assert (wt/name).read_bytes().startswith(subprocess.check_output(['git','show',base+':'+name],cwd=wt));assert subprocess.check_output(['git','diff','--name-only'],cwd=wt).decode().splitlines()==[name];(out/'manifest.json').write_text(json.dumps({'base':base,'production_unchanged':True,'game_test_helpers_SHA256':hashlib.sha256((wt/name).read_bytes()).hexdigest(),'app_SHA256':hashlib.sha256((out/'app').read_bytes()).hexdigest()},indent=2));env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib')
with (r/'audit-224-pc-master-owner-negative-a1.log').open('w') as f:q=subprocess.run([str(out/'app'),'pc_confirm_waits_15_before_commit_and_blocks_input','--nocapture'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==101;print('negative',q.returncode,flush=True)
for rep in [1,2]:
 p=r/f'audit-224-pc-master-capture-a1-{rep}';assert not p.exists();env['PC_CONFIRM_CAPTURE_224']=str(p)
 with (r/(p.name+'.log')).open('w') as f:subprocess.run([str(out/'app'),'capture_pc_confirm_delay_224','--ignored','--nocapture'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(rep,0,flush=True)
a=r/'audit-224-pc-master-capture-a1-1';b=r/'audit-224-pc-master-capture-a1-2';files=[p for p in a.rglob('*') if p.is_file()];assert len(files)==24*192
for p in files:assert p.read_bytes()==(b/p.relative_to(a)).read_bytes(),p
v={'base':base,'PNG':9168,'all_repeat_JSON_and_PNG_exact':True,'every_cached_full_pixel_equal':True,'negative_owner_exit':101};(r/'audit-224-pc-master-verification.json').write_text(json.dumps(v,indent=2));print(v)
