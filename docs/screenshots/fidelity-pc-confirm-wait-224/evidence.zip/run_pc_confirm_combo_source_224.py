from pathlib import Path
import subprocess,os
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';py=r/'stats-59-tools/venv/bin/python';script=r/'stats-59-tools/probe_pc_confirm_delay_224.py'
for context in ['change','release','toss','oak']:
 for case in ['up-a','down-a']:
  result=subprocess.run([str(py),str(script)],cwd=root,env=dict(os.environ,PC_CONTEXT_224=context,PC_CASE_224=case))
  print(context,case,result.returncode,flush=True)
  if result.returncode:raise SystemExit(result.returncode)
