from pathlib import Path
import os,subprocess,json
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-224-pc-confirm-wait-checkout';binary=r/'audit-224-pc-native-a3-immutable/app'
for rep in [1,2]:
 path=r/f'audit-224-pc-native-capture-a3-{rep}';assert not path.exists()
 with (r/(path.name+'.log')).open('w') as f:subprocess.run([str(binary),'capture_pc_confirm_delay_224','--ignored','--nocapture'],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(root/'.task-tmp/fidelity-18-27'),PC_CONFIRM_CAPTURE_224=str(path)),stdout=f,stderr=subprocess.STDOUT,check=True)
 print(rep,0,flush=True)
a=r/'audit-224-pc-native-capture-a3-1';b=r/'audit-224-pc-native-capture-a3-2';files=[p for p in a.rglob('*') if p.is_file()];assert len(files)==32*192
for p in files:assert p.read_bytes()==(b/p.relative_to(a)).read_bytes(),p
for p in a.rglob('frames.json'):
 rows=json.loads(p.read_text());assert len(rows)==191 and all(not row['owned_save_exists'] for row in rows),p
v={'actual_master_before':'591480e6244d74318cf490bbe0b7f2a0ebb0f2df','stacked_parent':'8a765b7 PR163','PNG':12224,'all_repeat_bytes_exact':True,'all_cached_full_pixels_equal':True,'all32_cases_pass_owner_regression':True,'no_early_owned_save':True};(r/'audit-224-pc-native-verification.json').write_text(json.dumps(v,indent=2));print(v)
