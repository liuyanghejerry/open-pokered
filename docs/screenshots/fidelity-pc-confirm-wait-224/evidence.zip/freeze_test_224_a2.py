from pathlib import Path
import subprocess,hashlib,json,shutil,os,re,sys
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';kind=sys.argv[1];paths={'pc':'fidelity-224-pc-confirm-wait-checkout','action':'fidelity-218-bag-action-checkout','list':'fidelity-219-bag-list-checkout','swap':'fidelity-221-bag-swap-checkout'};wt=root/'.task-tmp'/paths[kind];out=r/f'audit-224-{kind}-native-a2-immutable';out.mkdir(exist_ok=False);log=(r/f'audit-224-{kind}-native-build-a2.log').read_text();assert 'Finished `test` profile' in log
base='8a765b7f2c3bd95c7cb675f1d23c69db5669eae6';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip();sources=subprocess.check_output(['git','diff','--name-only',base,'--','crates'],cwd=wt).decode().splitlines();m={'base':base,'head':head,'sources':{s:hashlib.sha256((wt/s).read_bytes()).hexdigest() for s in sources},'binaries':{}}
for binary in ['core','app']:
 matches=[p for p in re.findall(r'Executable .*?\((/[^\n]+)\)',log) if f'pokered_{binary}-' in p];assert len(matches)==1,matches;shutil.copy2(matches[0],out/binary);m['binaries'][binary]=hashlib.sha256((out/binary).read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for binary in ['core','app']:
 with (r/f'audit-224-{kind}-{binary}-tests-a2.log').open('w') as f:result=subprocess.run([str(out/binary)],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(root/'.task-tmp/fidelity-18-27')),stdout=f,stderr=subprocess.STDOUT)
 print(kind,binary,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
