exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/input-98-pc-source-setup';setup.mkdir(exist_ok=True)
p=PyBoy(str(run/'retail-save.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((run/'retail-field.state').read_bytes()))
get=lambda n:int(p.memory[symbols[n][1]])
print('entry',{n:get(n) for n in ['wCurMap','wXCoord','wYCoord','wPartyCount']},flush=True)
def destination(ctx):
 if get('wCurMap')==41:
  a=symbols['wCurrentTileBlockMapViewPointer'][1];ptr=p.memory[a]+p.memory[a+1]*256-8;p.memory[a]=ptr&255;p.memory[a+1]=ptr>>8
  for n,v in [('wXCoord',13),('wYCoord',4),('wXBlockCoord',1),('wYBlockCoord',0)]:p.memory[symbols[n][1]]=v
p.hook_register(*symbols['LoadTilesetHeader.done'],destination,None)
for n,v in [('hWarpDestinationMap',41),('wDestinationWarpID',0),('wStatusFlags3',get('wStatusFlags3')|8)]:p.memory[symbols[n][1]]=v
p.tick(240);p.hook_deregister(*symbols['LoadTilesetHeader.done']);assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(41,13,4)
p.button_press('down')
for i in range(120):
 p.tick(1)
 if get('wYCoord')==5:break
else:raise RuntimeError('could not step Down')
p.button_release('down');p.tick(120)
p.button_press('up');p.tick(2);p.button_release('up');p.tick(120);assert (get('wXCoord'),get('wYCoord'))==(13,5)
state=io.BytesIO();p.save_state(state);(setup/'pretrigger.state').write_bytes(state.getvalue());p.screen.image.save(setup/'pretrigger.png');print('ready',{n:get(n) for n in ['wPlayerDirection','wPlayerLastStopDirection','wPlayerMovingDirection']},flush=True);p.stop(save=False)
for case,hold,keys in [('a-short',1,['a']),('a-held',40,['a']),('a-start-held',40,['a','start'])]:
 for trial in [1,2]:
  out=root/f'.task-tmp/fidelity-39-plus/input-98-pc-source-{case}-{trial}';out.mkdir(exist_ok=True)
  p=PyBoy(str(run/'retail-save.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(state.getvalue()));events=[];now=[-1]
  for n in ['DisplayTextID','OpenPokemonCenterPC','DisplayStartMenu','DrawStartMenu']:
   p.hook_register(*symbols[n],lambda ctx:events.append({'t':now[0],'routine':ctx,'a':p.register_file.A,'text_id':get('hTextID')}),n)
  rows=[]
  for t in range(-1,100):
   now[0]=t
   if t==0:p.button_press('up')
   if t==16:p.button_release('up')
   if t==5:
    for key in keys:p.button_press(key)
   if t==5+hold:
    for key in keys:p.button_release(key)
   if t>=0:p.tick(1)
   p.screen.image.save(out/f'frame-{t+1:04}.png');rows.append({'t':t,'frame':p.frame_count,'state':{n:get(n) for n in ['wCurMap','wXCoord','wYCoord','wWalkCounter','hJoyHeld','hJoyPressed','wPlayerMovingDirection','wPlayerLastStopDirection']}})
  (out/'frames.json').write_text(json.dumps(rows,indent=2));(out/'events.json').write_text(json.dumps(events,indent=2));p.stop(save=False);print(case,trial,events,flush=True)
