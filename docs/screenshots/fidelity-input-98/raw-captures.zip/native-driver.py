import os,subprocess,json,hashlib
from pathlib import Path
root=Path('/home/jerry/develop/open-pokered'); artifacts=root/'.task-tmp/fidelity-39-plus'
for variant in ['master-before','native-after']:
 driver=artifacts/f'input-98-{variant}-driver'
 for case in ['a-short','a-held','a-start-held']:
  for trial in [1,2]:
   out=artifacts/f'input-98-pc-{variant}-{case}-{trial}'
   env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',FIDELITY_MOVEMENT_CAPTURE=str(out),FIDELITY_MOVEMENT_SRAM=str(artifacts/'movement-91-setup/walking-continue.gbc.ram'),FIDELITY_INPUT_PC_CASE=case)
   result=subprocess.run([str(driver),'capture_actual_walk_bike_raw_91','--ignored','--exact' if False else '--nocapture','--test-threads=1'],cwd=root/('.task-tmp/fidelity-91-plus-checkout' if variant=='native-after' else '.task-tmp/fidelity-93-master-before'),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   (artifacts/f'input-98-pc-{variant}-{case}-{trial}.log').write_text(result.stdout)
   assert result.returncode==0 and '1 passed' in result.stdout,result.stdout[-2000:]
   rows=json.loads((out/'frames.json').read_text())
   print(variant,case,trial,[(r['t'],r['screen'],r['pc_phase'],r['pending_pc']) for r in rows if r['screen']!='Overworld' or r['pending_pc']][:3],flush=True)
