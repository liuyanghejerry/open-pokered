from pathlib import Path
import json
class WorkCpu:
 def __init__(self,state):
  self.rom=Path(state['rom_path']).read_bytes();self.ram=bytearray.fromhex(state['ram_hex']);self.r=state['registers'].copy();self.r['H']=self.r['HL']>>8;self.r['L']=self.r['HL']&255;self.bank=state['rom_bank'];self.cycles=0;self.steps=0;self.stop=state['stop_pc'];self.copy=state['copy_pc'];self.reads={};self.ops=set()
 def read(self,a):
  if a<0x8000:
   i=a if a<0x4000 else self.bank*0x4000+a-0x4000;v=self.rom[i];self.reads[i]=v;return v
  assert a>=0xc000,hex(a)
  return self.ram[a-0xc000]
 def write(self,a,v):
  if 0x2000<=a<0x4000:self.bank=(v&127) or 1;return
  assert a>=0xc000,hex(a)
  self.ram[a-0xc000]=v&255
 def pair(self,i):
  return [self.r['B']*256+self.r['C'],self.r['D']*256+self.r['E'],self.r['H']*256+self.r['L'],self.r['SP']][i]
 def setpair(self,i,v):
  v&=65535
  if i==3:self.r['SP']=v
  else:a,b=[('B','C'),('D','E'),('H','L')][i];self.r[a]=v>>8;self.r[b]=v&255
 def reg(self,i):return self.read(self.pair(2)) if i==6 else self.r['BCDEHLA'[i if i<6 else 6]]
 def setreg(self,i,v):
  if i==6:self.write(self.pair(2),v)
  else:self.r['BCDEHLA'[i if i<6 else 6]]=v&255
 def byte(self):
  a=self.r['PC'];self.r['PC']=(a+1)&65535;return self.read(a)
 def word(self):return self.byte()+256*self.byte()
 def pop(self):
  s=self.r['SP'];v=self.read(s)+256*self.read((s+1)&65535);self.r['SP']=(s+2)&65535;return v
 def push(self,v):
  s=(self.r['SP']-2)&65535;self.r['SP']=s;self.write(s,v&255);self.write(s+1,v>>8)
 def cond(self,i):return [not(self.r['F']&128),bool(self.r['F']&128),not(self.r['F']&16),bool(self.r['F']&16)][i]
 def alu(self,g,v):
  a=self.r['A'];carry=int(bool(self.r['F']&16)) if g in [1,3] else 0
  if g<=1:
   x=a+v+carry;f=(128 if x&255==0 else 0)|(32 if (a&15)+(v&15)+carry>15 else 0)|(16 if x>255 else 0)
  elif g in [2,3,7]:
   x=a-v-carry;f=64|(128 if x&255==0 else 0)|(32 if (a&15)<(v&15)+carry else 0)|(16 if x<0 else 0)
  else:
   x=[a&v,a^v,a|v][g-4];f=(128 if x==0 else 0)|(32 if g==4 else 0)
  if g!=7:self.r['A']=x&255
  self.r['F']=f
 def run(self):
  while self.r['PC']!=self.stop:
   assert self.steps<20000,'bounded work exhausted';self.steps+=1
   pc=self.r['PC']
   if pc==self.copy:
    n=self.pair(0);self.cycles+=52*n+172;self.setpair(0,0);self.setpair(1,self.pair(1)+n);self.setpair(2,self.pair(2)+n);self.r['A']=self.bank;self.r['PC']=self.pop();continue
   op=self.byte();self.ops.add(op)
   if op==0:self.cycles+=4
   elif op in [1,17,33,49]:self.setpair(op>>4,self.word());self.cycles+=12
   elif op in [3,19,35,51]:self.setpair(op>>4,self.pair(op>>4)+1);self.cycles+=8
   elif op in [11,27,43,59]:self.setpair(op>>4,self.pair(op>>4)-1);self.cycles+=8
   elif op&0xc7==0x04 or op&0xc7==0x05:
    i=(op>>3)&7;old=self.reg(i);dec=bool(op&1);x=(old+(-1 if dec else 1))&255;self.setreg(i,x);self.r['F']=(self.r['F']&16)|(128 if x==0 else 0)|(64 if dec else 0)|(32 if ((old&15)==(0 if dec else 15)) else 0);self.cycles+=12 if i==6 else 4
   elif op&0xc7==6:i=(op>>3)&7;self.setreg(i,self.byte());self.cycles+=12 if i==6 else 8
   elif 0x40<=op<0x80:
    assert op!=0x76,'HALT in work';d=(op>>3)&7;s=op&7;self.setreg(d,self.reg(s));self.cycles+=8 if d==6 or s==6 else 4
   elif 0x80<=op<0xc0:self.alu((op>>3)&7,self.reg(op&7));self.cycles+=8 if op&7==6 else 4
   elif op in [0xc6,0xce,0xd6,0xde,0xe6,0xee,0xf6,0xfe]:self.alu((op>>3)&7,self.byte());self.cycles+=8
   elif op in [2,18,10,26,34,42,50,58]:
    i=0 if op in [2,10] else 1 if op in [18,26] else 2;a=self.pair(i)
    if op&8:self.r['A']=self.read(a)
    else:self.write(a,self.r['A'])
    if op in [34,42,50,58]:self.setpair(2,a+(-1 if op in [50,58] else 1))
    self.cycles+=8
   elif op in [9,25,41,57]:
    a=self.pair(2);v=self.pair(op>>4);x=a+v;self.setpair(2,x);self.r['F']=(self.r['F']&128)|(32 if (a&4095)+(v&4095)>4095 else 0)|(16 if x>65535 else 0);self.cycles+=8
   elif op in [0xe0,0xf0,0xe2,0xf2,0xea,0xfa]:
    a=(0xff00+self.byte()) if op in [0xe0,0xf0] else (0xff00+self.r['C']) if op in [0xe2,0xf2] else self.word()
    if op&16:self.r['A']=self.read(a)
    else:self.write(a,self.r['A'])
    self.cycles+=12 if op in [0xe0,0xf0] else 8 if op in [0xe2,0xf2] else 16
   elif op in [0x18,0x20,0x28,0x30,0x38]:
    d=self.byte();d=d-256 if d>=128 else d;take=op==0x18 or self.cond((op-0x20)//8)
    if take:self.r['PC']=(self.r['PC']+d)&65535
    self.cycles+=12 if take else 8
   elif op in [0xc3,0xc2,0xca,0xd2,0xda]:
    dest=self.word();take=op==0xc3 or self.cond((op-0xc2)//8)
    if take:self.r['PC']=dest
    self.cycles+=16 if take else 12
   elif op==0xe9:self.r['PC']=self.pair(2);self.cycles+=4
   elif op in [0xcd,0xc4,0xcc,0xd4,0xdc]:
    dest=self.word();take=op==0xcd or self.cond((op-0xc4)//8)
    if take:self.push(self.r['PC']);self.r['PC']=dest
    self.cycles+=24 if take else 12
   elif op in [0xc9,0xc0,0xc8,0xd0,0xd8]:
    take=op==0xc9 or self.cond((op-0xc0)//8)
    if take:self.r['PC']=self.pop()
    self.cycles+=16 if op==0xc9 else 20 if take else 8
   elif op in [0xc5,0xd5,0xe5,0xf5]:
    i=(op-0xc5)//16;v=self.r['A']*256+self.r['F'] if i==3 else self.pair(i);self.push(v);self.cycles+=16
   elif op in [0xc1,0xd1,0xe1,0xf1]:
    i=(op-0xc1)//16;v=self.pop()
    if i==3:self.r['A']=v>>8;self.r['F']=v&240
    else:self.setpair(i,v)
    self.cycles+=12
   elif op in [0x37,0x3f]:self.r['F']=(self.r['F']&128)|(16 if op==0x37 or not(self.r['F']&16) else 0);self.cycles+=4
   elif op==0x2f:self.r['A']^=255;self.r['F']|=96;self.cycles+=4
   elif op==0xcb:
    cb=self.byte();i=cb&7;g=cb>>6;b=(cb>>3)&7;old=self.reg(i)
    if g==1:self.r['F']=(self.r['F']&16)|32|(128 if not(old&(1<<b)) else 0)
    elif g>=2:self.setreg(i,old&~(1<<b) if g==2 else old|(1<<b))
    else:
     carry=int(bool(self.r['F']&16))
     if b==0:x=((old<<1)|(old>>7))&255;c=old>>7
     elif b==1:x=(old>>1)|((old&1)<<7);c=old&1
     elif b==2:x=((old<<1)|carry)&255;c=old>>7
     elif b==3:x=(old>>1)|(carry<<7);c=old&1
     elif b==4:x=(old<<1)&255;c=old>>7
     elif b==5:x=(old>>1)|(old&128);c=old&1
     elif b==6:x=((old<<4)|(old>>4))&255;c=0
     else:x=old>>1;c=old&1
     self.setreg(i,x);self.r['F']=(128 if x==0 else 0)|(16 if c else 0)
    self.cycles+=12 if i==6 and g==1 else 16 if i==6 else 8
   else:raise AssertionError(f'unsupported {op:02x} PC{pc:04x} bank{self.bank}')
  return self.cycles
if __name__=='__main__':
 b=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');results={}
 for c in ['city','1f','2f','3f','bedroom']:
  state=json.load(open(b/f'party-142-source-{c}-1/cpu-input.json'));vm=WorkCpu(state);count=vm.run();a=json.load(open(b/f'party-142-source-{c}-1/events.json'));start=next(e for e in a if e['routine']=='InitMapSprites');end=next(e for e in a if e['routine']=='EnableLCD');expected=end['cycles']-start['cycles'];print(c,count,expected,'steps',vm.steps,'delta',count-expected,flush=True);assert count==expected
  results[c]=dict(predicted=count,original=expected,steps=vm.steps,opcodes=sorted(vm.ops),read_rom_bytes=len(vm.reads))
 (b/'party-142-work-replay-verification.json').write_text(json.dumps(results,indent=2)+'\n')
