exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
b=root/'.task-tmp/fidelity-39-plus';cases=json.load(open(b/'party-143-sprite-work-cases.json'));rom=b/'movement-91-road-setup/road.gbc';state=(b/'party-142-setup-city/party.state').read_bytes()
p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);context={};records=[]
def entry(_):
 c=context['case'];context['start']=p._cycles()
 for symbol,key in [('wCurMap','map'),('wXCoord','x'),('wYCoord','y'),('wNumSprites','count')]:p.memory[symbols[symbol][1]]=c[key]
 for i,picture in enumerate(c['pictures']):p.memory[symbols['wSpriteStateData1'][1]+i*16]=picture
 context['entry']={key:int(getattr(p.register_file,key)) for key in ['A','B','C','D','E','F','HL','SP','PC']}
def end(_):
 if 'start' in context and 'end' not in context:context['end']=p._cycles()
p.hook_register(*symbols['InitMapSprites'],entry,None);p.hook_register(*symbols['EnableLCD'],end,None)
for c in cases:
 if c['kind'].startswith('actual-'):continue
 p.load_state(io.BytesIO(state));context.clear();context['case']=c;p.button_press('b')
 for _ in range(12):
  p.tick(1)
  if 'end' in context:break
 assert 'end' in context,c['kind']
 actual=context['end']-context['start'];assert actual==c['cycles'],(c['kind'],actual,c['cycles'])
 records.append(dict(kind=c['kind'],predicted=c['cycles'],original_cpu_cycles=actual,registers=context['entry']))
p.stop(save=False)
report=dict(reference_rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),initial_state_sha256=hashlib.sha256(state).hexdigest(),scope='Controlled diagnostic writes at InitMapSprites entry to map/position/count/picture RAM only; original ROM code and cycle execution unchanged. These are not ordinary travel/menu scenarios.',cases=records)
(b/'party-143-retail-work-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(len(records),'original emulator work matches')
