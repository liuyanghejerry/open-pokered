exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
b=root/'.task-tmp/fidelity-39-plus'
setups={'city':(b/'movement-91-road-setup/road.gbc',b/'movement-91-road-reference-False-1/pretrigger.state'),'1f':(b/'victory-95-source-setup-1f/reference.gbc',b/'victory-95-source-setup-1f/pretrigger.state'),'2f':(b/'victory-95-source-setup-2f2/reference.gbc',b/'victory-95-source-setup-2f2/pretrigger.state'),'3f':(b/'victory-100-source-setup-3f-hole/reference.gbc',b/'victory-100-source-setup-3f-hole/pretrigger.state')}
for case,(rom,state) in setups.items():
 d=b/f'party-142-setup-{case}';d.mkdir(exist_ok=True);p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(state.read_bytes()))
 def get(n):return int(p.memory[symbols[n][1]])
 def tap(k):p.button_press(k);p.tick(2);p.button_release(k);p.tick(120)
 if case!='bedroom':
  p.button_press('start');p.tick(40);p.button_release('start');p.tick(120);assert get('wMaxMenuItem') in [6,7];choice=int(get('wMaxMenuItem')==7)
  for _ in range(8):
   if get('wCurrentMenuItem')==choice:break
   tap('up')
  assert get('wCurrentMenuItem')==choice;tap('a')
 with (d/'party.state').open('wb') as f:p.save_state(f)
 (d/'provenance.json').write_text(json.dumps(dict(initial_state_sha256=hashlib.sha256(state.read_bytes()).hexdigest(),rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),map=get('wCurMap'),position=[get('wXCoord'),get('wYCoord')],scope='Actual START/party input from existing source state, no new RAM writes; original Victory fixtures have controlled positions, not proof ordinary travel.'),indent=2)+'\n');p.stop(save=False)
 for trial in [1,2]:
  out=b/f'party-142-source-{case}-{trial}';out.mkdir(exist_ok=True);p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((d/'party.state').read_bytes()));events=[];rows=[];now=[-1]
  def get(n):return int(p.memory[symbols[n][1]])
  def hook(n):
   a=p.register_file
   if n=='InitMapSprites':
    inp={'registers':{key:int(getattr(a,key)) for key in ['A','B','C','D','E','F','HL','SP','PC']},'ram_hex':bytes(p.memory[0xc000:0x10000]).hex(),'rom_bank':get('hLoadedROMBank'),'rom_path':str(rom),'rom_sha256':hashlib.sha256(rom.read_bytes()).hexdigest(),'stop_pc':symbols['EnableLCD'][1],'copy_pc':symbols['FarCopyData2'][1]}
    (out/'cpu-input.json').write_text(json.dumps(inp,indent=2)+'\n')
   events.append(dict(t=now[0],routine=n,cycles=p._cycles(),LY=int(p.memory[0xff44]),lcd=int(p.memory[0xff40]),palette=int(p.memory[0xff47]),A=int(a.A),BC=int(a.B)*256+int(a.C),DE=int(a.D)*256+int(a.E),HL=int(a.HL),sprite_count=get('wNumSprites'),sprite_set=get('wSpriteSetID'),pictures=list(p.memory[symbols['wSpriteStateData1'][1]:symbols['wSpriteStateData1'][1]+256:16])))
  names=['GBPalWhiteOutWithDelay3','RestoreScreenTilesAndReloadTilePatterns','ReloadMapSpriteTilePatterns','InitMapSprites','LoadPlayerSpriteGraphics','LoadFontTilePatterns','LoadTextBoxTilePatterns','DisableLCD','EnableLCD','FarCopyData2','CopyVideoData','CopyVideoDataDouble','RedisplayStartMenu','DrawStartMenu','Joypad']
  for n in names:p.hook_register(*symbols[n],hook,n)
  for t in range(-1,80):
   now[0]=t
   if t==0:p.button_press('b')
   if t==2:p.button_release('b')
   if t>=0:p.tick(1)
   p.screen.image.save(out/f'frame-{t+1:04}.png');rows.append(dict(t=t,palette=int(p.memory[0xff47]),white=bool((p.screen.ndarray[:,:,:3]==255).all()),menu_item=get('wCurrentMenuItem')))
  (out/'events.json').write_text(json.dumps(events,indent=2)+'\n');(out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');p.stop(save=False)
  if trial==2:
   a=b/f'party-142-source-{case}-1';assert (a/'events.json').read_bytes()==(out/'events.json').read_bytes();assert (a/'frames.json').read_bytes()==(out/'frames.json').read_bytes();assert all((a/f'frame-{t+1:04}.png').read_bytes()==(out/f'frame-{t+1:04}.png').read_bytes() for t in range(-1,80))
  if case=='city':assert all((b/'party-140-source-0-1'/f'frame-{t+1:04}.png').read_bytes()==(out/f'frame-{t+1:04}.png').read_bytes() for t in range(-1,80))
  print(case,trial,[(e['t'],e['routine'],e['BC']) for e in events if e['routine'] in ['GBPalWhiteOutWithDelay3','InitMapSprites','EnableLCD','CopyVideoData','CopyVideoDataDouble','RedisplayStartMenu']],flush=True)
