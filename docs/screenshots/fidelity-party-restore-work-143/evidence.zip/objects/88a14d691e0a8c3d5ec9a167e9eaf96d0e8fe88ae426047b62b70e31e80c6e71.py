from pathlib import Path
import hashlib,json,zipfile
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';paths=[]
for case in ['city','1f','2f','3f','bedroom']:
 for trial in [1,2]:
  d=b/f'party-142-source-{case}-{trial}'
  for p in d.iterdir():
   if p.suffix in ['.json','.png']:paths.append((p,p.relative_to(b)))
 a=b/f'party-142-source-{case}-1';d=b/f'party-142-source-{case}-2'
 for p in a.iterdir():assert p.read_bytes()==(d/p.name).read_bytes(),p
 for p in (b/f'party-142-setup-{case}').iterdir():paths.append((p,p.relative_to(b)))
for name in ['party-142-work-inputs.log','party-142-bedroom-work-inputs.log','party-142-work-replay-verification.json','party-143-sprite-work-cases.json','party-143-formula-verification-a1.log','party-143-formula-verification-a2.log','party-143-formula-verification-a3.log','party-143-native-work-build-a1.log','party-143-native-work-build-a2.log','party-143-no-std-check.log','party-143-retail-work-verification.json','party-143-retail-work-verification.log']:
 paths.append((b/name,name))
for name in ['record_party_work_inputs_142.py','record_party_work_inputs_142_original4.py','replay_sprite_work_142.py','replay_sprite_trace_143.py','sprite_work_formula_143.py','verify_sprite_work_formula_143.py','verify_sprite_work_retail_143.py','seal_party_work_143.py']:
 paths.append((b/'stats-59-tools'/name,'tools/'+name))
archive=b/'party-143-work-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 m={};objects=set()
 for p,label in paths:
  data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();obj='objects/'+sha+p.suffix;m[str(label)]={'object':obj,'sha256':sha,'bytes':len(data)}
  if obj not in objects:z.writestr(obj,data);objects.add(obj)
 z.writestr('manifest.json',json.dumps(m,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 m=json.loads(z.read('manifest.json'))
 for v in m.values():assert hashlib.sha256(z.read(v['object'])).hexdigest()==v['sha256']
verdict=dict(paths=len(paths),objects=len(objects),source_unique_frames=405,each_repeated_twice=True,diagnostic_work_cases=496,actual_entry_work_cases=5,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),scope='501 Rust work-model matches: five actual captures plus 496 original-emulator controlled diagnostic work measurements. Instruction-work model, not a native runtime restoration fix. Diagnostic original routine executions do not establish ordinary gameplay. No measured elapsed duration used to predict cycles.')
(b/'party-143-work-archive-verification.json').write_text(json.dumps(verdict,indent=2)+'\n');print(verdict)
