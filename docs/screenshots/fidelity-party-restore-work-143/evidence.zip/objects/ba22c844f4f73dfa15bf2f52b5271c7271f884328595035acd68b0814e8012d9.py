import json, random, copy
from sprite_work_formula_143 import ROOT, work_cost
from replay_sprite_work_142 import WorkCpu
base=json.load(open(ROOT/'party-142-source-city-1/cpu-input.json'));rng=random.Random(143);cases=[]
def run(state,kind):
 vm=WorkCpu(state);expected=vm.run();got=work_cost(state)
 assert got==expected,(kind,got,expected)
 ram=bytearray.fromhex(state['ram_hex'])
 cases.append(dict(kind=kind,map=ram[0x135e],x=ram[0x1362],y=ram[0x1361],count=ram[0x14e1],pictures=[ram[0x100+i*16] for i in range(16)],cycles=expected))
for name in ['city','1f','2f','3f','bedroom']:
 run(json.load(open(ROOT/f'party-142-source-{name}-1/cpu-input.json')),f'actual-{name}')
for m in range(37):
 for x,y in [(0,0),(255,255),(42,7),(43,13),(54,12),(55,7),(61,8),(62,0)]:
  state=copy.deepcopy(base);ram=bytearray.fromhex(state['ram_hex']);ram[0x135e]=m;ram[0x1362]=x;ram[0x1361]=y
  for i in range(1,16):ram[0x100+i*16]=0
  state['ram_hex']=ram.hex();vm=WorkCpu(state);vm.run();sets=list(vm.ram[0x14de:0x14de+11])
  # Preserve valid map-specific sprite membership. Source wSpriteSet address
  # is loaded from symbols, rather than guessed below.
  syms={line.split()[1]:int(line.split()[0].split(':')[1],16) for line in (ROOT.parent/'stats-59-reference-sgvaaq/pokered.sym').read_text().splitlines() if len(line.split())==2 and ':' in line.split()[0]}
  addr=syms['wSpriteSet']-0xc000;sets=list(vm.ram[addr:addr+11])
  for i in range(1,16):ram[0x100+i*16]=rng.choice(sets+[0]*4)
  state['ram_hex']=ram.hex();run(state,f'outdoor-{m}-{x}-{y}')
for trial in range(200):
 state=copy.deepcopy(base);ram=bytearray.fromhex(state['ram_hex']);ram[0x135e]=rng.randrange(37,223);n=rng.randrange(16);ram[0x14e1]=n
 walking=rng.sample(range(1,61),rng.randrange(1,10));pool=walking+list(range(61,73))
 for i in range(1,16):ram[0x100+i*16]=rng.choice(pool) if i<=n else 0
 state['ram_hex']=ram.hex();run(state,f'indoor-{trial}')
(ROOT/'party-143-sprite-work-cases.json').write_text(json.dumps(cases,indent=2)+'\n');print(len(cases),'independent source/formula matches')
