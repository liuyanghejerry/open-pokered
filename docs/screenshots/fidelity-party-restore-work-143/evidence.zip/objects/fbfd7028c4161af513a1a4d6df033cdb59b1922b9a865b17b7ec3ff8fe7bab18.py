from replay_sprite_work_142 import WorkCpu
import json
from pathlib import Path
DEBUG=False
ROOT=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
def load_cost(ids,n,rom):
 if not n:return 16+4+8+16
 cost=16+4+12+4+8+12+4+12 + 16*48-4 +12
 bases=ids.copy();four=0
 for i in range(1,n+1):
  before=cost
  cost+=12
  duplicate=None
  for j in range(1,i):
   cost+=40
   if ids[j]==ids[i]:cost+=8+8+16;duplicate=j;break
   cost+=8+8+12+4+8+4+12
  if duplicate is not None:
   cost+=8+8+8;bases[i]=bases[duplicate]
  else:
   cost+=44+12+8
   slot=1
   for j in range(1,i):
    cost+=32+8+8
    if bases[j]>=11:cost+=12;continue
    cost+=8+4
    if bases[j]<slot:cost+=12;continue
    cost+=8+4+12;slot=bases[j]
   cost+=36+4+4+16+8+4+8
   sid=ids[i]
   if sid<61:cost+=12+12;slot+=1
   else:cost+=8+12+12+8+12;slot=11+four
   bases[i]=slot
   cost+=8+12+4+4+4+4+16+16+12
   offset=(sid-1)*4
   cost+=12 if offset<256 else 8+4
   offset&=255
   cost+=4+4+(12 if offset+0x27<256 else 8+4)
   cost+=16+24+68+16+16+16+12+12+12+8
   if slot<11:
    cost+=8+4+4+(slot-1)*24-4+12
   else:
    cost+=12+12+12+4
    if four:cost+=12
    else:cost+=8+12+4+12;four=1
   cost+=12+12+12+16+16+4+4+12+4+16+8+8
   pointer=0x5*0x4000+0x7b27-0x4000+(sid-1)*4
   length=rom[pointer+2];source=rom[pointer]+256*rom[pointer+1]
   cost+=4+8+24+52*length+172
   cost+=12+12+12+8
   if slot<11:
    cost+=8+16+24+68+16+8+4+4+(12 if (source&255)+192<256 else 8+4)+16+8+8+12+12+8+16+4+4+12+24+52*length+172+12
   else:cost+=12
   cost+=12+12+12
  cost+=4+8+4+4+(16 if i<n else 12)
  if DEBUG: print("loop",i,ids[i],cost-before)
 cost+=12+8+16*44-4+16
 return cost

def work_cost(state):
 vm=WorkCpu(state);r=vm.ram;rom=vm.rom
 ids=[r[0x100+i*16] for i in range(16)];n=r[0x14e1];m=r[0x135e]
 c=24+16+8
 if m>=37:
  c+=20+8+12+12+16*60-4
  c+=load_cost(ids,n,rom)
 else:
  c+=8+12+4+4+(12 if m+0x64<256 else 8+4)
  setid=rom[5*0x4000+0x7a64-0x4000+m]
  c+=8+8
  if setid>=0xf0:
   c+=24
   x,y=r[0x1362],r[0x1361]
   if setid==0xf8:
    c+=8+12+12+8+8+8
    if x<43:c+=20;setid=1
    else:
     c+=8+8+8+8
     if x>=62:c+=20;setid=10
     else:
      c+=8+8+8+8+(12 if x>=55 else 8+8)
      line=8 if x>=55 else 13
      c+=16+4+8
      if y<line:c+=20;setid=10
      else:c+=8+8+16;setid=1
   else:
    offset=((setid&15)-1)*4
    table=5*0x4000+0x7a89-0x4000+offset
    direction,line,left,right=rom[table:table+4]
    coord=x if direction==1 else y
    c+=8+8+12+8+4+8+8+4+4+12
    c+=8+8+8+4+(12 if direction==1 else 8)+16+(0 if direction==1 else 12)+4+(12 if coord<line else 8+8)+8+16
    setid=left if coord<line else right
  else:c+=12
  c+=0+4+16+8+8+16+4+8
  c+=4+16+4+4+8+4+8+8+4+4+12+4+4+(12 if ((setid-1)*11)+0xb9<256 else 8+4)
  c+=12+8+8+12
  sets=list(rom[5*0x4000+0x7ab9-0x4000+(setid-1)*11:][:11]);copies=[1]+sets+[0]*4
  c+=11*80-4+8+4*44-4+16+16+8+16+24
  if DEBUG: print("before load",c)
  c+=load_cost(copies,11,rom)
  if DEBUG: print("after load",c)
  c+=12+16+12+8+15*44-4
  c+=12
  if DEBUG: print("before store",c)
  for i in range(1,16):
   sid=ids[i];c+=8+8+4
   if not sid:c+=12
   else:
    c+=8+4+12
    idx=sets.index(sid)+1
    c+=idx*36-4+4
   c+=16+4+8+4+4+4+8+12+8+4+4+4+(12 if i<15 else 8)
  if DEBUG: print("after store",c)
  c+=4+16+20
 # Bankswitch return to caller, ending immediately before EnableLCD call entry.
 c+=12+4+12+16+16+24
 return c
if __name__=='__main__':
 for case in ['city','1f','2f','3f','bedroom']:
  s=json.load(open(ROOT/f'party-142-source-{case}-1/cpu-input.json'));v=WorkCpu(s);want=v.run();got=work_cost(s);print(case,got,want,got-want)
