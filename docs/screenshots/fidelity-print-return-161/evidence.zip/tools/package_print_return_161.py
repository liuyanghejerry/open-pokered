from pathlib import Path
import json,hashlib,shutil,subprocess,zipfile
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';base=root/'.task-tmp/fidelity-93-master-before';ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c');out=w/'docs/screenshots/fidelity-print-return-161';out.mkdir(parents=True,exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
helper=(r/'typing-160-capture-helper.rs').read_bytes()
for tree,head in [(base,'31b1eda3112514d6bc803af559ec7f7c9e20374f'),(w,'f4921b84c8ab035bc71c143c3eea25492476a02d')]:
 old=subprocess.check_output(['git','show',head+':crates/pokered-app/src/game.rs'],cwd=tree);new=(tree/'crates/pokered-app/src/game.rs').read_bytes();boundary=old.index(b'#[cfg(test)]\nmod session_guard_tests');assert old[:boundary]==new[:boundary];assert new.endswith(helper)
for side in ['before','after-final']:
 a=r/f'audit-161-{side}-counter-1';b=r/f'audit-161-{side}-counter-2'
 assert all(f.read_bytes()==(b/f.name).read_bytes() for f in a.iterdir())
 for trial in [1,2]:assert '1 passed' in (r/f'audit-161-{side}-counter-{trial}.log').read_text()
original=r/'audit-160-original-typing-a-0-1';repeat=r/'audit-160-original-typing-a-0-2';assert all(f.read_bytes()==(repeat/f.name).read_bytes() for f in original.iterdir())
before=load(r/'audit-161-before-counter-1/frames.json');after=load(r/'audit-161-after-final-counter-1/frames.json');assert [f['input_bits'] for f in before]==[f['input_bits'] for f in after];assert before[120]['overworld']['pending_choice'] is None;assert after[120]['overworld']['pending_choice']['options']==['YES','NO'];first=next(f['t'] for f in after if (f['letters'] or 0)>0);last=next(f['t'] for f in after if f['letters']==30);entry=next(f['t'] for f in after if 'ShowChoice' in (f['overworld']['active_script_effect'] or {}));assert (first,last,entry)==(3,90,93);assert entry-first==90 and entry-last==3
es=load(original/'events.json');choice=next(f for f in es if f['routine']=='YesNoChoice');letters=[f for f in es if f['routine']=='PrintLetterDelay' and f['cycles']<choice['cycles']];assert (letters[0]['t'],letters[-1]['t'],choice['t'])==(24,111,114);assert len(letters)==30
assert '2739 passed; 0 failed' in (r/'audit-161-core-tests-a3.log').read_text();assert '210 passed; 0 failed' in (r/'audit-161-app-tests-a2.log').read_text();assert '262 passed; 0 failed' in (r/'audit-161-data-tests.log').read_text();compare=(r/'audit-161-gba-compare-a2.log').read_text();assert len([s for s in compare.splitlines() if ' -> ' in s])==31 and 'within the configured regression budget' in compare
provenance=load(r/'audit-161-gba-provenance.json')
for name,sha in provenance['sources'].items():assert h(w/name)==sha
assert not provenance['baseline_changed']
for name,source in [('before.png','audit-161-before-counter-1/frame-0120.png'),('after.png','audit-161-after-final-counter-1/frame-0120.png'),('original-reference.png','audit-160-original-typing-a-0-1/frame-0120.png')]:shutil.copy2(r/source,out/name)
for name,newname in [('audit-161-gba-provenance.json','gba-provenance.json'),('audit-161-gba-result-a2.json','gba-result.json'),('audit-161-gba-compare-a2.log','gba-compare.log')]:shutil.copy2(r/name,out/newname)
entries={}
for pattern in ['audit-161-before-counter-*','audit-161-after-counter-*','audit-161-after-final-counter-*','audit-161-*.log','audit-161-*-graph.txt','audit-160-original-typing-a-0-*']:
 for p in r.glob(pattern):
  if p.is_dir():
   for f in p.rglob('*'):
    if f.is_file():entries[str(f.relative_to(r))]=f
  elif p.is_file():entries[str(p.relative_to(r))]=p
for name in provenance['sources']:entries['source/'+name]=w/name
entries['baseline-source/game.rs']=base/'crates/pokered-app/src/game.rs';entries['tools/typing_capture.rs']=r/'typing-160-capture-helper.rs'
for name in ['package_print_return_161.py','probe_typing_tail_160.py','probe_typing_pulse_original_159.py','record_retail_stats.py']:entries['tools/'+name]=r/'stats-59-tools'/name
for name in ['home/text.asm','home/text_script.asm','home/print_text.asm','home/joypad2.asm','scripts/SafariZoneGate.asm','text/SafariZoneGate.asm','scripts/Museum1F.asm','text/Museum1F.asm','engine/menus/naming_screen.asm','data/text/text_2.asm']:entries['reference-source/'+name]=ref/name
manifest={name:h(p) for name,p in entries.items()}
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip') as z:
 for name,sha in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
v=dict(base='31b1eda3112514d6bc803af559ec7f7c9e20374f',parent='f4921b84c8ab035bc71c143c3eea25492476a02d',reference='fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c',base_binary_sha256=h(r/'audit-160-master-final-immutable/pokered_app'),final_binary_sha256=h(r/'audit-161-after-final-immutable/pokered_app'),ROM_sha256=h(r/'safari-147-source-setup/reference.gbc'),SRAM_sha256=h(r/'safari-147-source-setup/safari-one-step.sav'),helper_sha256=h(r/'typing-160-capture-helper.rs'),paired_frame=120,identical_inputs=True,repeat_byte_exact=True,native=dict(first=first,last=last,return_to_choice=entry,choice_initialized=94),original=dict(first=24,last=111,return_to_choice=114),relative_last_wait=3,relative_first_to_choice=90,tests='core2739;app210,27ignored;data262;GBA31 unchanged baseline,21 final fileSHAexact',archive_sha256=h(out/'evidence.zip'),archive_files=len(manifest)+1,images={p.name:h(p) for p in out.glob('*.png')},scope=['Controlled original SRAM Continue then counter warp; not normal paid entry or finalhead mainline proof.','Original/native firstglyph24/3 differ: relative PrintText return only, no absolute startup/LCD parity claim.','Confirmed auto-return call sites migrated: Safari information question, Museum ticket questions at two entry paths and AMBER question, shared gifted-Pokemon nickname question. Other call sites and full text session boundary/init/close still pending.','Native choice command dispatched relative90; menu initialized next tick. Original YesNoChoice entry is relative90; actual LCD transfer not equated.'])
(out/'verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(json.dumps(v,ensure_ascii=False))
