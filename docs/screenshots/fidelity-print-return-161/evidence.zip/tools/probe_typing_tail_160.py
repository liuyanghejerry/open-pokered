exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';setup=r/'safari-147-source-setup'
for pulse in [False,True]:
 for button in ["a","b"]:
  for trial in [1,2]:
   out=r/f'audit-160-original-typing-{button}-{int(pulse)}-{trial}';out.mkdir(exist_ok=True);p=PyBoy(str(setup/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'pretrigger.state').read_bytes()));p.memory[symbols['wNumSafariBalls'][1]]=0
   for t in range(701):
    if t>=100 and t%30==10:p.button_press('a')
    if t>=100 and t%30==12:p.button_release('a')
    p.tick(1)
   # The replay ends on an A-press frame. Release explicitly before navigation.
   p.button_release('a');p.tick(30)
   get=lambda name:int(p.memory[symbols[name][1]])
   def move(button,name,target):
    p.button_press(button)
    for _ in range(160):
     p.tick(1)
     if get(name)==target:break
    else:raise AssertionError((button,name,target,get(name)))
    p.button_release(button);p.tick(30)
   move('down','wYCoord',4);move('left','wXCoord',3)
   p.button_press('left');p.tick(8);p.button_release('left');p.tick(8)
   assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(156,3,4)
   events=[];now=[-1];first=[None];letters=[0];rows=[]
   def hook(name):
    hl=int(p.register_file.HL)
    if name=='PrintLetterDelay':
     if first[0] is None:first[0]=now[0]
     letters[0]+=1
    events.append(dict(t=now[0],routine=name,cycles=p._cycles(),HL=hl,A=int(p.register_file.A),letters=letters[0],options=get('wOptions'),letter_flags=get('wLetterPrintingDelayFlags'),status5=get('wStatusFlags5'),joy_held=get('hJoyHeld'),joy6=get('hJoy6'),joy7=get('hJoy7')))
   for name in ['DisplayTextID','DisplayTextIDInit','PrintText','PrintText_NoCreatingTextBox','PlaceString','PrintLetterDelay','PlaySound','YesNoChoice','WaitForTextScrollButtonPress','JoypadLowSensitivity']:p.hook_register(*symbols[name],hook,name)
   for t in range(145):
    now[0]=t
    if t==0:p.button_press('a')
    if t==2:p.button_release('a')
    if pulse and first[0] is not None:
     if t==first[0]+10:p.button_press(button)
     if t==first[0]+12:p.button_release(button)
    p.tick(1);rows.append(dict(t=t,first_letter=first[0],letters=letters[0],options=get('wOptions'),joy_held=get('hJoyHeld'),joy6=get('hJoy6'),joy7=get('hJoy7')));p.screen.image.save(out/f'frame-{t:04}.png')
   (out/'events.json').write_text(json.dumps(events,indent=2)+'\n');(out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');p.stop(save=False)
   if trial==2:
    for f in out.iterdir():assert f.read_bytes()==(r/f'audit-160-original-typing-{button}-{int(pulse)}-1'/f.name).read_bytes(),f
   print(pulse,trial,'first',first[0],'relative',[(x['t']-first[0],x['letters'],x['joy_held']) for x in rows if first[0] is not None and 8<=x['t']-first[0]<=18],flush=True)
