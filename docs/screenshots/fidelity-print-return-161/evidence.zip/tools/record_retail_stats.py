import os,pathlib,io,re,json,hashlib
os.environ['SDL_AUDIODRIVER']='dummy'
from pyboy import PyBoy
root=pathlib.Path('/home/jerry/develop/open-pokered');tools=root/'.task-tmp/fidelity-39-plus/stats-59-tools'
source=pathlib.Path((tools/'reference-dir.txt').read_text().strip());run=pathlib.Path((tools/'reference-run-dir.txt').read_text().strip())
symbols={}
for line in (source/'pokered.sym').read_text().splitlines():
 m=re.match(r'([0-9a-fA-F]+):([0-9a-fA-F]+) (\S+)',line)
 if m:symbols[m[3]]=(int(m[1],16),int(m[2],16))
for trial in [1,2]:
 out=root/f'.task-tmp/fidelity-39-plus/stats-59-reference-{trial}';out.mkdir(exist_ok=True)
 p=PyBoy(str(run/'retail-save.gbc'),window='null',sound_emulated=True);p.set_emulation_speed(0)
 p.load_state(io.BytesIO((run/'retail-stats-pretrigger.state').read_bytes()));p.set_color_palette([0xffffff,0xaaaaaa,0x555555,0]);events=[];index=[-1]
 def callback(ctx):
  name=ctx
  events.append({'t':index[0],'routine':name,'A':int(p.register_file.A),'emulator_frame':p.frame_count})
 for name in ['PlaySound','PlayCry','StatusScreen','GBPalWhiteOutWithDelay3','GBPalNormal','WaitForTextScrollButtonPress','LoadFlippedFrontSpriteByMonIndex']:
  b,a=symbols[name];p.hook_register(b,a,callback,name)
 records=[]
 for t in range(-1,240):
  index[0]=t
  if t==0:p.button_press('a')
  if t==2:p.button_release('a')
  if t>=0:p.tick(1)
  p.screen.image.save(out/f'frame-{t+1:04}.png')
  (out/f'pcm-{t+1:04}.i8').write_bytes(p.sound.ndarray.tobytes())
  records.append({'t':t,'frame':p.frame_count,'palette':int(p.memory[0xff47]),'apu_registers':[int(p.memory[a]) for a in range(0xff10,0xff27)],'state':{k:int(p.memory[symbols[k][1]]) for k in ['wPartyCount','wCurMap','wWhichPokemon','wCurrentMenuItem','wIsInBattle','wCurPartySpecies']}})
 (out/'frames.json').write_text(json.dumps(records,indent=2));(out/'events.json').write_text(json.dumps(events,indent=2))
 (out/'provenance.json').write_text(json.dumps({'rom':'retail Red','source':'fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c','sha1':hashlib.sha1((run/'retail-save.gbc').read_bytes()).hexdigest(),'setup':'DEBUG Blue SRAM saved via actual SAVE; loaded via retail Continue; actual party menu input','snapshot_sha256':hashlib.sha256((run/'retail-stats-pretrigger.state').read_bytes()).hexdigest(),'dmg_rgb_palette':[16777215,11184810,5592405,0],'trigger':'A held 2 frames then release; one PNG per emulator frame'},indent=2))
 p.stop(save=False)
 print(trial,events,flush=True)
