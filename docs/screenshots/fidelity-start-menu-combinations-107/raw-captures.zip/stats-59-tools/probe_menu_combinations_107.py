exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/victory-100-source-setup-3f-hole';summary=[]

summary=[]
for keys in [('up','a'),('down','a'),('up','b'),('down','b'),('up','start'),('down','start'),('up','down')]:
 for trial in [1,2]:
  p=PyBoy(str(setup/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'pretrigger.state').read_bytes()));events=[];rows=[];now=[-1]
  def hook(name):events.append({'t':now[0],'routine':name,'a':p.register_file.A})
  for name in ['PlaySound','Joypad','DrawStartMenu','RedisplayStartMenu','CloseStartMenu','StartMenu_Pokemon','StartMenu_Pokedex','StartMenu_Item']:
   p.hook_register(*symbols[name],hook,name)
  for t in range(145):
   now[0]=t
   for at,key,pressed in [(0,'right',True),(16,'right',False),(71,'start',True),(111,'start',False)]:
    if t==at:(p.button_press if pressed else p.button_release)(key)
   if t==120:
    for key in keys:p.button_press(key)
   if t==122:
    for key in keys:p.button_release(key)
   p.tick(1)
   rows.append({'t':t,'current_item':int(p.memory[symbols['wCurrentMenuItem'][1]]),'held':int(p.memory[symbols['hJoyHeld'][1]]),'pressed':int(p.memory[symbols['hJoyPressed'][1]])})
  p.stop(save=False);summary.append({'keys':keys,'trial':trial,'events':events,'rows':rows})
  print(keys,trial,rows[120:123],[e for e in events if e['t']>=120 and e['routine']!='Joypad'],flush=True)
(root/'.task-tmp/fidelity-39-plus/menu-107-source-combinations.json').write_text(json.dumps(summary,indent=2))
