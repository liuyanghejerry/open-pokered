from pathlib import Path
import json,hashlib,zipfile
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';w=r/'.task-tmp/fidelity-91-plus-checkout';paths=[]
for prefix in ['party-140-source','party-144-native','party-144-master']:
 for probe in [0,1]:
  for trial in [1,2]:
   d=b/f'{prefix}-{probe}-{trial}'
   for p in d.iterdir():
    if p.suffix in ['.json','.png']:paths.append((p,p.relative_to(b)))
for trial in [1,2]:
 for p in (b/f'party-144-source-held-1-{trial}').iterdir():
  if p.suffix in ['.json','.png']:paths.append((p,p.relative_to(b)))
for p in (b/'party-144-source-held-setup').iterdir():paths.append((p,p.relative_to(b)))
for name in ['party-144-runtime-build-a1.log','party-144-runtime-build-a2.log','party-144-runtime-build-a3.log','party-144-runtime-build-a4.log','party-144-runtime-build-a5.log','party-144-runtime-build-a6.log','party-144-master-capture-build.log','party-144-master-capture-build-a2.log','party-144-master-capture.log','party-144-native-capture-a3.log','party-144-source-held.log','party-144-build-provenance.json','party-144-core-lifecycle-tests.log','party-144-old-regression-a1.log','party-144-actual-input-regression-a1.log','party-144-actual-input-cache-regression-a2.log','party-144-actual-input-cache-regression-a3.log','party-144-full-core-lib-tests.log','party-144-full-app-lib-tests.log','party-144-gba-source-provenance.json','party-144-gba-build.log','party-144-gba-result.json','party-144-gba-timer.log','party-144-gba-compare.log']:
 paths.append((b/name,name))
for name in ['record_party_native_144.py','record_party_master_144.py','record_party_held_144.py','report_party_return_144.py','seal_party_return_144.py','party_restore_capture_140.rs']:paths.append((b/'stats-59-tools'/name,'tools/'+name))
paths.append((w/'crates/pokered-app/tests/fixtures/party-restore-road-140.sav','fixtures/party-restore-road-140.sav'))
paths.append((w/'docs/screenshots/fidelity-party-return-144/verification.json','verification.json'))
archive=b/'party-144-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 m={};objects=set()
 for p,label in paths:
  data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();obj='objects/'+sha+p.suffix;m[str(label)]={'object':obj,'sha256':sha,'bytes':len(data)}
  if obj not in objects:z.writestr(obj,data);objects.add(obj)
 z.writestr('manifest.json',json.dumps(m,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 m=json.loads(z.read('manifest.json'))
 for v in m.values():assert hashlib.sha256(z.read(v['object'])).hexdigest()==v['sha256']
verdict=dict(paths=len(paths),objects=len(objects),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),scope='Actual SRAM/inputs from master and provisional fix plus original short/held probe; raw captures preserved. Native/master repeat comparison excludes only latent independently initialized overworld.rng.seed and script_engine.interp.host.rng_state. Cross-engine equality compares decoded RGB, not encoder bytes. No full pixel parity outside72 white frames, no global-phase/five-scene native claim.')
(b/'party-144-archive-verification.json').write_text(json.dumps(verdict,indent=2)+'\n');print(verdict)
