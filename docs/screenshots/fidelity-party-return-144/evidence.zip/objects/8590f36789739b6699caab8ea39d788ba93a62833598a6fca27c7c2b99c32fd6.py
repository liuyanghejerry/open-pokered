exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
b=root/'.task-tmp/fidelity-39-plus';out=b/'party-144-source-held-setup';out.mkdir(exist_ok=True)
p=PyBoy(str(b/'movement-91-road-setup/road.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((b/'movement-91-road-reference-False-1/pretrigger.state').read_bytes()))
def get(n):return int(p.memory[symbols[n][1]])
def tap(k):p.button_press(k);p.tick(2);p.button_release(k);p.tick(120)
assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(1,20,30)
p.button_press('start');p.tick(40);p.button_release('start');p.tick(120)
print('start state',{n:get(n) for n in ['wMaxMenuItem','wCurrentMenuItem','wFontLoaded','wPartyCount']},flush=True);p.screen.image.save(out/'start.png');assert get('wMaxMenuItem') in [6,7];pokemon_item=1 if get('wMaxMenuItem')==7 else 0
for _ in range(8):
 if get('wCurrentMenuItem')==pokemon_item:break
 tap('up')
assert get('wCurrentMenuItem')==pokemon_item;tap('a');p.screen.image.save(out/'party.png');assert get('wPartyCount')>0
with (out/'party.state').open('wb') as f:p.save_state(f)
p.stop(save=False)
for probe in [True]:
 for trial in [1,2]:
  d=b/f'party-144-source-held-{int(probe)}-{trial}';d.mkdir(exist_ok=True);p=PyBoy(str(b/'movement-91-road-setup/road.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((out/'party.state').read_bytes()));events=[];rows=[];now=[-1]
  def get(n):return int(p.memory[symbols[n][1]])
  def hook(n):events.append(dict(t=now[0],routine=n,cycles=p._cycles(),LY=int(p.memory[0xff44]),palette=int(p.memory[0xff47]),A=int(p.register_file.A),menu_item=get('wCurrentMenuItem')))
  for n in ['GBPalWhiteOutWithDelay3','RestoreScreenTilesAndReloadTilePatterns','ReloadMapSpriteTilePatterns','LoadFontTilePatterns','LoadPlayerSpriteGraphics','DisableLCD','EnableLCD','CopyVideoData','RedisplayStartMenu','DrawStartMenu','HandleMenuInput','Joypad']:
   p.hook_register(*symbols[n],hook,n)
  for t in range(-1,80):
   now[0]=t
   if t==0:p.button_press('b')
   if t==2:p.button_release('b')
   if probe:
    if t==10:p.button_press('down')
    # DOWN remains held through the first resumed Joypad.
    if t==16:p.button_press('a')
    if t==18:p.button_release('a')
   if t>=0:p.tick(1)
   p.screen.image.save(d/f'frame-{t+1:04}.png');rows.append(dict(t=t,palette=int(p.memory[0xff47]),white=bool((p.screen.ndarray[:,:,:3]==255).all()),menu_item=get('wCurrentMenuItem'),party_type=get('wPartyMenuTypeOrMessageID'),font=get('wFontLoaded')))
  (d/'events.json').write_text(json.dumps(events,indent=2)+'\n');(d/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');p.stop(save=False)
  if trial==2:
   a=b/f'party-144-source-held-{int(probe)}-1';assert (a/'events.json').read_bytes()==(d/'events.json').read_bytes();assert (a/'frames.json').read_bytes()==(d/'frames.json').read_bytes();assert all((a/f'frame-{t+1:04}.png').read_bytes()==(d/f'frame-{t+1:04}.png').read_bytes() for t in range(-1,80))
  print(probe,trial,[(e['t'],e['routine']) for e in events if e['routine'] in ['GBPalWhiteOutWithDelay3','RestoreScreenTilesAndReloadTilePatterns','LoadPlayerSpriteGraphics','LoadFontTilePatterns','RedisplayStartMenu','DrawStartMenu']], 'whiteframes',[r['t'] for r in rows if r['white']],flush=True)
