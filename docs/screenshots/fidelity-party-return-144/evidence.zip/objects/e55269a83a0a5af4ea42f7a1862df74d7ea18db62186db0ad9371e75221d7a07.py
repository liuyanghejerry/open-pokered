from pathlib import Path
import os,subprocess,json
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';w=r/'.task-tmp/fidelity-91-plus-checkout';exe=r/'.task-tmp/fidelity-18-27/target/debug/deps/pokered_app-3ecc077a95dd783d'
for probe in [0,1]:
 for trial in [1,2]:
  out=b/f'party-144-native-{probe}-{trial}';env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(r/'.task-tmp/fidelity-18-27'),FIDELITY_PARTY_RESTORE_CAPTURE=str(out),FIDELITY_PARTY_RESTORE_SRAM=str(b/'movement-91-road-setup/road.sav'))
  if probe:env['FIDELITY_PARTY_RESTORE_PROBE']='1'
  with (b/f'party-144-native-{probe}-{trial}.log').open('w') as f:result=subprocess.run([str(exe),'game::link_stats_cry_fidelity_tests::capture_actual_party_restore_140','--exact','--ignored','--nocapture','--test-threads=1'],cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
  assert result.returncode==0,(probe,trial,result.returncode)
  assert "1 passed" in (b/f'party-144-native-{probe}-{trial}.log').read_text(),"no capture test executed"
  rows=json.loads((out/'frames.json').read_text());assert len(rows)==81
  if trial==2:
   a=b/f'party-144-native-{probe}-1';left=json.loads((a/'frames.json').read_text());right=json.loads((out/'frames.json').read_text());
   for records in [left,right]:
    for row in records:
     row['overworld']['rng'].pop('seed');row['overworld']['script_engine']['interp']['host'].pop('rng_state')
   assert left==right,'state mismatch beyond unused independently initialized RNG seeds';assert all((a/f'frame-{t+1:04}.png').read_bytes()==(out/f'frame-{t+1:04}.png').read_bytes() for t in range(-1,80))
  print(probe,trial,[(v['t'],v['screen'],v['item']) for v in rows if v['t'] in [0,10,16,40,79]],flush=True)
