    #[test]
    #[ignore = "actual SRAM Continue and party-cancel restoration recording"]
    fn capture_actual_party_restore_140() {
        run_link_save_fixture(|| {
            let dir = std::path::PathBuf::from(std::env::var("FIDELITY_PARTY_RESTORE_CAPTURE").unwrap());
            std::fs::create_dir_all(&dir).unwrap();
            let save_path = dir.join("fixture.sav");
            std::fs::copy(std::env::var("FIDELITY_PARTY_RESTORE_SRAM").unwrap(), &save_path).unwrap();
            let mut g = PokemonGame::new_with_options(GameVersion::Red, Some(save_path), None, None,
                false, None, false, true, #[cfg(feature = "debug-server")] None);
            g.audio = Some(AudioOutput::new_pcm());
            g.state.config.language = pokered_core::game_state::Lang::En;
            let idle = InputState::new();
            let mut saw_menu = false;
            for t in 0..2000 {
                saw_menu |= g.state.screen == GameScreen::MainMenu;
                if g.state.screen == GameScreen::Overworld { break; }
                let a = button(GbButton::A);
                g.update(if t % 20 == 19 { &a } else { &idle });
            }
            assert!(saw_menu);
            assert_eq!(g.overworld.state.current_map, MapId::ViridianCity);
            assert_eq!((g.overworld.state.player.x, g.overworld.state.player.y), (20, 30));
            for _ in 0..120 { g.update(&idle); }
            let mut start = button(GbButton::Start);
            for _ in 0..40 { g.update(&start); start.begin_frame(); }
            for _ in 0..120 { g.update(&idle); }
            assert_eq!(g.state.screen, GameScreen::StartMenu);
            for _ in 0..8 {
                if g.start_menu.current_item() == pokered_core::start_menu::StartMenuItem::Pokemon { break; }
                g.update(&button(GbButton::Up));
                for _ in 0..121 { g.update(&idle); }
            }
            assert_eq!(g.start_menu.current_item(), pokered_core::start_menu::StartMenuItem::Pokemon);
            let mut a = button(GbButton::A);
            for _ in 0..2 { g.update(&a); a.begin_frame(); }
            for _ in 0..120 { g.update(&idle); }
            assert_eq!(g.state.screen, GameScreen::PartyScreen);
            assert_eq!(g.save_data.party.count(), 5);
            let probe = std::env::var("FIDELITY_PARTY_RESTORE_PROBE").is_ok();
            let mut rows = Vec::new();
            let mut input = InputState::new();
            for t in -1i32..80 {
                if t >= 0 {
                    input.begin_frame();
                    if t == 0 { input.press(GbButton::B); }
                    if t == 2 { input.release(GbButton::B); }
                    if probe {
                        if t == 10 { input.press(GbButton::Down); }
                        if t == 12 { input.release(GbButton::Down); }
                        if t == 16 { input.press(GbButton::A); }
                        if t == 18 { input.release(GbButton::A); }
                    }
                    g.update(&input);
                }
                let mut fb = FrameBuffer::new(RenderConfig::new(160, 144), Rgba::WHITE);
                g.draw(&mut fb);
                fb.save_png(&dir.join(format!("frame-{:04}.png", t + 1))).unwrap();
                rows.push(serde_json::json!({"t":t,"input_bits":input.raw_current(),
                    "screen":format!("{:?}",g.state.screen),"item":format!("{:?}",g.start_menu.current_item()),
                    "party_phase":format!("{:?}",g.party_screen.phase()),
                    "start_initializing":g.start_menu.field_initialization_active(),
                    "overworld":pokered_core::snapshot::OverworldSnapshot::capture(&g.overworld)}));
            }
            std::fs::write(dir.join("frames.json"), serde_json::to_string_pretty(&rows).unwrap()).unwrap();
        });
    }
