exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'npc-136-route1-setup/route1.state'
for trial in [1,2]:
 out=r/f'audit-375-source-bag-battle-memory-a{trial}';out.mkdir();p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()));now=[0];events=[]
 get=lambda n:int(p.memory[symbols[n][1]])
 stock=[20,4,11,3,4,2,53,2,29,1,30,2,18,3,19,4];p.memory[symbols['wNumBagItems'][1]]=8
 for i,b in enumerate(stock+[255]):p.memory[symbols['wBagItems'][1]+i]=b
 for n in ['wBagSavedMenuItem','wSavedListScrollOffset','wBattleAndStartSavedMenuItem','wRepelRemainingSteps']:p.memory[symbols[n][1]]=0
 def hook(n):events.append({'t':now[0],'routine':n,'cursor':get('wCurrentMenuItem'),'scroll':get('wListScrollOffset'),'bag_saved':get('wBagSavedMenuItem'),'battle':get('wIsInBattle')})
 for n in ['DisplayStartMenu','StartMenu_Item','InitBattleVariables','DisplayBattleMenu','EndOfBattle','WaitForTextScrollButtonPress']:p.hook_register(*symbols[n],hook,n)
 schedule=[(0,'start',2),(70,'down',2),(110,'down',2),(150,'a',2),(600,'b',2),(650,'b',2)]+[(230+40*i,'down',2)for i in range(6)];held=None;rows=[];reopened=False;last_ack=-100;ack_until=-1
 for t in range(6001):
  now[0]=t;k=next((b for at,b,d in schedule if at<=t<at+d),None);cue=lambda n:[x['t']for x in events if x['routine']==n];init=cue('InitBattleVariables');menus=cue('DisplayBattleMenu');end=cue('EndOfBattle');starts=cue('DisplayStartMenu');waits=cue('WaitForTextScrollButtonPress');extra=[]
  if t>=700 and not init and (t-700)%40<2:k='down'if (t-700)//40%2==0 else'up'
  if menus and not end:
   m=menus[-1];extra.extend([(m+70,'down',2),(m+110,'right',2),(m+150,'a',2)])
  if waits and init and not end and waits[-1]>(menus[-1]if menus else-1) and held is None and t-last_ack>=24:
   last_ack=t;ack_until=t+2
  if t<ack_until:k='a'
  if end:extra.append((end[0]+260,'start',2))
  if len(starts)>=2 and not reopened and t>=starts[1]+70 and t%24==0:
   cur=get('wCurrentMenuItem');k='down'if cur<2 else'up'if cur>2 else'a'
   if cur==2:reopened=True
  for at,b,duration in extra:
   if at<=t<at+duration:k=b
  if k!=held:
   if held:p.button_release(held)
   if k:p.button_press(k)
   held=k
  p.tick(1);rows.append({'t':t,'input':k,'cursor':get('wCurrentMenuItem'),'scroll':get('wListScrollOffset'),'bag_saved_cursor':get('wBagSavedMenuItem'),'in_battle':get('wIsInBattle'),'bag':[int(p.memory[symbols['wBagItems'][1]+i])for i in range(17)]})
  if t in [550,1000,1500,1981,2500,4000,6000]:p.screen.image.save(out/f'frame-{t}.png')
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
 assert rows[550]['cursor']+rows[550]['scroll']==6
 assert init and end and len(menus)>=1,events
 assert sum(x['routine']=='StartMenu_Item'for x in events)==2,events
 assert (rows[-1]['cursor'],rows[-1]['scroll'],rows[-1]['bag_saved_cursor'])==(0,0,0),rows[-1]
 assert all(x['bag']==stock+[255]for x in rows)
 if trial==2:
  old=r/'audit-375-source-bag-battle-memory-a1';assert all(f.read_bytes()==(old/f.name).read_bytes()for f in out.iterdir())
 print(trial,'battle_init',init,'battle_end',end,'menu',menus,'final',rows[-1],flush=True)
