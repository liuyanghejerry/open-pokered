from pathlib import Path
import os,subprocess,json
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus'
for kind,wtname,test,envkey,ncases,old in [('list','fidelity-219-bag-list-checkout','capture_bag_list_219','BAG_LIST_CAPTURE_219',7,'audit-219-native-capture-a2-1'),('swap','fidelity-221-bag-swap-checkout','capture_bag_swap_221','BAG_SWAP_CAPTURE_221',7,'audit-221-native-capture-a1-1')]:
 binary=r/f'audit-223-{kind}-native-a1-immutable/app';wt=root/'.task-tmp'/wtname
 for repeat in [1,2]:
  out=r/f'audit-223-{kind}-native-capture-a1-{repeat}';assert not out.exists()
  with (r/(out.name+'.log')).open('w') as f:q=subprocess.run([str(binary),test,'--ignored','--nocapture'],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',**{envkey:str(out)}),stdout=f,stderr=subprocess.STDOUT)
  print(kind,repeat,q.returncode,flush=True)
  if q.returncode:raise SystemExit(q.returncode)
 a=r/f'audit-223-{kind}-native-capture-a1-1';b=r/f'audit-223-{kind}-native-capture-a1-2';assert len(list(a.iterdir()))==ncases
 files=[p for p in a.rglob('*') if p.is_file()]
 for p in files:assert p.read_bytes()==(b/p.relative_to(a)).read_bytes(),p
 pics=[p for p in files if p.suffix=='.png'];prior=r/old
 changed=[str(p.relative_to(a)) for p in pics if p.read_bytes()!=(prior/p.relative_to(a)).read_bytes()]
 v={'base':'591480e6244d74318cf490bbe0b7f2a0ebb0f2df','PNG':len(pics)*2,'repeat_all_raw_and_png_byte_exact':True,'every_cached_full_pixel_equal':True,'different_from_historical_61_frames':changed};(r/f'audit-223-{kind}-native-capture-verification.json').write_text(json.dumps(v,indent=2));print(kind,v,flush=True)
