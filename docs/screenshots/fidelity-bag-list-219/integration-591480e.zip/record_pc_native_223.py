from pathlib import Path
import os,subprocess,json
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-222-pc-confirm-checkout';binary=r/'audit-223-pc-native-a2-immutable/app'
for rep in [1,2]:
 path=r/f'audit-223-pc-native-capture-a2-{rep}';assert not path.exists()
 with (r/(path.name+'.log')).open('w') as f:subprocess.run([str(binary),'capture_pc_confirm_222','--ignored','--nocapture'],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',PC_CONFIRM_CAPTURE_222=str(path)),stdout=f,stderr=subprocess.STDOUT,check=True)
 print(rep,0,flush=True)
a=r/'audit-223-pc-native-capture-a2-1';b=r/'audit-223-pc-native-capture-a2-2';files=[p for p in a.rglob('*') if p.is_file()];assert len(files)==4536
for p in files:assert p.read_bytes()==(b/p.relative_to(a)).read_bytes(),p
for p in a.rglob('*.png'):assert p.read_bytes()==(r/'audit-222-pc-native-capture-a3-1'/p.relative_to(a)).read_bytes(),p
v={'base':'591480e6244d74318cf490bbe0b7f2a0ebb0f2df','PNG':9016,'all_repeat_bytes_exact':True,'all_cached_full_pixels_equal':True,'all_pixels_match_historical_0c58485_candidate':True};(r/'audit-223-pc-native-verification.json').write_text(json.dumps(v,indent=2));print(v)
