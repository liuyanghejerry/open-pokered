from pathlib import Path
import subprocess,hashlib,json,shutil,os,re
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-223-menu-before-checkout';out=r/'audit-223-menu-master-a1-immutable';out.mkdir(exist_ok=False);log=(r/'audit-223-menu-master-build-a1.log').read_text();assert 'Finished `test` profile' in log;p=re.findall(r'Executable .*?\((/[^\n]+)\)',log);assert len(p)==1;shutil.copy2(p[0],out/'app');base='591480e6244d74318cf490bbe0b7f2a0ebb0f2df';name='crates/pokered-app/src/game.rs';assert (wt/name).read_bytes().startswith(subprocess.check_output(['git','show',base+':'+name],cwd=wt));changes=subprocess.check_output(['git','diff','--name-only'],cwd=wt).decode().splitlines();assert changes==[name];(out/'manifest.json').write_text(json.dumps({'base':base,'production_unchanged':True,'game_with_test_helpers':hashlib.sha256((wt/name).read_bytes()).hexdigest(),'app':hashlib.sha256((out/'app').read_bytes()).hexdigest()},indent=2))
for kind,test in [('pc','pc_confirm_defaults_clamps_and_cancel_follow_original'),('list','bag_list_selection_and_mark_match_original'),('swap','bag_swap_wait_commit_and_reopen_match_original')]:
 with (r/f'audit-223-{kind}-master-owner-negative-a1.log').open('w') as f:q=subprocess.run([str(out/'app'),test,'--nocapture'],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib'),stdout=f,stderr=subprocess.STDOUT)
 assert q.returncode==101,(kind,q.returncode)
 print('owner negative',kind,q.returncode,flush=True)
for kind,test,envkey,ncases,nframes in [('list','capture_bag_list_219','BAG_LIST_CAPTURE_219',7,121),('swap','capture_bag_swap_221','BAG_SWAP_CAPTURE_221',7,161),('pc','capture_pc_confirm_222','PC_CONFIRM_CAPTURE_222',28,161)]:
 for rep in [1,2]:
  path=r/f'audit-223-{kind}-master-capture-a1-{rep}';assert not path.exists()
  with (r/(path.name+'.log')).open('w') as f:q=subprocess.run([str(out/'app'),test,'--ignored','--nocapture'],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',**{envkey:str(path)}),stdout=f,stderr=subprocess.STDOUT)
  print(kind,rep,q.returncode,flush=True)
  if q.returncode:raise SystemExit(q.returncode)
 a=r/f'audit-223-{kind}-master-capture-a1-1';b=r/f'audit-223-{kind}-master-capture-a1-2';files=[p for p in a.rglob('*') if p.is_file()];assert len(files)==ncases*(nframes+1)
 for p in files:assert p.read_bytes()==(b/p.relative_to(a)).read_bytes(),p
 v={'base':base,'PNG':ncases*nframes*2,'repeat_all_raw_and_png_exact':True,'all_cached_full_pixels_equal':True};(r/f'audit-223-{kind}-master-verification.json').write_text(json.dumps(v,indent=2));print(kind,v,flush=True)
