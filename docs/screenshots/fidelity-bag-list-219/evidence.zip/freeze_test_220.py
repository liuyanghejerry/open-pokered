from pathlib import Path
import subprocess,hashlib,json,shutil,os,re,sys
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';kind=sys.argv[1];paths={'rope':'fidelity-217-escape-rope-checkout','action':'fidelity-218-bag-action-checkout','list':'fidelity-219-bag-list-checkout'};wt=root/'.task-tmp'/paths[kind];out=r/f'audit-220-{kind}-native-a1-immutable';out.mkdir(exist_ok=False);log=(r/f'audit-220-{kind}-native-build-a1.log').read_text();assert 'Finished `test` profile' in log
base='61a1e666efc6191e8285fb67195ef9a18761e1ec';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip();sources=subprocess.check_output(['git','diff','--name-only',base,'--','crates'],cwd=wt).decode().splitlines();m={'base':base,'head':head,'sources':{s:hashlib.sha256((wt/s).read_bytes()).hexdigest() for s in sources},'binaries':{}}
for binary in ['core','app']:
 matches=[p for p in re.findall(r'Executable .*?\((/[^\n]+)\)',log) if f'pokered_{binary}-' in p];assert len(matches)==1,matches;shutil.copy2(matches[0],out/binary);m['binaries'][binary]=hashlib.sha256((out/binary).read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for binary in ['core','app']:
 with (r/f'audit-220-{kind}-{binary}-tests-a1.log').open('w') as f:result=subprocess.run([str(out/binary)],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib'),stdout=f,stderr=subprocess.STDOUT)
 print(kind,binary,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
