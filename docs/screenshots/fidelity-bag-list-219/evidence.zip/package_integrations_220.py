from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';sha=lambda b:hashlib.sha256(b).hexdigest();base='61a1e666efc6191e8285fb67195ef9a18761e1ec'
for kind,wtname,folder in [('rope','fidelity-217-escape-rope-checkout','fidelity-escape-rope-217'),('action','fidelity-218-bag-action-checkout','fidelity-bag-action-218'),('list','fidelity-219-bag-list-checkout','fidelity-bag-list-219')]:
 wt=root/'.task-tmp'/wtname;d=wt/'docs/screenshots'/folder;d.mkdir(parents=True,exist_ok=True);m=json.loads((r/f'audit-220-{kind}-native-a1-immutable/manifest.json').read_text());assert m['base']==base
 for name,h in m['sources'].items():assert sha((wt/name).read_bytes())==h,name
 for binary in ['core','app']:assert 'test result: ok.' in (r/f'audit-220-{kind}-{binary}-tests-a1.log').read_text()
 sides={s:(r/f'audit-219-{s}-capture-a2' if kind=='list' else r/f'audit-220-{kind}-{s}-capture-a1') for s in ['master','native']};files={}
 for side,prefix in sides.items():
  for repeat in [1,2]:
   p=Path(str(prefix)+f'-{repeat}')
   for f in p.rglob('*'):
    if f.is_file():files[str(f.relative_to(r))]=f
   log=r/(p.name+'.log');files[log.name]=log
  a=Path(str(prefix)+'-1');b=Path(str(prefix)+'-2');assert all(f.read_bytes()==(b/f.relative_to(a)).read_bytes() for f in a.rglob('*') if f.is_file())
 if kind=='list':
  for case in ['mark-b','mark-a','self-select','cancel-select','ab','a-select','up-down']:
   for repeat in [1,2]:
    p=r/f'audit-219-original-bag-list-{case}-a1-{repeat}'
    for f in p.iterdir():files[str(f.relative_to(r))]=f
  for name in ['audit-219-original-bag-list-a1.log','audit-219-original-list-verification.json','stats-59-tools/probe_bag_list_219.py']:files[name]=r/name
 for name in [f'audit-220-{kind}-native-build-a1.log',f'audit-220-{kind}-core-tests-a1.log',f'audit-220-{kind}-app-tests-a1.log',f'audit-220-{kind}-master-negative.log','audit-219-master-build-a2.log','freeze_test_220.py','record_integrations_220.py','record_bag_list_219_current.py','package_integrations_220.py']:files[name]=r/name
 for name in [f'audit-220-{kind}-native-a1-immutable/manifest.json','audit-219-master-a2-immutable/manifest.json']:files[name]=r/name
 for name in m['sources']:files['current-source/'+name]=wt/name
 files['master-game-with-test-only-helpers.rs']=root/'.task-tmp/fidelity-219-bag-list-before-checkout/crates/pokered-app/src/game.rs'
 if kind=='list':
  ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
  for name in ['home/list_menu.asm','home/window.asm','engine/menus/swap_items.asm','engine/menus/start_sub_menus.asm']:files['original-source/'+name]=ref/name
 png={};blobs={};archive=d/('evidence.zip' if kind=='list' else 'integration-61a1e66.zip')
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for name,p in files.items():
   data=p.read_bytes()
   if p.suffix=='.png':
    h=sha(data);png[name]=h
    if h not in blobs:blobs[h]=data;z.writestr('png-blobs/'+h+'.png',data)
   else:z.writestr(name,data)
  z.writestr('png-files.json',json.dumps(png,indent=2))
 assert len(png)=={'rope':1204,'action':2904,'list':10108}[kind]
 with zipfile.ZipFile(archive) as z:
  for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
 pairs={'rope':[('',None,170)],'action':[('cursor','down-down',16),('priority','up-down',30)],'list':[('cancel','mark-b',100),('select','mark-a',100),('mark','self-select',100),('priority','up-down',4)]}[kind]
 for name,case,frame in pairs:
  for side,label in [('master','before'),('native','after')]:
   p=Path(str(sides[side])+'-1');p=p/case if case else p;shutil.copy2(p/f'frame-{frame:04}.png',d/(f'{name}-{label}.png' if name else f'{label}.png'))
 v={'base':base,'source_manifest':m,'PNG':len(png),'full_repeat_bytes_exact':True,'retained_full_pixels_equal_each_frame':True,'archive_all_files_roundtrip_bytes_exact':True,'archive_sha256':sha(archive.read_bytes()),'full_tests':{'core':2724 if kind=='rope' else 2722,'app':199,'ignored':23},'master_prefix_verified':json.loads((r/'audit-219-master-a2-immutable/manifest.json').read_text())};(d/('verification.json' if kind=='list' else 'integration-61a1e66.json')).write_text(json.dumps(v,indent=2)+'\n')
 note=f'''Current integration evidence: actual master61a1e66 vs frozen source {m['head']}.
Full core {v['full_tests']['core']} / app199 pass (23 opt-in capture helpers ignored).
All {len(png)} PNG paths plus complete raw JSON/logs/source are read back from the
lossless SHA256 PNG archive and compared byte-for-byte. Both sides repeat exactly;
every frame compares all retained/full pixels. Baseline Game production prefix
is unchanged, with identical test-only helpers. Same inputs/state/frame screenshots
are published above. No ROM/SRAM/emulator state/executable is distributed. These
are controlled collision-checked owner fixtures, not natural mainline traversal.
Latest own CI and unchanged GBA gates must independently pass before merge.
'''
 if kind=='list':
  note='''# Bag list selection and marked-row rules, standalone219

Original DisplayListMenuID gives A priority over B/SELECT after cursor movement.
UP wins simultaneous UP+DOWN even at the top. A selects an item while a swap mark
exists; B exits the list. HandleItemListSwapping ignores SELECT on the marked item
or CANCEL without clearing the mark. Actual master differs in all these cases.
The repair touches one production file (core/bag_screen.rs); Game only adds an
actual-input regression/capture helper. Existing merge/quantity/field-use/menu
rendering remains governed by its existing code.

Original7 cases (mark-b, mark-a, self-select, cancel-select, A+B, A+SELECT,
UP+DOWN) each480 frames twice produce6720 PNG and full state/hooks byte exact.
Both current native/master record7 cases each121 frames twice (3388 PNG), using
Potion3/Antidote4, seed42, English/Medium, injured Bulbasaur5, collision-checked
Viridian Center4,4 and direct Bag entry. Inventory is unchanged in these cases.
Baseline owner fails at marked B: stays Bag instead of StartMenu. Final actual
Game owner and all suites pass. Screenshots are matched100/4-frame states.

This PR does not complete the entire swap lifecycle: the original20-frame mark/
swap protected waits remain a confirmed gap (separate original4-case evidence),
and persistence of a completed swap into saved inventory needs an actual Game
reopen probe. These pending audits are not claimed fixed by this selection change.
No font/translation/dialogue-box layout changes are included. Historical59-based
build/captures remain retained in the workspace; current evidence below is61.

'''+note
  (d/'README.md').write_text(note)
 else:
  p=d/'README.md';p.write_text('## Latest integration on master61a1e66\n\n'+note+'\n## Historical evidence retained\n\n'+p.read_text())
 print(kind,'PNG',len(png),'archive',archive.stat().st_size,'roundtrip exact')
