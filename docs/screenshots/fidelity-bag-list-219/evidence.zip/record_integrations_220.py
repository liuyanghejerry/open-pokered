from pathlib import Path
import os,json,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';side=os.environ.get('INTEGRATION_SIDE_220','native')
for kind,fn,envkey,wtname in [('rope','capture_escape_rope_216','ESCAPE_ROPE_CAPTURE_216','fidelity-217-escape-rope-checkout'),('action','capture_bag_action_218','BAG_ACTION_CAPTURE_218','fidelity-218-bag-action-checkout')]:
 binary=r/(f'audit-220-{kind}-native-a1-immutable/app' if side=='native' else 'audit-219-master-a2-immutable/app');wt=root/'.task-tmp'/(wtname if side=='native' else 'fidelity-219-bag-list-before-checkout')
 for repeat in [1,2]:
  out=r/f'audit-220-{kind}-{side}-capture-a1-{repeat}';out.mkdir(exist_ok=False)
  with (r/(out.name+'.log')).open('w') as log:subprocess.run([str(binary),fn,'--ignored','--nocapture'],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',**{envkey:str(out)}),stdout=log,stderr=subprocess.STDOUT,check=True)
 a=r/f'audit-220-{kind}-{side}-capture-a1-1';b=r/f'audit-220-{kind}-{side}-capture-a1-2';files=[p for p in a.rglob('*') if p.is_file()];assert all(p.read_bytes()==(b/p.relative_to(a)).read_bytes() for p in files);png=sum(p.suffix=='.png' for p in files)*2;assert png==(602 if kind=='rope' else 1452)
 report={'kind':kind,'side':side,'PNG':png,'repeats_all_raw_json_and_png_byte_exact':True,'every_retained_full_frame_pixel_identical':True,'base':'61a1e66','scope':'same controlled collision-checked owner scenario, not natural playthrough or absolute original PPU alignment'};(r/f'audit-220-{kind}-{side}-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
