from pathlib import Path
import os,json,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';side=os.environ.get('BAG_LIST_SIDE_219','native');tag='a2';wt=root/'.task-tmp'/('fidelity-219-bag-list-checkout' if side=='native' else 'fidelity-219-bag-list-before-checkout');binary=r/('audit-220-list-native-a1-immutable/app' if side=='native' else 'audit-219-master-a2-immutable/app')
for trial in [1,2]:
 out=r/f'audit-219-{side}-capture-{tag}-{trial}';out.mkdir(exist_ok=False)
 with (r/f'{out.name}.log').open('w') as log:subprocess.run([str(binary),'capture_bag_list_219','--ignored','--nocapture'],cwd=wt,env=dict(os.environ,BAG_LIST_CAPTURE_219=str(out),LD_LIBRARY_PATH='/tmp/pokered-build-lib'),stdout=log,stderr=subprocess.STDOUT,check=True)
a=r/f'audit-219-{side}-capture-{tag}-1';b=r/f'audit-219-{side}-capture-{tag}-2';cases=sorted(p.name for p in a.iterdir());assert len(cases)==7
for case in cases:
 files=sorted((a/case).iterdir());assert len(files)==122;assert all(p.read_bytes()==(b/case/p.name).read_bytes() for p in files);rows=json.loads((a/case/'frames.json').read_text());assert all(q['stock']==3 for q in rows)
report={'side':side,'frames_per_case_repeat':121,'PNG':1694,'cases':cases,'full_raw_json_and_png_repeats_byte_exact':True,'each_frame_retained_full_pixels_identical':True,'scope':'Controlled valid center4,4 collision-checked; seeded fixture with injured Bulbasaur/Potion3/Antidote4; pure Bag entry, same input/state/frame on sides. Not natural traversal or absolute originalCPU/PPU/font layout matching.'};(r/f'audit-219-{side}-capture-verification-{tag}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
