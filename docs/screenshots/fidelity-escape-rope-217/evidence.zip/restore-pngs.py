from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
for n,h in json.loads((r/'png-index.json').read_text()).items():
 b=(r/'png-by-sha256'/(h+'.png')).read_bytes();assert hashlib.sha256(b).hexdigest()==h
 p=r/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
print('All PNG paths and bytes restored.')
