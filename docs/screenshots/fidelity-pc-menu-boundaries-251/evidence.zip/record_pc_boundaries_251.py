from pathlib import Path
import sys,os,json,socket,subprocess,hashlib
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-250-pc-menu-boundaries-checkout';sys.path.insert(0,str(w/'scripts'));from debug_drive import DebugClient
kind=sys.argv[1];assert kind in ['master','native'];binary=r/('audit-245-reentry-cli-immutable' if kind=='master' else 'audit-251-boundaries-cli-immutable')/'pokered-app';manifest=json.loads((binary.parent/'manifest.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['binary'];snapshot=r/'audit-181-native-pc-slow-four-snapshot.json'
for case in ['main','player','bill']:
 for direction in ['up','down']:
  for repeat in [1,2]:
   out=r/f'audit-251-{kind}-{case}-{direction}-{repeat}';out.mkdir(exist_ok=False)
   with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
   log=(r/(out.name+'.log')).open('w');p=subprocess.Popen([str(binary),'--scripts-dir',str(w/'crates/pokered-data/maps'),'run','--headless','--debug-port',str(port),'--speed','0','--skip-intro','--no-audio','--seed','42','--save',str(out/'owned.sav'),'--snapshot',str(snapshot),'--lang','en'],cwd=w,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib'),stdout=log,stderr=subprocess.STDOUT);d=None
   try:
    d=DebugClient(port=port)
    def drive(keys):q=d.cmd(cmd='press_timeline',buttons=keys,advance=True);assert q.get('ok'),q
    def reach(target):
     last=None
     for _ in range(500):
      if d.state().get('pc_phase')==target:return
      key='a' if last is None else None;drive([key]);last=key
     raise AssertionError((target,d.state()))
    q=d.cmd(cmd='set_flag',name='EVENT_GOT_POKEDEX',value=True);assert q.get('ok'),q;q=d.cmd(cmd='warp',map='ViridianPokecenter',x=13,y=4);assert q.get('ok');drive([None]*120+['up']*20+[None]*20+['a']*20+[None]*20);reach('MainMenu')
    if case!='main':drive((['down',None] if case=='player' else [])+['a',None]);reach('ItemQuestion' if case=='player' else 'BillsMenu')
    rows=[];count={'main':12,'player':4,'bill':5}[case];end=340 if case=='main' else 190
    for t in range(end+1):
     key='up' if direction=='up' and 70<=t<72 else None
     if direction=='down' and any(20+n*24<=t<22+n*24 for n in range(count)):key='down'
     if t:drive([key])
     state=d.state();assert not (out/'owned.sav').exists();q=d.cmd(cmd='capture_frame',path=str(out/f'frame-{t:03}.png')) if t in [0,20,70,71,72,94,190,284,285,286,340] else {'ok':True};assert q.get('ok');rows.append({'t':t,'input':key,'state':state,'bag':d.cmd(cmd='get_bag'),'owned_save_exists':False})
    assert d.state()['pc_phase']=={'main':'MainMenu','player':'ItemMenu','bill':'BillsMenu'}[case]
    reference=20 if direction=='up' else (94 if case=='bill' else 70)
    edge_kept=(out/f'frame-{end:03}.png').read_bytes()==(out/f'frame-{reference:03}.png').read_bytes();assert edge_kept==(kind=='native'),(kind,case,direction,edge_kept)
    (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n')
   finally:
    if d:d.close()
    p.terminate()
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:p.kill();p.wait()
    log.close()
   if repeat==2:
    old=r/f'audit-251-{kind}-{case}-{direction}-1';files=sorted(q.name for q in out.iterdir() if q.suffix in ['.png','.json']);assert all((out/q).read_bytes()==(old/q).read_bytes() for q in files)
  print(kind,case,direction,'two exact repeats; source edge kept',kind=='native',flush=True)
