from pathlib import Path
import subprocess,os
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
for case in ['main','player','bill']:
 for direction in ['up','down']:
  with (r/f'audit-247-original-{case}-{direction}-run-a2.log').open('w') as f:p=subprocess.run([str(r/'stats-59-tools/venv/bin/python'),str(r/'stats-59-tools/probe_pc_menu_boundaries_247.py')],env=dict(os.environ,PC_BOUNDARY_CASE_247=case,PC_BOUNDARY_DIRECTION_247=direction,FIDELITY_PC_SPEED='5'),stdout=f,stderr=subprocess.STDOUT)
  print(case,direction,p.returncode,flush=True);assert p.returncode==0
