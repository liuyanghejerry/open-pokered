from pathlib import Path
import json,re,hashlib,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-250-pc-menu-boundaries-checkout';out=wt/'docs/screenshots/fidelity-pc-menu-boundaries-251'
base='35b6b1eb0d5dd1632ab1176c1b30d06c8e354e29';sha=lambda b:hashlib.sha256(b).hexdigest()
proof=json.loads((r/'audit-251-before-source-promoted-master-equivalence.json').read_text());assert proof['current_master']==base and proof['entire_crates_tree_equal']
results=json.loads((r/'audit-251-boundaries-all-unit-and-integration-results-a1.json').read_text());assert results['all_pass'] and results['every_binary_completed'] and len(results['results'])==78
cli=json.loads((r/'audit-251-boundaries-cli-regression-results.json').read_text());assert cli['base']==base and cli['fresh_m01_m03'] and cli['separate_process_s07_save_continue']
files={};cases=[]
for case in ['main','player','bill']:
 for direction in ['up','down']:
  source_tag='a3' if case=='main' and direction=='down' else 'a2';source_name=f'audit-247-original-withdraw-{case}-{direction}-boundary-{source_tag}'
  for repeat in [1,2]:
   folder=r/f'{source_name}-{repeat}'
   for p in folder.iterdir():
    assert p.suffix in ['.png','.json'];files[str(p.relative_to(r))]=p
   rows=json.loads((folder/'frames.json').read_text());assert rows[-1]['cursor']==(0 if direction=='up' else {'main':3,'player':3,'bill':4}[case]);assert rows[-1]['wrapping_enabled']==0
   assert all(x['bag_items']==rows[0]['bag_items'] and x['pc_items']==rows[0]['pc_items'] for x in rows)
   if repeat==2:
    first=r/f'{source_name}-1';assert all(p.read_bytes()==(first/p.name).read_bytes() for p in folder.iterdir())
  for side in ['master','native']:
   for repeat in [1,2]:
    folder=r/f'audit-251-{side}-{case}-{direction}-{repeat}'
    assert not (folder/'owned.sav').exists()
    for p in folder.iterdir():
     assert p.suffix in ['.png','.json'];files[str(p.relative_to(r))]=p
    rows=json.loads((folder/'frames.json').read_text());assert all(x['bag']==rows[0]['bag'] and not x['owned_save_exists'] for x in rows)
    assert rows[-1]['state']['pc_phase']=={'main':'MainMenu','player':'ItemMenu','bill':'BillsMenu'}[case]
    final=340 if case=='main' else 190;ref=20 if direction=='up' else (94 if case=='bill' else 70)
    kept=(folder/f'frame-{final:03}.png').read_bytes()==(folder/f'frame-{ref:03}.png').read_bytes();assert kept==(side=='native')
    if repeat==2:
     first=r/f'audit-251-{side}-{case}-{direction}-1';assert all(p.read_bytes()==(first/p.name).read_bytes() for p in folder.iterdir())
  cases.append({'menu':case,'direction':direction,'original_final_cursor':0 if direction=='up' else {'main':3,'player':3,'bill':4}[case],'original_wrapping_enabled':0,'source_raw_repeat_exact':True,'master_raw_repeat_exact':True,'candidate_raw_repeat_exact':True,'candidate_final_png_equals_edge':True,'master_final_png_differs_from_edge':True,'inventory_unchanged':True,'save_not_created':True})
for name in ['audit-251-before-source-promoted-master-equivalence.json','audit-251-boundaries-all-tests-build-a1.log','audit-251-boundaries-all-unit-and-integration-results-a1.json','audit-251-boundaries-all-tests-a1-immutable/manifest.json','audit-251-boundaries-cli-immutable/manifest.json','audit-251-boundaries-cli-regression-results.json','audit-251-master-boundaries-run.log','audit-251-native-boundaries-run.log','record_pc_boundaries_251.py','freeze_run_all_tests_251.py','freeze_run_boundaries_cli_251.py','package_pc_boundaries_251.py','stats-59-tools/probe_pc_menu_boundaries_247.py','stats-59-tools/run_pc_menu_boundaries_247_a2.py','stats-59-tools/probe_pc_menu_boundaries_247_a3.py']:
 p=r/name;assert p.exists(),name;files[name]=p
for row in results['results']:files[row['log']]=r/row['log']
for name in ['crates/pokered-core/src/pokemon/pc_menu.rs','crates/pokered-core/src/pokemon/pc_menu_tests.rs']:files['candidate-source/'+name]=wt/name
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['home/window.asm','engine/menus/pc.asm','engine/menus/players_pc.asm','engine/pokemon/bills_pc.asm']:files['original-source/'+name]=ref/name
out.mkdir(parents=True,exist_ok=False);png={};blobs=set()
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  b=p.read_bytes()
  if p.suffix=='.png':
   h=sha(b);png[name]=h
   if h not in blobs:blobs.add(h);z.writestr('png-blobs/'+h+'.png',b)
  else:z.writestr(name,b)
 z.writestr('png-files.json',json.dumps(png,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for case in ['main','player','bill']:
 for direction in ['up','down']:
  for side,label in [('master','before'),('native','after')]:
   end=340 if case=='main' else 190;shutil.copy2(r/f'audit-251-{side}-{case}-{direction}-1/frame-{end:03}.png',out/f'{case}-{direction}-{label}.png')
tot=[0,0,0]
for row in results['results']:
 m=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored',row['summary']);assert m
 for i in range(3):tot[i]+=int(m[i+1])
v={'base':base,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'tests':{'programs':78,'pass':tot[0],'fail':tot[1],'ignore':tot[2]},'cases':cases,'main_actual_menu_rows':4,'main_fixture_get_pokedex':True,'main_fixture_entered_hall_of_fame':False,'core_main_availability_variants':[3,4,5],'PNG':len(png),'archive_roundtrip_byte_exact':True,'archive_sha256':sha((out/'evidence.zip').read_bytes()),'archive_bytes':(out/'evidence.zip').stat().st_size,'scope':'PC direction boundaries only; controlled snapshots, not natural playthrough or complete input timing fidelity'}
(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
