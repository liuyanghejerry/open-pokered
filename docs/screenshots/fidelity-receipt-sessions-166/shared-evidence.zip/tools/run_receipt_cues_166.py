from pathlib import Path
import subprocess,os,json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
summary={}
for case in ['old','good','super','chairman']:
 sides={}
 for side,folder,wt in [('master31','audit-166-master31-immutable','fidelity-93-master-before'),('after-a8','audit-166-after-a8-immutable','fidelity-91-plus-checkout')]:
  exe=r/folder/'pokered_app'
  for trial in [1,2]:
   dest=r/f'audit-166-cue-{side}-{case}-{trial}';env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',FIDELITY_RECEIPT_CASE=case,FIDELITY_RECEIPT_CAPTURE=str(dest));log=r/f'audit-166-cue-{side}-{case}-{trial}.log'
   with log.open('w') as f:p=subprocess.run([str(exe),'game::link_stats_cry_fidelity_tests::capture_reward_receipt_166','--exact','--ignored','--nocapture','--test-threads=1'],env=env,cwd=r.parent/wt,stdout=f,stderr=subprocess.STDOUT)
   assert p.returncode==0 and '1 passed' in log.read_text(),(case,side,trial,log.read_text()[-800:])
   frames=json.loads((dest/'frames.json').read_text());cue=next(x['t'] for x in frames if x['overworld']['active_script_effect'] and any(v.get('phase')=='PlayingSound' or v.get('sound_started') is True for v in x['overworld']['active_script_effect'].values()))
   assert frames[cue]['sfx_playing'] and frames[cue]['has_item']
   if trial==2:
    old=r/f'audit-166-cue-{side}-{case}-1';assert all(f.read_bytes()==(old/f.name).read_bytes() for f in dest.iterdir())
  sides[side]=dict(cue=cue,frames=len(frames),screenshot_hw=cue+150,postcue_inputs=[x['input_bits'] for x in frames[cue:cue+261]])
  print(case,side,'cue',cue,'frames',len(frames),'repeat byteexact',flush=True)
 assert sides['master31']['postcue_inputs']==sides['after-a8']['postcue_inputs'],'postcue controls must be identical'
 for v in sides.values():del v['postcue_inputs']
 summary[case]=sides
(r/'audit-166-cue-summary.json').write_text(json.dumps(dict(cases=summary,scope='Independent actual interaction prefixes in each branch to the same receipt/fanfare phase. Same261 postcue input bits; same screenshot hardware frame150 after first SoundStarted. Full raw frame numbers retained, no absolute pre-cue timing equality claim.'),indent=2)+'\n')
