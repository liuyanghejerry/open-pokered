from pathlib import Path
import shutil,subprocess,os,json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');base=r.parent/'fidelity-93-master-before';out=r/'audit-166-master31-immutable';out.mkdir();assert 'Finished `test`' in (r/'audit-166-master31-build.log').read_text();shutil.copy2(r.parent/'fidelity-18-27/target/debug/deps/pokered_app-823b1783d030defc',out/'pokered_app');(out/'pokered_app').chmod(0o555)
for case in ['old','good','super','chairman']:
 for trial in [1,2]:
  dest=r/f'audit-166-native-master31-{case}-{trial}';env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',FIDELITY_RECEIPT_CASE=case,FIDELITY_RECEIPT_CAPTURE=str(dest),FIDELITY_RECEIPT_INPUTS=str(r/f'audit-166-native-after-a8-{case}-1/inputs.json'))
  log=r/f'audit-166-native-master31-{case}-{trial}.log'
  with log.open('w') as f:p=subprocess.run([str(out/'pokered_app'),'game::link_stats_cry_fidelity_tests::capture_reward_receipt_166','--exact','--ignored','--nocapture','--test-threads=1'],env=env,cwd=base,stdout=f,stderr=subprocess.STDOUT)
  assert p.returncode==0 and '1 passed' in log.read_text(),(case,trial,log.read_text()[-1200:])
  frames=json.loads((dest/'frames.json').read_text());after=json.loads((r/f'audit-166-native-after-a8-{case}-1/frames.json').read_text());assert len(frames)==len(after);assert [x['input_bits'] for x in frames]==[x['input_bits'] for x in after]
  if trial==2:
   prev=r/f'audit-166-native-master31-{case}-1';assert all(x.read_bytes()==(prev/x.name).read_bytes() for x in dest.iterdir())
 print(case,'master31 repeat exact',len(frames),flush=True)
