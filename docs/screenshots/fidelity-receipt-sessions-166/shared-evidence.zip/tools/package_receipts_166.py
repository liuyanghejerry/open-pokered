from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=r.parent/'fidelity-91-plus-checkout';base=r.parent/'fidelity-93-master-before';out=w/'docs/screenshots/fidelity-receipt-sessions-166';out.mkdir(parents=True,exist_ok=True);load=lambda p:json.loads(p.read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for tree,head in [(base,'31b1eda3112514d6bc803af559ec7f7c9e20374f'),(w,'897c57a7322abb2b381300687d8c0f03ff80d46c')]:
 old=subprocess.check_output(['git','show',head+':crates/pokered-app/src/game.rs'],cwd=tree);actual=(tree/'crates/pokered-app/src/game.rs').read_bytes();end=old.index(b'#[cfg(test)]\nmod session_guard_tests');assert old[:end]==actual[:end];assert actual.count((r/'receipt-166-helper.rs').read_bytes())==1
for k,n in [('core',2741),('data',262),('app',217),('agent',54)]:assert f'{n} passed; 0 failed' in (r/f'audit-166-{k}-tests-a8.log').read_text()
gba=load(r/'audit-166-gba-provenance-a2.json');assert len(gba['sources'])==39 and all(h(w/f)==sha for f,sha in gba['sources'].items());c=(r/'audit-166-gba-compare-a2.log').read_text();assert len([x for x in c.splitlines() if ' -> ' in x])==31 and 'within the configured regression budget' in c
summary=load(r/'audit-166-cue-summary.json');archives={}
def archive(name,entries):
 manifest={k:h(p) for k,p in entries.items()}
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED) as z:
  for k,p in sorted(entries.items()):z.write(p,k)
  z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(out/name) as z:
  for k,sha in manifest.items():assert hashlib.sha256(z.read(k)).hexdigest()==sha
 size=(out/name).stat().st_size;assert size<95*1024*1024
 archives[name]=dict(bytes=size,sha256=h(out/name),entries=len(entries));print(name,size,len(entries),flush=True)
for case,sides in summary['cases'].items():
 entries={};bits={}
 for side,meta in sides.items():
  for trial in [1,2]:
   folder=r/f'audit-166-cue-{side}-{case}-{trial}'
   for f in folder.iterdir():entries[str(f.relative_to(r))]=f
   log=r/f'audit-166-cue-{side}-{case}-{trial}.log';assert '1 passed' in log.read_text();entries[log.name]=log
  a=r/f'audit-166-cue-{side}-{case}-1';b=r/f'audit-166-cue-{side}-{case}-2';assert all(f.read_bytes()==(b/f.name).read_bytes() for f in a.iterdir())
  rows=load(a/'frames.json');cue=meta['cue'];bits[side]=[x['input_bits'] for x in rows[cue:cue+261]];assert rows[cue]['has_item'] and rows[cue]['sfx_playing'];assert rows[cue+150]['has_item'];assert rows[cue+150]['overworld']['state']['player']['x']==rows[cue]['overworld']['state']['player']['x']
  target=out/(case+'-'+('before' if side=='master31' else 'after')+'.png');shutil.copy2(a/f'frame-{cue+150:04}.png',target)
 assert bits['master31']==bits['after-a8'];archive(case+'-evidence.zip',entries)
entries={}
for trial in [1,2]:
 folder=r/f'audit-166-original-good-{trial}'
 for f in folder.iterdir():entries[str(f.relative_to(r))]=f
assert all(f.read_bytes()==(r/'audit-166-original-good-2'/f.name).read_bytes() for f in (r/'audit-166-original-good-1').iterdir())
for f in (r/'audit-166-good-source-setup').iterdir():entries[str(f.relative_to(r))]=f
for pat in ['audit-166-*.json','audit-166-*.log','audit-166-*.txt']:
 for p in r.glob(pat):entries[p.name]=p
for f in gba['sources']:entries['native-source/'+f]=w/f
entries['native-source/crates/pokered-agent/src/semantics/extract.rs']=w/'crates/pokered-agent/src/semantics/extract.rs';entries['master-helper/game.rs']=base/'crates/pokered-app/src/game.rs';entries['tools/receipt-helper.rs']=r/'receipt-166-helper.rs'
for name in ['add_inner_receipt_166.py','add_receipt_regression_166.py','add_receipt_capture_166.py','explicit_paragraphs_166.py','probe_good_rod_receipt_166.py','run_receipt_after_166.py','run_receipt_master_166.py','run_receipt_cues_166.py','package_receipts_166.py']:entries['tools/'+name]=r/'stats-59-tools'/name
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for f in ['home/text.asm','home/text_script.asm','home/window.asm','home/yes_no.asm','home/joypad2.asm','home/delay.asm','macros/scripts/text.asm']:entries['original-source/'+f]=ref/f
for map in ['VermilionOldRodHouse','FuchsiaGoodRodHouse','Route12SuperRodHouse','PokemonFanClub']:
 for prefix in ['scripts','text']:entries[f'original-source/{prefix}/{map}.asm']=ref/prefix/f'{map}.asm'
archive('shared-evidence.zip',entries)
for src,target in [('audit-166-cue-summary.json','cue-summary.json'),('audit-166-paragraph-migrations.json','paragraph-migrations.json'),('audit-166-inner-receipt-source-plan.json','source-audit.json'),('audit-166-gba-provenance-a2.json','gba-provenance.json'),('audit-166-gba-result-a2.json','gba-result.json'),('audit-166-gba-compare-a2.log','gba-compare.log')]:shutil.copy2(r/src,out/target)
v=dict(parent='897c57a7322abb2b381300687d8c0f03ff80d46c',master='31b1eda3112514d6bc803af559ec7f7c9e20374f',sources=gba['sources'],tests=dict(core=2741,data=262,app=217,agent=54,app_ignored=32),archives=archives,case_cues=summary['cases'],scope=summary['scope'],state_capture='Complete initial snapshot and selected per-frame player/NPC/effect/dialogue/window/restore fields plus audio channels, inputbits, reward/flag. Not a full per-frame runtime snapshot.',original='Good Rod only, 2x820 PNG/rows/events byteexact: sound654 outerWait727 (73frames), noAfor60frames, finalreleaseClose789. Controlled map/view/player5,4, cleared obtainedbit+bag. Other3 source-audited, not emulator-recorded.',limitations=['No absolute prefix/init/close timing, pixel or audio-waveform parity claim.','Default font/layout/Chinese exclusions remain.','Fulltextinitialization/closure, acknowledged-Aarrowphase, other previous draft gates and final m01..49/independentSAVECONTINUE remain.'])
(out/'verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(out/'README.md').write_text('''# 钓竿与兑换券文字会话

三种钓竿和会长的实际领取会话使用原作的内层音效语义：打印领取文字后等待完整音效，保留同一窗口，不执行外层 A 保持或关闭。好钓竿音效后等待新的最终 A/B；另外两种钓竿和兑换券等待手动段落推进，清空文字区20帧后打印说明。普通地上拾取物品的自动关闭保持原行为。

四个NPC的开场、赠送、说明、拒绝、背包满和再次问候中的显式段落已接入共享printFieldParagraph；会长故事末尾的waitFieldPrompt只完成内层ProtectedDelay3/ManualTextScroll，不HoldA/Close。钓竿领取标记在赠送文字前设置，兑换券标记在说明打印完后、外层最终确认前设置。

实际输入回归覆盖成功/拒绝四NPC、背包满四NPC、完整PCM领取音效长度、音效中的B/方向短按、等待中JSON恢复、会长PROMPT后的A保持，以及最终等待和释放A。完整core2741/data262/app217/agent54通过；32个ignored包含诊断录制。GBA39源文件SHA与隔离检出一致，31项维持原始预算，未修改基线。

原作好钓竿两次820帧录制逐字节一致：音效654、外层等待727，等待期间60帧没有按键也不关闭；最终A释放后Close789。原作采用受控地图/视图/玩家与领取位、背包准备，ROM/文字/图块未修改，不是自然旅行证明。其余三NPC只有原作汇编核对。

截图为实际master31和修复检出的**领取音效开始后第150个硬件帧**。各自通过真实NPC交互到达同一领取文字/音效阶段，准备过程的输入与耗时不同；音效开始后的261帧输入bits相同。每侧重复两次，完整录制的PNG/选定状态/输入逐字节复现。原始帧号在cue-summary中保留，截图没有事后移动像素；不主张准备过程或绝对文字开关时序相同。前图好钓竿已自动关闭，另外三者自动打印说明；后图均保留领取文字等待新按键。两侧都实际领取了物品。

各case的-evidence.zip保存两侧全部录制和SHA清单；shared-evidence.zip保存原作录制、汇编、源码、工具、失败日志、单元/性能记录。最初原作YES/NO按键在初始化期被丢弃，修正为初始化后的新按键；最初同输入会长master还停在故事中，未领取，故改用明确的音效锚点，不将失败录制当作有效比较。最初core2项只检查旧命令名的断言已改为检查实际内层音效及背包满分支。

完整文字初始化/关闭、确认A后的箭头相位、其他旧草稿门槛和最终m01..m49/独立SAVE/CONTINUE未完成，PR继续保持草稿。
''');print(json.dumps(archives),flush=True)
