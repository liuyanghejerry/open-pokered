from pathlib import Path
w=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout')
def edit(f,a,b):
 p=w/f;s=p.read_text();assert a in s,(f,a[:90]);p.write_text(s.replace(a,b,1))
f='crates/pokered-data/src/script_command.rs'
edit(f,'PrintFieldParagraph { text: String },','PrintFieldParagraph { text: String, sound_id: Option<String> },\n    /// Inner text sound opcode, returning with its text window retained.\n    PrintItemFieldText { text: String, sound_id: Option<String> },\n    /// Inner PROMPT: manual A/B return without holding A or closing the window.\n    WaitFieldPrompt,')
edit(f,'Self::PrintFieldParagraph { .. } => "printFieldParagraph",','Self::PrintFieldParagraph { .. } => "printFieldParagraph",\n            Self::PrintItemFieldText { .. } => "printItemFieldText",\n            Self::WaitFieldPrompt => "waitFieldPrompt",')
edit(f,'Self::PrintFieldText { text } | Self::PrintFieldParagraph { text } => vec![json!(text)],','Self::PrintFieldText { text } => vec![json!(text)],\n            Self::PrintFieldParagraph { text, sound_id } | Self::PrintItemFieldText { text, sound_id } => {\n                let mut args=vec![json!(text)];if let Some(sound)=sound_id {args.push(json!(sound));}args\n            },')
edit(f,'            Self::FinishFieldText\n','            Self::WaitFieldPrompt\n            | Self::FinishFieldText\n')
edit(f,'"printFieldParagraph" => Self::PrintFieldParagraph { text: string(0)? },','"printFieldParagraph" => Self::PrintFieldParagraph { text: string(0)?, sound_id: args.get(1).filter(|v| !v.is_null()).map(|_|string(1)).transpose()? },\n            "printItemFieldText" => Self::PrintItemFieldText { text: string(0)?, sound_id: args.get(1).filter(|v| !v.is_null()).map(|_|string(1)).transpose()? },\n            "waitFieldPrompt" => Self::WaitFieldPrompt,')
f='crates/pokered-data/src/script_api.rs'
edit(f,'Ok(PokemonScriptCommand::PrintFieldParagraph { text }.into_script_command())','let sound_id=if args.len()>1 {Some(args.get_or_undefined(1).to_string(ctx)?.to_std_string_lossy())} else {None};\n            Ok(PokemonScriptCommand::PrintFieldParagraph { text, sound_id }.into_script_command())')
edit(f,'        engine.register_async_fn("finishFieldText",','''        engine.register_async_fn("printItemFieldText", |args: &[JsValue], ctx: &mut Context| -> JsResult<ScriptCommand> {
            let text=args.get_or_undefined(0).to_string(ctx)?.to_std_string_lossy();
            let sound_id=if args.len()>1 {Some(args.get_or_undefined(1).to_string(ctx)?.to_std_string_lossy())} else {None};
            Ok(PokemonScriptCommand::PrintItemFieldText {text,sound_id}.into_script_command())
        });
        engine.register_async_fn("waitFieldPrompt", |_: &[JsValue], _: &mut Context| -> JsResult<ScriptCommand> {
            Ok(PokemonScriptCommand::WaitFieldPrompt.into_script_command())
        });
        engine.register_async_fn("finishFieldText",''')
f='crates/pokered-core/src/overworld/native_script.rs'
edit(f,'"printFieldParagraph" => Ok(pokemon(PokemonScriptCommand::PrintFieldParagraph { text: args::text(v.first().ok_or("printFieldParagraph: missing text")?, "printFieldParagraph")? })),','''"printFieldParagraph" | "printItemFieldText" => {
                let text=args::text(v.first().ok_or("field print: missing text")?, name)?;
                let sound_id=v.get(1).map(|value|args::string(value,name)).transpose()?;
                Ok(pokemon(if name=="printFieldParagraph" {PokemonScriptCommand::PrintFieldParagraph {text,sound_id}} else {PokemonScriptCommand::PrintItemFieldText {text,sound_id}}))
            }
            "waitFieldPrompt" => Ok(pokemon(PokemonScriptCommand::WaitFieldPrompt)),''')
f='crates/pokered-data/src/script_function_catalog.rs'
edit(f,'    "printFieldText",','    "printFieldText",\n    "printItemFieldText",')
edit(f,'    "waitMusic",','    "waitFieldPrompt",\n    "waitMusic",')
f='crates/pokered-agent/src/semantics/extract.rs'
edit(f,'    "printFieldParagraph",','    "printFieldParagraph",\n    "printItemFieldText",\n    "waitFieldPrompt",')
f='crates/pokered-core/src/overworld/script_bridge.rs'
edit(f,'    Printing,','    Printing,\n    PlayingSound,')
edit(f,'PrintFieldParagraph { text: String, phase: FieldParagraphPhase },','''PrintFieldParagraph { text: String, #[serde(default)] sound_id: Option<String>, phase: FieldParagraphPhase },
    PrintItemFieldText { text: String, sound_id: Option<String>, phase: FieldParagraphPhase },
    WaitFieldPrompt { protected_remaining: u8 },''')
edit(f,'ScriptEffect::PrintFieldParagraph { text, phase } => json!({ "effect": "PrintFieldParagraph", "text": text, "phase": phase }),','''ScriptEffect::PrintFieldParagraph { text, sound_id, phase } => json!({ "effect": "PrintFieldParagraph", "text": text, "sound_id": sound_id, "phase": phase }),
            ScriptEffect::PrintItemFieldText { text, sound_id, phase } => json!({ "effect": "PrintItemFieldText", "text": text, "sound_id": sound_id, "phase": phase }),
            ScriptEffect::WaitFieldPrompt { protected_remaining } => json!({ "effect": "WaitFieldPrompt", "protected_remaining": protected_remaining }),''')
edit(f,'| ScriptEffect::PrintFieldParagraph { text, .. } = &mut effect','| ScriptEffect::PrintFieldParagraph { text, .. } | ScriptEffect::PrintItemFieldText {text,..} = &mut effect')
edit(f,'PokemonScriptCommand::PrintFieldParagraph { text } => ScriptEffect::PrintFieldParagraph { text, phase:','PokemonScriptCommand::PrintFieldParagraph { text, sound_id } => ScriptEffect::PrintFieldParagraph { text, sound_id, phase:')
edit(f,'        PokemonScriptCommand::FinishFieldText =>','''        PokemonScriptCommand::PrintItemFieldText {text,sound_id} => ScriptEffect::PrintItemFieldText {text,sound_id,phase:FieldParagraphPhase::Printing},
        PokemonScriptCommand::WaitFieldPrompt => ScriptEffect::WaitFieldPrompt {protected_remaining:3},
        PokemonScriptCommand::FinishFieldText =>''')
f='crates/pokered-core/src/overworld/update.rs'
edit(f,'FieldParagraphPhase::BlankDelay { .. }, .. }))','FieldParagraphPhase::BlankDelay { .. } | script_bridge::FieldParagraphPhase::PlayingSound, .. } | script_bridge::ScriptEffect::PrintItemFieldText {phase:script_bridge::FieldParagraphPhase::PlayingSound,..} | script_bridge::ScriptEffect::WaitFieldPrompt {protected_remaining:1..=u8::MAX} ))')
edit(f,'script_bridge::ScriptEffect::PrintFieldText { .. } | script_bridge::ScriptEffect::PrintFieldParagraph { .. });','script_bridge::ScriptEffect::PrintFieldText { .. } | script_bridge::ScriptEffect::PrintFieldParagraph { .. } | script_bridge::ScriptEffect::PrintItemFieldText { .. });')
edit(f,'script_bridge::FieldParagraphPhase::Printing } => {','script_bridge::FieldParagraphPhase::Printing, .. } | script_bridge::ScriptEffect::PrintItemFieldText {text,phase:script_bridge::FieldParagraphPhase::Printing,..} => {')
edit(f,'''                        *last_script_dialogue = pending_dialogue.take();
                        return true;
                    }
                    false
                }
            }
            script_bridge::ScriptEffect::PlayCry''','''                        *last_script_dialogue = pending_dialogue.take();
                        match effect {
                            script_bridge::ScriptEffect::PrintItemFieldText {sound_id,phase,..} => {
                                audio_requests.push(OverworldAudioRequest::PlaySound {sound_id:sound_id.clone().unwrap_or_else(||"SFX_GET_ITEM_1".into())});
                                *phase=script_bridge::FieldParagraphPhase::PlayingSound;false
                            }
                            script_bridge::ScriptEffect::PrintFieldParagraph {sound_id:Some(sound),phase,..} => {
                                audio_requests.push(OverworldAudioRequest::PlaySound {sound_id:sound.clone()});
                                *phase=script_bridge::FieldParagraphPhase::PlayingSound;false
                            }
                            _ => true,
                        }
                    } else { false }
                }
            }
            script_bridge::ScriptEffect::PrintItemFieldText {phase:script_bridge::FieldParagraphPhase::PlayingSound,..}
            | script_bridge::ScriptEffect::PrintFieldParagraph {phase:script_bridge::FieldParagraphPhase::PlayingSound,..} => !script_sfx_playing,
            script_bridge::ScriptEffect::PrintItemFieldText {..} => unreachable!("item text starts in Printing"),
            script_bridge::ScriptEffect::WaitFieldPrompt {protected_remaining} => {
                if *protected_remaining>0 { *protected_remaining-=1;return false; }
                if a_just_pressed || b_just_pressed {
                    *sfx_event=OverworldSfxEvent::TextAdvance;
                    true
                } else {false}
            }
            script_bridge::ScriptEffect::PlayCry''')
edit(f,'ScriptEffect::PrintFieldParagraph { text, phase } =>','ScriptEffect::PrintFieldParagraph { text, phase, .. } =>')
edit(f,'FieldParagraphPhase::Printing => unreachable!("handled with inner printing"),','FieldParagraphPhase::Printing | FieldParagraphPhase::PlayingSound => unreachable!("handled with inner printing/sound"),')
edit(f,'ScriptEffect::PrintFieldParagraph {text:"next paragraph".into(),phase:','ScriptEffect::PrintFieldParagraph {text:"next paragraph".into(),sound_id:None,phase:')
f='crates/pokered-core/src/overworld/screen.rs'
edit(f,'Some(super::script_bridge::ScriptEffect::FinishFieldText { .. }','Some(super::script_bridge::ScriptEffect::WaitFieldPrompt { .. } | super::script_bridge::ScriptEffect::FinishFieldText { .. }')
# Greeting/receipt paragraphs: preserve same text content but explicit original PARA boundaries.
for map,rod,article in [('VermilionOldRodHouse','OLD','an'),('FuchsiaGoodRodHouse','GOOD','a')]:
 f=f'crates/pokered-data/maps/{map}/script.scene';p=w/f;s=p.read_text();start=s.index('            @speaker("") {',s.index('@if (given)'));end=s.index('\n          } @else',start)
 old=s[start:end];flag=f'EVENT_GOT_{rod}_ROD';rec=old[old.index('showItemDialogue(')+len('showItemDialogue('):].split('\n            @speaker')[0].strip();assert rec.endswith(')');rec=rec[:-1]
 greeting=old[old.index('@t('):old.index('\n            }')].strip();assert greeting.endswith(')');import re
 en,zh=re.match(r'@t\("(.*?)", "(.*?)"\)',greeting).groups();e=en.split(r'\n\n');z=zh.split(r'\n\n');assert len(e)==len(z)==2
 new=f'''            setFlag("{flag}")
            printFieldText(@t("{e[0]}", "{z[0]}"))
            printFieldParagraph(@t("{e[1]}", "{z[1]}"))
            printFieldParagraph({rec}, "SFX_GET_ITEM_1")'''
 if rod=='OLD':
  narration=old[old.index('@t(',old.index('showItemDialogue(')):].split('\n            }')[0].strip();new+='\n            printFieldParagraph('+narration+')'
 new+='\n            finishFieldText()';s=s[:start]+new+s[end:];p.write_text(s)
f='crates/pokered-data/maps/Route12SuperRodHouse/script.scene';p=w/f;s=p.read_text();start=s.index('            showItemDialogue(');end=s.index('\n          } @else',start);old=s[start:end];en,zh=re.match(r'            showItemDialogue\(@t\("(.*?)", "(.*?)"\)\)',old).groups();e=en.split(r'\n\n');z=zh.split(r'\n\n');assert len(e)==len(z)==3
new=f'''            printFieldText(@t("{e[0]}", "{z[0]}"))
            printFieldParagraph(@t("{e[1]}", "{z[1]}"))
            printFieldParagraph(@t("{e[2]}", "{z[2]}"), "SFX_GET_ITEM_1")''';narration=old[old.index('@t(',old.index('@speaker')):].split('\n            }')[0].strip();new+='\n            printFieldParagraph('+narration+')\n            finishFieldText()';s=s[:start]+new+s[end:];p.write_text(s)
f='crates/pokered-data/maps/PokemonFanClub/script.scene';p=w/f;s=p.read_text();start=s.index('          @speaker("") {',s.index('@option(@t("YES"'));end=s.index('\n          // Original: GiveItem',start);old=s[start:end];text=old[old.index('@t('):].split('\n          }')[0].strip();s=s[:start]+'          printFieldText('+text+')\n          waitFieldPrompt()'+s[end:]
s=s.replace('            setFlag("EVENT_GOT_BIKE_VOUCHER")\n','',1).replace('            showItemDialogue(', '            printItemFieldText(',1)
start=s.index('            @speaker("") { @t("Exchange');end=s.index('\n          } @else',start);old=s[start:end];text=old[old.index('@t('):].rsplit(' }',1)[0].strip();s=s[:start]+'            printFieldParagraph('+text+')\n            setFlag("EVENT_GOT_BIKE_VOUCHER")\n            finishFieldText()'+s[end:];p.write_text(s)
