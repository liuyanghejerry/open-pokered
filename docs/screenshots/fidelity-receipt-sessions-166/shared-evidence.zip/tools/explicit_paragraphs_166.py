from pathlib import Path
import re,json
w=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout');report=[]
pat=r'@t\("(.*?)", "(.*?)"\)'
for map in ['VermilionOldRodHouse','FuchsiaGoodRodHouse','Route12SuperRodHouse','PokemonFanClub']:
 p=w/f'crates/pokered-data/maps/{map}/script.scene';s=p.read_text();start=s.index('  @storyline("talkChairman")') if map=='PokemonFanClub' else 0;end=s.index('  @storyline("talkReceptionist")') if map=='PokemonFanClub' else len(s);piece=s[start:end]
 def authored(en,zh,first,indent):
  a=en.split(r'\n\n');b=zh.split(r'\n\n');assert len(a)==len(b);report.append(dict(map=map,first=first,paragraphs=len(a),english=en))
  return ('\n'+indent).join((first if i==0 else 'printFieldParagraph')+'(@t("'+e+'", "'+z+'"))' for i,(e,z) in enumerate(zip(a,b)))
 def outer(m):
  indent=m[1];en,zh=re.match(pat,m[2]).groups();return indent+authored(en,zh,'printFieldText',indent)+'\n'+indent+'finishFieldText()'
 piece=re.sub(r'(?m)^([ \t]*)@speaker\(""\)\s*\{\s*('+pat+r')\s*\}',outer,piece)
 def inner(m):
  indent,kind,en,zh=m.groups();return indent+authored(en,zh,kind,indent)
 piece=re.sub(r'(?m)^([ \t]*)(printFieldText|printFieldParagraph)\(@t\("(.*?)", "(.*?)"\)\)\s*$',inner,piece)
 p.write_text(s[:start]+piece+s[end:])
p=w/'crates/pokered-app/src/game.rs';s=p.read_text();a=s.index('    fn fishing_and_chairman_questions_auto_return_but_story_prompt_still_waits()');b=s.index('\n    #[test]',a);piece=s[a:b].replace('let ack=g.overworld.pending_dialogue.as_ref().is_some_and(|d| d.waiting_for_input() && !d.holding_open() && d.has_more_pages());','let ack=receipt_prompt_needs_press(&g);');s=s[:a]+piece+s[b:];p.write_text(s)
(w.parent/'fidelity-39-plus/audit-166-paragraph-migrations.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
