from pathlib import Path
import shutil,subprocess,os,concurrent.futures,json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');w=r.parent/'fidelity-91-plus-checkout';base=r.parent/'fidelity-18-27/target/debug/deps';env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib');bins={'core':'pokered_core-2c51020d2f798a38','data':'pokered_data-d7b082c31245379f','app':'pokered_app-b8d052c409cfb957','agent':'pokered_agent-9deab8be0a621659'}
assert 'Finished `test`' in (r/'audit-166-build-a8.log').read_text();out=r/'audit-166-after-a8-immutable';out.mkdir();shutil.copy2(base/bins['app'],out/'pokered_app');(out/'pokered_app').chmod(0o555)
def unit(k):
 with (r/f'audit-166-{k}-tests-a8.log').open('w') as f:p=subprocess.run([str(base/bins[k]),'--test-threads=1'],env=env,cwd=w,stdout=f,stderr=subprocess.STDOUT)
 print(k,p.returncode,flush=True);assert p.returncode==0
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(unit,bins))
for case in ['old','good','super','chairman']:
 for trial in [1,2]:
  dest=r/f'audit-166-native-after-a8-{case}-{trial}';en=dict(env,FIDELITY_RECEIPT_CASE=case,FIDELITY_RECEIPT_CAPTURE=str(dest))
  if trial==2:en['FIDELITY_RECEIPT_INPUTS']=str(r/f'audit-166-native-after-a8-{case}-1/inputs.json')
  log=r/f'audit-166-native-after-a8-{case}-{trial}.log'
  with log.open('w') as f:p=subprocess.run([str(out/'pokered_app'),'game::link_stats_cry_fidelity_tests::capture_reward_receipt_166','--exact','--ignored','--nocapture','--test-threads=1'],env=en,cwd=w,stdout=f,stderr=subprocess.STDOUT)
  assert p.returncode==0 and '1 passed' in log.read_text()
  frames=json.loads((dest/'frames.json').read_text());assert any(x['overworld']['active_script_effect'] and next(iter(x['overworld']['active_script_effect'].values())).get('phase')=='PlayingSound' for x in frames)
  if trial==2:
   a=r/f'audit-166-native-after-a8-{case}-1';assert all(x.read_bytes()==(a/x.name).read_bytes() for x in dest.iterdir())
 print(case,'repeat exact',len(frames),flush=True)
