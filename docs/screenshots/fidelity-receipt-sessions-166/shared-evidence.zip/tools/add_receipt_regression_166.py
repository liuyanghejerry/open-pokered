from pathlib import Path
w=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout')
p=w/'crates/pokered-core/src/overworld/native_script.rs';s=p.read_text().replace('args::string(value,name)','args::text(value,name)');p.write_text(s)
p=w/'crates/pokered-app/src/game.rs';s=p.read_text();marker='    #[test]\n    fn fishing_and_chairman_questions_auto_return_but_story_prompt_still_waits()';a=s.index(marker)
helper='''    fn receipt_prompt_needs_press(g: &PokemonGame) -> bool {
        use pokered_core::overworld::script_bridge::{ScriptEffect,FieldParagraphPhase};
        match pokered_core::snapshot::OverworldSnapshot::capture(&g.overworld).active_script_effect {
            Some(ScriptEffect::WaitFieldPrompt {protected_remaining:0})
            | Some(ScriptEffect::FinishFieldText {acknowledged:false})
            | Some(ScriptEffect::PrintFieldParagraph {phase:FieldParagraphPhase::WaitForButton,..}) => true,
            Some(ScriptEffect::ShowDialogue {..}) => g.overworld.pending_dialogue.as_ref().is_some_and(|d|d.waiting_for_input() && !d.holding_open()),
            Some(ScriptEffect::PrintFieldText {..})
            | Some(ScriptEffect::ShowItemDialogue {..})
            | Some(ScriptEffect::PrintItemFieldText {phase:FieldParagraphPhase::Printing,..})
            | Some(ScriptEffect::PrintFieldParagraph {phase:FieldParagraphPhase::Printing,..}) => g.overworld.pending_dialogue.as_ref().is_some_and(|d|d.waiting_for_input() && d.has_more_pages()),
            _ => false,
        }
    }

'''
s=s[:a]+helper+s[a:];a=s.index(marker);b=s.index('\n    #[test]',a+len(marker));old=s[a:b]
old=old.replace('''let ack=g.overworld.pending_dialogue.as_ref().is_some_and(|d| d.waiting_for_input() && !d.holding_open()
                            && (g.overworld.active_script_effect_label().as_deref()!=Some("ShowItemDialogue") || d.has_more_pages()));''','let ack=receipt_prompt_needs_press(&g);')
old=old.replace('if accept && map==MapId::PokemonFanClub && ack {','if accept && map==MapId::PokemonFanClub && ack && g.overworld.active_script_effect_label().as_deref()==Some("WaitFieldPrompt") {').replace('let d=g.overworld.pending_dialogue.as_ref().unwrap();','let d=g.overworld.displayed_field_dialogue().unwrap();')
s=s[:a]+old+s[b:]
a=s.index(marker)
new='''    #[test]
    fn rod_and_voucher_receipts_keep_inner_sound_and_fresh_outer_confirmation() {
        use pokered_core::overworld::{Direction,script_bridge::{ScriptEffect,FieldParagraphPhase}};
        use pokered_core::snapshot::OverworldSnapshot;
        use pokered_data::items::ItemId;
        run_link_save_fixture(|| {
            for (map,x,y,item,flag) in [
                (MapId::VermilionOldRodHouse,2,5,ItemId::OldRod,"EVENT_GOT_OLD_ROD"),
                (MapId::FuchsiaGoodRodHouse,5,4,ItemId::GoodRod,"EVENT_GOT_GOOD_ROD"),
                (MapId::Route12SuperRodHouse,2,5,ItemId::SuperRod,"EVENT_GOT_SUPER_ROD"),
                (MapId::PokemonFanClub,3,2,ItemId::BikeVoucher,"EVENT_GOT_BIKE_VOUCHER"),
            ] {
                let mut g=fixture(Species::Bulbasaur,x,Direction::Up);
                g.state.config.language=pokered_core::game_state::Lang::En;
                g.overworld.warp_to_map(map,x as u8,y);
                let idle=InputState::new();let a=button(GbButton::A);
                for _ in 0..120 {g.update(&idle);}
                g.update(&button(GbButton::Up));for _ in 0..20 {g.update(&idle);}
                let mut saw_story=false;let mut sound_started=None;let mut sound_ended=None;
                for t in 0..6000 {
                    let before=OverworldSnapshot::capture(&g.overworld);
                    let sound=matches!(before.active_script_effect,
                        Some(ScriptEffect::PrintItemFieldText {phase:FieldParagraphPhase::PlayingSound,..})
                        | Some(ScriptEffect::PrintFieldParagraph {phase:FieldParagraphPhase::PlayingSound,..}));
                    if sound {
                        if sound_started.is_none() {
                            sound_started=Some(t);
                            assert!(g.save_data.game_data.bag.has_item_const(item));
                            assert_eq!(g.overworld.script_flags().get(flag).copied().unwrap_or(false),map!=MapId::PokemonFanClub);
                            assert!(g.overworld.displayed_field_dialogue().unwrap().get_display_text().is_some_and(|(a,b)|format!("{a} {b}").contains("received")));
                            let raw=serde_json::to_string(&before).unwrap();serde_json::from_str::<OverworldSnapshot>(&raw).unwrap().restore_into(&mut g.overworld);
                        }
                        assert!(!g.overworld.dialogue_needs_button());
                        assert!(before.field_text_restore.is_none());
                        let pulse=sound_started.is_some_and(|start|t==start+1);
                        let mut keys=InputState::new();if pulse {keys.press(GbButton::B);keys.press(GbButton::Down);}
                        g.update(&keys);
                        assert_eq!((g.overworld.state.player.x,g.overworld.state.player.y),(x,u16::from(y)));
                    } else if sound_started.is_some() {sound_ended=Some(t);break;} else {
                        let prompt=receipt_prompt_needs_press(&g);
                        if matches!(before.active_script_effect,Some(ScriptEffect::WaitFieldPrompt {protected_remaining:0})) {
                            assert!(!g.save_data.game_data.bag.has_item_const(item));saw_story=true;
                            // Keep A held after PROMPT acknowledgement: inner
                            // ManualTextScroll must return without HoldA/Close.
                            for _ in 0..8 {g.update(&a);}
                            assert!(g.save_data.game_data.bag.has_item_const(item));
                            assert!(OverworldSnapshot::capture(&g.overworld).field_text_restore.is_none());
                            g.update(&idle);
                        } else {g.update(if t==0 || prompt || g.overworld.pending_choice.is_some() {&a} else {&idle});}
                    }
                }
                assert!(sound_started.is_some() && sound_ended.is_some(),"{map:?}: actual receipt jingle");
                assert_eq!(saw_story,map==MapId::PokemonFanClub);
                for _ in 0..60 {g.update(&idle);}
                assert!(g.overworld.dialogue_needs_button());
                assert_eq!(g.overworld.active_script_effect_label().as_deref(),Some(if map==MapId::FuchsiaGoodRodHouse {"FinishFieldText"} else {"PrintFieldParagraph"}));
                assert!(g.overworld.displayed_field_dialogue().unwrap().get_display_text().is_some_and(|(a,b)|format!("{a} {b}").contains("received")),"jingle must not dismiss receipt or start explanation automatically");
                if map!=MapId::FuchsiaGoodRodHouse {
                    g.update(&button(GbButton::B));
                    for t in 1..20 {g.update(&idle);assert_eq!(g.overworld.displayed_field_dialogue().unwrap().get_display_text(),Some((String::new(),String::new())),"blank {t}");}
                    g.update(&idle);assert_eq!(g.overworld.displayed_field_dialogue().unwrap().char_index(),1);
                    for _ in 0..3000 {
                        if g.overworld.active_script_effect_label().as_deref()==Some("FinishFieldText") {break;}
                        let ack=receipt_prompt_needs_press(&g);g.update(if ack {&a} else {&idle});
                    }
                }
                assert_eq!(g.overworld.active_script_effect_label().as_deref(),Some("FinishFieldText"));
                assert!(g.overworld.script_flags().get(flag).copied().unwrap_or(false));
                for _ in 0..40 {g.update(&idle);assert!(g.overworld.displayed_field_dialogue().is_some());}
                for _ in 0..8 {g.update(&a);assert!(g.overworld.displayed_field_dialogue().is_some());}
                for _ in 0..40 {g.update(&idle);}
                assert!(g.overworld.displayed_field_dialogue().is_none());
            }
        });
    }

'''
s=s[:a]+new+s[a:];p.write_text(s)
