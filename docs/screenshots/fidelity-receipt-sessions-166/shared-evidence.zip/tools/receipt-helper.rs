    #[test]
    #[ignore = "matched NPC reward interaction and raw frame evidence"]
    fn capture_reward_receipt_166() {
        use pokered_core::overworld::Direction;
        run_link_save_fixture(|| {
            let dir=std::path::PathBuf::from(std::env::var("FIDELITY_RECEIPT_CAPTURE").unwrap());std::fs::create_dir_all(&dir).unwrap();
            let (map,x,y,item,flag)=match std::env::var("FIDELITY_RECEIPT_CASE").unwrap().as_str() {
                "old" => (MapId::VermilionOldRodHouse,2,5,"OLD_ROD","EVENT_GOT_OLD_ROD"),
                "good" => (MapId::FuchsiaGoodRodHouse,5,4,"GOOD_ROD","EVENT_GOT_GOOD_ROD"),
                "super" => (MapId::Route12SuperRodHouse,2,5,"SUPER_ROD","EVENT_GOT_SUPER_ROD"),
                "chairman" => (MapId::PokemonFanClub,3,2,"BIKE_VOUCHER","EVENT_GOT_BIKE_VOUCHER"),
                _ => panic!("unknown fixture"),
            };
            let mut g=fixture(Species::Bulbasaur,x,Direction::Up);g.state.config.language=pokered_core::game_state::Lang::En;
            g.overworld.warp_to_map(map,x as u8,y);let idle=InputState::new();for _ in 0..120 {g.update(&idle);}
            for n in &mut g.overworld.npc_states {n.movement_type=pokered_core::overworld::NpcMovementType::Stationary;n.x=n.home_x;n.y=n.home_y;n.walk_counter=0;}
            let replay:Option<Vec<Vec<String>>>=std::env::var("FIDELITY_RECEIPT_INPUTS").ok().map(|p|serde_json::from_str(&std::fs::read_to_string(p).unwrap()).unwrap());
            let mut input=InputState::new();let mut rows=Vec::new();let mut controls=Vec::new();let mut sound_started=None;
            for t in 0..replay.as_ref().map_or(4000,Vec::len) {
                let effect=g.overworld.active_script_effect_value().unwrap_or(serde_json::Value::Null);
                let kind=effect["effect"].as_str().unwrap_or("");
                let sound=(kind=="ShowItemDialogue" && effect["sound_started"]==true)
                    || ((kind=="PrintFieldParagraph" || kind=="PrintItemFieldText") && effect["phase"]=="PlayingSound");
                if sound {sound_started.get_or_insert(t);}
                let buttons=if let Some(replay)=&replay {replay[t].clone()} else if t<20 {vec!["up".to_string()]} else if (20..40).contains(&t) {vec!["a".to_string()]} else if let Some(start)=sound_started {
                    if (start+180..start+182).contains(&t) {vec!["a".to_string()]} else {Vec::new()}
                } else {
                    let pages=g.overworld.pending_dialogue.as_ref().is_some_and(|d|d.waiting_for_input() && !d.holding_open() && (kind=="ShowDialogue" || d.has_more_pages()));
                    let wait=(kind=="PrintFieldParagraph" && effect["phase"]=="WaitForButton") || (kind=="WaitFieldPrompt" && effect["protected_remaining"]==0);
                    if pages || wait || g.overworld.pending_choice.is_some() {vec!["a".to_string()]} else {Vec::new()}
                };
                input.begin_frame();for (name,button) in [("up",GbButton::Up),("a",GbButton::A)] {if buttons.iter().any(|v|v==name) {input.press(button);} else {input.release(button);}}
                g.update(&input);let mut fb=FrameBuffer::new(RenderConfig::new(160,144),Rgba::WHITE);g.draw(&mut fb);fb.save_png(&dir.join(format!("frame-{t:04}.png"))).unwrap();
                let raw=serde_json::to_value(pokered_core::snapshot::OverworldSnapshot::capture(&g.overworld)).unwrap();
                if t==0 {std::fs::write(dir.join("initial-snapshot.json"),serde_json::to_string_pretty(&raw).unwrap()).unwrap();}
                let selected:serde_json::Map<String,serde_json::Value>=["state","player_sprite_state","npc_states","active_script_effect","pending_dialogue","last_script_dialogue","inner_field_text_open","field_text_restore","field_loop_wait"].into_iter().map(|k|(k.into(),raw.get(k).cloned().unwrap_or(serde_json::Value::Null))).collect();
                rows.push(serde_json::json!({"t":t,"input_bits":input.raw_current(),"sfx_playing":g.audio.as_ref().unwrap().is_sfx_playing(),"audio_channels":channels(&g),"has_item":g.save_data.game_data.bag.has_item_const(item),"obtained_flag":g.overworld.script_flags().get(flag).copied().unwrap_or(false),"overworld":selected}));controls.push(buttons);
                if replay.is_none() && sound_started.is_some_and(|start|t>=start+260) {break;}
            }
            assert!(g.save_data.game_data.bag.has_item_const(item),"both branch fixtures must actually receive the reward");
            std::fs::write(dir.join("frames.json"),serde_json::to_string_pretty(&rows).unwrap()).unwrap();std::fs::write(dir.join("inputs.json"),serde_json::to_string_pretty(&controls).unwrap()).unwrap();
        });
    }

