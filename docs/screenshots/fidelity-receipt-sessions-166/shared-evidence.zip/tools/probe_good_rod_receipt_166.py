exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';setup=r/'audit-166-good-source-setup';setup.mkdir(exist_ok=True);rom=r/'safari-147-source-setup/reference.gbc';state=run/'retail-field.state'
p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(state.read_bytes()))
get=lambda n:int(p.memory[symbols[n][1]])
put=lambda n,v:p.memory.__setitem__(symbols[n][1],v)
def destination(_):
 if get('wCurMap')==0xa4:
  px,py=5,4;oldx,oldy=get('wXCoord'),get('wYCoord');base=symbols['wCurrentTileBlockMapViewPointer'][1];ptr=p.memory[base]+p.memory[base+1]*256
  ptr+=((py-4)//2-(oldy-4)//2)*10+(px-4)//2-(oldx-4)//2;p.memory[base]=ptr&255;p.memory[base+1]=ptr>>8
  put('wXCoord',px);put('wYCoord',py);put('wXBlockCoord',px%2);put('wYBlockCoord',py%2)
p.hook_register(*symbols['LoadTilesetHeader.done'],destination,None)
put('hWarpDestinationMap',0xa4);put('wDestinationWarpID',0);put('wStatusFlags3',get('wStatusFlags3')|8);p.tick(240);p.hook_deregister(*symbols['LoadTilesetHeader.done'])
put('wStatusFlags1',get('wStatusFlags1')&~16);put('wNumBagItems',0);put('wBagItems',0xff)
p.button_press('up');p.tick(2);p.button_release('up');p.tick(30)
assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(0xa4,5,4)
with (setup/'pretrigger.state').open('wb') as f:p.save_state(f)
(setup/'provenance.json').write_text(json.dumps(dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),state_sha256=hashlib.sha256(state.read_bytes()).hexdigest(),setup='Controlled warp0xa4/0 and LoadTilesetHeader.done player5,4,block parity/view stride10; clear BIT_GOT_GOOD_ROD,empty bag; actualUp facing. No ROM/text/tile edits, not ordinary travel proof.'),indent=2)+'\n');p.stop(save=False)
sound_id=(symbols['SFX_Get_Item1_1'][1]-symbols['SFX_Headers_1'][1])//3
for trial in [1,2]:
 out=r/f'audit-166-original-good-{trial}';out.mkdir(exist_ok=True);p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'pretrigger.state').read_bytes()));events=[];rows=[];now=[-1];need=[False];receipt=[None];final_wait=[None];closed=[None];held_until=None;last_ack=-100;choice_due=[None]
 def hook(n):
  a=int(p.register_file.A)
  if n=='PlaySound' and a==sound_id:receipt[0]=now[0]
  if n=='YesNoChoice':choice_due[0]=now[0]+40
  if n=='WaitForTextScrollButtonPress':
   need[0]=True
   if n=='WaitForTextScrollButtonPress' and receipt[0] is not None and final_wait[0] is None:final_wait[0]=now[0]
  if n=='CloseTextDisplay':closed[0]=now[0]
  events.append(dict(t=now[0],routine=n,cycles=p._cycles(),A=a,good_flag=bool(get('wStatusFlags1')&16),bag_count=get('wNumBagItems'),bag_items=list(p.memory[symbols['wBagItems'][1]:symbols['wBagItems'][1]+5])))
 for n in ['DisplayTextID','PrintText','YesNoChoice','GiveItem','Paragraph','ManualTextScroll','WaitForTextScrollButtonPress','PlaySound','WaitForSoundToFinish','AfterDisplayingTextID','HoldTextDisplayOpen','CloseTextDisplay']:p.hook_register(*symbols[n],hook,n)
 for t in range(1800):
  now[0]=t;press=False
  if held_until is not None and t==held_until:p.button_release('a');held_until=None
  if t==choice_due[0]:need[0]=True
  ready=need[0] and held_until is None and t-last_ack>=8
  if final_wait[0] is not None and t<final_wait[0]+60:ready=False
  if t==0 or ready:p.button_press('a');press=True;held_until=t+2;last_ack=t;need[0]=False
  p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png');rows.append(dict(t=t,press_a=press,held_a=held_until is not None,final_wait=final_wait[0],receipt=receipt[0],closed=closed[0],good_flag=bool(get('wStatusFlags1')&16),bag_count=get('wNumBagItems')))
  if closed[0] is not None and t>=closed[0]+30:break
 (out/'events.json').write_text(json.dumps(events,indent=2)+'\n');(out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');p.stop(save=False)
 assert receipt[0] is not None and final_wait[0] is not None and closed[0] is not None,('incomplete',receipt,final_wait,closed)
 assert closed[0]>=final_wait[0]+60
 if trial==2:
  a=r/'audit-166-original-good-1';assert all(f.read_bytes()==(a/f.name).read_bytes() for f in out.iterdir())
 print(trial,'sound',receipt[0],'outerWait',final_wait[0],'close',closed[0],'frames',len(rows),flush=True)
