use std::{fs, path::Path};
use dotzuki_app::InputState;
use dotzuki_engine::render_config::RenderConfig;
use dotzuki_renderer::input::GbButton;
use pokered_app::{PokemonGame, render::draw_pokedex_screen};
use pokered_core::{game_state::{GameScreen, Lang}, pokedex_screen::PokedexScreenState, save::SaveData};
use pokered_data::{maps::MapId, species::Species, wild_data::GameVersion};
use pokered_renderer::{FrameBuffer, Rgba, resource::{AssetRoot, ResourceManager}};
use serde_json::json;

fn idle(g: &mut PokemonGame, n: usize) {
    for _ in 0..n { g.update(&InputState::new()); }
}
fn press(g: &mut PokemonGame, keys: &[GbButton]) {
    let mut input = InputState::new();
    for &key in keys { input.press(key); }
    g.update(&input);
}
fn game(count: u8) -> PokemonGame {
    let mut g = PokemonGame::new_with_options(
        GameVersion::Red, None, None, None, false, None, false, true,
        #[cfg(feature = "debug-server")] None,
    );
    g.save_data = SaveData::new();
    let mut dex = g.save_data.game_data.pokedex.clone();
    for n in 1..=count { dex.set_seen(Species::from_index_id(n)); }
    g.save_data.game_data.pokedex = dex.clone();
    g.pokedex_screen = PokedexScreenState::new(dex, GameVersion::Red);
    g.state.screen = GameScreen::Pokedex;
    g.state.config.language = Lang::En;
    idle(&mut g, 70);
    g
}
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let out = Path::new(&args[1]);
    let fixed = args[2] == "after";
    fs::create_dir_all(out).unwrap();
    use GbButton::{A, Down, Up, Left, Right};
    let cases: Vec<(&str, u8, usize, Option<usize>, Vec<GbButton>, (u16,u16,&str,u8))> = vec![
        ("down",25,0,None,vec![Down],(2,0,"List",0)),
        ("down-a",25,0,None,vec![Down,A],(3,1,"List",0)),
        ("up-right",25,0,None,vec![Up,Right],(1,0,"List",0)),
        ("down-right",25,0,None,vec![Down,Right],(3,1,"List",0)),
        ("right",25,0,None,vec![Right],(8,7,"List",0)),
        ("a-right",25,0,None,vec![A,Right],(8,7,"List",0)),
        ("a",25,0,None,vec![A],(1,0,"SideMenu",0)),
        ("left-a",25,0,None,vec![Left,A],(1,0,"List",0)),
        ("up-down-top",25,0,None,vec![Up,Down],(1,0,"List",0)),
        ("up-down-mid",25,3,None,vec![Up,Down],(3,0,"List",0)),
        ("short-down-a",6,0,None,vec![Down,A],(2,0,"List",0)),
        ("side-top",25,0,Some(0),vec![Up,Down],(1,0,"SideMenu",0)),
        ("side-mid",25,0,Some(2),vec![Up,Down],(1,0,"SideMenu",1)),
    ];
    let mut rows = Vec::new();
    for (name,count,list_rows,side_rows,keys,expected) in cases {
        let mut g = game(count);
        let bag = serde_json::to_value(g.save_data.game_data.bag.items()).unwrap();
        for _ in 0..list_rows { press(&mut g,&[Down]); idle(&mut g,23); }
        if let Some(n) = side_rows {
            press(&mut g,&[A]); idle(&mut g,47);
            for _ in 0..n { press(&mut g,&[Down]); idle(&mut g,23); }
        }
        press(&mut g,&keys);
        idle(&mut g,if side_rows.is_some() {72} else {120});
        assert_eq!(serde_json::to_value(g.save_data.game_data.bag.items()).unwrap(),bag);
        assert_eq!(g.pokedex_screen.seen_count() as usize,count as usize);
        assert_eq!(g.pokedex_screen.owned_count(),0);
        let mode = format!("{:?}",g.pokedex_screen.mode());
        let endpoint=(g.pokedex_screen.cursor(),g.pokedex_screen.scroll_offset(),mode.as_str(),g.pokedex_screen.side_menu_cursor());
        if fixed { assert_eq!(endpoint,expected,"actual host input case {name}"); }
        let mut fb=FrameBuffer::new(RenderConfig::new(160,144),Rgba::WHITE);
        let mut rm=Some(ResourceManager::new(AssetRoot::auto_detect().unwrap()));
        draw_pokedex_screen(&g.pokedex_screen,MapId::ViridianPokecenter,false,&mut rm,&mut fb);
        fb.save_png(&out.join(format!("{name}.png"))).unwrap();
        rows.push(json!({"case":name,"seen":count,"owned":0,"initial_list_row":list_rows,"initial_side_row":side_rows,"keys":keys.iter().map(|b|format!("{b:?}")).collect::<Vec<_>>(),"relative_frame":190+24*side_rows.unwrap_or(list_rows),"cursor":endpoint.0,"scroll":endpoint.1,"mode":endpoint.2,"side_cursor":endpoint.3,"inventory_stable":true,"method":"seeded public PokemonGame, actual update(InputState), real Pokedex renderer; not TCP nor natural START/playthrough"}));
        println!("{name}: {endpoint:?}");
    }
    fs::write(out.join("cases.json"),serde_json::to_string_pretty(&rows).unwrap()+"\n").unwrap();
}
