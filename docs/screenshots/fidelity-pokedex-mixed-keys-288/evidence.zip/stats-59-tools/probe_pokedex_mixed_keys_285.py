exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state';case=os.environ.get('DEX_MIXED_CASE_285','down-a');count=int(os.environ.get('DEX_MAX_SEEN_280','25'));row=int(os.environ.get('DEX_INITIAL_ROW_280','0'))
for repeat in [1,2]:
 out=r/f'audit-285-original-dex-{case}-max-{count}-row-{row}-a1-{repeat}';out.mkdir(exist_ok=False)
 p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]]);a=symbols['wPokedexSeen'][1]
 for n in range(symbols['wPokedexSeenEnd'][1]-a):p.memory[a+n]=0
 for n in range(count):p.memory[a+n//8]=int(p.memory[a+n//8])|(1<<(n%8))
 for n in range(symbols['wPokedexOwnedEnd'][1]-symbols['wPokedexOwned'][1]):p.memory[symbols['wPokedexOwned'][1]+n]=0
 p.memory[symbols['wBattleAndStartSavedMenuItem'][1]]=0
 cues={'ShowPokedexMenu':None};now=[-1];events=[];held=None;rows=[]
 def hook(n):
  if n in cues and cues[n] is None:cues[n]=now[0]
  events.append({'t':now[0],'routine':n,'cursor':get('wCurrentMenuItem'),'scroll':get('wListScrollOffset'),'joy7':get('hJoy7'),'joy6':get('hJoy6'),'countdown':get('hFrameCounter'),'held':get('hJoyHeld'),'pressed':get('hJoyPressed'),'sample':get('hJoy5')})
 for n in ['ShowPokedexMenu','HandlePokedexListMenu','HandleMenuInput','PlaceMenuCursor','JoypadLowSensitivity','HandleMenuInput_.keyPressed','HandlePokedexSideMenu']:p.hook_register(*symbols[n],hook,n)
 for t in range(900):
  now[0]=t;key='start' if t in [0,1] else ('a' if t in [70,71] else None);anchor=cues['ShowPokedexMenu']
  if anchor is not None:
   key=None;offset=t-anchor
   key='down' if offset in [70+24*i for i in range(row)] else None
   if offset==70+24*row:key=case
  if key!=held:
   if held:
    for k in held.split('-'):p.button_release(k)
   if key:
    for k in key.split('-'):p.button_press(k)
   held=key
  p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png');rows.append({'t':t,'input':key,'cues':dict(cues),'cursor':get('wCurrentMenuItem'),'scroll':get('wListScrollOffset'),'max_seen':get('wDexMaxSeenMon'),'joy7':get('hJoy7'),'joy6':get('hJoy6'),'countdown':get('hFrameCounter'),'held':get('hJoyHeld'),'pressed':get('hJoyPressed'),'sample':get('hJoy5')})
  if anchor is not None and t>=anchor+190+24*row:break
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
 assert cues['ShowPokedexMenu'] is not None,(case,events[-10:])
 expected={'down':(1,0),'down-a':(1,1 if count>=7 else 0),'up-right':(0,0),'down-right':(1,1),'right':(0,7),'a-right':(0,7),'a':(0,0),'left-a':(0,0),'up-down':(max(0,row-1),0)}[case]
 assert (rows[-1]['cursor'],rows[-1]['scroll'])==expected,(case,rows[-1])
 assert sum(e['routine']=='HandlePokedexSideMenu' for e in events)==(1 if case=='a' else 0),(case,events[-10:])
 if repeat==2:
  other=r/f'audit-285-original-dex-{case}-max-{count}-row-{row}-a1-1';assert all(p.read_bytes()==(other/p.name).read_bytes() for p in out.iterdir())
 print(case,repeat,rows[-1],flush=True)
