from pathlib import Path
import json,re,hashlib,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-285-pokedex-input-checkout';base='c6f40c24f008c00c8dd74433affae3504a41878d';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip();sha=lambda b:hashlib.sha256(b).hexdigest();files={}
tests=json.loads((r/'audit-288-full-regression-summary.json').read_text());assert tests['source_head']==head and tests['programs']==78 and tests['failed']==0
cli=json.loads((r/'audit-288-dex-cli-regression-results.json').read_text());assert cli['base']==base and cli['head']==head and cli['fresh_m01_m03'] and cli['separate_process_s07_save_continue']
def pair(prefix,source=False):
 a,b=[r/(prefix+'-'+str(n)) for n in [1,2]];assert sorted(p.name for p in a.iterdir())==sorted(p.name for p in b.iterdir());assert all(p.read_bytes()==(b/p.name).read_bytes() for p in a.iterdir())
 for d in [a,b]:
  for p in d.iterdir():assert p.suffix in ['.json','.png'];files[str(p.relative_to(r))]=p
 return a
native={}
for side in ['before','after']:
 d=pair('audit-288-host-'+side+'-a1');native[side]={x['case']:x for x in json.loads((d/'cases.json').read_text())};assert len(native[side])==13 and all(x['inventory_stable'] for x in native[side].values())
cases=[]
for d in sorted(r.glob('audit-285-original-dex-*-a1-1')):
 m=re.fullmatch(r'audit-285-original-dex-(.*)-max-(\d+)-row-(\d+)-a1-1',d.name);assert m;pair(d.name[:-2],True);rows=json.loads((d/'frames.json').read_text());events=json.loads((d/'events.json').read_text());name=m[1]
 if name=='up-down':name='up-down-mid' if int(m[3]) else 'up-down-top'
 if int(m[2])==6:name='short-down-a'
 after=native['after'][name];mode='SideMenu' if any(x['routine']=='HandlePokedexSideMenu' for x in events) else 'List';assert after['mode']==mode and after['scroll']==rows[-1]['scroll'] and after['cursor']==rows[-1]['cursor']+rows[-1]['scroll']+1;cases.append(name)
for row,name in [(0,'side-top'),(2,'side-mid')]:
 d=pair(f'audit-287-original-dex-side-up-down-max-25-row-{row}-a2',True);rows=json.loads((d/'frames.json').read_text());after=native['after'][name];assert after['mode']=='SideMenu' and after['side_cursor']==rows[-1]['cursor'] and after['cursor']==1;cases.append(name)
assert len(cases)==13
for name in ['down','right','a']:assert (r/f'audit-288-host-before-a1-1/{name}.png').read_bytes()==(r/f'audit-288-host-after-a1-1/{name}.png').read_bytes()
for name in ['audit-288-full-regression-summary.json','audit-288-dex-all-tests-build-a1.log','audit-288-dex-all-unit-and-integration-results-a1.json','audit-288-dex-all-tests-a1-immutable/manifest.json','audit-288-dex-cli-build-a1.log','audit-288-dex-cli-immutable/manifest.json','audit-288-dex-cli-regression-results.json','audit-288-dex-cli-regression-run.log','audit-288-before-host-immutable/manifest.json','audit-288-after-host-immutable/manifest.json','audit-288-host-tool-dependency-equivalence.json','audit-288-before-host-tool-build-a2.log','audit-288-after-host-tool-build-a1.log','capture_pokedex_host_288.rs','freeze_run_pokedex_input_all_tests_288.py','freeze_run_pokedex_input_cli_288.py','stats-59-tools/probe_pokedex_mixed_keys_285.py','stats-59-tools/probe_pokedex_side_mixed_keys_287_a2.py','audit-285-original-mixed-key-all11-summary.json','audit-287-original-side-mixed-keys-a2.log','audit-285-native-core-all-pokedex-before-a2.log','audit-287-native-side-priority-before.log','audit-287-native-all-pokedex-after.log','package_pokedex_mixed_keys_288.py']:
 p=r/name;assert p.exists(),name;files[name]=p
for x in json.loads((r/'audit-288-dex-all-unit-and-integration-results-a1.json').read_text())['results']:files[x['log']]=r/x['log']
files['candidate-source/pokedex_screen.rs']=w/'crates/pokered-core/src/pokedex_screen.rs'
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['engine/menus/pokedex.asm','home/window.asm']:files['original-source/'+name]=ref/name
out=w/'docs/screenshots/fidelity-pokedex-mixed-keys-288';out.mkdir(parents=True,exist_ok=False);pngs={};blobs=set()
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  data=p.read_bytes()
  if p.suffix=='.png':
   h=sha(data);pngs[name]=h
   if h not in blobs:z.writestr('png-blobs/'+h+'.png',data);blobs.add(h)
  else:z.writestr(name,data)
 z.writestr('png-files.json',json.dumps(pngs,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+pngs[name]+'.png' if name in pngs else name)==p.read_bytes()
for name in ['down-a','up-right','a-right','side-mid']:
 for side in ['before','after']:shutil.copy2(r/f'audit-288-host-{side}-a1-1/{name}.png',out/f'{name}-{side}.png')
v={'base':base,'tested_source_head':head,'tests':tests,'cases':cases,'original_and_native_repeats':2,'three_single_key_control_PNG_byte_exact':True,'native_method':'public seeded PokemonGame.update(InputState) with multiple keys, then real Pokedex renderer; TCP one-button interface not used; not natural START/playthrough','inventory_stable':True,'captures_match_same_menu_frame':True,'capture_dependencies_locked_equal_except_helper_package':True,'archive_roundtrip_byte_exact':True,'archive_SHA256':sha((out/'evidence.zip').read_bytes()),'archive_bytes':(out/'evidence.zip').stat().st_size,'PNG':len(pngs),'scope':'list inner row move then watched-key caller priority; common side UP-over-DOWN priority. Held repeats, initial guards, cry waits and broader gameplay remain under audit; fonts/Chinese/IME/dialogue layout excluded.'}
(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
(out/'README.md').write_text('''# Pokédex mixed-button navigation

The original first moves a visible row in HandleMenuInput, then processes watched buttons in HandlePokedexListMenu. UP/DOWN win over RIGHT/LEFT/A in that caller. For seen001–025, DOWN+A moves to row1 and scroll1 (selected003), staying in the list. Side-menu UP wins over DOWN even at the first item. One production file restores those priorities.

13 original emulator scenarios and 13 actual native host scenarios each repeat twice byte exactly. Native fixtures seed the public PokemonGame menu state, feed simultaneous InputState keys through actual game.update, and draw with the real Pokédex renderer. These are controlled menu fixtures, not TCP multi-key inputs, natural START inputs or full playthroughs. Master c6f40c2 and candidate use the identical helper and locked dependencies. The three DOWN/RIGHT/A single-key controls retain exact PNG bytes. Inventory remains stable.

Four before/after pairs cover DOWN+A, UP+RIGHT, A+RIGHT and an opposite-direction side-menu case. English text and UI artwork use the current master renderer on both sides. Fonts, Chinese, IME and dialogue layout are unchanged.

78 frozen app/core debug-enabled programs: 3691 passed, 0 failed, 76 ignored. Fresh m01–m03 and separate-process s07 SAVE/CONTINUE pass. The evidence archive contains deduplicated frames, metadata, scripts, source excerpts and full test logs, verified by byte-for-byte readback. It contains no ROM, SRAM, emulator state, private snapshot or executable. Reconstruct PNG paths using png-files.json and png-blobs.

Held repeat, initial guards, cry waits, entry/area input behavior and broader story/function fidelity remain under separate audit. No whole-game equivalence is claimed.
''')
print(json.dumps(v),flush=True)
