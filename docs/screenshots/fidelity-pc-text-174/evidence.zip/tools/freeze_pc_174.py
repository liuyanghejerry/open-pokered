from pathlib import Path
import re,sys,shutil,json,hashlib,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';side=sys.argv[1];log=r/sys.argv[2];text=log.read_text();assert 'Finished `test`' in text;d=r/f'audit-174-{side}-immutable';d.mkdir(exist_ok=True);manifest={}
for m in re.finditer(r'Executable unittests src/lib.rs \(([^)]+/pokered_(core|data|app|agent)-[a-f0-9]+)\)',text):
 p=Path(m[1]);target=d/f'pokered_{m[2]}';shutil.copy2(p,target);manifest[m[2]]={'source_binary':str(p),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size}
assert 'app' in manifest
wt=root/'.task-tmp'/('fidelity-93-master-before' if side=='master31' else 'fidelity-91-plus-checkout');game=wt/'crates/pokered-app/src/game.rs';v={'side':side,'binaries':manifest,'game_source_sha256':hashlib.sha256(game.read_bytes()).hexdigest(),'build_log':str(log)}
if side=='master31':
 master=subprocess.check_output(['git','show','31b1eda3112514d6bc803af559ec7f7c9e20374f:crates/pokered-app/src/game.rs'],cwd=root);marker=b'#[cfg(test)]\nmod session_guard_tests';assert game.read_bytes().split(marker)[0]==master.split(marker)[0];v['production_prefix_equals_master31']=True
(d/'manifest.json').write_text(json.dumps(v,indent=2)+'\n');print(side,list(manifest))
