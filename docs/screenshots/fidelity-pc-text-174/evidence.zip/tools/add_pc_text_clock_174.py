from pathlib import Path
root=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout');p=root/'crates/pokered-core/src/pc_screen.rs';s=p.read_text();s=s.replace('    OaksConfirmPage,','    OaksConfirmPage,\n    OaksConfirmMenu,',1);pos=s.index('const MSG_LINES_PER_PAGE');s=s[:pos]+'''#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PcMessageEnd { Prompt, Done, WaitButton }

'''+s[pos:];s=s.replace('    msg_next: AfterMessage,','''    msg_next: AfterMessage,
    msg_pages: Vec<(usize, usize)>,
    msg_end: PcMessageEnd,
    msg_chars: usize,
    msg_intro_wait: u8,
    msg_letter_wait: u8,
    msg_prompt_guard: u8,
    msg_finished: bool,
    msg_paragraph_blank: u8,
    text_delay_frames: u8,
    text_delay_disabled: bool,''',1);s=s.replace('            msg_next: AfterMessage::Exit,','''            msg_next: AfterMessage::Exit,
            msg_pages: Vec::new(), msg_end: PcMessageEnd::Prompt,
            msg_chars: 0, msg_intro_wait: 0, msg_letter_wait: 0,
            msg_prompt_guard: 0, msg_finished: false, msg_paragraph_blank: 0,
            text_delay_frames: 3,
            text_delay_disabled: entry != PcEntry::PokemonCenter,''',1);s=s.replace('''        self.msg_lines.len().div_ceil(MSG_LINES_PER_PAGE).max(1)''','''        self.msg_pages.len().max(1)''',1);pos=s.index('    pub fn main_menu(');s=s[:pos]+'''    pub fn configure_field_text(&mut self, delay_frames: u8, incoming_disabled: bool) {
        self.text_delay_frames = delay_frames.max(1);
        self.text_delay_disabled = self.field_text_delay_change.unwrap_or(incoming_disabled);
    }

    pub fn message_page_lines(&self) -> &[String] {
        let (start, end) = self.msg_pages.get(self.msg_page).copied().unwrap_or((0, 0));
        &self.msg_lines[start..end]
    }

    pub fn message_visible_chars(&self) -> usize { self.msg_chars }

    fn write_field_text_delay(&mut self, disabled: bool) {
        self.text_delay_disabled = disabled;
        self.field_text_delay_change = Some(disabled);
    }

'''+s[pos:];s=s.replace('self.field_text_delay_change = Some(true);','self.write_field_text_delay(true);').replace('self.field_text_delay_change = Some(false);','self.write_field_text_delay(false);');s=s.replace('''    fn set_message(&mut self, lines: Vec<String>, next: AfterMessage) {
''','''    fn set_message(&mut self, lines: Vec<String>, next: AfterMessage) {
        self.set_message_with_end(lines, next, PcMessageEnd::Prompt);
    }

    fn set_message_with_end(&mut self, lines: Vec<String>, next: AfterMessage, ending: PcMessageEnd) {
''',1);marker='''        self.msg_page = 0;
        self.msg_next = next;
        self.phase = PcPhase::Message;''';assert marker in s;s=s.replace(marker,'''        self.msg_pages.clear();
        let mut start = 0;
        for i in 0..self.msg_lines.len() {
            if self.msg_lines[i].is_empty() {
                if start < i { self.msg_pages.push((start, i)); }
                start = i + 1;
            } else if i + 1 - start == MSG_LINES_PER_PAGE {
                self.msg_pages.push((start, i + 1)); start = i + 1;
            }
        }
        if start < self.msg_lines.len() { self.msg_pages.push((start, self.msg_lines.len())); }
        if self.msg_pages.is_empty() { self.msg_pages.push((0, 0)); }
        self.msg_page = 0;
        self.msg_next = next;
        self.msg_end = ending;
        self.start_message_page(3);
        self.phase = PcPhase::Message;''',1);s=s.replace('''        if (self.msg_page + 1) * MSG_LINES_PER_PAGE < self.msg_lines.len() {
            self.msg_page += 1;
            return;
        }''','''        if self.msg_page + 1 < self.msg_pages.len() {
            self.msg_page += 1;
            self.start_message_page(0);
            self.msg_paragraph_blank = 20;
            return;
        }''',1);s=s.replace('''            AfterMessage::OaksConfirmPage => self.enter_oaks_confirm(),''','''            AfterMessage::OaksConfirmPage => self.set_message_with_end(
                vec!["Want to get your".into(), "#DEX rated?".into()],
                AfterMessage::OaksConfirmMenu, PcMessageEnd::Done),
            AfterMessage::OaksConfirmMenu => self.enter_oaks_confirm(),''',1)
# Every ClosedOaksPCText caller uses TX_WAITBUTTON rather than PROMPT.
s=s.replace('''self.set_message(
                    vec!["Closed link to".into(), "PROF.OAK's PC.".into()],
                    AfterMessage::MainMenu,
                );''','''self.set_message_with_end(
                    vec!["Closed link to".into(), "PROF.OAK's PC.".into()],
                    AfterMessage::MainMenu, PcMessageEnd::WaitButton,
                );''');s=s.replace('''self.set_message(
                vec!["Closed link to".into(), "PROF.OAK's PC.".into()],
                AfterMessage::MainMenu,
            );''','''self.set_message_with_end(
                vec!["Closed link to".into(), "PROF.OAK's PC.".into()],
                AfterMessage::MainMenu, PcMessageEnd::WaitButton,
            );''');pos=s.index('    fn advance_message');s=s[:pos]+'''    fn start_message_page(&mut self, intro: u8) {
        self.msg_chars = 0; self.msg_intro_wait = intro;
        self.msg_letter_wait = 0; self.msg_prompt_guard = 0;
        self.msg_finished = false; self.msg_paragraph_blank = 0;
    }

    fn tick_message(&mut self, input: MenuInput, held_ab: bool) -> PcScreenAction {
        if self.msg_intro_wait > 0 {
            self.msg_intro_wait -= 1;
            if self.msg_intro_wait > 0 { return PcScreenAction::Continue; }
        }
        if self.msg_paragraph_blank > 0 {
            self.msg_paragraph_blank -= 1;
            if self.msg_paragraph_blank > 0 { return PcScreenAction::Continue; }
        }
        let total: usize = self.message_page_lines().iter().map(|line| line.chars().count()).sum();
        if self.msg_letter_wait > 0 {
            if held_ab { self.msg_letter_wait = 1; }
            self.msg_letter_wait -= 1;
            if self.msg_letter_wait > 0 { return PcScreenAction::Continue; }
        }
        if self.msg_chars < total {
            if self.text_delay_disabled { self.msg_chars = total; }
            else { self.msg_chars += 1; self.msg_letter_wait = if held_ab {1} else {self.text_delay_frames}; return PcScreenAction::Continue; }
        }
        let last = self.msg_page + 1 == self.msg_pages.len();
        if !self.msg_finished {
            self.msg_finished = true;
            if last && self.msg_end == PcMessageEnd::Done { self.advance_message(); return PcScreenAction::Continue; }
            if last && self.msg_end == PcMessageEnd::Prompt { self.msg_prompt_guard = 3; }
            // A/B used to speed the final letter cannot also acknowledge it.
            return PcScreenAction::Continue;
        }
        if self.msg_prompt_guard > 0 { self.msg_prompt_guard -= 1; return PcScreenAction::Continue; }
        if input.a || input.b {
            let exit = last && self.msg_next == AfterMessage::Exit;
            self.advance_message();
            if exit { self.sfx.push(PcSfx::TurnOff); return PcScreenAction::Exit; }
        }
        PcScreenAction::Continue
    }

'''+s[pos:];marker='''    pub fn update_frame_with_sound(&mut self, input: MenuInput, ctx: &mut PcContext, sound_playing: bool) -> PcScreenAction {
        let before = self.phase;''';assert marker in s;s=s.replace(marker,'''    pub fn update_frame_with_sound(&mut self, input: MenuInput, ctx: &mut PcContext, sound_playing: bool) -> PcScreenAction {
        self.update_frame_with_text_input(input, ctx, sound_playing, input.a || input.b)
    }

    pub fn update_frame_with_text_input(&mut self, input: MenuInput, ctx: &mut PcContext, sound_playing: bool, held_ab: bool) -> PcScreenAction {
        let before = self.phase;''',1).replace('self.update_frame_with_sound_inner(input, ctx, sound_playing);','self.update_frame_with_sound_inner(input, ctx, sound_playing, held_ab);',1).replace('fn update_frame_with_sound_inner(&mut self, input: MenuInput, ctx: &mut PcContext, sound_playing: bool)','fn update_frame_with_sound_inner(&mut self, input: MenuInput, ctx: &mut PcContext, sound_playing: bool, held_ab: bool)',1);start=s.index('            PcPhase::Message => {',s.index('    fn update_frame_with_sound_inner'));end=s.index('            PcPhase::MainMenu =>',start);s=s[:start]+'''            PcPhase::Message => self.tick_message(input, held_ab),
'''+s[end:];p.write_text(s)
p=root/'crates/pokered-app/src/game.rs';s=p.read_text();marker='''                        self.pc_screen = Some(PcScreen::new_with_language(entry, &open, self.state.config.language));''';s=s.replace(marker,marker+'''
                        self.pc_screen.as_mut().unwrap().configure_field_text(self.state.config.text_speed.delay_frames(), self.overworld.text_delay_disabled);''',1);s=s.replace('''                            pc.update_frame_with_sound(menu_input, &mut ctx, audio.is_sfx_playing())
                        } else { pc.update_frame(menu_input, &mut ctx) }''','''                            pc.update_frame_with_text_input(menu_input, &mut ctx, audio.is_sfx_playing(), input.is_pressed(GbButton::A) || input.is_pressed(GbButton::B))
                        } else { pc.update_frame_with_text_input(menu_input, &mut ctx, false, input.is_pressed(GbButton::A) || input.is_pressed(GbButton::B)) }''',1);p.write_text(s)
p=root/'crates/pokered-app/src/render/pc.rs';s=p.read_text();marker='''fn draw_message(lines: &[String], fb: &mut FrameBuffer, is_zh: bool) {
''';s=s.replace(marker,marker+'''    draw_message_with_limit(lines, usize::MAX, fb, is_zh);
}

fn draw_message_with_limit(lines: &[String], mut visible: usize, fb: &mut FrameBuffer, is_zh: bool) {
''',1);s=s.replace('''        draw_text(line, T, by + T + i as u32 * pitch, FG, fb);''','''        let shown: String = line.chars().take(visible).collect();
        visible = visible.saturating_sub(line.chars().count());
        draw_text(&shown, T, by + T + i as u32 * pitch, FG, fb);''',1);start=s.index('''            let start = pc.message_page() * 4;''');end=s.index('''        PcPhase::MainMenu =>''',start);s=s[:start]+'''            draw_message_with_limit(pc.message_page_lines(), pc.message_visible_chars(), fb, is_zh);
        }
'''+s[end:];p.write_text(s)
