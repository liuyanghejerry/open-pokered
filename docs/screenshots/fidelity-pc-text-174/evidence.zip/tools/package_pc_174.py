from pathlib import Path
import json,hashlib,zipfile,shutil
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';perf=Path('/home/jerry/develop/open-pokered-perf118');out=w/'docs/screenshots/fidelity-pc-text-174';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());gba=load(r/'audit-174-gba-source-manifest-a7.json');assert len(gba['sources'])==53;assert all(h(w/f)==sha==h(perf/f) for f,sha in gba['sources'].items());compare=(r/'audit-174-gba-compare-a7.log').read_text();assert compare.count(' -> ')==31 and 'GBA performance is within the configured regression budget.' in compare
entries={}
for pattern in ['audit-174-pc-opening-master31-*','audit-174-pc-opening-after-a7-*','audit-172-original-player-pc-a2-*','audit-172-original-main-pc-a1-*','audit-172-original-main-pc-slow-a1-*']:
 for d in r.glob(pattern):
  if d.is_dir():
   for f in d.rglob('*'):
    if f.is_file():entries[str(f.relative_to(r))]=f
for name in ['audit-173-pc-message-source-audit.json','audit-172-global-text-mode-source-audit.json']:
 f=r/name;entries['prior-audit/'+name]=f
for name in ['audit-172-player-pc-setup','audit-172-main-pc-setup','audit-172-main-pc-slow-setup']:
 d=r/name
 if d.exists():
  for f in d.rglob('*'):
   if f.is_file():entries['original-setup/'+str(f.relative_to(r))]=f
for pattern in ['audit-174-*.log','audit-174-*.json']:
 for f in r.glob(pattern):entries[str(f.relative_to(r))]=f
for side in ['master31','after-a7']:
 f=r/f'audit-174-{side}-immutable/manifest.json';entries[str(f.relative_to(r))]=f
for name in ['freeze_pc_174.py','run_pc_tests_174.py','stage_pc_gba_174.py','add_pc_text_clock_174.py','package_pc_174.py']:
 f=r/'stats-59-tools'/name;entries['tools/'+name]=f
for f in w.glob('crates/pokered-*/src/pc_screen.rs'):entries['final-source/'+str(f.relative_to(w))]=f
for name in ['crates/pokered-app/src/game.rs','crates/pokered-app/src/render/pc.rs']:entries['final-source/'+name]=w/name
for pkg,count in [('core',2748),('data',263),('app',220),('agent',54)]:
 log=(r/f'audit-174-suite-{pkg}-a7.log').read_text();assert f'{count} passed; 0 failed;' in log
verification={'native_revision':'a7','tests':{'core':2748,'data':263,'app':220,'app_ignored':33,'agent':54},'opening':load(r/'audit-174-pc-opening-verification.json'),'sources':load(r/'audit-174-source-a7.json'),'gba_source_count':len(gba['sources']),'gba_metrics':31,'remaining':['actual PC PCM/music-bank equivalence','CONT intermediate half-row animation','special confirmation phase text clocks','full text init/close/arrow and earlier movement/mainline/SAVE-CONTINUE gates']}
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,f in sorted(entries.items()):z.write(f,name)
verification['archive']={'bytes':archive.stat().st_size,'sha256':h(archive),'entries':len(entries)};(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n');shutil.copy2(r/'audit-174-gba-source-manifest-a7.json',out/'gba-source-manifest.json');shutil.copy2(r/'audit-174-gba-compare-a7.log',out/'gba-compare.log');print(verification['archive'])
