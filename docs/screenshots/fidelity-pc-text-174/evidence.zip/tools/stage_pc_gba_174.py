from pathlib import Path
import json,hashlib,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';perf=Path('/home/jerry/develop/open-pokered-perf118');j=json.loads((r/'audit-171-gba-source-manifest-a4.json').read_text());paths=set(j['sources'])|set(subprocess.check_output(['git','diff','--name-only'],cwd=w,text=True).splitlines());hashes={}
for name in sorted(paths):
 src=w/name;dst=perf/name;assert src.is_file();dst.parent.mkdir(parents=True,exist_ok=True)
 if not dst.exists() or src.read_bytes()!=dst.read_bytes():shutil.copy2(src,dst)
 hashes[name]=hashlib.sha256(src.read_bytes()).hexdigest();assert hashes[name]==hashlib.sha256(dst.read_bytes()).hexdigest()
baseline=perf/'crates/pokered-gba/perf-baseline.json';assert hashlib.sha256(baseline.read_bytes()).hexdigest()==j['baseline_sha256']
(r/'audit-174-gba-source-manifest-a7.json').write_text(json.dumps({'parent':'audit-171-gba-source-manifest-a4.json','scope':'all prior sources plus final local PC source changes','sources':hashes,'baseline_sha256':j['baseline_sha256']},indent=2)+'\n');print('unique source hashes',len(hashes))
