//! Renderer for the PC storage screens (Bill's PC, the player's item PC, and
//! PROF.OAK's #DEX rating).
//!
//! GB-style presentation over the same primitives as the elevator/menu
//! renderers: text boxes with `>` cursors, single/double-spaced lists, YES/NO
//! popups. All logic lives in `pokered_core::pc_screen`.

use crate::alloc_prelude::*;
use pokered_core::battle::state::Pokemon;
use pokered_core::game_state::Lang;
use pokered_core::pc_screen::{ItemListMode, MonListMode, PcPhase, PcScreen, PC_LIST_VISIBLE_ROWS};
use pokered_core::save::SaveData;
use pokered_data::lang_data;
use pokered_data::text_layout::{wrap_hard_lines, DIALOGUE_LINE_WIDTH_PX};
use pokered_renderer::embedded_font::{draw_text, measure_text};
use pokered_renderer::palette::GRAYSCALE_SPRITE_PALETTE;
use pokered_renderer::resource::ResourceManager;
use pokered_renderer::{FrameBuffer, Rgba, TILE_SIZE};

use super::{blit_tileset, draw_text_box, species_to_sprite_name};
use crate::render::battle_i18n::zh_name;
use pokered_data::ui_text::{zh_main_menu_label, zh_pc_line};

const BG: Rgba = Rgba::WHITE;
const FG: Rgba = Rgba::BLACK;

const T: u32 = 8; // tile size in pixels

/// Repaint the two cursor cells used by PC menus and lists.
///
/// This is deliberately limited to the marker column: menu labels begin
/// in the next 8px tile, and the box chooser has no separating space.
pub fn redraw_pc_cursor(
    previous: (u32, u32),
    current: (u32, u32),
    fb: &mut FrameBuffer,
) {
    for (x, y) in [previous, current] {
        for py in y..(y + 10).min(fb.height()) {
            for px in x..(x + measure_text(">")).min(fb.width()) {
                fb.set_pixel(px, py, BG);
            }
        }
    }
    draw_text(">", current.0, current.1, FG, fb);
}

fn item_name(id: pokered_data::items::ItemId, is_zh: bool) -> String {
    if is_zh {
        lang_data::item_name(id, true).to_string()
    } else {
        pokered_data::item_data::get_item_data(id)
            .map(|d| d.name.to_string())
            .unwrap_or_else(|| "???".to_string())
    }
}

fn mon_row(mon: &Pokemon) -> String {
    let mut name_buf = [0u8; pokered_core::battle::state::NAME_TEXT_BUF];
    format!("{} :L{}", mon.display_name(&mut name_buf), mon.level)
}

/// Bottom text box holding up to `lines` lines (max 5), plus the current
/// message page of the Message phase. Lines are routed through
/// [`zh_pc_line`] so the English messages produced by `pokered_core::pc_screen`
/// are translated at display time only.
fn draw_message(lines: &[String], fb: &mut FrameBuffer, is_zh: bool) {
    draw_message_with_limit(lines, usize::MAX, fb, is_zh);
}

fn draw_message_with_limit(lines: &[String], mut visible: usize, fb: &mut FrameBuffer, is_zh: bool) {
    let shown: Vec<String> = lines.iter().take(5)
        .flat_map(|line| {
            let text = if is_zh { zh_pc_line(line) } else { line.clone() };
            wrap_message(&text)
        }).collect();
    let pitch = 12;
    let height = (shown.len().max(1) as u32 * pitch).div_ceil(T);
    let by = 144u32.saturating_sub((height + 2) * T);
    draw_text_box(fb, 0, by, 18, height, FG);
    for (i, line) in shown.iter().enumerate() {
        let shown: String = line.chars().take(visible).collect();
        visible = visible.saturating_sub(line.chars().count());
        draw_text(&shown, T, by + T + i as u32 * pitch, FG, fb);
    }
}

fn wrap_message(text: &str) -> Vec<String> {
    if pokered_data::dialogue_layout::contains_chinese(text) {
        pokered_core::text::zh_dialogue::wrap_lines(text, DIALOGUE_LINE_WIDTH_PX, &[])
    } else { wrap_hard_lines(text, DIALOGUE_LINE_WIDTH_PX) }
}

/// Render the legacy placeholder as text with the same open font as its label.
fn draw_pc_label(text: &str, x: u32, y: u32, fb: &mut FrameBuffer) {
    draw_text(&text.replace("#MON", "PKMN"), x, y, FG, fb);
}

/// YES/NO popup on the right side (original: TWO_OPTION_MENU at hlcoord 14,7).
fn draw_yes_no(selected_yes: bool, fb: &mut FrameBuffer, is_zh: bool) {
    let bx = 14 * T;
    let by = if is_zh { T } else { 7 * T };
    draw_text_box(fb, bx, by, 4, 4, FG);
    let cy = if selected_yes { 1 } else { 3 };
    draw_text(">", bx + T, by + cy * T, FG, fb);
    draw_text(lang_data::ui_label("YES", is_zh), bx + 2 * T, by + T, FG, fb);
    draw_text(lang_data::ui_label("NO", is_zh), bx + 2 * T, by + 3 * T, FG, fb);
}

/// A boxed, scrollable selection list. `rows` are the label lines; `cancel`
/// appends a CANCEL row. Returns nothing; purely visual.
fn draw_list(
    bx: u32,
    by: u32,
    bw: u32,
    visible: usize,
    rows: &[String],
    cursor: usize,
    scroll: usize,
    is_zh: bool,
    fb: &mut FrameBuffer,
) {
    let pitch = 12;
    let bh = (visible as u32 * pitch).div_ceil(T);
    draw_text_box(fb, bx, by, bw, bh, FG);
    for (row, (i, label)) in rows
        .iter()
        .enumerate()
        .skip(scroll)
        .take(visible)
        .enumerate()
    {
        let y = by + T + row as u32 * pitch;
        let marker = if i == cursor { ">" } else { " " };
        draw_text(&format!("{} {}", marker, label), bx + T, y, FG, fb);
    }
}

/// Scrolling window start that keeps `cursor` visible (same policy as the
/// bag screen's clamp_scroll).
fn follow_scroll(cursor: usize, rows: usize, visible: usize) -> usize {
    if rows <= visible {
        return 0;
    }
    cursor
        .saturating_sub(visible / 2)
        .min(rows - visible)
}

/// Current mon list (party for DEPOSIT, current box otherwise) + CANCEL.
fn mon_rows(pc: &PcScreen, save: &SaveData, is_zh: bool) -> Vec<String> {
    let mut rows: Vec<String> = match pc.mon_mode() {
        MonListMode::Deposit => save.party.iter().map(mon_row).collect(),
        MonListMode::Withdraw | MonListMode::Release => save
            .pc_storage
            .current_box()
            .iter()
            .map(mon_row)
            .collect(),
    };
    rows.push(lang_data::ui_label("CANCEL", is_zh).to_string());
    rows
}

/// Current item list (bag for DEPOSIT, PC storage otherwise) + CANCEL.
fn item_rows(pc: &PcScreen, save: &SaveData, is_zh: bool) -> Vec<String> {
    let src: Vec<(pokered_data::items::ItemId, u32)> = match pc.item_mode() {
        ItemListMode::Deposit => save.game_data.bag.items(),
        ItemListMode::Withdraw | ItemListMode::Toss => save.game_data.pc_items.items(),
    };
    let mut rows: Vec<String> = src
        .iter()
        .map(|(id, qty)| {
            if id.is_key_item() {
                item_name(*id, is_zh)
            } else {
                format!("{} x{:02}", item_name(*id, is_zh), qty)
            }
        })
        .collect();
    rows.push(lang_data::ui_label("CANCEL", is_zh).to_string());
    rows
}

const BILLS_LABELS: [&str; 5] = [
    "WITHDRAW #MON",
    "DEPOSIT #MON",
    "RELEASE #MON",
    "CHANGE BOX",
    "SEE YA!",
];

const PLAYERS_LABELS: [&str; 4] = ["WITHDRAW ITEM", "DEPOSIT ITEM", "TOSS ITEM", "LOG OFF"];

/// Double-spaced vertical menu (the original PC menus use 2-tile rows).
fn draw_menu(bx: u32, by: u32, bw: u32, labels: &[String], cursor: usize, fb: &mut FrameBuffer) {
    let bh = labels.len() as u32 * 2;
    draw_text_box(fb, bx, by, bw, bh, FG);
    for (i, label) in labels.iter().enumerate() {
        let y = by + (1 + i as u32 * 2) * T;
        let marker = if i == cursor { ">" } else { " " };
        draw_text(marker, bx + T, y, FG, fb);
        draw_pc_label(label, bx + 2 * T, y, fb);
    }
}

// `zh_main_menu_label` / `zh_pc_line` (+ the PC_LINE_ZH table) moved to
// `pokered_data::ui_text` so the TUI frontend shares them; re-imported below.

/// "BOX No.N" indicator (bills_pc.asm:149-169).
fn draw_box_no(save: &SaveData, fb: &mut FrameBuffer, is_zh: bool) {
    let bx = 9 * T;
    let by = 14 * T;
    draw_text_box(fb, bx, by, 9, 2, FG);
    let n = save.pc_storage.current_box_index() + 1;
    let text = if is_zh {
        format!("盒子{}号", n)
    } else {
        format!("BOX No.{}", n)
    };
    draw_text(&text, bx + T, by + T + 4, FG, fb);
}

pub fn draw_pc(
    pc: &PcScreen,
    save: &SaveData,
    resources: &mut Option<ResourceManager>,
    fb: &mut FrameBuffer,
    lang: Lang,
) {
    let is_zh = lang == Lang::Zh;
    fb.clear(BG);
    match pc.phase() {
        PcPhase::Message => {
            draw_message_with_limit(pc.message_page_lines(), pc.message_visible_chars(), fb, is_zh);
        }
        PcPhase::MainMenu => {
            let labels: Vec<String> = pc
                .main_menu_labels()
                .iter()
                .map(|s| if is_zh { zh_main_menu_label(s) } else { s.clone() })
                .collect();
            draw_menu(0, 0, 14, &labels, pc.main_menu().cursor(), fb);
        }
        PcPhase::BillsMenu => {
            let labels: Vec<String> = BILLS_LABELS
                .iter()
                .map(|s| lang_data::ui_label(s, is_zh).to_string())
                .collect();
            draw_menu(0, 0, 12, &labels, pc.bills_menu().cursor(), fb);
            draw_box_no(save, fb, is_zh);
        }
        PcPhase::MonList | PcPhase::MonAction | PcPhase::ReleaseConfirm => {
            let rows = mon_rows(pc, save, is_zh);
            let cursor = pc.mon_cursor();
            let scroll = follow_scroll(cursor, rows.len(), 8);
            draw_list(0, 0, 18, 8, &rows, cursor, scroll, is_zh, fb);
            match pc.phase() {
                PcPhase::MonAction => {
                    let first = match pc.mon_mode() {
                        MonListMode::Withdraw => "WITHDRAW",
                        MonListMode::Deposit => "DEPOSIT",
                        MonListMode::Release => "RELEASE",
                    };
                    let labels: Vec<String> = [first, "STATS", "CANCEL"]
                        .iter()
                        .map(|s| lang_data::ui_label(s, is_zh).to_string())
                        .collect();
                    draw_menu(10 * T, 8 * T, 8, &labels, pc.mon_action_cursor(), fb);
                }
                PcPhase::ReleaseConfirm => {
                    let mut name_buf = [0u8; pokered_core::battle::state::NAME_TEXT_BUF];
                    let name = save
                        .pc_storage
                        .current_box()
                        .get(cursor)
                        .map(|m| m.display_name(&mut name_buf))
                        .unwrap_or("");
                    // "Once released, {NAME} is gone forever. OK?"
                    // (_OnceReleasedText)
                    if is_zh {
                        draw_message(
                            &[
                                format!("一旦放生，{}就", name),
                                "永远消失了。".to_string(),
                                "可以吗？".to_string(),
                            ],
                            fb,
                            is_zh,
                        );
                    } else {
                        draw_message(
                            &[
                                "Once released,".to_string(),
                                format!("{} is", name),
                                "gone forever. OK?".to_string(),
                            ],
                            fb,
                            is_zh,
                        );
                    }
                    draw_yes_no(pc.yes_selected(), fb, is_zh);
                }
                _ => {}
            }
        }
        PcPhase::ChangeBoxConfirm => {
            // "When you change a #MON BOX, data will be saved. Is that okay?"
            // (_WhenYouChangeBoxText)
            draw_message(
                &[
                    "When you change a".to_string(),
                    "#MON BOX, data".to_string(),
                    "will be saved.".to_string(),
                    String::new(),
                    "Is that okay?".to_string(),
                ],
                fb,
                is_zh,
            );
            draw_yes_no(pc.yes_selected(), fb, is_zh);
        }
        PcPhase::BoxList => {
            // "Choose a #MON BOX." header + the 12 box names; a filled
            // marker stands in for the original's pokeball tile next to
            // non-empty boxes (save.asm DisplayChangeBoxMenu:487-498).
            draw_text_box(fb, 0, 0, 9, if is_zh { 3 } else { 4 }, FG);
            let (h1, h2) = if is_zh {
                ("选择盒子。", "")
            } else {
                ("Choose a", "#MON BOX.")
            };
            draw_text(h1, T, T, FG, fb);
            if !h2.is_empty() {
                draw_pc_label(h2, T, 3 * T, fb);
            }
            if is_zh {
                for col in 0..2 {
                    draw_text_box(fb, col * 10 * T, 4 * T, 8, 12, FG);
                }
            } else {
                draw_text_box(fb, 11 * T, 0, 7, 16, FG);
            }
            for i in 0..12usize {
                let (bx, y) = if is_zh {
                    ((i / 6) as u32 * 10 * T, (5 + (i % 6) as u32 * 2) * T)
                } else { (11 * T, T + i as u32 * 10) };
                let marker = if i == pc.box_cursor() { ">" } else { " " };
                let name = if is_zh { format!("盒子{:>2}", i + 1) }
                    else { format!("BOX{:>2}", i + 1) };
                draw_text(&format!("{}{}", marker, name), bx + T, y, FG, fb);
                if save.pc_storage.get_box(i).is_ok_and(|b| !b.is_empty()) {
                    for dy in 0..4u32 {
                        for dx in 0..4u32 {
                            fb.set_pixel(bx + 7 * T + 2 + dx, y + 2 + dy, FG);
                        }
                    }
                }
            }
        }
        PcPhase::ItemMenu => {
            let labels: Vec<String> = PLAYERS_LABELS
                .iter()
                .map(|s| lang_data::ui_label(s, is_zh).to_string())
                .collect();
            draw_menu(0, 0, 14, &labels, pc.players_menu().cursor(), fb);
        }
        PcPhase::ItemList | PcPhase::ItemQuantity | PcPhase::TossConfirm => {
            let rows = item_rows(pc, save, is_zh);
            let cursor = pc.item_list_cursor();
            let scroll = follow_scroll(cursor, rows.len(), PC_LIST_VISIBLE_ROWS.max(8));
            draw_list(0, 0, 18, 8, &rows, cursor, scroll, is_zh, fb);
            match pc.phase() {
                PcPhase::ItemQuantity => {
                    // "How many?" + the running quantity (players_pc.asm
                    // DisplayChooseQuantityMenu).
                    let name = rows.get(cursor).cloned().unwrap_or_default();
                    let prompt = if is_zh { "几个？" } else { "How many?" };
                    draw_message(&[prompt.to_string()], fb, is_zh);
                    let bx = 12 * T;
                    let by = 10 * T;
                    draw_text_box(fb, bx, by, 6, 2, FG);
                    draw_text(&format!("x{:02}", pc.item_qty()), bx + T, by + T + 4, FG, fb);
                    let _ = name;
                }
                PcPhase::TossConfirm => {
                    // "Is it OK to toss {ITEM}?" (_IsItOKToTossItemText)
                    let name = save
                        .game_data
                        .pc_items
                        .get(cursor)
                        .map(|(id, _)| item_name(id, is_zh))
                        .unwrap_or_default();
                    if is_zh {
                        draw_message(&[format!("要扔掉{}吗？", name)], fb, is_zh);
                    } else {
                        draw_message(
                            &[
                                "Is it OK to toss".to_string(),
                                format!("{}?", name),
                            ],
                            fb,
                            is_zh,
                        );
                    }
                    draw_yes_no(pc.yes_selected(), fb, is_zh);
                }
                _ => {}
            }
        }
        PcPhase::OaksConfirm => {
            // "Want to get your #DEX rated?" (_GetDexRatedText)
            draw_message(
                &[
                    "Want to get your".to_string(),
                    "#DEX rated?".to_string(),
                ],
                fb,
                is_zh,
            );
            draw_yes_no(pc.yes_selected(), fb, is_zh);
        }
        PcPhase::LeagueHoF => {
            draw_league_hof(pc, resources, fb, is_zh);
        }
    }
}

/// #MON LEAGUE HoF viewer (LeaguePCShowMon, engine/menus/league_pc.asm:
/// 78-113): the recorded mon's front pic, "HALL OF FAME No. X" and the
/// nickname / LEVEL / TYPE1 / TYPE2 info (`HoFDisplayMonInfo`).
fn draw_league_hof(pc: &PcScreen, resources: &mut Option<ResourceManager>, fb: &mut FrameBuffer, is_zh: bool) {
    let Some((team_no, view)) = pc.league_hof_mon() else {
        return;
    };
    // The recorded mon's front pic at hlcoord 12,5 (league_pc.asm:95-100).
    if let Some(rm) = resources.as_mut() {
        let sprite = species_to_sprite_name(&format!("{}", view.species));
        if let Ok(cached) = rm.load_pokemon_front(&sprite) {
            super::blit_front_pic(fb, cached, (12 * T) as i32, (5 * T) as i32, false);
        }
    }
    let hof_no = if is_zh {
        format!("名人堂第{:>3}号", team_no)
    } else {
        format!("HALL OF FAME No.{:>3}", team_no)
    };
    draw_text(&hof_no, T, 15 * T, FG, fb);
    super::hof_ceremony::draw_hof_mon_info(
        view.species, view.level, &view.nickname, fb, is_zh,
    );
}

// The exact `PC_LINE_ZH` table and `zh_pc_line` moved to `pokered_data::ui_text`
// (shared with the TUI); imported at the top of this file.

#[cfg(test)]
mod layout_tests {
    use super::*;
    use dotzuki_engine::render_config::RenderConfig;
    use pokered_core::main_menu::MenuInput;
    use pokered_core::pc_screen::{HofMonView, HofTeamRecord, PcContext, PcEntry, PcOpenContext};
    use pokered_core::pokemon::stats::create_pokemon;
    use pokered_data::items::ItemId;
    use pokered_data::species::Species;

    const A: MenuInput = MenuInput {
        up: false,
        down: false,
        a: true,
        b: false,
    };
    const UP: MenuInput = MenuInput {
        up: true,
        down: false,
        a: false,
        b: false,
    };
    const DOWN: MenuInput = MenuInput {
        up: false,
        down: true,
        a: false,
        b: false,
    };

    fn open_context(has_pokedex: bool) -> PcOpenContext {
        PcOpenContext {
            has_pokedex,
            met_bill: true,
            beaten_league: false,
            player_name: "RED".into(),
            hof_teams: Vec::new(),
        }
    }

    fn update_pc(pc: &mut PcScreen, save: &mut SaveData, input: MenuInput) {
        let mut ctx = PcContext {
            party: &mut save.party,
            pc_storage: &mut save.pc_storage,
            bag: &mut save.game_data.bag,
            pc_items: &mut save.game_data.pc_items,
            pokedex: &save.game_data.pokedex,
        };
        let _ = pc.update_frame(input, &mut ctx);
    }

    fn skip_message(pc: &mut PcScreen, save: &mut SaveData) {
        while pc.phase() == PcPhase::Message {
            update_pc(pc, save, A);
        }
    }

    fn render_pc_state(pc: &PcScreen, save: &SaveData, language: Lang) -> FrameBuffer {
        let mut fb = FrameBuffer::new(RenderConfig::new(160, 144), Rgba::BLACK);
        let mut resources = None;
        draw_pc(pc, save, &mut resources, &mut fb, language);
        fb
    }

    fn assert_framebuffers_equal(actual: &FrameBuffer, expected: &FrameBuffer) {
        assert_eq!(actual.width(), expected.width());
        assert_eq!(actual.height(), expected.height());
        for y in 0..actual.height() {
            for x in 0..actual.width() {
                assert_eq!(
                    actual.get_pixel(x, y),
                    expected.get_pixel(x, y),
                    "framebuffer mismatch at ({x}, {y})",
                );
            }
        }
    }

    fn assert_cursor_repaint(
        previous: &PcScreen,
        current: &PcScreen,
        save: &SaveData,
        language: Lang,
        previous_position: (u32, u32),
        current_position: (u32, u32),
    ) {
        let mut actual = render_pc_state(previous, save, language);
        redraw_pc_cursor(previous_position, current_position, &mut actual);
        let expected = render_pc_state(current, save, language);
        assert_framebuffers_equal(&actual, &expected);
    }

    fn cursor_state(
        base: &PcScreen,
        save: &mut SaveData,
        cursor: usize,
    ) -> PcScreen {
        let mut state = base.clone();
        for _ in 0..cursor {
            update_pc(&mut state, save, DOWN);
        }
        state
    }

    #[test]
    fn box_number_leaves_a_two_pixel_gutter_above_bottom_border() {
        let mut save = SaveData::new();
        save.pc_storage.change_box(11).unwrap();
        for is_zh in [false,true] {
            let mut fb=FrameBuffer::new(RenderConfig::new(160,144),BG);
            draw_box_no(&save,&mut fb,is_zh);
            for y in 136..138 { for x in 80..152 {
                assert_eq!(fb.get_pixel(x,y),Some(BG),"box number entered bottom gutter ({x},{y})");
            }}
        }
    }

    #[test]
    #[ignore = "writes PC font-padding audit frames to PR_SCREENSHOTS"]
    fn capture_pc_padding_audit() {
        let out = std::path::PathBuf::from(std::env::var("PR_SCREENSHOTS").unwrap());
        std::fs::create_dir_all(&out).unwrap();
        for (language, tag) in [(Lang::En,"en"),(Lang::Zh,"zh")] {
            let mut save = SaveData::new();
            let mut pc = PcScreen::new(PcEntry::BillsPc, &open_context(false));
            skip_message(&mut pc, &mut save);
            render_pc_state(&pc,&save,language).save_png(&out.join(format!("pc-bills-{tag}.png"))).unwrap();
            for _ in 0..3 { update_pc(&mut pc,&mut save,DOWN); }
            update_pc(&mut pc,&mut save,A);
            skip_message(&mut pc,&mut save);
            update_pc(&mut pc,&mut save,UP);
            update_pc(&mut pc,&mut save,A);
            assert_eq!(pc.phase(),PcPhase::BoxList);
            render_pc_state(&pc,&save,language).save_png(&out.join(format!("pc-box-list-{tag}.png"))).unwrap();
            save.game_data.pc_items.add_item(ItemId::Potion,99).unwrap();
            let mut pc = PcScreen::new(PcEntry::PlayersPc,&open_context(false));
            skip_message(&mut pc,&mut save);
            update_pc(&mut pc,&mut save,A);
            update_pc(&mut pc,&mut save,A);
            assert_eq!(pc.phase(),PcPhase::ItemQuantity);
            render_pc_state(&pc,&save,language).save_png(&out.join(format!("pc-quantity-{tag}.png"))).unwrap();
            let mut fb=FrameBuffer::new(RenderConfig::new(160,144),BG);
            let rows=(0..8).map(|i| format!("POTION x{}",i+1)).collect::<Vec<_>>();
            draw_list(0,0,18,8,&rows,7,0,language==Lang::Zh,&mut fb);
            fb.save_png(&out.join(format!("pc-list-{tag}.png"))).unwrap();
            fb.clear(BG);
            draw_message(&["Withdrew THUNDERSTONE from storage.".into()],&mut fb,language==Lang::Zh);
            fb.save_png(&out.join(format!("pc-message-{tag}.png"))).unwrap();
        }
    }

    #[test]
    fn pkmn_label_uses_fusion_text_at_exact_pixel_coordinates() {
        let mut actual = FrameBuffer::new(RenderConfig::new(160, 144), BG);
        draw_pc_label("Withdraw #MON!", 8, 11, &mut actual);
        let mut expected = FrameBuffer::new(RenderConfig::new(160, 144), BG);
        dotzuki_renderer::embedded_font::draw_text("Withdraw PKMN!", 8, 11, FG, &mut expected);
        assert_framebuffers_equal(&actual, &expected);
    }

    #[test]
    fn translated_message_wrap_preserves_text_and_fits_box() {
        for text in ["一旦放生，CHARMANDER就永远消失了。可以吗？", "更换宝可梦盒子时，数据会被保存。", "Withdrew THUNDERSTONE.", ""] {
            let lines = wrap_message(text);
            assert_eq!(lines.concat().split_whitespace().collect::<String>(), text.split_whitespace().collect::<String>());
            assert!(lines.iter().all(|line| measure_text(line) <= 144));
        }
    }

    // Expected borders below use the ROM's c=12/14 menu widths and
    // c=9 box-number width, rather than measuring the rendered strings.
    #[test]
    fn original_pc_menu_borders_survive_the_widest_labels() {
        for language in [Lang::En, Lang::Zh] {
            for (entry, inner_width, inner_height) in [
                (PcEntry::PokemonCenter, 14, 8),
                (PcEntry::BillsPc, 12, 10),
                (PcEntry::PlayersPc, 14, 8),
            ] {
                let mut save = SaveData::new();
                let mut context = open_context(true);
                context.player_name = "ABCDEFG".into();
                let mut pc = PcScreen::new(entry, &context);
                skip_message(&mut pc, &mut save);
                let actual = render_pc_state(&pc, &save, language);
                let mut border = FrameBuffer::new(RenderConfig::new(160, 144), BG);
                draw_text_box(&mut border, 0, 0, inner_width, inner_height, FG);
                let right_x = (inner_width + 1) * T;
                for y in T..(inner_height + 1) * T {
                    for x in right_x..right_x + T {
                        assert_eq!(actual.get_pixel(x, y), border.get_pixel(x, y),
                            "PC {entry:?} {language:?} overwrote the original border at ({x},{y})");
                    }
                }
            }
        }
    }

    #[test]
    fn box_twelve_number_and_withdrawn_item_leave_the_border_intact() {
        let mut save = SaveData::new();
        save.pc_storage.change_box(11).unwrap();
        let mut actual = FrameBuffer::new(RenderConfig::new(160, 144), BG);
        draw_box_no(&save, &mut actual, false);
        let mut border = FrameBuffer::new(RenderConfig::new(160, 144), BG);
        draw_text_box(&mut border, 9 * T, 14 * T, 9, 2, FG);
        for y in 15 * T..16 * T {
            for x in 19 * T..20 * T {
                assert_eq!(actual.get_pixel(x, y), border.get_pixel(x, y));
            }
        }
        actual.clear(BG);
        let message = "Withdrew THUNDERSTONE from storage.";
        // 35 half-width Latin characters occupy 175px, beyond the 144px
        // interior. The short real-item message fits on one Fusion row.
        assert_eq!(message.chars().count() * 5, 175);
        assert_eq!(wrap_message(message), vec!["Withdrew THUNDERSTONE from", "storage."]);
        draw_message(&[message.into()], &mut actual, false);
        border.clear(BG);
        // The longer message requires two rows inside the 144px box.
        draw_text_box(&mut border, 0, 13 * T, 18, 3, FG);
        for y in 14 * T..17 * T {
            for x in 19 * T..20 * T {
                assert_eq!(actual.get_pixel(x, y), border.get_pixel(x, y));
            }
        }
    }

    #[test]
    fn hof_info_keeps_the_original_front_picture_region_clear() {
        for language in [Lang::En, Lang::Zh] {
            let mut save = SaveData::new();
            let mut context = open_context(true);
            context.beaten_league = true;
            context.hof_teams = vec![HofTeamRecord {
                team_no: 1,
                mons: vec![HofMonView {
                    species: Species::Pikachu,
                    level: 100,
                    nickname: "PIKACHU".into(),
                }],
            }];
            let mut pc = PcScreen::new(PcEntry::PokemonCenter, &context);
            skip_message(&mut pc, &mut save);
            for _ in 0..3 { update_pc(&mut pc, &mut save, DOWN); }
            update_pc(&mut pc, &mut save, A);
            skip_message(&mut pc, &mut save);
            assert_eq!(pc.phase(), PcPhase::LeagueHoF);
            let mut fb = FrameBuffer::new(RenderConfig::new(160, 144), BG);
            draw_league_hof(&pc, &mut None, &mut fb, language == Lang::Zh);
            // The ROM reserves (12,5)..(18,11) for the 7x7 front picture.
            for y in 5 * T..12 * T {
                for x in 12 * T..19 * T {
                    assert_eq!(fb.get_pixel(x, y), Some(BG),
                        "HoF {language:?} text entered the front-picture region at ({x},{y})");
                }
            }
        }
    }

    #[test]
    fn chinese_list_leaves_clear_pixels_between_rows() {
        let mut actual = FrameBuffer::new(RenderConfig::new(160, 144), BG);
        let rows = vec!["精灵球 x03".into(), "好伤药 x12".into()];
        draw_list(0, 0, 18, 8, &rows, 0, 0, true, &mut actual);

        // Keep both rows intact at their authored 12px baselines. The second
        // row's digit 1 starts at x=58 (two spaces, three 10px Chinese glyphs,
        // a space and x); its Fusion bitmap has ink at offset (2,3).
        let mut first = FrameBuffer::new(RenderConfig::new(160, 144), BG);
        let mut second = FrameBuffer::new(RenderConfig::new(160, 144), BG);
        draw_text("> 精灵球 x03", 8, 8, FG, &mut first);
        draw_text("  好伤药 x12", 8, 20, FG, &mut second);
        assert_eq!(actual.get_pixel(60, 23), Some(FG), "project-font digit 1 must remain intact");

        let mut last_first_ink = None;
        let mut first_second_ink = None;
        for y in 8..32 {
            for x in 8..152 {
                let first_ink = first.get_pixel(x, y) == Some(FG);
                let second_ink = second.get_pixel(x, y) == Some(FG);
                assert!(!(first_ink && second_ink), "row glyphs intersect at {x},{y}");
                if first_ink { last_first_ink = Some(y); }
                if second_ink { first_second_ink.get_or_insert(y); }
                let expected = if first_ink || second_ink { FG } else { BG };
                assert_eq!(actual.get_pixel(x, y), Some(expected),
                    "list lost or displaced row ink at {x},{y}");
            }
        }
        let last_first_ink = last_first_ink.expect("first row has ink");
        let first_second_ink = first_second_ink.expect("second row has ink");
        assert!(first_second_ink >= last_first_ink + 2, "rows need a full clear scanline");
        for y in last_first_ink + 1..first_second_ink {
            for x in 8..152 {
                assert_eq!(actual.get_pixel(x, y), Some(BG), "row gap occupied at {x},{y}");
            }
        }
    }

    #[test]
    fn pc_menu_cursor_repaint_matches_full_redraw_for_every_transition() {
        for language in [Lang::En, Lang::Zh] {
            for (entry, phase, item_count) in [
                (PcEntry::PokemonCenter, PcPhase::MainMenu, 4),
                (PcEntry::BillsPc, PcPhase::BillsMenu, 5),
                (PcEntry::PlayersPc, PcPhase::ItemMenu, 4),
            ] {
                let mut save = SaveData::new();
                let mut base = PcScreen::new(entry, &open_context(true));
                skip_message(&mut base, &mut save);
                assert_eq!(base.phase(), phase);

                for previous_cursor in 0..item_count {
                    for current_cursor in 0..item_count {
                        if previous_cursor == current_cursor {
                            continue;
                        }
                        let previous = cursor_state(&base, &mut save, previous_cursor);
                        let current = cursor_state(&base, &mut save, current_cursor);
                        let position = |cursor| (8, (1 + cursor as u32 * 2) * T);
                        assert_cursor_repaint(
                            &previous,
                            &current,
                            &save,
                            language,
                            position(previous_cursor),
                            position(current_cursor),
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn pc_list_and_overlay_cursor_repaint_matches_full_redraw() {
        for language in [Lang::En, Lang::Zh] {
            let pitch = 12;

            let mut mon_save = SaveData::new();
            let mon = create_pokemon(Species::Bulbasaur, 9, [0x9a, 0x78]).unwrap();
            mon_save.pc_storage.current_box_mut().deposit(mon).unwrap();
            let mut mon_list = PcScreen::new(PcEntry::BillsPc, &open_context(false));
            skip_message(&mut mon_list, &mut mon_save);
            update_pc(&mut mon_list, &mut mon_save, A);
            assert_eq!(mon_list.phase(), PcPhase::MonList);

            let mon_cancel = cursor_state(&mon_list, &mut mon_save, 1);
            assert_cursor_repaint(
                &mon_list,
                &mon_cancel,
                &mon_save,
                language,
                (T, T),
                (T, T + pitch),
            );
            assert_cursor_repaint(
                &mon_cancel,
                &mon_list,
                &mon_save,
                language,
                (T, T + pitch),
                (T, T),
            );

            let mut mon_action = mon_list.clone();
            update_pc(&mut mon_action, &mut mon_save, A);
            assert_eq!(mon_action.phase(), PcPhase::MonAction);
            for previous_cursor in 0..3 {
                for current_cursor in 0..3 {
                    if previous_cursor == current_cursor {
                        continue;
                    }
                    let previous = cursor_state(&mon_action, &mut mon_save, previous_cursor);
                    let current = cursor_state(&mon_action, &mut mon_save, current_cursor);
                    let position = |cursor| (11 * T, (9 + cursor as u32 * 2) * T);
                    assert_cursor_repaint(
                        &previous,
                        &current,
                        &mon_save,
                        language,
                        position(previous_cursor),
                        position(current_cursor),
                    );
                }
            }

            let mut item_save = SaveData::new();
            item_save
                .game_data
                .pc_items
                .add_item(ItemId::Potion, 2)
                .unwrap();
            item_save
                .game_data
                .pc_items
                .add_item(ItemId::Antidote, 1)
                .unwrap();
            let mut item_list = PcScreen::new(PcEntry::PlayersPc, &open_context(false));
            skip_message(&mut item_list, &mut item_save);
            update_pc(&mut item_list, &mut item_save, A);
            assert_eq!(item_list.phase(), PcPhase::ItemList);

            for previous_cursor in 0..3 {
                for current_cursor in 0..3 {
                    if previous_cursor == current_cursor {
                        continue;
                    }
                    let previous = cursor_state(&item_list, &mut item_save, previous_cursor);
                    let current = cursor_state(&item_list, &mut item_save, current_cursor);
                    let position = |cursor| (T, T + cursor as u32 * pitch);
                    assert_cursor_repaint(
                        &previous,
                        &current,
                        &item_save,
                        language,
                        position(previous_cursor),
                        position(current_cursor),
                    );
                }
            }
        }
    }

    #[test]
    fn pc_confirmation_and_box_cursor_repaint_matches_full_redraw() {
        for language in [Lang::En, Lang::Zh] {
            let yes_no_position = |selected_yes| {
                let box_y = if language == Lang::Zh { T } else { 7 * T };
                (15 * T, box_y + if selected_yes { T } else { 3 * T })
            };

            let mut save = SaveData::new();
            let mut confirm = PcScreen::new(PcEntry::BillsPc, &open_context(false));
            skip_message(&mut confirm, &mut save);
            for _ in 0..3 {
                update_pc(&mut confirm, &mut save, DOWN);
            }
            update_pc(&mut confirm, &mut save, A);
            assert_eq!(confirm.phase(), PcPhase::ChangeBoxConfirm);
            let mut yes = confirm.clone();
            update_pc(&mut yes, &mut save, UP);
            assert_cursor_repaint(
                &confirm,
                &yes,
                &save,
                language,
                yes_no_position(false),
                yes_no_position(true),
            );
            assert_cursor_repaint(
                &yes,
                &confirm,
                &save,
                language,
                yes_no_position(true),
                yes_no_position(false),
            );

            update_pc(&mut yes, &mut save, A);
            assert_eq!(yes.phase(), PcPhase::BoxList);
            let box_position = |cursor: usize| {
                if language == Lang::Zh {
                    (
                        (cursor / 6) as u32 * 10 * T + T,
                        (5 + (cursor % 6) as u32 * 2) * T,
                    )
                } else {
                    (12 * T, T + cursor as u32 * 10)
                }
            };
            for previous_cursor in 0..12 {
                for current_cursor in 0..12 {
                    if previous_cursor == current_cursor {
                        continue;
                    }
                    let previous = cursor_state(&yes, &mut save, previous_cursor);
                    let current = cursor_state(&yes, &mut save, current_cursor);
                    assert_cursor_repaint(
                        &previous,
                        &current,
                        &save,
                        language,
                        box_position(previous_cursor),
                        box_position(current_cursor),
                    );
                }
            }

            let mut release_save = SaveData::new();
            let mon = create_pokemon(Species::Pikachu, 5, [0x9a, 0x78]).unwrap();
            release_save
                .pc_storage
                .current_box_mut()
                .deposit(mon)
                .unwrap();
            let mut release = PcScreen::new(PcEntry::BillsPc, &open_context(false));
            skip_message(&mut release, &mut release_save);
            update_pc(&mut release, &mut release_save, DOWN);
            update_pc(&mut release, &mut release_save, DOWN);
            update_pc(&mut release, &mut release_save, A);
            update_pc(&mut release, &mut release_save, A);
            assert_eq!(release.phase(), PcPhase::ReleaseConfirm);
            let mut release_yes = release.clone();
            update_pc(&mut release_yes, &mut release_save, UP);
            assert_cursor_repaint(
                &release,
                &release_yes,
                &release_save,
                language,
                yes_no_position(false),
                yes_no_position(true),
            );

            let mut toss_save = SaveData::new();
            toss_save
                .game_data
                .pc_items
                .add_item(ItemId::Potion, 2)
                .unwrap();
            let mut toss = PcScreen::new(PcEntry::PlayersPc, &open_context(false));
            skip_message(&mut toss, &mut toss_save);
            update_pc(&mut toss, &mut toss_save, DOWN);
            update_pc(&mut toss, &mut toss_save, DOWN);
            update_pc(&mut toss, &mut toss_save, A);
            update_pc(&mut toss, &mut toss_save, A);
            update_pc(&mut toss, &mut toss_save, A);
            assert_eq!(toss.phase(), PcPhase::TossConfirm);
            let mut toss_yes = toss.clone();
            update_pc(&mut toss_yes, &mut toss_save, UP);
            assert_cursor_repaint(
                &toss,
                &toss_yes,
                &toss_save,
                language,
                yes_no_position(false),
                yes_no_position(true),
            );

            let mut oak_save = SaveData::new();
            let mut oak = PcScreen::new(PcEntry::PokemonCenter, &open_context(true));
            skip_message(&mut oak, &mut oak_save);
            update_pc(&mut oak, &mut oak_save, DOWN);
            update_pc(&mut oak, &mut oak_save, DOWN);
            update_pc(&mut oak, &mut oak_save, A);
            skip_message(&mut oak, &mut oak_save);
            assert_eq!(oak.phase(), PcPhase::OaksConfirm);
            let mut oak_yes = oak.clone();
            update_pc(&mut oak_yes, &mut oak_save, UP);
            assert_cursor_repaint(
                &oak,
                &oak_yes,
                &oak_save,
                language,
                yes_no_position(false),
                yes_no_position(true),
            );
        }
    }
}
