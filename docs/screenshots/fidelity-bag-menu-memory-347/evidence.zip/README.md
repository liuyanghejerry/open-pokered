# Bag menu memory audit 347

Base: 967264bf4ffae32aab474d41c8493daaf8cd037a
Tested production/test commit: 3d3e673ae0e477d29d4b7a1075bb822630ebf7a6
Original: pret/pokered fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c

Ordinary callers use matched 1701-frame schedules, 8 cases, each repeated twice on Original, master and candidate. Four Player/Bill PC and four Pewter Mart cases compare actual actions, not identical input frames; native dialogue pagination and existing mart greeting flow require adapted acknowledgements. Battle verification uses natural Route 1 encounters, RUN and field-bag reopen; only menu-memory boundaries are compared, not battle timing, species/RNG or whole-save parity.

79 native app/core test programs: 3717 passed, 0 failed, 76 ignored. Fresh m01-m03 and independent-process s07 SAVE/CONTINUE passed. GBA validation remains CI.

151 cached/full drawing mismatches occur on both actual master and candidate in the battle walk replay; first frame 722 has a real RGB difference at (65,74)-(76,78). Rendering pass is not claimed for that replay. Both also preserve START cursor 2 after battle, where Original resets to 0. These are separate baseline findings, not fixed here.

No ROM, save, emulator state, full snapshot or executable is distributed. Native recursive battle Debug records are reduced to phase tags; private original JSON hashes are retained alongside public JSON. Replays are inputs and scoped observations, not general parity proof. Before/after screenshots use actual master and candidate with the same helper, inputs and frame 1700.
