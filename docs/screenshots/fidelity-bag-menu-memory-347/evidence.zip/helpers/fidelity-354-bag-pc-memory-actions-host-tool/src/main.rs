use std::{fs,path::Path};use dotzuki_app::InputState;use dotzuki_engine::render_config::RenderConfig;use dotzuki_renderer::input::GbButton;use pokered_app::{PokemonGame,render::session::RenderSession};use pokered_core::{game_state::{GameScreen,Lang,TextSpeed},start_menu::StartMenuState,bag_screen::BagPhase,items::inventory::Inventory};use pokered_data::{items::ItemId,wild_data::GameVersion};use pokered_renderer::{FrameBuffer,Rgba};use serde_json::json;
fn main(){let a:Vec<String>=std::env::args().collect();let out=Path::new(&a[1]);fs::create_dir_all(out).unwrap();for case in ["main","withdraw","scroll","bill"]{let dir=out.join(case);fs::create_dir(&dir).unwrap();let save=dir.join("private-owned.sav");let mut g=PokemonGame::new_with_options(GameVersion::Red,Some(save.clone()),None,None,false,None,false,true,None);g.audio=None;g.player_name="NINTEN".into();g.save_data.player_name=pokered_data::charmap::encode_string("NINTEN").unwrap();g.save_data.game_data.player_money=3000;g.set_seed(42);g.state.config.language=Lang::En;g.state.config.text_speed=TextSpeed::Slow;let stock=[(ItemId::Potion,4),(ItemId::Antidote,3),(ItemId::PokeBall,2),(ItemId::Revive,2),(ItemId::EscapeRope,1),(ItemId::Repel,2),(ItemId::HyperPotion,3),(ItemId::SuperPotion,4)];g.save_data.game_data.bag=Inventory::new_bag();g.save_data.game_data.bag.replace_item_slots(&stock).unwrap();g.save_data.game_data.pc_items.replace_item_slots(&stock).unwrap();g.state.screen=GameScreen::Overworld;g.overworld.warp_to_map(pokered_data::maps::MapId::ViridianPokecenter,13,4);g.overworld.state.player.facing=pokered_core::overworld::Direction::Up;for _ in 0..120{g.update(&InputState::new());}let party:serde_json::Value=serde_json::from_str(include_str!("../party.json")).unwrap();g.save_data.party.clear();for row in party.as_array().unwrap(){let mon=pokered_core::pokemon::stats::create_pokemon(pokered_data::species::Species::from_rom_id(row["id"].as_u64().unwrap()as u8),row["level"].as_u64().unwrap()as u8,[0x99;2]).unwrap();g.save_data.party.add(mon).unwrap();}g.overworld.set_event_flag_live(pokered_data::event_flags::EventFlag::EVENT_GOT_POKEDEX);g.start_menu=StartMenuState::new(true,true,false);g.state.screen=GameScreen::StartMenu;let cases:serde_json::Value=serde_json::from_str(include_str!("../schedule.json")).unwrap();let schedule:Vec<(usize,GbButton)>=cases[case].as_array().unwrap().iter().map(|row|(row[0].as_u64().unwrap()as usize,match row[1].as_str().unwrap(){"up"=>GbButton::Up,"down"=>GbButton::Down,"a"=>GbButton::A,"b"=>GbButton::B,"select"=>GbButton::Select,"start"=>GbButton::Start,_=>panic!("key")})).collect();let mut input=InputState::new();let mut held=None;let mut stage=0u8;let mut adaptive_key=None;let mut adaptive_at=0usize;let mut rows=vec![];let mut session=RenderSession::new();let mut cached=FrameBuffer::new(RenderConfig::new(160,144),Rgba::WHITE);for t in 0..=2600{input.begin_frame();let mut k=schedule.iter().filter(|(at,_)|*at<=700).find(|(at,_)|(*at..*at+2).contains(&t)).map(|(_,b)|*b);
if t>740 {
    if t%24==0 {
        use pokered_core::pc_screen::PcPhase;
        adaptive_key=None;adaptive_at=t;
        match g.state.screen {
            GameScreen::PC=>{
                let pc=g.pc_screen.as_ref().unwrap();let phase=pc.phase();
                if phase==PcPhase::Message {adaptive_key=Some(GbButton::A);}
                else if stage==0 && phase==PcPhase::MainMenu {
                    let target=if case=="bill"{0}else{1};adaptive_key=Some(if pc.main_menu().cursor()<target {GbButton::Down}else{GbButton::A});
                } else if stage==0 && (phase==PcPhase::ItemMenu || phase==PcPhase::BillsMenu) {
                    if case=="main" || case=="bill" {adaptive_key=Some(GbButton::B);stage=3;}
                    else {adaptive_key=Some(GbButton::A);stage=1;}
                } else if stage==1 && phase==PcPhase::ItemList {
                    if case=="scroll" && pc.item_list_cursor()<3 {adaptive_key=Some(GbButton::Down);}
                    else {adaptive_key=Some(GbButton::B);stage=2;}
                } else if stage==2 && phase==PcPhase::ItemMenu {adaptive_key=Some(GbButton::B);stage=3;}
                else if stage==3 && phase==PcPhase::MainMenu {adaptive_key=Some(GbButton::B);stage=4;}
            },
            GameScreen::Overworld if stage==4=>{adaptive_key=Some(GbButton::Start);stage=5;},
            GameScreen::StartMenu if stage==5=>{adaptive_key=Some(GbButton::A);stage=6;},
            _=>{},
        }
    }
    if t<adaptive_at+2 {k=adaptive_key;}
}if k!=held{if let Some(b)=held{input.release(b);}if let Some(b)=k{input.press(b);}held=k;}g.update(&input);let mut scroll=|_:&mut[u8],_:usize,_:usize,_:i32,_:i32,_:u8|{};session.render(&mut g,&mut cached,&mut scroll);let mut full=FrameBuffer::new(RenderConfig::new(160,144),Rgba::WHITE);g.draw(&mut full);assert_eq!(cached.packed(),full.packed(),"cached/full {case}/{t}");assert!(!save.exists());let state=&g.bag_screen;
#[cfg(feature="fixed")]let renderer_scroll=pokered_app::render::top_level_bag_viewport_offset(state);
#[cfg(not(feature="fixed"))]let renderer_scroll=pokered_app::render::top_level_bag_viewport_offset(state.items().len(),state.cursor());
let marked=match state.phase(){BagPhase::SwapFrom{row}=>Some(row),_=>None};rows.push(json!({"t":t,"input":input.raw_current(),"screen":format!("{:?}",g.state.screen),"phase":format!("{:?}",state.phase()),"pc_phase":g.pc_screen.as_ref().map(|pc|format!("{:?}",pc.phase())),"cursor":state.cursor(),"scroll":state.scroll(),"marked":marked,"renderer_scroll":renderer_scroll,"bag":g.save_data.game_data.bag.items(),"cached_equals_full":true,"ordinary_save_exists":false}));if [550,1000,1500,2000,2600].contains(&t){full.save_png(&dir.join(format!("frame-{t}.png"))).unwrap();}}fs::write(dir.join("frames.json"),serde_json::to_string_pretty(&rows).unwrap()+"\n").unwrap();println!("{case}: {}",rows[2600]);}}
