exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state';case='owned-layout';count=int(os.environ.get('DEX_MAX_SEEN_278','25'));row=int(os.environ.get('DEX_INITIAL_ROW_278','0'))
for repeat in [1,2]:
 out=r/f'audit-283-original-dex-{case}-a1-{repeat}';out.mkdir(exist_ok=False)
 p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]]);a=symbols['wPokedexSeen'][1]
 for n in range(symbols['wPokedexSeenEnd'][1]-a):p.memory[a+n]=0
 for n in range(count):p.memory[a+n//8]=int(p.memory[a+n//8])|(1<<(n%8))
 for n in range(symbols['wPokedexOwnedEnd'][1]-symbols['wPokedexOwned'][1]):p.memory[symbols['wPokedexOwned'][1]+n]=0
 p.memory[symbols['wPokedexOwned'][1]]=0x15
 p.memory[symbols['wBattleAndStartSavedMenuItem'][1]]=0
 cues={'ShowPokedexMenu':None};now=[-1];events=[];held=None;rows=[]
 def hook(n):
  if n in cues and cues[n] is None:cues[n]=now[0]
  events.append({'t':now[0],'routine':n,'cursor':get('wCurrentMenuItem'),'scroll':get('wListScrollOffset'),'joy7':get('hJoy7')})
 for n in ['ShowPokedexMenu','HandlePokedexListMenu','HandleMenuInput']:p.hook_register(*symbols[n],hook,n)
 for t in range(900):
  now[0]=t;key='start' if t in [0,1] else ('a' if t in [70,71] else None);anchor=cues['ShowPokedexMenu']
  if anchor is not None:
   key=None;offset=t-anchor
   key={70:'down',118:'a',166:'b'}.get(offset)
  if key!=held:
   if held:
    for k in held.split('-'):p.button_release(k)
   if key:
    for k in key.split('-'):p.button_press(k)
   held=key
  p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png');rows.append({'t':t,'input':key,'cues':dict(cues),'cursor':get('wCurrentMenuItem'),'scroll':get('wListScrollOffset'),'max_seen':get('wDexMaxSeenMon')})
  if anchor is not None and t>=anchor+210:break
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
 assert cues['ShowPokedexMenu'] is not None,(case,events[-10:])
 assert rows[-1]['cursor']==1 and rows[-1]['scroll']==0,rows[-1]
 if repeat==2:
  other=r/f'audit-283-original-dex-{case}-a1-1';assert all(p.read_bytes()==(other/p.name).read_bytes() for p in out.iterdir())
 print(case,repeat,rows[-1],flush=True)
