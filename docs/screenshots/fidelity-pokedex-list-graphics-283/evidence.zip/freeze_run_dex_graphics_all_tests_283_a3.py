from pathlib import Path
import subprocess,hashlib,json,shutil,os,re,sys
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';kind=sys.argv[1];wt=root/'.task-tmp'/({'dex':'fidelity-283-pokedex-list-graphics-checkout'}[kind]);out=r/f'audit-283-{kind}-all-tests-a3-immutable';out.mkdir(exist_ok=False);log=(r/f'audit-283-{kind}-all-tests-build-a3.log').read_text();assert 'Finished `test` profile' in log;paths=re.findall(r'Executable .*?\((/[^\n]+)\)',log);assert len(paths)==len(set(paths)) and len(paths)>20;sha=lambda b:hashlib.sha256(b).hexdigest();files=subprocess.check_output(['git','diff','--name-only','7a6191e1959f1ca4eca70f35feac23044e0cfd8c','--','crates'],cwd=wt).decode().splitlines();m={'base':'7a6191e1959f1ca4eca70f35feac23044e0cfd8c','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'sources':{p:sha((wt/p).read_bytes()) for p in files},'binaries':{}}
for path in paths:
 p=Path(path);dest=out/p.name;shutil.copy2(p,dest);m['binaries'][p.name]=sha(dest.read_bytes())
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');results=[]
for i,path in enumerate(paths):
 p=Path(path);dest=out/p.name;testlog=r/f'audit-283-{kind}-alltests-a3-{i:03}-{p.name}.log'
 with testlog.open('w') as f:q=subprocess.run([str(dest),'--test-threads=4'],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(root/'.task-tmp/fidelity-18-27')),stdout=f,stderr=subprocess.STDOUT)
 lines=[line for line in testlog.read_text().splitlines() if line.startswith('test result:')];assert len(lines)==1,(p,lines);results.append({'binary':p.name,'exit':q.returncode,'summary':lines[0],'log':testlog.name});print(i,p.name,q.returncode,lines[0],flush=True)
 if q.returncode:break
(r/f'audit-283-{kind}-all-unit-and-integration-results-a3.json').write_text(json.dumps({'binaries_built':len(paths),'results':results,'every_binary_completed':len(paths)==len(results),'all_pass':all(x['exit']==0 for x in results)},indent=2)+'\n')
if any(x['exit'] for x in results):sys.exit(101)
