from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile

root = Path('/home/jerry/develop/open-pokered')
r = root / '.task-tmp/fidelity-39-plus'
w = root / '.task-tmp/fidelity-283-pokedex-list-graphics-checkout'
base = '7a6191e1959f1ca4eca70f35feac23044e0cfd8c'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w).decode().strip()
sha = lambda data: hashlib.sha256(data).hexdigest()
tests = json.loads((r / 'audit-283-full-regression-summary.json').read_text())
assert tests['source_head'] == head and tests['programs'] == 78
assert tests['all_completed'] and tests['all_pass'] and tests['failed'] == 0
cli = json.loads((r / 'audit-283-dex-cli-regression-results.json').read_text())
assert cli['head'] == head and cli['base'] == base
assert cli['fresh_m01_m03'] and cli['separate_process_s07_save_continue']
before = json.loads((r / 'audit-283-promoted-master-cli-equivalence.json').read_text())
assert before['base'] == base and before['entire_crates_tree_equal']
source_path = 'crates/pokered-app/src/render/pokedex.rs'
manifest = json.loads((r / 'audit-283-dex-all-tests-a3-immutable/manifest.json').read_text())
assert manifest['head'] == head and manifest['sources'][source_path] == sha((w / source_path).read_bytes())
files = {}
for prefix, source in [
    ('audit-283-original-dex-owned-layout-a1', True),
    ('audit-283-master-promoted-dex-owned-layout-a1', False),
    ('audit-283-native-dex-owned-layout-a1', False),
]:
    a, b = [r / (prefix + '-' + str(n)) for n in [1, 2]]
    assert sorted(p.name for p in a.iterdir()) == sorted(p.name for p in b.iterdir())
    assert all(p.read_bytes() == (b / p.name).read_bytes() for p in a.iterdir())
    for d in [a, b]:
        rows = json.loads((d / 'frames.json').read_text())
        if source:
            assert (rows[-1]['cursor'], rows[-1]['scroll'], rows[-1]['max_seen']) == (1, 0, 25)
        else:
            assert all(x['bag'] == rows[0]['bag'] and not x['owned_save_exists'] for x in rows)
            assert not (d / 'owned.sav').exists()
        for p in d.iterdir():
            assert p.suffix in ['.png', '.json'], p
            files[str(p.relative_to(r))] = p
for name in [
    'audit-283-full-regression-summary.json',
    'audit-283-dex-all-tests-build-a3.log',
    'audit-283-dex-all-unit-and-integration-results-a3.json',
    'audit-283-dex-all-tests-a3-immutable/manifest.json',
    'audit-283-promoted-master-cli-equivalence.json',
    'audit-283-dex-cli-build-a1.log',
    'audit-283-dex-cli-immutable/manifest.json',
    'audit-283-dex-cli-regression-results.json',
    'audit-283-dex-cli-regression-run.log',
    'audit-283-promoted-master-owned-layout.log',
    'audit-283-native-owned-layout.log',
    'audit-283-original-owned-layout.log',
    'record_pokedex_owned_layout_master_promoted_283.py',
    'record_pokedex_owned_layout_after_283.py',
    'stats-59-tools/probe_pokedex_owned_layout_283.py',
    'freeze_run_dex_graphics_all_tests_283_a3.py',
    'freeze_run_dex_graphics_cli_283.py',
    'package_pokedex_list_graphics_283.py',
]:
    p = r / name
    assert p.exists(), p
    files[name] = p
full = json.loads((r / 'audit-283-dex-all-unit-and-integration-results-a3.json').read_text())
for x in full['results']:
    files[x['log']] = r / x['log']
files['candidate-source/' + source_path] = w / source_path
ref = Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for path in ['engine/menus/pokedex.asm', 'engine/gfx/load_pokedex_tiles.asm', 'home/load_font.asm']:
    files['original-source/' + path] = ref / path
out = w / 'docs/screenshots/fidelity-pokedex-list-graphics-283'
out.mkdir(parents=True, exist_ok=False)
pngs, blobs = {}, set()
with zipfile.ZipFile(out / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name, p in files.items():
        data = p.read_bytes()
        if p.suffix == '.png':
            h = sha(data)
            pngs[name] = h
            if h not in blobs:
                z.writestr('png-blobs/' + h + '.png', data)
                blobs.add(h)
        else:
            z.writestr(name, data)
    z.writestr('png-files.json', json.dumps(pngs, indent=2) + '\n')
with zipfile.ZipFile(out / 'evidence.zip') as z:
    for name, p in files.items():
        assert z.read('png-blobs/' + pngs[name] + '.png' if name in pngs else name) == p.read_bytes()
for name, t in [('initial', 20), ('moved', 74), ('side-menu', 122), ('returned', 170)]:
    for prefix, label in [('master-promoted', 'before'), ('native', 'after')]:
        shutil.copy2(r / f'audit-283-{prefix}-dex-owned-layout-a1-1/frame-{t:03}.png', out / f'{name}-{label}.png')
verification = {
    'base': base, 'tested_source_head': head, 'tests': tests,
    'actual_control': 'START -> POKEDEX, DOWN at70, A at118, B at166; first25 seen, owned001/003/005; actual original and both native sides each repeat twice byte exact',
    'source_coordinates': 'CONTENTS(1,1), number(1,2+2row), owned ball(3,3+2row), name(4,3+2row); PrintNumber advances HL before dec/inc',
    'tiles': 'pokedex tiles70/71, battle HUD7a, battle balls72; resource-backed/fallback equality test requires real assets to load',
    'cursor': 'existing filled/hollow glyphs; list cursor column0, owned marker column3, existing cached cursor repaint unchanged and full/cached equality tests pass',
    'master_binary': 'frozen tested172 binary, entire crates tree equality to actual master proved; not claimed newly rebuilt',
    'scope': 'CONTENTS English coordinates and UI artwork/active selection only; fonts/Chinese/IME/dialogue layout excluded; input guards/repeat/combined keys and broader gameplay audits remain incomplete',
    'controlled_fixture_not_natural_playthrough': True,
    'native_bag_stable_no_auto_save': True,
    'PNG': len(pngs), 'archive_roundtrip_byte_exact': True,
    'archive_sha256': sha((out / 'evidence.zip').read_bytes()),
    'archive_bytes': (out / 'evidence.zip').stat().st_size,
}
(out / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
(out / 'README.md').write_text('''# Pokédex CONTENTS graphics fidelity

One production file restores the original two-line English rows, owned marker position, full-height divider tiles and hollow inactive list cursor. CONTENTS stays at its original (1,1). Existing font rendering and Chinese text coordinates stay unchanged.

Four before/after pairs show the initial list, moved cursor, side menu and return. Before uses the frozen tested PR172 binary with proved entire `crates` tree equality to actual master `7a6191e`; after uses this candidate's explicitly built debug CLI. These are controlled real START/POKEDEX inputs with seen001–025 and owned001/003/005, not a natural full playthrough. Original emulator and both native sides repeat twice byte exactly. Inventory remains stable and no automatic save is written.

Original `PrintNumber` advances the tile pointer from column1 to4; `dec hl` writes the owned marker at3, and the subsequent `inc hl` places the name at4. Title is (1,1), numbers are one tile above each name. `LoadPokedexTilePatterns` and `HandlePokedexListMenu` supply the UI tiles. Resource/fallback regression requires actual assets to load; existing list/side-menu cursor tests compare full frames to incremental repaint for both languages.

78 frozen app/core debug-enabled test programs: 3687 passed, 0 failed, 76 ignored. Fresh m01–m03 and separate-process s07 SAVE/CONTINUE also pass. `verification.json` records commits, scope and archive hash. `evidence.zip` contains byte-checked frames, metadata, source excerpts, scripts and logs; it contains no ROM, SRAM, emulator state, private snapshot or executable. PNG paths are reconstructed via `png-files.json` and deduplicated `png-blobs`.

Input guards, held repeat, combined-key handling and broader story/function fidelity remain under separate audit. No whole-game equivalence is claimed.
''')
print(json.dumps(verification), flush=True)
