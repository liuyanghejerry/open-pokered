from pathlib import Path
import hashlib,json,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-221-bag-swap-checkout';d=wt/'docs/screenshots/fidelity-bag-swap-221';d.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((r/'audit-221-native-a1-immutable/manifest.json').read_text())
for name,h in m['sources'].items():assert sha((wt/name).read_bytes())==h,name
files={}
for side,tag in [('master','a2'),('native','a1')]:
 for repeat in [1,2]:
  p=r/f'audit-221-{side}-capture-{tag}-{repeat}'
  for f in p.rglob('*'):
   if f.is_file():files[str(f.relative_to(r))]=f
  files[p.name+'.log']=r/(p.name+'.log')
 for name in [f'audit-221-{side}-{tag}-immutable/manifest.json',f'audit-221-{side}-verification-{tag}.json']:files[name]=r/name
for prefix,cases in [('audit-221-original-bag-mark-wait',['early-b','early-a','early-down','early-select']),('audit-221-original-bag-swap',['swap']),('audit-221-original-bag-merge',['merge','overflow'])]:
 for case in cases:
  for repeat in [1,2]:
   p=r/f'{prefix}-{case}-a1-{repeat}'
   for f in p.iterdir():files[str(f.relative_to(r))]=f
for name in ['audit-221-original-mark-wait-a1.log','audit-221-original-swap-a1.log','audit-221-original-merge-a1.log','audit-221-original-wait-verification.json','audit-221-original-swap-verification.json','audit-221-original-merge-verification.json','audit-221-master-build-a1.log','audit-221-master-build-a2.log','audit-221-native-build-a1.log','audit-221-master-negative-a1.log','audit-221-master-negative-a2.log','audit-221-core-tests-a1.log','audit-221-app-tests-a1.log','audit-221-master-verification.json','audit-221-bag-swap-owner-helper.rs','audit-221-bag-swap-owner-helper-a2.rs','freeze_bag_swap_221.py','record_bag_swap_221.py','package_bag_swap_221.py','stats-59-tools/probe_bag_mark_wait_221.py','stats-59-tools/probe_bag_swap_221.py','stats-59-tools/probe_bag_merge_221.py']:files[name]=r/name
for name in m['sources']:files['final-source/'+name]=wt/name
files['actual-master-game-with-test-only-helper.rs']=root/'.task-tmp/fidelity-221-bag-swap-before-checkout/crates/pokered-app/src/game.rs'
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['engine/menus/swap_items.asm','engine/items/inventory.asm','home/list_menu.asm','home/window.asm']:files['original-source/'+name]=ref/name
png={};blobs={}
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  b=p.read_bytes()
  if p.suffix=='.png':
   h=sha(b);png[name]=h
   if h not in blobs:blobs[h]=b;z.writestr('png-blobs/'+h+'.png',b)
  else:z.writestr(name,b)
 z.writestr('png-files.json',json.dumps(png,indent=2))
assert len(png)==9408,len(png)
with zipfile.ZipFile(d/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for name,case,frame in [('wait','swap',100),('reopen','swap',145),('merge','merge',115),('early','early-down',16)]:
 for side,tag,label in [('master','a2','before'),('native','a1','after')]:shutil.copy2(r/f'audit-221-{side}-capture-{tag}-1/{case}/frame-{frame:04}.png',d/f'{name}-{label}.png')
v={'master_before':'61a1e666efc6191e8285fb67195ef9a18761e1ec','stacked_source_base':'af67939 PR161','source_commit':'7893247','sources':m,'tests':{'core':2724,'app':200,'ignored':24},'PNG':9408,'all_archive_files_roundtrip_bytes_equal':True,'archive_sha256':sha((d/'evidence.zip').read_bytes())};(d/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
(d/'README.md').write_text('''# Bag protected swap and physical inventory commit, standalone221

Actual master61a1e66 swaps only the screen list, leaving save_data inventory
unchanged; exiting and reopening restores the old order. It also omits both
original20-frame waits. Same-kind merges incorrectly keep the first slot rather
than the second. Primary HandleItemListSwapping waits20 after marking, then20
before a valid second swap. It combines into the second slot, erases the first,
and resets current row/scroll0; overflow keeps first remainder and second99.
AddItemToInventory_ explicitly creates overflow slots, so duplicates are supported
in the original, although these recordings seed them rather than acquire them.

Repair: two private wait fields freeze all input, then emit one ItemsReordered
commit; validated Inventory::replace_item_slots atomically preserves physical
order and duplicates. Game commits at that event and rolls the screen back to
authoritative inventory on validation failure. Existing same/CANCEL SELECT and
A/B priority rules from PR161 are retained. Three production files (Bag, Inventory,
Game); render/menu changes only its cached/full test to let the protected mark
wait finish before testing a real cursor move. No font/Chinese/dialogue-box
layout, PC or other menu changes are included.

This branch is stacked on PR161af67939. Before is actual master61a1e66 production
with only the identical owner helper appended, independently compiled/frozen.
After frozen source hashes match source7893247. Own latest master integration CI
must be rerun after PR161 merges; stacked green is not that proof. Do not merge
before dependency and all own final CI/GBA gates are green, with no threshold edits.

Original controlled field fixture records brief B/A/DOWN/SELECT at mark+10..11:
all ignored by the20-frame delay, mark1/cursor0 retained, no list exit. Four cases
350 frames twice yield2800 PNG and full hook/state data byte exact. Valid two-item
swap and duplicate merge/overflow each350 frames twice add2100 PNG. Second SELECT
is299; physical inventory first changes319 exactly20 later. Merge becomes
Antidote4/Potion7 with row/scroll0; overflow Potion41/Antidote4/Potion99 with row2.
The mark byte changes before the delay, while the already drawn marker is held;
we do not equate that transient raw byte with frontend phase or PPU timing.

Actual Game starts on collision-checked Viridian Center4,4, seed42, English/Medium,
injured Bulbasaur5 and direct Bag entry. First SELECT0, movement40/64, second90:
inventory unchanged through109 and committed110; B120 exits, DOWN130/A138 reopen
and preserve physical slot order. Four brief interference cases start10 and stay
marked with row0. Before normal regression fails at premature phase change90;
raw data show displayed swap90 but saved order old, and reopened138 old again.
Expanded7 cases each161 frames twice on both sides produce4508 PNG, full JSON
byte exact within-side. Every frame compares every retained/full pixel. Core2724
and app200 pass (24 opt-in captures ignored), including PR161/field Bag regressions,
exact20-frame once-only commit and atomic validation/duplicate tests. Images use
matched states/input/frame: wait100, reopen145, merge115, early direction16.

Evidence archive retains all9408 original/current PNG paths losslessly via SHA256
blobs; every PNG and every other file is read back and compared byte-for-byte.
Complete raw JSON, hooks, primary assembly, source/hash manifests, scripts and
full logs are included. Initial5-case baseline evidence is retained as diagnostic
in the workspace and its verification/log is archived; final symmetrical evidence
uses expanded7-case helper on both sides. No ROM, SRAM, emulator state or binary
is published. These are controlled runtime probes, not natural mainline traversal,
a complete SAVE/CONTINUE proof, or absolute originalCPU/PPU pixel/frame alignment.
Broader held-repeat/scroll/cursor-return and other fidelity audits remain open.
''')
print(json.dumps({'PNG':len(png),'archive_bytes':(d/'evidence.zip').stat().st_size,'roundtrip':True}))
