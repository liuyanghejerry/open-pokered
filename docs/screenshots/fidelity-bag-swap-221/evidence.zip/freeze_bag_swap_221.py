from pathlib import Path
import subprocess,hashlib,json,shutil,os,re,sys
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-221-bag-swap-checkout';out=r/'audit-221-native-a1-immutable';out.mkdir(exist_ok=False);log=(r/'audit-221-native-build-a1.log').read_text();assert 'Finished `test` profile' in log;m=json.loads((r/'audit-221-native-source-a1.json').read_text())
for name,h in m['sources'].items():assert hashlib.sha256((wt/name).read_bytes()).hexdigest()==h,name
m['binaries']={}
for binary in ['core','app']:
 a=[p for p in re.findall(r'Executable .*?\((/[^\n]+)\)',log) if f'pokered_{binary}-' in p];assert len(a)==1;shutil.copy2(a[0],out/binary);m['binaries'][binary]=hashlib.sha256((out/binary).read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for binary in ['core','app']:
 with (r/f'audit-221-{binary}-tests-a1.log').open('w') as f:q=subprocess.run([str(out/binary)],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib'),stdout=f,stderr=subprocess.STDOUT)
 print(binary,q.returncode,flush=True)
 if q.returncode:sys.exit(q.returncode)
