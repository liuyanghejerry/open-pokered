from pathlib import Path
import os,subprocess,json
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';side=os.environ.get('BAG_SWAP_SIDE_221','native');tag='a1' if side=='native' else 'a2';binary=r/f'audit-221-{side}-{tag}-immutable/app';wt=root/'.task-tmp'/('fidelity-221-bag-swap-checkout' if side=='native' else 'fidelity-221-bag-swap-before-checkout')
for repeat in [1,2]:
 out=r/f'audit-221-{side}-capture-{tag}-{repeat}';out.mkdir(exist_ok=False)
 with (r/(out.name+'.log')).open('w') as f:subprocess.run([str(binary),'capture_bag_swap_221','--ignored','--nocapture'],cwd=wt,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',BAG_SWAP_CAPTURE_221=str(out)),stdout=f,stderr=subprocess.STDOUT,check=True)
a=r/f'audit-221-{side}-capture-{tag}-1';b=r/f'audit-221-{side}-capture-{tag}-2';assert len(list(a.iterdir()))==7;assert all(p.read_bytes()==(b/p.relative_to(a)).read_bytes() for p in a.rglob('*') if p.is_file());png=len(list(a.rglob('*.png')))*2;assert png==2254
report={'side':side,'PNG':png,'repeat_all_raw_and_png_byte_exact':True,'every_retained_full_frame_pixels_equal':True,'scope':'controlled Bag, original protected20 timing and physical slots; native7cases, seeded/collision-checked center4,4; not natural traversal or absolute originalCPU/PPU framealignment'};(r/f'audit-221-{side}-verification-{tag}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
