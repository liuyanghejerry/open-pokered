exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state'
for case in ['merge','overflow']:
 for trial in [1,2]:
  out=r/f'audit-221-original-bag-merge-{case}-a1-{trial}';out.mkdir(exist_ok=False)
  p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()));get=lambda n:int(p.memory[symbols[n][1]])
  p.memory[symbols['wNumBagItems'][1]]=3;a=symbols['wBagItems'][1]
  for i,v in enumerate([0x14,3 if case=="merge" else 60,0x0b,4,0x14,4 if case=="merge" else 80,0xff]):p.memory[a+i]=v
  for n in ['wBattleAndStartSavedMenuItem','wBagSavedMenuItem','wListScrollOffset']:p.memory[symbols[n][1]]=0
  p.memory[symbols['wOptions'][1]]=(get('wOptions')&0xf0)|3
  now=[-1];events=[];cues={n:None for n in ['DrawStartMenu','StartMenu_Item','StartMenu_Item.choseItem','CloseStartMenu']}
  def hook(n):
   if n in cues and cues[n] is None:cues[n]=now[0]
   events.append({'t':now[0],'routine':n,'cursor':get('wCurrentMenuItem'),'mark':get('wMenuItemToSwap'),'scroll':get('wListScrollOffset')})
  for n in list(cues)+['DisplayListMenuID','HandleItemListSwapping','ExitListMenu']:p.hook_register(*symbols[n],hook,n)
  held=set();rows=[];steps=None
  for t in range(350):
   now[0]=t;keys={'start'} if t<2 else set();m=cues['DrawStartMenu'];li=cues['StartMenu_Item']
   if m is not None and li is None:
    if steps is None and t>=m+40:steps=2 if get('wMaxMenuItem')==7 else 1
    if steps is not None:
     for n in range(steps):
      if m+70+n*24<=t<m+72+n*24:keys={'down'}
     if m+70+steps*24<=t<m+72+steps*24:keys={'a'}
   if li is not None:
    if li+70<=t<li+72 or li+160<=t<li+162:keys={'select'}
    if li+110<=t<li+112 or li+134<=t<li+136:keys={'down'}
   for key in held-keys:p.button_release(key)
   for key in keys-held:p.button_press(key)
   held=keys;p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png')
   rows.append({'t':t,'input':sorted(keys),'cues':dict(cues),'cursor':get('wCurrentMenuItem'),'max':get('wMaxMenuItem'),'mark':get('wMenuItemToSwap'),'scroll':get('wListScrollOffset'),'bag':[int(p.memory[a+i]) for i in range(7)],'textbox':get('wTextBoxID')})
  (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
  if trial==2:
   before=r/f'audit-221-original-bag-merge-{case}-a1-1';assert all(f.read_bytes()==(before/f.name).read_bytes() for f in out.iterdir())
  print(case,trial,cues,[(q['t'],q['cursor'],q['mark'],q['textbox']) for q in rows if li is not None and q['t'] in [li+69,li+79,li+90,li+110,li+160]],flush=True)
