
#[cfg(all(test,not(target_os="none")))]
mod bag_swap_owner_221 {
 use super::*;
 fn run(capture:Option<&std::path::Path>) {
  use pokered_data::items::ItemId;
  for case in ["swap","merge","overflow","early-b","early-a","early-down","early-select"] {
   let mut g=PokemonGame::new(GameVersion::Red);g.audio=None;g.set_seed(42);g.state.config.language=pokered_core::game_state::Lang::En;g.state.config.text_speed=pokered_core::game_state::TextSpeed::Medium;
   let mut mon=pokered_core::pokemon::stats::create_pokemon(pokered_data::species::Species::Bulbasaur,5,[0x99,0x88]).unwrap();mon.hp-=1;g.save_data.party.add(mon).unwrap();
   g.state.screen=GameScreen::Overworld;g.overworld.warp_to_map(MapId::ViridianPokecenter,4,4);let mut input=InputState::new();for _ in 0..120 {g.update(&input);}
   assert!(pokered_core::overworld::update::is_script_walkable_tile(g.overworld.map_data.as_ref().unwrap(),4,4));
   g.save_data.game_data.bag=pokered_core::items::inventory::Inventory::new_bag();g.save_data.game_data.bag.add_item(ItemId::Potion,3).unwrap();g.save_data.game_data.bag.add_item(ItemId::Antidote,4).unwrap();if matches!(case,"merge"|"overflow") {
    let first=if case=="merge" {3}else{60};let second=if case=="merge" {4}else{80};
    let mut v=serde_json::to_value(&g.save_data.game_data.bag).unwrap();v["items"]=serde_json::json!([(ItemId::Potion,first),(ItemId::Antidote,4),(ItemId::Potion,second)]);g.save_data.game_data.bag=serde_json::from_value(v).unwrap();
   }
   g.bag_screen=BagScreenState::new(g.save_data.game_data.bag.items().to_vec());g.state.screen=GameScreen::Bag;
   let mut session=crate::render::session::RenderSession::new();let mut retained=FrameBuffer::new(dotzuki_engine::render_config::RenderConfig::new(160,144),pokered_renderer::Rgba::WHITE);let mut scroll=|_:&mut [u8],_:usize,_:usize,_:i32,_:i32,_:u8|{};let mut held=Vec::new();let mut rows=Vec::new();
   for t in 0..161 {
    input.begin_frame();let keys=match t {
     0=>vec![GbButton::Select],
     10=>match case {"early-b"=>vec![GbButton::B],"early-a"=>vec![GbButton::A],"early-down"=>vec![GbButton::Down],"early-select"=>vec![GbButton::Select],_=>vec![]},
     40|130 if matches!(case,"swap"|"merge"|"overflow")=>vec![GbButton::Down],
     64 if matches!(case,"merge"|"overflow")=>vec![GbButton::Down],
     90 if matches!(case,"swap"|"merge"|"overflow")=>vec![GbButton::Select],
     120 if matches!(case,"swap"|"merge"|"overflow")=>vec![GbButton::B],138 if matches!(case,"swap"|"merge"|"overflow")=>vec![GbButton::A],_=>vec![]};
    for &key in &held {if !keys.contains(&key){input.release(key);}}for &key in &keys {if !held.contains(&key){input.press(key);}}held=keys;
    g.update(&input);session.render(&mut g,&mut retained,&mut scroll);let mut full=FrameBuffer::new(dotzuki_engine::render_config::RenderConfig::new(160,144),pokered_renderer::Rgba::WHITE);g.draw(&mut full);assert_eq!(retained.packed(),full.packed(),"{case} cached/full {t}");
    if capture.is_none() {
     use pokered_core::bag_screen::BagPhase;
     if matches!(case,"swap"|"merge"|"overflow") {
      let old=if case=="swap" {vec![(ItemId::Potion,3),(ItemId::Antidote,4)]}else{vec![(ItemId::Potion,if case=="merge" {3}else{60}),(ItemId::Antidote,4),(ItemId::Potion,if case=="merge" {4}else{80})]};
      let after=if case=="swap" {vec![(ItemId::Antidote,4),(ItemId::Potion,3)]}else if case=="merge" {vec![(ItemId::Antidote,4),(ItemId::Potion,7)]}else{vec![(ItemId::Potion,41),(ItemId::Antidote,4),(ItemId::Potion,99)]};
      let expected=if t<110 {old}else{after.clone()};
      assert_eq!(g.save_data.game_data.bag.items(),expected,"{case} inventory commit/reopen at{t}");
      if t<110 {assert_eq!(g.bag_screen.phase(),BagPhase::SwapFrom{row:0},"marked/waiting at{t}");}
      if (120..138).contains(&t) {assert_eq!(g.state.screen,GameScreen::StartMenu);}else {assert_eq!(g.state.screen,GameScreen::Bag);}
      if t>=138 {assert_eq!(g.bag_screen.items(),after,"reopened item order");}
     } else {assert_eq!(g.state.screen,GameScreen::Bag);assert_eq!(g.bag_screen.phase(),BagPhase::SwapFrom{row:0});assert_eq!(g.bag_screen.cursor(),0,"{case} protected input");assert_eq!(g.save_data.game_data.bag.items(),&[(ItemId::Potion,3),(ItemId::Antidote,4)]);}
    }
    if let Some(path)=capture {let dir=path.join(case);std::fs::create_dir_all(&dir).unwrap();full.save_png(&dir.join(format!("frame-{t:04}.png"))).unwrap();rows.push(serde_json::json!({"t":t,"input":input.raw_current(),"screen":format!("{:?}",g.state.screen),"phase":format!("{:?}",g.bag_screen.phase()),"stock":g.save_data.game_data.bag.item_quantity(ItemId::Potion),"cursor":g.bag_screen.cursor(),"bag":format!("{:?}",g.save_data.game_data.bag.items()),"display_items":format!("{:?}",g.bag_screen.items()),"overworld":pokered_core::snapshot::OverworldSnapshot::capture(&g.overworld)}));}
   }
   if let Some(path)=capture {std::fs::write(path.join(case).join("frames.json"),serde_json::to_string_pretty(&rows).unwrap()).unwrap();}
  }
 }
 #[test]fn bag_swap_wait_commit_and_reopen_match_original(){std::thread::Builder::new().stack_size(16*1024*1024).spawn(||run(None)).unwrap().join().unwrap();}
 #[test]#[ignore="controlled Bag swap before-after capture"]fn capture_bag_swap_221(){let path=std::path::PathBuf::from(std::env::var("BAG_SWAP_CAPTURE_221").unwrap());std::thread::Builder::new().stack_size(16*1024*1024).spawn(move||run(Some(&path))).unwrap().join().unwrap();}
}
