exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
base=root/'.task-tmp/fidelity-39-plus'
out=base/'npc-136-route1-setup';out.mkdir(exist_ok=True)
p=PyBoy(str(base/'movement-91-road-setup/road.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0)
p.load_state(io.BytesIO((base/'movement-91-road-reference-False-1/pretrigger.state').read_bytes()))
get=lambda n:int(p.memory[symbols[n][1]])
p.memory[symbols['wRepelRemainingSteps'][1]]=200
p.memory[symbols['wPartyMon1Level'][1]]=50
p.button_press('down')
for t in range(1800):
 p.tick(1)
 if get('wCurMap')==12 and get('wYCoord')==12:break
else:raise RuntimeError(('failed route1 walk',get('wCurMap'),get('wXCoord'),get('wYCoord')))
p.button_release('down');p.tick(30)
assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(12,10,12)
for target in [11,12,13,14,15,16]:
 p.button_press('right')
 for t in range(120):
  p.tick(1)
  if get('wXCoord')==target:break
 else:raise RuntimeError(('right blocked',get('wXCoord')))
 p.button_release('right');p.tick(30)
 assert get('wXCoord')==target
p.button_press('down')
for t in range(1800):
 p.tick(1)
 if get('wYCoord')==22:break
else:
 p.screen.image.save(out/'blocked.png')
 raise RuntimeError(('southern walk blocked',get('wCurMap'),get('wXCoord'),get('wYCoord'),get('wIsInBattle'),get('wRepelRemainingSteps'),get('wPartyMon1Level')))
p.button_release('down');p.tick(30)
assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(12,16,22)
for target in [15,14,13,12]:
 p.button_press('left')
 for t in range(120):
  p.tick(1)
  if get('wXCoord')==target:break
 else:raise RuntimeError(('left blocked',get('wXCoord')))
 p.button_release('left');p.tick(30)
 assert get('wXCoord')==target
assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(12,12,22)
p.screen.image.save(out/'route1.png')
with (out/'route1.state').open('wb') as f:p.save_state(f)
info={'source':'fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c','method':'load true City road Continue pretrigger, actual Down transition toRoute1 y12, Right6 toavoidrockwall, Down toy22, Left4','controlled_write':'wRepelRemainingSteps=200 and wPartyMon1Level=50 before walk, suppress wild encounters. Level control is only for Repel; no battle/party-stat fidelity claim. No map/coordinate/BG/ROM edit','map':get('wCurMap'),'x':get('wXCoord'),'y':get('wYCoord'),'grass_tile':get('wGrassTile'),'player_standing':get('hTilePlayerStandingOn')}
(out/'setup.json').write_text(json.dumps(info,indent=2)+'\n');print(info,flush=True);p.stop(save=False)
