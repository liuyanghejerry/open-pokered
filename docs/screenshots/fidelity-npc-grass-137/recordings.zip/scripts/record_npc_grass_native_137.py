import os,subprocess,json
from pathlib import Path
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus'
for build in ['master','after']:
 w=r/('.task-tmp/fidelity-93-master-before' if build=='master' else '.task-tmp/fidelity-91-plus-checkout')
 exe=r/('.task-tmp/fidelity-39-plus/unoptimized-target/debug/deps/pokered_app-ff0279f3644dd22e' if build=='master' else '.task-tmp/fidelity-18-27/target/debug/deps/pokered_app-823b1783d030defc')
 for case in (['stand'] if build=='master' else ['stand','walk','player']):
  future=127 if case in ['stand','player'] else 16
  for trial in [1,2]:
   out=b/f'npc-137-grass-{case}-final-{build}-{trial}'
   env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(r/'.task-tmp/fidelity-18-27'),FIDELITY_NPC_GRASS_CAPTURE=str(out),FIDELITY_NPC_GRASS_FUTURE_DELAY=str(future))
   if case!='stand':env['FIDELITY_NPC_GRASS_WALK']='1'
   if case=='player':env['FIDELITY_NPC_GRASS_PLAYER_WALK']='1'
   with (b/f'npc-137-grass-{case}-final-{build}-{trial}.log').open('w') as f:
    result=subprocess.run([str(exe),'game::link_stats_cry_fidelity_tests::capture_npc_grass_raw_136','--exact','--ignored','--nocapture','--test-threads=1'],cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
   assert result.returncode==0,result.returncode
   rows=json.loads((out/'frames.json').read_text());assert len(rows)==(21 if case=='stand' else 31)
   print(build,case,trial,flush=True)
