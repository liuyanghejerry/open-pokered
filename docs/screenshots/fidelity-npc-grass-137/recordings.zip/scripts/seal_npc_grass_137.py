from pathlib import Path
import json,hashlib,re,zipfile,shutil
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';w=r/'.task-tmp/fidelity-91-plus-checkout';d=w/'docs/screenshots/fidelity-npc-grass-137';d.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results={};folders=[]
for prefix in ['npc-136-grass-source','npc-137-grass-walk-source','npc-137-grass-player-walk-source','npc-137-grass-stand-final-master','npc-137-grass-stand-final-after','npc-137-grass-walk-final-after','npc-137-grass-player-final-after','npc-136-grass-native-before']:
 a=b/f'{prefix}-1';c=b/f'{prefix}-2';assert (a/'frames.json').read_bytes()==(c/'frames.json').read_bytes();imgs=sorted(a.glob('frame-*.png'))
 for p in imgs:assert p.read_bytes()==(c/p.name).read_bytes()
 results[prefix]={'frames':len(imgs),'RAM_and_PNG_repeats':'exact'};folders.extend([a,c])
for kind,folder in [('before','npc-137-grass-stand-final-master-1'),('after','npc-137-grass-stand-final-after-1'),('previous-head','npc-136-grass-native-before-1')]:shutil.copyfile(b/folder/'frame-0000.png',d/f'standing-{kind}.png')
for f in ['npc-137-grass-oracle.log','npc-137-gba-result.json','npc-137-gba-compare.log','npc-137-gba-provenance.json','npc-136-grass-before-comparison.json']:shutil.copyfile(b/f,d/f)
(d/'recording-verification.json').write_text(json.dumps({'source_oracle_frames':83,'source_pixel_strips':'exact: 21 standing +31 NPC walking +31 player/NPC walking','cached_full_frames':'all pixels exact on83 oracle +12 prime frames','snapshot_replay':'30HW x3 cases exact; legacy nested grass_priority fields deserialize false','before':'53 wrong pixels in lower8 rows on all21 frames','repeats':results},indent=2)+'\n')
s=(b/'npc-137-full-core-app-tests.log').read_text();rows=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',s);assert len(rows)==80 and all(x[0]=='ok' and x[2]=='0' for x in rows)
(d/'regression-verification.json').write_text(json.dumps({'command':'cargo test -p pokered-core -p pokered-app --features pokered-app/debug-server --offline -j4','groups':80,'passed':sum(int(x[1]) for x in rows),'failed':0,'ignored':sum(int(x[3]) for x in rows),'log_sha256':sha(b/'npc-137-full-core-app-tests.log')},indent=2)+'\n')
files=['crates/pokered-core/src/overworld/presentation.rs','crates/pokered-core/src/overworld/update.rs','crates/pokered-core/src/overworld/screen.rs','crates/pokered-app/src/render/overworld.rs','crates/pokered-app/src/render/session.rs','crates/pokered-app/src/game.rs','crates/pokered-app/tests/fixtures/npc-grass-137.json']
info={'original':'fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c','master':'31b1eda3112514d6bc803af559ec7f7c9e20374f','isolated_before':'2e03e6b production plus ignored fixture helper','setup':'Source actual City->Route1 walk, Repel200 and leadLv50 only prevent wild battles; native unit fixture warp12,22. No BG/map/ROM edits. Actor0 at14,22 Down idle127 or actor1 origin15,22 target16,22 Right remaining12 phase1 intra0. Prime4. Idle or playerDown0..15. Same setup/input/HW for actual master before and branch after; the full PR changes field cadence and resulting master prime counter.','future_wait':'Native preloads source chosen16/127; unused before completion; no general PRNG alignment claim.','source_rule':'CheckSpriteAvailability retains top-right footprint tile inA/C. Xfloor8/Yfloor16 before NPC advance; frozen while old player counter nonzero; priority included in two-HW OAM queue.','superseded':'x16,22 GP0 was ordinary ground, excluded. Initial bottom-left/whole-cell sampling superseded after original walking oracle. Native phase0 counter fixture was one HW early, replaced with source-derived phase1; no post-capture frame offset. Master helper first build ran root without helper, corrected actual WT builda2 before capture.','hashes':{f:sha(w/f) for f in files}}
(d/'provenance.json').write_text(json.dumps(info,indent=2)+'\n')
with zipfile.ZipFile(d/'recordings.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in folders+[b/'npc-136-route1-setup']:
  for p in folder.iterdir():
   if p.is_file():z.write(p,'recordings/'+folder.name+'/'+p.name)
 for f in ['prepare_npc_grass_route1_136.py','record_npc_grass_136.py','record_npc_grass_walk_137.py','record_npc_grass_player_walk_137.py','record_npc_grass_native_137.py','record_retail_stats.py','seal_npc_grass_137.py']:z.write(b/'stats-59-tools'/f,'scripts/'+f)
 for f in ['npc-136-route1-setup.log','npc-136-route1-setup-a2.log','npc-136-route1-setup-a3.log','npc-136-route1-setup-a4.log','npc-136-route1-setup-a5.log','npc-136-route1-setup-a6.log','npc-136-grass-source.log','npc-136-grass-source-a2.log','npc-137-grass-after-build.log','npc-137-grass-oracle.log','npc-137-full-core-app-tests.log','npc-137-gba-build.log']:z.write(b/f,'logs/'+f)
 for f in files:z.write(w/f,'tested-source/'+f)
 z.write(r/'.task-tmp/fidelity-93-master-before/crates/pokered-app/src/game.rs','capture-helper/master-game.rs')
print('sealed archive bytes', (d/'recordings.zip').stat().st_size)
