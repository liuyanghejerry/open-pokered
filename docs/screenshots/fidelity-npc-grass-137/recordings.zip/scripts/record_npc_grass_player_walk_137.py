exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
base=root/'.task-tmp/fidelity-39-plus'
for trial in [1,2]:
 out=base/f'npc-137-grass-player-walk-source-{trial}';out.mkdir(exist_ok=True)
 p=PyBoy(str(base/'movement-91-road-setup/road.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0)
 p.load_state(io.BytesIO((base/'npc-136-route1-setup/route1.state').read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]])
 assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(12,12,22)
 values={'wSprite02StateData1MovementStatus':3,'wSprite02StateData1ImageIndex':45,'wSprite02StateData1YStepVector':0,'wSprite02StateData1YPixels':60,'wSprite02StateData1XStepVector':1,'wSprite02StateData1XPixels':116,'wSprite02StateData1IntraAnimFrameCounter':0,'wSprite02StateData1AnimFrameCounter':1,'wSprite02StateData1FacingDirection':12,'wSprite02StateData2WalkAnimationCounter':12,'wSprite02StateData2MovementDelay':0,'wSprite02StateData2MapY':26,'wSprite02StateData2MapX':20,'wSprite02StateData2GrassPriority':0}
 for n,v in values.items():p.memory[symbols[n][1]]=v
 p.tick(4)
 fields=list(values)+['wCurMap','wXCoord','wYCoord','wWalkCounter','wFontLoaded','wGrassTile','wSprite02StateData1PictureID','wPlayerLastStopDirection','wPlayerMovingDirection','wCheckFor180DegreeTurn']
 rows=[]
 for t in range(-1,30):
  if t==0:p.button_press('down')
  if t==16:p.button_release('down')
  if t>=0:p.tick(1)
  p.screen.image.save(out/f'frame-{t+1:04}.png');rows.append({'t':t,**{n:get(n) for n in fields}})
 assert rows[0]['wSprite02StateData2GrassPriority']==128,rows[0]
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'provenance.json').write_text(json.dumps({'original':'fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c','input':'player Down0..15 then release,30HW after4prime','setup':'real route transition/walk to12,22, Repel control as setup.json. Controlled NPC1 origin15,22 target16,22 Right remaining12 phase1 intra0; rawX116. Future wait chosen by original at completion; no aligned RNG claim.. Actual BG unchanged.','controlled_writes':values},indent=2)+'\n');p.stop(save=False);print(trial,rows[0],flush=True)
