exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
base=root/'.task-tmp/fidelity-39-plus'
for trial in [1,2]:
 out=base/f'npc-136-grass-source-{trial}';out.mkdir(exist_ok=True)
 p=PyBoy(str(base/'movement-91-road-setup/road.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0)
 p.load_state(io.BytesIO((base/'npc-136-route1-setup/route1.state').read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]])
 assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(12,12,22)
 values={'wSprite01StateData1MovementStatus':2,'wSprite01StateData1ImageIndex':32,'wSprite01StateData1YStepVector':0,'wSprite01StateData1YPixels':60,'wSprite01StateData1XStepVector':0,'wSprite01StateData1XPixels':96,'wSprite01StateData1IntraAnimFrameCounter':0,'wSprite01StateData1AnimFrameCounter':0,'wSprite01StateData1FacingDirection':0,'wSprite01StateData2WalkAnimationCounter':0,'wSprite01StateData2MovementDelay':127,'wSprite01StateData2MapY':26,'wSprite01StateData2MapX':18,'wSprite01StateData2GrassPriority':0}
 for n,v in values.items():p.memory[symbols[n][1]]=v
 p.tick(4)
 fields=list(values)+['wCurMap','wXCoord','wYCoord','wWalkCounter','wFontLoaded','wGrassTile','wSprite01StateData1PictureID']
 rows=[]
 for t in range(-1,20):
  if t>=0:p.tick(1)
  p.screen.image.save(out/f'frame-{t+1:04}.png');rows.append({'t':t,**{n:get(n) for n in fields}})
 assert rows[0]['wSprite01StateData2GrassPriority']==128,rows[0]
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'provenance.json').write_text(json.dumps({'original':'fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c','input':'20 idle HW after4prime','setup':'real route transition/walk to12,22, Repel control as setup.json. Controlled NPC0 relocated to14,22, standingDown delay127. Actual BG unchanged.','controlled_writes':values},indent=2)+'\n');p.stop(save=False);print(trial,rows[0],flush=True)
