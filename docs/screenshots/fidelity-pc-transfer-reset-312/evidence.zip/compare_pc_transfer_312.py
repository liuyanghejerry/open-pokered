from pathlib import Path
import json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');results=[]
def stock(raw):
 out=[]
 for i in range(0,len(raw),2):
  if raw[i]==255:break
  out.append([{20:'Potion',11:'Antidote',4:'PokeBall',53:'Revive',29:'EscapeRope'}[raw[i]],raw[i+1]])
 return out
for mode,moves in [('withdraw',0),('deposit',1)]:
 for c in json.loads((r/'audit-311-case-schedules.json').read_text()):
  d=r/f'audit-311-original-{mode}-list-select-{c}-three-items-a1-1';fs=json.loads((d/'frames.json').read_text());assert(d/'frames.json').read_bytes()==(r/f'audit-311-original-{mode}-list-select-{c}-three-items-a1-2/frames.json').read_bytes();anchor=fs[-1]['cues']['PlayerPCMenu']+70+24*moves;src={f['t']-anchor:f for f in fs if f['t']>=anchor};a=r/f'audit-312-transfer-after-a1/{mode}-{c}';b=r/f'audit-312-transfer-after-a2/{mode}-{c}';after=json.loads((a/'frames.json').read_text());before=json.loads((r/f'audit-311-depletion-master-a1/{mode}-{c}/frames.json').read_text());assert (a/'frames.json').read_bytes()==(b/'frames.json').read_bytes();commit=310 if 'scrolled' in c else 190 if c=='full_first' else 250
  mismatches=[f['t'] for f in after if f['t']>=commit and (f['cursor'],f['scroll'])!=(src[f['t']]['cursor']+src[f['t']]['list_scroll'],src[f['t']]['list_scroll'])];inventory=[f['t'] for f in after if f['bag']!=stock(src[f['t']]['bag_items']) or f['pc']!=stock(src[f['t']]['pc_items'])];bad=[f['t'] for f in before if f['t']>=commit and (f['cursor'],f['scroll'])!=(src[f['t']]['cursor']+src[f['t']]['list_scroll'],src[f['t']]['list_scroll'])];assert not mismatches and not inventory,(mode,c,mismatches[:8],inventory[:8]);assert all(f['cached_equals_full'] and not f['ordinary_save_exists'] for f in after)
  if c.startswith('partial') or c=='full_first':assert before==after
  else:assert bad
  assert after[-1]['phase']=='ItemList'
  results.append({'mode':mode,'case':c,'frames':1101,'inventory_source_equal_every_frame':True,'cursor_scroll_source_equal_from_commit_through_list_return':True,'commit_frame':commit,'before_cursor_mismatches':len(bad),'cache_full_equal_every_frame':True,'SAVE_absent':True,'source_and_native_repeats_equal':True,'unchanged_control':before==after})
assert len(results)==10;(r/'audit-312-source-native-transfer-summary.json').write_text(json.dumps(results,indent=2)+'\n');print('PASS10 original/native repeated transfer cases; inventories every frame; window from commit through returned list')
controls=[]
for name,prior in [('select15','audit-309-select15'),('select-held4','audit-309-select-held4'),('watched12','audit-309-fidelity-pc-watched-input-host')]:
 for d in sorted((r/f'audit-312-{name}-a1').iterdir()):
  if not d.is_dir():continue
  assert(d/'frames.json').read_bytes()==(r/f'audit-312-{name}-a2'/d.name/'frames.json').read_bytes()
  assert(d/'frames.json').read_bytes()==(r/f'{prior}-a1'/d.name/'frames.json').read_bytes()
  controls.append({'control':name,'case':d.name,'entire_frame_record_equals_prior_source_verified':True,'repeat_bytes_equal':True})
for c in ['qty_second','marked_qty_second','scrolled_qty']:
 p=r/f'audit-312-followup8-a1/withdraw-{c}/frames.json';assert p.read_bytes()==(r/f'audit-312-followup8-a2/withdraw-{c}/frames.json').read_bytes();assert p.read_bytes()==(r/f'audit-309-followup8-a1/withdraw-{c}/frames.json').read_bytes();controls.append({'control':'quantity_cancel','case':c,'entire_frame_record_equals_prior_source_verified':True,'repeat_bytes_equal':True})
for c in json.loads((r/'audit-311-case-schedules.json').read_text()):
 p=r/f'audit-312-transfer-after-a1/toss-{c}/frames.json';assert p.read_bytes()==(r/f'audit-311-depletion-master-a1/toss-{c}/frames.json').read_bytes();assert p.read_bytes()==(r/f'audit-312-transfer-after-a2/toss-{c}/frames.json').read_bytes();controls.append({'control':'Toss_unchanged_NOT_source_equal','case':c,'entire_frame_record_equals_actual_master':True,'repeat_bytes_equal':True})
assert len(controls)==39;(r/'audit-312-unchanged-controls-summary.json').write_text(json.dumps(controls,indent=2)+'\n');print('PASS34 source-verified unchanged controls +5 Toss unchanged (known mismatch retained)')
