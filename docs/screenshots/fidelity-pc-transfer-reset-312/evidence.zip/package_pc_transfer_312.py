from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-312-pc-transfer-reset-checkout';docs=wt/'docs/screenshots/fidelity-pc-transfer-reset-312';items={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p):
 assert p.suffix in ['.json','.png','.py','.rs','.log'];items[str(p.relative_to(r))]=p
for mode in ['withdraw','deposit']:
 for c in json.loads((r/'audit-311-case-schedules.json').read_text()):
  for trial in [1,2]:
   for prefix in [f'audit-311-original-{mode}-list-select-{c}-three-items-a1-{trial}',f'audit-311-depletion-master-a{trial}/{mode}-{c}',f'audit-314-transfer-after-a{trial}/{mode}-{c}']:
    for p in (r/prefix).iterdir():
     if p.suffix in ['.json','.png']:add(p)
for name in ['select15','select-held4','watched12']:
 for trial in [1,2]:
  for p in (r/f'audit-314-{name}-a{trial}').rglob('*'):
   if p.is_file() and p.suffix in ['.json','.png']:add(p)
for c in ['qty_second','marked_qty_second','scrolled_qty']:
 for trial in [1,2]:
  for p in (r/f'audit-314-followup8-a{trial}/withdraw-{c}').iterdir():
   if p.suffix in ['.json','.png']:add(p)
for p in (r/'audit-314-ui-save-a1').rglob('*'):
 if p.name in ['save-verification.json','reload-verification.json']:add(p)
for name in ['audit-311-case-schedules.json','audit-312-source-native-transfer-summary.json','audit-312-unchanged-controls-summary.json','audit-314-ui-save-continue-summary.json','audit-312-watched-full-regression-summary.json','audit-312-watched-all-unit-and-integration-results-a2.json','audit-314-watched-cli-regression-results.json','audit-312-core-default-tests-a1.log','audit-312-generated-asset-setup.json','capture_pc_depletion_311.rs','capture_pc_watched_input_309.rs','capture_pc_select_save_host_300.rs','capture_pc_select_held_host_303.rs','capture_pc_item_followup_306.rs','compare_pc_transfer_312.py','compare_pc_transfer_fixed_313.py','compare_pc_transfer_assets_314.py','freeze_run_pc_transfer_hosts_assets_314.py','freeze_run_pc_transfer_all_tests_retry_312.py','freeze_run_pc_transfer_cli_retry_314.py','audit-312-validation-retries.json','package_pc_transfer_312.py','freeze_run_pc_transfer_hosts_312.py','freeze_run_pc_transfer_hosts_fixed_313.py','freeze_run_pc_transfer_all_tests_312.py','freeze_run_pc_transfer_cli_312.py']:
 add(r/name)
for name in ['probe_pc_depletion_311.py','probe_pc_watched_input_309.py']:add(r/'stats-59-tools'/name)
manifest={'base':'575aec0a7552ebe01f5e782b869ccce8bdca7bed','tested_code':'e726ec34a28e310357c0d2a9f9a48561f63af01a','source':{'crates/pokered-core/src/pc_screen.rs':sha((wt/'crates/pokered-core/src/pc_screen.rs').read_bytes())},'scope':'10 deposit/withdraw cases, inventory every frame and cursor/scroll from commit through returned list; not global text timing or Toss parity','instrumentation_retry':'Initial312 extra helpers omitted fixed introspection feature; failed marked-field comparison preserved locally; 313 uses same source with fixed enabled and passes entire-record controls','files':{n:sha(p.read_bytes()) for n,p in sorted(items.items())}}
archive=docs/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(items.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,digest in manifest['files'].items():assert sha(z.read(n))==digest
record={'paths':len(items),'archive_bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'roundtrip_verified':True,'excluded':['ROM','SRAM','whole game snapshot','emulator state','executables']};(r/'audit-312-public-archive-verification.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
