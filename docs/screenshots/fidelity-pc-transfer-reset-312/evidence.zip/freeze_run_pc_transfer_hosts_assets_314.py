from pathlib import Path
import shutil,subprocess,json,hashlib,os
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-312-pc-transfer-reset-checkout';target=root/'.task-tmp/fidelity-288-before-host-native-target/debug';out=r/'audit-314-hosts-fixed-immutable';out.mkdir();assert 'Finished `dev` profile' in (r/'audit-312-transfer-host-build-a3.log').read_text();names=['fidelity-pc-transfer-reset-host','select15','select-held4','followup8','watched12'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={'base':'575aec0a7552ebe01f5e782b869ccce8bdca7bed','tested_code':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip(),'production_sha256':sha(wt/'crates/pokered-core/src/pc_screen.rs'),'helper_sha256':sha(r/'capture_pc_depletion_311.rs'),'bins':{}}
for name in names:shutil.copy2(target/name,out/name);manifest['bins'][name]=sha(out/name)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(root/'.task-tmp/fidelity-18-27'))
for trial in [1,2]:
 for name in names:
  label='transfer-after' if name=='fidelity-pc-transfer-reset-host' else name
  with (r/f'audit-314-{label}-a{trial}.log').open('w') as f:q=subprocess.run([str(out/name),str(r/f'audit-314-{label}-a{trial}')],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
  assert q.returncode==0,(name,trial,q.returncode);print('PASS',label,trial,flush=True)
with (r/'audit-314-ui-save-a1.log').open('w') as f:q=subprocess.run([str(out/'select15'),str(r/'audit-314-ui-save-a1')],cwd=wt,env=dict(env,PC_SELECT_SAVE_300='1'),stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==0
records=[]
for d in sorted((r/'audit-314-ui-save-a1').iterdir()):
 if not d.is_dir():continue
 with (r/f'audit-314-ui-continue-{d.name}.log').open('w') as f:q=subprocess.run([str(out/'select15'),'reload',str(d)],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert q.returncode==0,d.name
 assert (d/'save-verification.json').exists() and (d/'reload-verification.json').exists()
 records.append({'case':d.name,'ordinary_ui_SAVE':True,'separate_process_CONTINUE':True})
assert len(records)==15;(r/'audit-314-ui-save-continue-summary.json').write_text(json.dumps(records,indent=2)+'\n');print('PASS15 UI SAVE/independent CONTINUE',flush=True)
