from pathlib import Path
import sys,os,json,socket,subprocess,hashlib
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';kind=sys.argv[1];assert kind in ['master','native'];w=root/'.task-tmp/fidelity-243-pc-reentry-checkout';sys.path.insert(0,str(w/'scripts'));from debug_drive import DebugClient
binary=r/('audit-240-questions-cli-immutable' if kind=='master' else 'audit-245-reentry-cli-immutable')/'pokered-app';manifest=json.loads((binary.parent/'manifest.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['binary'];snapshot=r/'audit-181-native-pc-slow-four-snapshot.json';records=[]
for case in ['player','bill']:
 for repeat in [1,2]:
  out=r/f'audit-245-{kind}-{case}-fresh-entry-{repeat}';out.mkdir(exist_ok=False)
  with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
  log=(r/(out.name+'.log')).open('w');p=subprocess.Popen([str(binary),'--scripts-dir',str(w/'crates/pokered-data/maps'),'run','--headless','--debug-port',str(port),'--speed','0','--skip-intro','--no-audio','--seed','42','--save',str(out/'owned.sav'),'--snapshot',str(snapshot),'--lang','en'],cwd=w,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib'),stdout=log,stderr=subprocess.STDOUT);d=None
  try:
   d=DebugClient(port=port)
   def drive(keys):q=d.cmd(cmd='press_timeline',buttons=keys,advance=True);assert q.get('ok'),q
   def capture(name):q=d.cmd(cmd='capture_frame',path=str(out/name));assert q.get('ok'),q
   def enter(target):
    last=None
    for _ in range(500):
     if d.state().get('pc_phase')==target:return
     key='a' if last is None else None;drive([key]);last=key
    raise AssertionError((target,d.state()))
   q=d.cmd(cmd='warp',map='ViridianPokecenter',x=13,y=4);assert q.get('ok');drive([None]*120+['up']*20+[None]*20+['a']*20+[None]*20);enter('MainMenu');drive((['down',None] if case=='player' else [])+['a',None]);enter('ItemQuestion' if case=='player' else 'BillsMenu');drive([None]*80);capture('initial-default.png');stock=d.cmd(cmd='get_bag');initial_pc=d.state()['pc_phase']
   if case=='player':
    drive(['down']*2+[None]*22+['down']*2+[None]*22+['a']);drive([None]*80);assert d.state()['pc_phase']=='ItemList';drive(['b']);drive([None]*200);assert d.state()['pc_phase']=='ItemMenu';capture('inside-return.png');assert (out/'inside-return.png').read_bytes()!=(out/'initial-default.png').read_bytes();drive(['b'])
   else:
    drive((['down']*2+[None]*22)*4);capture('before-exit.png');drive(['a'])
   drive([None]*80);assert d.state()['pc_phase']=='MainMenu';drive((['down',None] if case=='player' else [])+['a',None]);enter('ItemQuestion' if case=='player' else 'BillsMenu');rows=[]
   for t in range(21):
    if t:drive([None])
    state=d.state();assert not (out/'owned.sav').exists();assert d.cmd(cmd='get_bag')==stock;capture(f'frame-{t:03}.png');rows.append({'t':t,'input':None,'state':state,'bag':stock,'owned_save_exists':False})
   assert d.state()['pc_phase']==initial_pc
   default_restored=(out/'frame-020.png').read_bytes()==(out/'initial-default.png').read_bytes();assert default_restored==(kind=='native'),(kind,case,default_restored)
   (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n')
  finally:
   if d:d.close()
   p.terminate()
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   log.close()
  if repeat==2:
   old=r/f'audit-245-{kind}-{case}-fresh-entry-1';files=sorted(q.name for q in out.iterdir() if q.suffix in ['.png','.json']);assert all((out/q).read_bytes()==(old/q).read_bytes() for q in files)
 print(kind,case,'two exact repeats; fresh default restored',kind=='native',flush=True);records.append({'case':case,'repeat_raw_exact':True,'fresh_default_png_exact':kind=='native','inventory_unchanged':True,'no_owned_save':True,'runtime_manifest':manifest})
(r/f'audit-245-{kind}-fresh-entry-results.json').write_text(json.dumps(records,indent=2)+'\n')
