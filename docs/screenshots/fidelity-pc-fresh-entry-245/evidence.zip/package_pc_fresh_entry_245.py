from pathlib import Path
import json,re,hashlib,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-243-pc-reentry-checkout';d=wt/'docs/screenshots/fidelity-pc-fresh-entry-245';d.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();files={};base='40ebaa763b440951368c8ec88b8c72bd6a463d75'
results=json.loads((r/'audit-245-reentry-all-unit-and-integration-results-a1.json').read_text());assert results['all_pass'] and results['every_binary_completed'] and len(results['results'])==78
proof=json.loads((r/'audit-245-before-source-promoted-master-equivalence.json').read_text());assert proof['current_master']==base and proof['entire_crates_tree_equal']
for side in ['master','native']:
 records=json.loads((r/f'audit-245-{side}-fresh-entry-results.json').read_text());assert len(records)==2 and all(x['repeat_raw_exact'] and x['fresh_default_png_exact']==(side=='native') for x in records)
 for case in ['player','bill']:
  for repeat in [1,2]:
   folder=r/f'audit-245-{side}-{case}-fresh-entry-{repeat}'
   for p in folder.iterdir():
    if p.is_file():assert p.suffix in ['.png','.json'];files[str(p.relative_to(r))]=p
 files[f'audit-245-{side}-fresh-entry-results.json']=r/f'audit-245-{side}-fresh-entry-results.json'
 files[f'audit-245-{side}-fresh-entry-run.log']=r/f'audit-245-{side}-fresh-entry-run.log'
for mode,prefix,tag in [('withdraw','audit-242-original','player-pc-reentry-a2'),('withdraw','audit-244-original','bill-pc-reentry-a1')]:
 for repeat in [1,2]:
  folder=r/f'{prefix}-{mode}-{tag}-{repeat}'
  for p in folder.iterdir():
   if p.suffix in ['.png','.json']:files[str(p.relative_to(r))]=p
for name in ['audit-245-before-source-promoted-master-equivalence.json','audit-245-reentry-all-tests-build-a1.log','audit-245-reentry-all-unit-and-integration-results-a1.json','audit-245-reentry-all-tests-a1-immutable/manifest.json','audit-245-reentry-cli-immutable/manifest.json','audit-245-reentry-cli-regression-results.json','audit-242-original-pc-reentry-results.json','audit-244-original-bill-reentry-results.json','record_pc_fresh_entry_245.py','freeze_run_all_tests_245.py','freeze_run_reentry_cli_245.py','package_pc_fresh_entry_245.py','stats-59-tools/probe_pc_reentry_242_a2.py','stats-59-tools/probe_bill_pc_reentry_244.py']:files[name]=r/name
for row in results['results']:files[row['log']]=r/row['log']
files['candidate-source/crates/pokered-core/src/pc_screen.rs']=wt/'crates/pokered-core/src/pc_screen.rs';ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['engine/menus/players_pc.asm','engine/pokemon/bills_pc.asm']:files['original-source/'+name]=ref/name
png={};blobs=set()
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  b=p.read_bytes()
  if p.suffix=='.png':
   h=sha(b);png[name]=h
   if h not in blobs:blobs.add(h);z.writestr('png-blobs/'+h+'.png',b)
  else:z.writestr(name,b)
 z.writestr('png-files.json',json.dumps(png,indent=2)+'\n')
with zipfile.ZipFile(d/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for case in ['player','bill']:
 for side,label in [('master','before'),('native','after')]:shutil.copy2(r/f'audit-245-{side}-{case}-fresh-entry-1/frame-020.png',d/f'{case}-{label}.png')
tot=[0,0,0]
for row in results['results']:
 m=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored',row['summary']);assert m
 for i in range(3):tot[i]+=int(m[i+1])
v={'base':base,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'tests':{'programs':78,'pass':tot[0],'fail':tot[1],'ignore':tot[2]},'cases':['player fresh entry','Bill fresh entry'],'source_and_native_two_repeats_raw_exact':True,'native_fresh_entry_png_matches_initial_default_exact':True,'inside_player_pc_list_return_preserves_selection':True,'current_box_preserved_by_core_regression':2,'PNG':len(png),'archive_roundtrip_byte_exact':True,'archive_sha256':sha((d/'evidence.zip').read_bytes()),'archive_bytes':(d/'evidence.zip').stat().st_size,'scope':'fresh PC menu defaults only; controlled snapshot fixture, not full natural playthrough or complete PC timing fidelity'}
(d/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
