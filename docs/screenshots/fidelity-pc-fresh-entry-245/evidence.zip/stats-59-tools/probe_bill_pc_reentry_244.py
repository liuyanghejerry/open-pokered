exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state'
mode=os.environ.get('FIDELITY_PC_MODE','withdraw');speed=int(os.environ.get('FIDELITY_PC_SPEED','5'));key=os.environ.get('PC_QUESTION_KEY_239','b');offset=int(os.environ.get('PC_QUESTION_OFFSET_239','2'));tag='bill-pc-reentry-a1';moves={'withdraw':0,'deposit':1,'toss':2}[mode];interference='none'
for trial in [1,2]:
 out=r/f'audit-244-original-{mode}-{tag}-{trial}';assert not out.exists();out.mkdir()
 p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]]);now=[-1];events=[];cues={n:None for n in ['PCMainMenu','BillsPCMenu','DisplayListMenuID','DisplayChooseQuantityMenu']};need=[False];ack_until=-1;last_ack=-100;held=None
 assert get('wNumBoxItems')==1
 if tag!='a1':
  p.memory[symbols['wOptions'][1]]=(get('wOptions')&0xf0)|speed
  p.memory[symbols['wNumBagItems'][1]]=1
  a=symbols['wBagItems'][1];p.memory[a]=0x14;p.memory[a+1]=4;p.memory[a+2]=0xff
  a=symbols['wBoxItems'][1];p.memory[a+1]=4
 def hook(n):
  if n in cues and cues[n] is None:cues[n]=now[0]
  if n=='WaitForTextScrollButtonPress':need[0]=True
  events.append({'t':now[0],'routine':n,'cycles':p._cycles(),'no_delay':bool(get('wStatusFlags5')&0x40),'cursor':get('wCurrentMenuItem'),'bag_items':[int(p.memory[symbols['wBagItems'][1]+i]) for i in range(3)],'pc_items':[int(p.memory[symbols['wBoxItems'][1]+i]) for i in range(3)]})
 for n in list(cues)+['BillsPC_','BillsPCWithdraw','PrintText','WaitForTextScrollButtonPress','RemoveItemFromInventory','AddItemToInventory','PrintLetterDelay','HandleMenuInput','DisplayPCMainMenu']:
  assert n in symbols,n;p.hook_register(*symbols[n],hook,n)
 rows=[]
 for t in range(2400):
  now[0]=t;key='a' if t<2 else None
  m=cues['PCMainMenu'];pc=cues['BillsPCMenu'];li=cues['DisplayListMenuID'];qty=cues['DisplayChooseQuantityMenu']
  if m is not None and pc is None:
   if False:key='down'
   if m+94<=t<m+96:key='a'
  if pc is not None and li is None:
   for n in range(moves):
    if pc+70+n*24<=t<pc+72+n*24:key='down'
   if pc+70+moves*24<=t<pc+72+moves*24:key='a'
  if li is not None and qty is None and li+70<=t<li+72:key='a'
  if need[0] and held is None and t-last_ack>=20 and qty is None:
   need[0]=False;ack_until=t+2;last_ack=t
  if t<ack_until:key='a'
  text_events=[e for e in events if e['routine']=='PrintText' and pc is not None and e['t']>=pc]
  if text_events:
   start_question=text_events[0]['t']
   if start_question+offset<=t<start_question+offset+2:key=os.environ.get('PC_QUESTION_KEY_239','b')
  entries=[e['t'] for e in events if e['routine']=='BillsPCMenu']
  if entries:
   first=entries[0];key=None
   if len(entries)==1:
    for n in range(4):
     if first+70+n*24<=t<first+72+n*24:key='down'
    if first+166<=t<first+168:key='a'
    returned=[e['t'] for e in events if e['routine']=='DisplayPCMainMenu' and e['t']>first+150]
    if returned:
     second_main=returned[0]
     if second_main+94<=t<second_main+96:key='a'
     if t<ack_until:key='a'
  if key!=held:
   if held:p.button_release(held)
   if key:p.button_press(key)
   held=key
  p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png');rows.append({'t':t,'input':key,'no_delay':bool(get('wStatusFlags5')&0x40),'cues':dict(cues),'cursor':get('wCurrentMenuItem'),'bag_items':[int(p.memory[symbols['wBagItems'][1]+i]) for i in range(3)],'pc_items':[int(p.memory[symbols['wBoxItems'][1]+i]) for i in range(3)]})
  text_events=[e for e in events if e['routine']=='PrintText' and cues['BillsPCMenu'] is not None and e['t']>=cues['BillsPCMenu']]
  entries=[e['t'] for e in events if e['routine']=='BillsPCMenu']
  if len(entries)>=2 and t>=entries[1]+50:break
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
 assert len([e for e in events if e['routine']=='BillsPCMenu'])==2
 print(trial,cues,'source event count',len(events),flush=True)
 if trial==2:
  old=r/f'audit-244-original-{mode}-{tag}-1';assert sorted(f.name for f in out.iterdir())==sorted(f.name for f in old.iterdir());assert all(f.read_bytes()==(old/f.name).read_bytes() for f in out.iterdir())
