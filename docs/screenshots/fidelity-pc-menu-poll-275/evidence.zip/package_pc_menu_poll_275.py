from pathlib import Path
import json,re,hashlib,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-274-pc-menu-poll-checkout';out=wt/'docs/screenshots/fidelity-pc-menu-poll-275';base='7bdc4f097b3df815bec055aa4a5a161729b50318';sha=lambda b:hashlib.sha256(b).hexdigest();files={}
proof=json.loads((r/'audit-275-before-promoted-master-source-equivalence.json').read_text());assert proof['master']==base and proof['entire_crates_tree_equal']
tests=json.loads((r/'audit-275-menu-poll-all-unit-and-integration-results-a2.json').read_text());assert tests['all_pass'] and tests['every_binary_completed'] and len(tests['results'])==78
cli=json.loads((r/'audit-275-menu-poll-cli-regression-results.json').read_text());assert cli['base']==base and cli['fresh_m01_m03'] and cli['separate_process_s07_save_continue']
def folder_pair(prefix,source=False):
 a=r/(prefix+'-1');b=r/(prefix+'-2');assert a.exists() and b.exists()
 for p in a.iterdir():
  assert p.suffix in ['.png','.json']
  assert p.read_bytes()==(b/p.name).read_bytes(),(p,b)
 for d in [a,b]:
  rows=json.loads((d/'frames.json').read_text())
  if source:assert all(row['bag_items']==[20,4,255] and row['pc_items']==[20,4,255] for row in rows)
  else:assert all(row['bag']==rows[0]['bag'] and not row['owned_save_exists'] for row in rows) and not (d/'owned.sav').exists()
  for p in d.iterdir():files[str(p.relative_to(r))]=p
 return json.loads((a/'frames.json').read_text()),a
cases=[]
for case in ['main','player','bill']:
 for spacing in [3,4]:
  source,_=folder_pair(f'audit-271-original-withdraw-{case}-down-taps-{spacing}-a1',True)
  assert source[-1]['cursor']==(1 if spacing==3 else 2)
  before,bd=folder_pair(f'audit-271-native-{case}-down-taps-{spacing}')
  after,ad=folder_pair(f'audit-275-native-{case}-down-taps-{spacing}')
  expected=(spacing==3)
  assert ((ad/'frame-190.png').read_bytes()==(ad/'frame-071.png').read_bytes())==expected
  assert (bd/'frame-190.png').read_bytes()!=(bd/'frame-071.png').read_bytes()
  cases.append({'menu':case,'spacing':spacing,'source_final_cursor':source[-1]['cursor'],'two_repeat_frames_and_JSON_byte_exact':True,'candidate_second_tap_ignored':expected,'native_bag_unchanged':True,'source_full_bag_and_PC_unchanged':True,'no_native_automatic_save':True})
 source,_=folder_pair(f'audit-253-original-withdraw-{case}-down-held-80-a1',True);assert source[-1]['cursor']==1
 after,ad=folder_pair(f'audit-275-native-{case}-down-held-80');assert (ad/'frame-190.png').read_bytes()==(ad/'frame-071.png').read_bytes()
for duration in [2,3]:
 source,sd=folder_pair(f'audit-275-original-withdraw-main-down-a-duration-{duration}-a2',True)
 events=json.loads((sd/'events.json').read_text());anchor=source[-1]['cues']['PCMainMenu'];assert any(e['routine']=='PrintText' and e['t']>anchor+70 for e in events)==(duration==3)
 before,_=folder_pair(f'audit-275-master-main-down-a-duration-{duration}')
 after,_=folder_pair(f'audit-275-native-main-down-a-duration-{duration}')
 assert before[71]['state']['pc_phase']=='Message'
 assert after[71]['state']['pc_phase']=='MainMenu' and after[72]['state']['pc_phase']=='MainMenu'
 assert after[73]['state']['pc_phase']==('MainMenu' if duration==2 else 'Message')
for name in ['audit-275-before-promoted-master-source-equivalence.json','audit-275-menu-poll-core-targeted-build-a2.log','audit-275-menu-poll-all-tests-build-a2.log','audit-275-menu-poll-all-unit-and-integration-results-a2.json','audit-275-menu-poll-all-tests-a2-immutable/manifest.json','audit-275-menu-poll-cli-build-a1.log','audit-275-menu-poll-cli-immutable/manifest.json','audit-275-menu-poll-cli-regression-results.json','audit-275-menu-poll-cli-regression-run.log','record_pc_close_direction_taps_275.py','record_pc_menu_crossing_a_275.py','record_pc_ordinary_held_direction_275.py','freeze_run_menu_poll_all_tests_275_a2.py','freeze_run_menu_poll_cli_275.py','package_pc_menu_poll_275.py','stats-59-tools/probe_pc_close_direction_taps_271.py','stats-59-tools/probe_pc_menu_crossing_a_275_a2.py','audit-275-source-crossing-a-a1-predicate-correction.json','audit-275-master-crossing-a-terminal-qualified.json','audit-275-original-menu-crossing-a-a2.log','audit-275-master-menu-crossing-a.log','audit-275-full-a1-failures-preserved.json']:
 p=r/name;assert p.exists(),p;files[name]=p
for x in tests['results']:files[x['log']]=r/x['log']
for name in ['crates/pokered-core/src/pc_screen.rs','crates/pokered-app/src/game.rs']:files['candidate-source/'+name]=wt/name
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['home/joypad2.asm','home/window.asm','engine/menus/players_pc.asm','engine/pokemon/bills_pc.asm']:files['original-source/'+name]=ref/name
out.mkdir(parents=True,exist_ok=False);png={};blobs=set()
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  data=p.read_bytes()
  if p.suffix=='.png':
   h=sha(data);png[name]=h
   if h not in blobs:blobs.add(h);z.writestr('png-blobs/'+h+'.png',data)
  else:z.writestr(name,data)
 z.writestr('png-files.json',json.dumps(png,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for case in ['main','player','bill']:
 for side,label in [('before','before'),('after','after')]:
  folder=f'audit-{271 if side=="before" else 275}-native-{case}-down-taps-3-1';shutil.copy2(r/folder/'frame-190.png',out/f'{case}-{label}.png')
for side,label in [('master','before'),('native','after')]:shutil.copy2(r/f'audit-275-{side}-main-down-a-duration-2-1/frame-072.png',out/f'short-a-{label}.png')
total=[0,0,0]
for x in tests['results']:
 m=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored',x['summary']);assert m
 for i in range(3):total[i]+=int(m[i+1])
v={'base':base,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'tests':{'programs':78,'pass':total[0],'fail':total[1],'ignore':total[2]},'cases':cases,'held_direction_control_80_frames':True,'short_and_crossing_A_controls':True,'PNG':len(png),'archive_roundtrip_byte_exact':True,'archive_sha256':sha((out/'evidence.zip').read_bytes()),'archive_bytes':(out/'evidence.zip').stat().st_size,'scope':'Post-navigation sampled input history in MainMenu/BillsMenu/ItemMenu only. Controlled real-host PC fixtures and source emulator input; not natural playthrough. Native PC stock asserted in core test; TCP getter absent. Initial menu guards, list repeat/SELECT sorting and other text/audio differences remain under audit.'}
(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
