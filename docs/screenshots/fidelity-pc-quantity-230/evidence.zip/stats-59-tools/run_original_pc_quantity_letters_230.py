from pathlib import Path
import subprocess,os,json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');out=[]
cases=[('withdraw',5,'none'),('deposit',5,'none'),('toss',5,'none'),('withdraw',3,'none'),('withdraw',1,'none')]+[(mode,5,key) for mode in ['withdraw','deposit','toss'] for key in ['a','b']]
for mode,speed,key in cases:
 tag=f'letters-{speed}-{key}-a1';env=dict(os.environ,FIDELITY_PC_MODE=mode,FIDELITY_PC_SPEED=str(speed),FIDELITY_PC_TAG=tag,PC_QUANTITY_INTERFERENCE_226=key)
 with (r/f'audit-230-original-{mode}-{tag}.log').open('w') as f:p=subprocess.run([str(r/'stats-59-tools/venv/bin/python'),str(r/'stats-59-tools/probe_pc_quantity_letters_230.py')],env=env,stdout=f,stderr=subprocess.STDOUT)
 print(mode,speed,key,p.returncode,flush=True);assert p.returncode==0
 rows=json.loads((r/f'audit-230-original-{mode}-{tag}-1/frames.json').read_text());events=json.loads((r/f'audit-230-original-{mode}-{tag}-1/events.json').read_text());cues=rows[-1]['cues'];select=cues['DisplayListMenuID']+70;qty=next(i for i,e in enumerate(events) if e['routine']=='DisplayChooseQuantityMenu');letters=[e['t']-select for e in events[:qty] if e['routine']=='PrintLetterDelay' and e['t']>=select];delay=cues['DisplayChooseQuantityMenu']-select
 expected=[3+i*speed for i in range(9)] if key=='none' else [3,8,11,12,17,22,27,32,37]
 print('glyphs',letters,'quantity',delay,flush=True);assert letters==expected,(mode,speed,key,letters,expected);assert delay==(3+9*speed if key=='none' else 42)
 out.append({'mode':mode,'speed':speed,'key':key,'tag':tag,'glyph_hook_frames':letters,'quantity_frame':delay,'repeat_byte_exact':True,'pngs':len(rows)*2})
(r/'audit-230-original-quantity-letter-results.json').write_text(json.dumps(out,indent=2)+'\n')
