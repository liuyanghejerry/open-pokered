from pathlib import Path
import subprocess,os,json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');out=[]
for offset in [3,8,47,48]:
 for key in ['a','b']:
  tag=f'boundary-{offset}-{key}-a1';env=dict(os.environ,FIDELITY_PC_MODE='withdraw',FIDELITY_PC_SPEED='5',FIDELITY_PC_TAG=tag,PC_QUANTITY_INTERFERENCE_226=key,PC_QUANTITY_OFFSET_231=str(offset))
  with (r/f'audit-231-original-withdraw-{tag}.log').open('w') as f:p=subprocess.run([str(r/'stats-59-tools/venv/bin/python'),str(r/'stats-59-tools/probe_pc_quantity_boundaries_231.py')],env=env,stdout=f,stderr=subprocess.STDOUT)
  print(offset,key,p.returncode,flush=True);assert p.returncode==0
  rows=json.loads((r/f'audit-231-original-withdraw-{tag}-1/frames.json').read_text());events=json.loads((r/f'audit-231-original-withdraw-{tag}-1/events.json').read_text());cues=rows[-1]['cues'];select=cues['DisplayListMenuID']+70;qty=next(i for i,e in enumerate(events) if e['routine']=='DisplayChooseQuantityMenu');letters=[e['t']-select for e in events[:qty] if e['routine']=='PrintLetterDelay' and e['t']>=select];delay=cues['DisplayChooseQuantityMenu']-select;effects=[e|{'relative_frame':e['t']-select} for e in events if e['routine'] in ['RemoveItemFromInventory','AddItemToInventory'] and e['t']>=select]
  record={'offset':offset,'key':key,'tag':tag,'letters':letters,'quantity_frame':delay,'effects':effects,'last_bag':rows[-1]['bag_items'],'last_pc':rows[-1]['pc_items'],'repeat_byte_exact':True,'pngs':len(rows)*2};out.append(record);print(record,flush=True)
(r/'audit-231-original-quantity-boundaries-results.json').write_text(json.dumps(out,indent=2)+'\n')
