from pathlib import Path
import subprocess,hashlib,json,shutil,os,re,sys
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';kind=sys.argv[1];wt=root/'.task-tmp'/({'master':'fidelity-226-master-pc-quantity-checkout','native':'fidelity-230-pc-quantity-prompt-checkout'}[kind]);out=r/f'audit-234-pc-quantity-{kind}-immutable';out.mkdir(exist_ok=False);log=(r/('audit-234-pc-quantity-master-build-a1.log' if kind=='master' else 'audit-234-quantity-all-tests-build-a1.log')).read_text();assert 'Finished `test` profile' in log
paths=re.findall(r'Executable unittests src/lib.rs \((/[^\n]+/pokered_app-[^\)]+)\)',log);assert len(paths)==1,paths
if kind=='native':
 original=r/'audit-234-quantity-all-tests-a1-immutable'/Path(paths[0]).name;results=json.loads((r/'audit-234-quantity-all-unit-and-integration-results-a1.json').read_text());assert results['every_binary_completed'] and results['all_pass'];assert original.is_file();shutil.copy2(original,out/'app')
else:shutil.copy2(paths[0],out/'app')
m={'base':'535c1cf7f8061e105ee788df41e4f664c498b72c','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'sources':{p:hashlib.sha256((wt/p).read_bytes()).hexdigest() for p in ['crates/pokered-core/src/pc_screen.rs','crates/pokered-app/src/game.rs','crates/pokered-app/src/render/pc.rs','crates/pokered-app/src/render/session.rs']},'binary':hashlib.sha256((out/'app').read_bytes()).hexdigest()};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(root/'.task-tmp/fidelity-18-27'))
if kind=='master':
 with (r/'audit-234-pc-quantity-master-negative.log').open('w') as f:p=subprocess.run([str(out/'app'),'pc_quantity_prompt_matches_nineteen_source_input_clocks','--nocapture'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==101,p.returncode;s=(r/'audit-234-pc-quantity-master-negative.log').read_text();assert 'original DONE clock' in s and 'ItemQuantityPrompt' in s,s;print('baseline valid phase failure',flush=True)
for repeat in [1,2]:
 cap=r/f'audit-234-pc-quantity-{kind}-capture-{repeat}';assert not cap.exists()
 with (r/f'audit-234-pc-quantity-{kind}-capture-{repeat}.log').open('w') as f:p=subprocess.run([str(out/'app'),'capture_pc_quantity_230','--ignored','--nocapture'],cwd=wt,env=env|{'PC_QUANTITY_CAPTURE_230':str(cap)},stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,(repeat,p.returncode);print('capture',kind,repeat,p.returncode,flush=True)
 if repeat==2:
  first=r/f'audit-234-pc-quantity-{kind}-capture-1';files=sorted(p.relative_to(cap) for p in cap.rglob('*') if p.is_file());assert files==sorted(p.relative_to(first) for p in first.rglob('*') if p.is_file());assert all((cap/p).read_bytes()==(first/p).read_bytes() for p in files)
