
#[cfg(all(test, not(target_os = "none")))]
mod pc_quantity_owner_230 {
 use super::*;
 use pokered_core::pc_screen::PcPhase;
 fn tick(g:&mut PokemonGame,input:&mut InputState,held:&mut Vec<GbButton>,keys:Vec<GbButton>){input.begin_frame();for &k in held.iter(){if !keys.contains(&k){input.release(k);}}for &k in &keys{if !held.contains(&k){input.press(k);}}*held=keys;g.update(input);}
 fn quantity_chars(_g:&PokemonGame)->Option<usize>{None}
 fn run(capture: Option<&std::path::Path>) {
  use pokered_data::items::ItemId;
  let mut cases=Vec::new();
  for (mode,cursor,speed,delay,ready) in [("withdraw",0,pokered_core::game_state::TextSpeed::Slow,5,48),("deposit",1,pokered_core::game_state::TextSpeed::Slow,5,48),("toss",2,pokered_core::game_state::TextSpeed::Slow,5,48),("withdraw-medium",0,pokered_core::game_state::TextSpeed::Medium,3,30),("withdraw-fast",0,pokered_core::game_state::TextSpeed::Fast,1,12)] {cases.push((mode.to_string(),cursor,speed,None,ready,(0..9).map(|i|3+i*delay).collect::<Vec<usize>>()));}
  for (mode,cursor) in [("withdraw",0),("deposit",1),("toss",2)] {for key in [GbButton::A,GbButton::B] {cases.push((format!("{mode}-early-{key:?}"),cursor,pokered_core::game_state::TextSpeed::Slow,Some((10,key)),42,vec![3,8,11,12,17,22,27,32,37]));}}
  for offset in [3,8,47,48] {for key in [GbButton::A,GbButton::B] {let (ready,glyphs)=match offset {3=>(40,vec![3,4,5,10,15,20,25,30,35]),8=>(40,vec![3,8,9,10,15,20,25,30,35]),47=>(48,vec![3,8,13,18,23,28,33,38,43]),48=>(49,vec![3,8,13,18,23,28,33,38,43]),_=>unreachable!()};cases.push((format!("withdraw-boundary-{offset}-{key:?}"),0,pokered_core::game_state::TextSpeed::Slow,Some((offset,key)),ready,glyphs));}}
  assert_eq!(cases.len(),19);
  for (context,cursor,speed,extra,ready,glyphs) in cases {
   let private_dir=std::env::temp_dir().join(format!("pc-quantity-230-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
   std::fs::create_dir(&private_dir).unwrap();let save_path=private_dir.join("owned.sav");assert!(!save_path.exists());
   #[cfg(feature="debug-server")]let mut g=PokemonGame::new_with_options(GameVersion::Red,Some(save_path.clone()),None,None,false,None,false,true,None);
   #[cfg(not(feature="debug-server"))]let mut g=PokemonGame::new_with_options(GameVersion::Red,Some(save_path.clone()),None,None,false,None,false,true);
   g.audio=None;g.set_seed(42);g.state.config.language=pokered_core::game_state::Lang::En;g.state.config.text_speed=speed;
   g.save_data.game_data.bag=pokered_core::items::inventory::Inventory::new_bag();
   g.save_data.game_data.pc_items=pokered_core::items::inventory::Inventory::new_pc();
   g.save_data.game_data.bag.add_item(ItemId::Potion,4).unwrap();g.save_data.game_data.pc_items.add_item(ItemId::Potion,4).unwrap();
   assert_eq!(g.save_data.game_data.bag.item_quantity(ItemId::Potion),4);assert_eq!(g.save_data.game_data.pc_items.item_quantity(ItemId::Potion),4);
   g.state.screen=GameScreen::Overworld;g.overworld.warp_to_map(MapId::ViridianPokecenter,13,4);g.overworld.state.player.facing=pokered_core::overworld::Direction::Up;
   let idle=InputState::new();for _ in 0..120{g.update(&idle);}
   assert!(pokered_core::overworld::update::is_script_walkable_tile(g.overworld.map_data.as_ref().unwrap(),13,4));
   let mut input=InputState::new();let mut held=Vec::new();let mut setup=None;
   for t in 0..2000 {
    let phase=g.pc_screen.as_ref().map(|p|p.phase());if phase==Some(PcPhase::ItemList){setup=Some(t);break;}
    let keys=if t==0 {vec![GbButton::A]}else if t%8!=0 {vec![]}else {match phase {
     Some(PcPhase::Message)=>vec![GbButton::A],
     Some(PcPhase::MainMenu)=>{if g.pc_screen.as_ref().unwrap().main_menu().cursor()<1 {vec![GbButton::Down]}else{vec![GbButton::A]}},
     Some(PcPhase::ItemMenu)=>{if g.pc_screen.as_ref().unwrap().players_menu().cursor()<cursor {vec![GbButton::Down]}else{vec![GbButton::A]}},
     _=>vec![]}};
    tick(&mut g,&mut input,&mut held,keys);
   }
   assert!(setup.is_some(),"{context}: actual hidden PC and item-menu navigation");
   for _ in 0..70 {tick(&mut g,&mut input,&mut held,vec![]);}
   assert_eq!(g.pc_screen.as_ref().unwrap().phase(),PcPhase::ItemList);
   assert_eq!(g.pc_screen.as_ref().unwrap().item_list_cursor(),0);
   let mut session=crate::render::session::RenderSession::new();let mut retained=FrameBuffer::new(dotzuki_engine::render_config::RenderConfig::new(160,144),pokered_renderer::Rgba::WHITE);let mut scroll=|_:&mut [u8],_:usize,_:usize,_:i32,_:i32,_:u8|{};let mut rows=Vec::new();
   for t in 0..99 {
    let keys=if t<2 {vec![GbButton::A]}else if let Some((at,key))=extra {if t==at || t==at+1 {vec![key]}else{vec![]}}else{vec![]};
    tick(&mut g,&mut input,&mut held,keys);session.render(&mut g,&mut retained,&mut scroll);
    let mut full=FrameBuffer::new(dotzuki_engine::render_config::RenderConfig::new(160,144),pokered_renderer::Rgba::WHITE);g.draw(&mut full);assert_eq!(retained.packed(),full.packed(),"{context} cached/full {t}");assert!(!save_path.exists());
    if capture.is_none(){
     assert_eq!(g.save_data.game_data.bag.item_quantity(ItemId::Potion),4,"{context} bag stock {t}");assert_eq!(g.save_data.game_data.pc_items.item_quantity(ItemId::Potion),4,"{context} PC stock {t}");
     assert_eq!(format!("{:?}",g.pc_screen.as_ref().unwrap().phase()),if t<ready {"ItemQuantityPrompt"}else{"ItemQuantity"},"{context} original DONE clock {t}");
     assert_eq!(quantity_chars(&g),Some(glyphs.iter().filter(|&&at|at<=t).count()),"{context} original glyph clock {t}");
    }
    if let Some(root)=capture {
     let dir=root.join(&context);std::fs::create_dir_all(&dir).unwrap();full.save_png(&dir.join(format!("frame-{t:03}.png"))).unwrap();
     rows.push(serde_json::json!({"t":t,"input":input.raw_current(),"phase":format!("{:?}",g.pc_screen.as_ref().unwrap().phase()),"chars":quantity_chars(&g),"pc":format!("{:?}",g.pc_screen.as_ref().unwrap()),"bag_potions":g.save_data.game_data.bag.item_quantity(ItemId::Potion),"pc_potions":g.save_data.game_data.pc_items.item_quantity(ItemId::Potion),"owned_save_exists":save_path.exists(),"overworld":pokered_core::snapshot::OverworldSnapshot::capture(&g.overworld)}));
    }
   }
   if capture.is_none() {
    for _ in 0..2 {tick(&mut g,&mut input,&mut held,vec![GbButton::A]);}
    let expected=match cursor {0=>(5,3),1=>(3,5),2=>(4,4),_=>unreachable!()};
    assert_eq!(g.save_data.game_data.bag.item_quantity(ItemId::Potion),expected.0);assert_eq!(g.save_data.game_data.pc_items.item_quantity(ItemId::Potion),expected.1);
    if cursor==2 {assert_eq!(g.pc_screen.as_ref().unwrap().phase(),PcPhase::TossConfirm);}
    assert!(!save_path.exists());
   }
   if let Some(root)=capture{std::fs::write(root.join(&context).join("frames.json"),serde_json::to_vec_pretty(&rows).unwrap()).unwrap();}
   std::fs::remove_dir_all(private_dir).unwrap();
  }
 }
 #[test]fn pc_quantity_prompt_matches_nineteen_source_input_clocks(){std::thread::Builder::new().stack_size(16*1024*1024).spawn(||run(None)).unwrap().join().unwrap();}
 #[test]#[ignore="actual PC quantity nineteen source inputs before/after capture"]fn capture_pc_quantity_230(){let path=std::path::PathBuf::from(std::env::var("PC_QUANTITY_CAPTURE_230").unwrap());std::thread::Builder::new().stack_size(16*1024*1024).spawn(move||run(Some(&path))).unwrap().join().unwrap();}
}
