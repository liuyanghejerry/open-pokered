from pathlib import Path
import hashlib,json,zipfile,shutil,re,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-230-pc-quantity-prompt-checkout';d=wt/'docs/screenshots/fidelity-pc-quantity-230';d.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();files={}
results=json.loads((r/'audit-234-quantity-all-unit-and-integration-results-a1.json').read_text());assert results['all_pass'] and results['every_binary_completed'];assert len(results['results'])==78
for side in ['master','native']:
 manifest=json.loads((r/f'audit-234-pc-quantity-{side}-immutable/manifest.json').read_text());assert manifest['base']=='535c1cf7f8061e105ee788df41e4f664c498b72c'
 if side=='native':
  for p,h in manifest['sources'].items():assert sha((wt/p).read_bytes())==h,p
 for repeat in [1,2]:
  cap=r/f'audit-234-pc-quantity-{side}-capture-{repeat}';assert len(list(cap.iterdir()))==19
  for p in cap.rglob('*'):
   if p.is_file():assert p.suffix in ['.json','.png'];files[str(p.relative_to(r))]=p
  files[cap.name+'.log']=r/(cap.name+'.log')
 for name in [f'audit-234-pc-quantity-{side}-immutable/manifest.json',f'audit-234-pc-quantity-{side}-freeze-record.log']:files[name]=r/name
for filename,prefix in [('audit-230-original-quantity-letter-results.json','audit-230-original'),('audit-231-original-quantity-boundaries-results.json','audit-231-original')]:
 for case in json.loads((r/filename).read_text()):
  mode=case.get('mode','withdraw');tag=case['tag']
  for repeat in [1,2]:
   folder=r/f'{prefix}-{mode}-{tag}-{repeat}'
   for p in folder.iterdir():
    if p.is_file() and p.suffix in ['.json','.png']:files[str(p.relative_to(r))]=p
  log=r/f'{prefix}-{mode}-{tag}.log';files[log.name]=log
for name in ['audit-230-original-quantity-letter-results.json','audit-230-original-quantity-letter-independent-verification.json','audit-231-original-quantity-boundaries-results.json','audit-231-original-boundary-independent-verification.json','audit-234-pc-quantity-master-negative.log','audit-234-pc-quantity-master-build-a1.log','audit-234-quantity-all-tests-build-a1.log','audit-234-quantity-all-unit-and-integration-results-a1.json','audit-230-pc-quantity-owner-helper.rs','audit-230-pc-quantity-before-owner-helper.rs','freeze_run_all_tests_234.py','freeze_record_pc_quantity_234.py','package_pc_quantity_234.py','stats-59-tools/probe_pc_quantity_letters_230.py','stats-59-tools/probe_pc_quantity_boundaries_231.py','stats-59-tools/run_original_pc_quantity_letters_230.py','stats-59-tools/run_original_pc_quantity_boundaries_231.py']:files[name]=r/name
for row in results['results']:files[row['log']]=r/row['log']
for name in ['crates/pokered-core/src/pc_screen.rs','crates/pokered-app/src/game.rs','crates/pokered-app/src/render/pc.rs','crates/pokered-app/src/render/session.rs']:files['candidate-source/'+name]=wt/name
files['master-game-with-test-only-helper.rs']=root/'.task-tmp/fidelity-226-master-pc-quantity-checkout/crates/pokered-app/src/game.rs'
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['engine/menus/players_pc.asm','home/print_text.asm','home/list_menu.asm']:files['original-source/'+name]=ref/name
png={};blobs={}
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  b=p.read_bytes()
  if p.suffix=='.png':
   h=sha(b);png[name]=h
   if h not in blobs:blobs[h]=b;z.writestr('png-blobs/'+h+'.png',b)
  else:z.writestr(name,b)
 z.writestr('png-files.json',json.dumps(png,indent=2)+'\n')
assert len(png)==35690,len(png)
with zipfile.ZipFile(d/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for name,case,t in [('withdraw','withdraw',20),('deposit','deposit',20),('toss','toss',20),('early-a','withdraw-early-A',20),('done-boundary','withdraw-boundary-48-A',48)]:
 for side,label in [('master','before'),('native','after')]:shutil.copy2(r/f'audit-234-pc-quantity-{side}-capture-1/{case}/frame-{t:03}.png',d/f'{name}-{label}.png')
tot=[0,0,0]
for row in results['results']:
 m=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored',row['summary']);assert m
 for i in range(3):tot[i]+=int(m[i+1])
v={'base':'535c1cf7f8061e105ee788df41e4f664c498b72c','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'tests':{'programs':78,'pass':tot[0],'fail':tot[1],'ignore':tot[2]},'source_cases':19,'original_png':28166,'current_native_png':7524,'PNG':len(png),'repeat_raw_png_byte_exact':True,'every_native_cached_full_frame_pixel_equal':True,'all_archive_files_roundtrip_byte_exact':True,'archive_sha256':sha((d/'evidence.zip').read_bytes()),'archive_bytes':(d/'evidence.zip').stat().st_size}
(d/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
