from pathlib import Path
import sys,os,json,socket,subprocess
root=Path('/home/jerry/develop/open-pokered');w=root/'.task-tmp/fidelity-91-plus-checkout';r=root/'.task-tmp/fidelity-39-plus';sys.path.insert(0,str(w/'scripts'));from debug_drive import DebugClient
tag=os.environ.get('FIDELITY_PC_TAG','before-a1');binary=Path(os.environ.get('FIDELITY_PC_BIN',str(r/'audit-179-debug-cli-immutable/pokered-app-real')));snapshot=Path(os.environ.get('FIDELITY_PC_SNAPSHOT',str(r/'audit-176-native-pc-snapshot.json')));expected=int(os.environ.get('FIDELITY_PC_EXPECTED_QUANTITY_FRAME','0'))
original=json.loads((r/'audit-181-original-withdraw-a1-1/frames.json').read_text());cues=original[-1]['cues'];select=cues['DisplayListMenuID']+70;controls=[v['input'] for v in original[select:]]
for trial in [1,2]:
 out=r/f'audit-181-native-withdraw-{tag}-{trial}';assert not out.exists();out.mkdir()
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib');log=(r/f'audit-181-native-withdraw-{tag}-{trial}.log').open('w');p=subprocess.Popen([str(binary),'--scripts-dir',os.environ.get('FIDELITY_PC_MAPS',str(r/'audit-179-fresh-context/crates/pokered-data/maps')),'run','--headless','--debug-port',str(port),'--speed','0','--skip-intro','--no-audio','--seed','42','--save',str(out/'isolated.sav'),'--snapshot',str(snapshot),'--lang','en'],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT);d=None
 try:
  d=DebugClient(port=port)
  def drive(keys):
   v=d.cmd(cmd='press_timeline',buttons=keys,advance=True);assert v.get('ok'),v
  v=d.cmd(cmd='warp',map='ViridianPokecenter',x=13,y=4);assert v.get('ok'),v
  drive([None]*120+['up']*20+[None]*20+['a']*20+[None]*20)
  def reach(target):
   for _ in range(500):
    if d.state().get('pc_phase')==target:return
    drive(['a',None])
   raise AssertionError((target,d.state()))
  reach('MainMenu');drive(['down',None,'a',None]);reach('ItemMenu');v=d.cmd(cmd='capture_frame',path=str(out/'item-menu-ready.png'));assert v.get('ok'),v
  drive(['a',None]);reach('ItemList');drive([None]*70);v=d.cmd(cmd='capture_frame',path=str(out/'item-list-ready.png'));assert v.get('ok'),v
  (out/'preselect-state.json').write_text(json.dumps(d.state(),indent=2)+'\n');rows=[]
  for t,key in enumerate(controls):
   drive([key]);v=d.state();response=d.cmd(cmd='capture_frame',path=str(out/f'frame-{t:04}.png'));assert response.get('ok'),response;rows.append({'t':t,'input':key,'state':v})
  (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');print(trial,'quantity first frame',[v['t'] for v in rows if v['state'].get('pc_phase')=='ItemQuantity'][:1],flush=True);assert [v['t'] for v in rows if v['state'].get('pc_phase')=='ItemQuantity'][0]==expected
 finally:
  if d:d.close()
  p.terminate()
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait()
  log.close()
 if trial==2:
  old=r/f'audit-181-native-withdraw-{tag}-1';files=sorted(v.name for v in out.iterdir() if v.suffix in ['.png','.json']);assert files==sorted(v.name for v in old.iterdir() if v.suffix in ['.png','.json']);assert all((out/f).read_bytes()==(old/f).read_bytes() for f in files)
