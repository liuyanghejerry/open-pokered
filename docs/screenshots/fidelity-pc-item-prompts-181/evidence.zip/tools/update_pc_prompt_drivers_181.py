from pathlib import Path
import re
w=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout');p=w/'crates/pokered-core/src/pc_screen.rs';s=p.read_text();marker='    /// Advance through every page of the current message.\n';assert s.count(marker)==1;s=s.replace(marker,'''    /// DONE questions yield to their menus automatically; supply no new input.
    fn finish_pc_done_text(s: &mut PcScreen, w: &mut World) {
        for _ in 0..3000 {
            if s.phase() != PcPhase::Message || s.msg_end != PcMessageEnd::Done { return; }
            s.update_frame(NONE, &mut w.ctx());
        }
        panic!("PC DONE question did not yield to its menu");
    }

'''+marker)
for name in ['deposit_item_with_quantity','deposit_key_item_skips_quantity_prompt','deposit_into_full_pc_storage_fails_without_moving','withdraw_item_with_quantity','withdraw_into_full_bag_fails','toss_item_flow_and_key_item_refusal','pc_text_mode_writes_follow_sub_pc_and_list_boundaries']:
 a=s.index('    fn '+name+'(');b=s.index('\n    #[test]',a) if '\n    #[test]' in s[a:] else len(s);part=s[a:b];pattern=r'(s\.update_frame\([AB],\s*&mut w\.ctx\(\)\);)';part,n=re.subn(pattern,r'\1 finish_pc_done_text(&mut s, &mut w);',part);assert n>0,name;s=s[:a]+part+s[b:]
p.write_text(s)
p=w/'crates/pokered-app/src/render/pc.rs';s=p.read_text();marker='''            update_pc(&mut item_list, &mut item_save, A);
            assert_eq!(item_list.phase(), PcPhase::ItemList);''';assert s.count(marker)==1;s=s.replace(marker,'''            update_pc(&mut item_list, &mut item_save, A);
            skip_message(&mut item_list, &mut item_save);
            assert_eq!(item_list.phase(), PcPhase::ItemList);''');marker='            update_pc(&mut toss, &mut toss_save, A);';assert s.count(marker)==3;s=s.replace(marker,marker+'\n            skip_message(&mut toss, &mut toss_save);');a=s.index('    fn capture_pc_padding_audit(');b=s.index('\n    #[test]',a) if '\n    #[test]' in s[a:] else len(s);part=s[a:b];old='            update_pc(&mut pc,&mut save,A);';# only quantity actions, not earlier Bill CHANGE BOX action
q=part.index('            save.game_data.pc_items.add_item');prefix=part[:q];tail=part[q:];assert tail.count(old)==2;part=prefix+tail.replace(old,old+'\n            skip_message(&mut pc,&mut save);');s=s[:a]+part+s[b:];p.write_text(s)
