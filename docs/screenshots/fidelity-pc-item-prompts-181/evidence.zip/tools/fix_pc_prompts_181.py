from pathlib import Path
w=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-91-plus-checkout');p=w/'crates/pokered-core/src/pc_screen.rs';s=p.read_text()
def replace(old,new,count=1):
 global s
 assert s.count(old)==count,(old[:100],s.count(old));s=s.replace(old,new)
replace('    ItemMenu,\n    /// Re-enter', '    ItemMenu,\n    ItemMenuReady,\n    ItemListFromMenuReady,\n    ItemListReady,\n    ItemQuantity,\n    /// Re-enter')
replace('            AfterMessage::TossConfirm => Some(PcPhase::ItemList),','''            AfterMessage::TossConfirm | AfterMessage::ItemQuantity | AfterMessage::ItemListReady => Some(PcPhase::ItemList),
            AfterMessage::ItemMenuReady | AfterMessage::ItemListFromMenuReady => Some(PcPhase::ItemMenu),''')
replace('''            AfterMessage::ItemList => {
                // players_pc.asm `jp .loop` — re-show the list where the
                // cursor was; update_item_list clamps it if the list shrank.
                self.phase = PcPhase::ItemList;
            }''','''            AfterMessage::ItemList => self.print_item_list_question(false),
            AfterMessage::ItemMenuReady => self.phase = PcPhase::ItemMenu,
            AfterMessage::ItemListFromMenuReady | AfterMessage::ItemListReady => self.phase = PcPhase::ItemList,
            AfterMessage::ItemQuantity => self.phase = PcPhase::ItemQuantity,''')
replace('''    fn enter_item_menu(&mut self) {
        self.players_menu.restore_saved_cursor();
        self.phase = PcPhase::ItemMenu;
    }''','''    fn enter_item_menu(&mut self) {
        self.players_menu.restore_saved_cursor();
        if self.language == crate::game_state::Lang::Zh {
            self.phase = PcPhase::ItemMenu;
        } else {
            // PlayerPCMenu prints DONE before HandleMenuInput.
            self.set_message_with_end(vec!["What do you want".into(), "to do?".into()],
                AfterMessage::ItemMenuReady, PcMessageEnd::Done);
        }
    }''')
replace('''        self.item_list_scroll = 0;
        self.phase = PcPhase::ItemList;
    }''','''        self.item_list_scroll = 0;
        self.print_item_list_question(true);
    }

    pub fn item_list_question(&self) -> [&'static str; 2] {
        ["What do you want", match self.item_mode {
            ItemListMode::Deposit => "to deposit?",
            ItemListMode::Withdraw => "to withdraw?",
            ItemListMode::Toss => "to toss away?",
        }]
    }

    fn print_item_list_question(&mut self, from_menu: bool) {
        if self.language == crate::game_state::Lang::Zh {
            self.phase = PcPhase::ItemList;
        } else {
            // The .loop prints the question before DisplayListMenuID sets
            // NO_TEXT_DELAY. A receipt/quantity cancellation keeps its cursor.
            let next = if from_menu { AfterMessage::ItemListFromMenuReady } else { AfterMessage::ItemListReady };
            self.set_message_with_end(self.item_list_question().into_iter().map(String::from).collect(),
                next, PcMessageEnd::Done);
        }
    }

    fn enter_item_quantity(&mut self) {
        self.item_qty = 1;
        if self.language == crate::game_state::Lang::Zh {
            self.phase = PcPhase::ItemQuantity;
        } else {
            // List selection has cleared NO_TEXT_DELAY. PrintText's DONE
            // must finish before DisplayChooseQuantityMenu owns fresh input.
            self.set_message_with_end(vec!["How many?".into()], AfterMessage::ItemQuantity, PcMessageEnd::Done);
        }
    }''')
replace('''                        self.item_qty = 1;
                        let _ = have;
                        self.phase = PcPhase::ItemQuantity;''','''                        let _ = have;
                        self.enter_item_quantity();''')
replace('''                        self.item_qty = 1;
                        self.phase = PcPhase::ItemQuantity;''','''                        self.enter_item_quantity();''')
a = s.index('    fn update_item_quantity(')
b = s.index('    /// Move `qty`', a)
part = s[a:b]
old = "            self.phase = PcPhase::ItemList;\n            return PcScreenAction::Continue;"
assert part.count(old) == 2
part = part.replace(old, "            self.print_item_list_question(false);\n            return PcScreenAction::Continue;")
s = s[:a] + part + s[b:]
p.write_text(s)
p=w/'crates/pokered-app/src/render/pc.rs';s=p.read_text();marker='''                Some(PcPhase::MonList) => {''';assert s.count(marker)==1;s=s.replace(marker,'''                Some(PcPhase::ItemMenu) => {
                    let labels: Vec<String> = PLAYERS_LABELS.iter()
                        .map(|s| lang_data::ui_label(s, is_zh).to_string()).collect();
                    draw_menu(0, 0, 14, &labels, pc.players_menu().cursor(), fb);
                }
'''+marker);marker='''            draw_menu(0, 0, 14, &labels, pc.players_menu().cursor(), fb);
        }
        PcPhase::ItemList''';assert s.count(marker)==1;s=s.replace(marker,'''            draw_menu(0, 0, 14, &labels, pc.players_menu().cursor(), fb);
            if !is_zh {
                draw_message(&["What do you want".into(), "to do?".into()], fb, is_zh);
            }
        }
        PcPhase::ItemList''');marker='''                _ => {}
            }
        }
        PcPhase::OaksConfirm''';assert s.count(marker)==1;s=s.replace(marker,'''                _ => {
                    if !is_zh {
                        draw_message(&pc.item_list_question().into_iter().map(String::from).collect::<Vec<_>>(), fb, is_zh);
                    }
                }
            }
        }
        PcPhase::OaksConfirm''');p.write_text(s)
p=w/'crates/pokered-app/src/render/session.rs';s=p.read_text();marker='''                        PcPhase::MonList => {
                            hash_byte(&mut visual_hash, pc.mon_mode() as u8);''';assert s.count(marker)==1;s=s.replace(marker,'''                        PcPhase::ItemMenu => {
                            hash_u32(&mut visual_hash, pc.players_menu().cursor() as u32);
                        }
'''+marker);p.write_text(s)
