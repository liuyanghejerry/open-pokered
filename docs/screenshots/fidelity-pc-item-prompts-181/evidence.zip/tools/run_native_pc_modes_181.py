from pathlib import Path
import os,json,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');cases=json.loads((r/'audit-181-original-mode-cases.json').read_text());group=sys.argv[1];rev=os.environ.get('FIDELITY_PC_REV','a1');assert group in ['before','after'];binary=r/('audit-179-debug-cli-immutable/pokered-app-real' if group=='before' else os.environ.get('FIDELITY_PC_AFTER_BIN','audit-181-debug-cli-a3-immutable/pokered-app'))
def run(case):
 mode=case['mode'];label=case['label'];tag=f'{group}-modes-{rev}-{label}';expected=0 if group=='before' else case['delay'];env=dict(os.environ,FIDELITY_PC_MODE=mode,FIDELITY_PC_TAG=tag,FIDELITY_PC_ORIGINAL_TAG=case['tag'],FIDELITY_PC_BIN=str(binary),FIDELITY_PC_SNAPSHOT=str(r/f'audit-181-native-pc-{label}-four-snapshot.json'),FIDELITY_PC_EXPECTED_QUANTITY_FRAME=str(expected))
 log=r/f'audit-181-native-{mode}-{tag}.log'
 with log.open('w') as f:p=subprocess.run(['python3',str(r/'stats-59-tools/run_native_pc_quantity_modes_181.py')],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(group,mode,label,p.returncode,flush=True);assert p.returncode==0,log
 return case|{'native_tag':tag,'expected':expected}
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,cases))
(r/f'audit-181-native-{group}-mode-cases-{rev}.json').write_text(json.dumps(results,indent=2)+'\n')
