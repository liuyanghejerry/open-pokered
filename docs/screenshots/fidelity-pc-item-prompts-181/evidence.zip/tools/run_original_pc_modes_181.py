from pathlib import Path
import os,sys,json,subprocess
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');cases=[('withdraw',5,'slow'),('deposit',5,'slow'),('toss',5,'slow'),('withdraw',3,'medium'),('withdraw',1,'fast')];out=[]
for mode,speed,label in cases:
 tag=f'modes-a2-{label}';env=dict(os.environ,FIDELITY_PC_MODE=mode,FIDELITY_PC_SPEED=str(speed),FIDELITY_PC_TAG=tag)
 log=r/f'audit-181-original-{mode}-{tag}.log'
 with log.open('w') as f:p=subprocess.run([str(r/'stats-59-tools/venv/bin/python'),str(r/'stats-59-tools/probe_pc_quantity_modes_181.py')],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(mode,speed,p.returncode,flush=True);assert p.returncode==0,log
 rows=json.loads((r/f'audit-181-original-{mode}-{tag}-1/frames.json').read_text());cues=rows[-1]['cues'];delay=cues['DisplayChooseQuantityMenu']-cues['DisplayListMenuID']-70;assert delay==3+9*speed,(mode,speed,delay)
 out.append({'mode':mode,'speed':speed,'label':label,'tag':tag,'delay':delay,'setup':'controlled originalpretrigger; options nibble1/3/5; BAG Potion4, PC Potion4; all other state untouched; originalROM/source unchanged','cues':cues})
(r/'audit-181-original-mode-cases.json').write_text(json.dumps(out,indent=2)+'\n')
