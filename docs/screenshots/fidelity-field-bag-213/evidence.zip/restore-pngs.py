from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
for name,h in json.loads((root/'png-index.json').read_text()).items():
 data=(root/'png-by-sha256'/(h+'.png')).read_bytes();assert hashlib.sha256(data).hexdigest()==h
 target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
print('Restored all original PNG paths, byte exact.')
