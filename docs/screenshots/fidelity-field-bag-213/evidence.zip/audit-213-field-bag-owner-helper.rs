#[cfg(all(test, not(target_os = "none")))]
mod field_bag_owner_213 {
    use super::*;
    use pokered_data::items::ItemId;
    use pokered_core::overworld::TransportMode;
    trait MessageObservation213 { fn toss_dialogue(&self) -> Option<&BedroomDialogue> { None } }
    impl MessageObservation213 for BagScreenState {}

    fn run(capture: Option<&std::path::Path>) {
        for case in ["repel-a", "repel-b", "coins-a", "coins-b", "parcel-a", "parcel-b", "nugget-a", "nugget-b", "bike-indoor", "bike-surf", "bike-forced", "bike-mount", "bike-dismount", "town-map", "pokedex"] {
            let mut g = PokemonGame::new(GameVersion::Red);
            g.audio = None; g.set_seed(42);
            g.state.config.language = pokered_core::game_state::Lang::En;
            g.state.config.text_speed = pokered_core::game_state::TextSpeed::Medium;
            let bike = case.starts_with("bike-");
            let successful_bike = matches!(case, "bike-mount" | "bike-dismount");
            let viewer = matches!(case, "town-map" | "pokedex");
            g.state.screen = GameScreen::Overworld;
            g.overworld.warp_to_map(if successful_bike { MapId::Route1 } else { MapId::ViridianPokecenter }, 4, 4);
            let idle = InputState::new(); for _ in 0..120 { g.update(&idle); }
            if case == "bike-surf" { g.overworld.state.player.transport = TransportMode::Surfing; }
            if matches!(case, "bike-forced" | "bike-dismount") { g.overworld.state.player.transport = TransportMode::Biking; }
            if case == "bike-forced" {
                let mut value = serde_json::to_value(pokered_core::snapshot::OverworldSnapshot::capture(&g.overworld)).unwrap();
                value["forced_bike"]["active"] = serde_json::json!(true);
                let snapshot: pokered_core::snapshot::OverworldSnapshot = serde_json::from_value(value).unwrap();
                snapshot.restore_into(&mut g.overworld);
            }
            g.save_data.game_data.bag = pokered_core::items::inventory::Inventory::new_bag();
            let item = if case.starts_with("repel") { ItemId::Repel } else if case.starts_with("coins") { ItemId::CoinCase }
                else if case.starts_with("parcel") { ItemId::OaksParcel } else if case.starts_with("nugget") { ItemId::Nugget }
                else if bike { ItemId::Bicycle } else if case == "town-map" { ItemId::TownMap } else { ItemId::Pokedex };
            let stock = if item == ItemId::Repel { 2 } else { 1 };
            if viewer { g.save_data.game_data.bag.add_item(ItemId::Potion, 1).unwrap(); }
            g.save_data.game_data.bag.add_item(item, stock).unwrap();
            g.bag_screen = BagScreenState::new(g.save_data.game_data.bag.items().to_vec());
            g.state.screen = GameScreen::Bag;
            let mut session = crate::render::session::RenderSession::new();
            let mut retained = FrameBuffer::new(dotzuki_engine::render_config::RenderConfig::new(160,144), pokered_renderer::Rgba::WHITE);
            let mut scroll = |_: &mut [u8], _: usize, _: usize, _: i32, _: i32, _: u8| {};
            let mut input = InputState::new(); let mut held = Vec::new(); let mut rows = Vec::new();
            let acknowledgement = if case.ends_with("-b") || viewer { GbButton::B } else { GbButton::A };
            for t in 0..301 {
                input.begin_frame();
                let keys = if viewer {
                    match t { 8 => vec![GbButton::Down], 16 | 32 => vec![GbButton::A], 120 => vec![GbButton::B], _ => vec![] }
                } else {
                    match t { 0 => vec![GbButton::A], 16 if !bike => vec![GbButton::A], 120 => vec![acknowledgement],
                        240 if case.starts_with("nugget") || case == "bike-surf" => vec![acknowledgement], _ => vec![] }
                };
                for &key in &held { if !keys.contains(&key) { input.release(key); } }
                for &key in &keys { if !held.contains(&key) { input.press(key); } } held = keys;
                g.update(&input); session.render(&mut g, &mut retained, &mut scroll);
                let mut full = FrameBuffer::new(dotzuki_engine::render_config::RenderConfig::new(160,144), pokered_renderer::Rgba::WHITE); g.draw(&mut full);
                assert_eq!(retained.packed(), full.packed(), "{case} retained/full frame{t}");
                if capture.is_none() {
                    if successful_bike {
                        assert_eq!(g.state.screen, GameScreen::Overworld, "direct bike use closes the bag at{t}");
                        assert_eq!(g.overworld.state.player.transport, if case == "bike-mount" { TransportMode::Biking } else { TransportMode::Walking });
                    } else if viewer {
                        if (32..120).contains(&t) { assert_eq!(g.state.screen, if case == "town-map" { GameScreen::TownMap } else { GameScreen::Pokedex }); }
                        if t >= 120 { assert_eq!(g.state.screen, GameScreen::Bag); assert_eq!(g.bag_screen.cursor(), 1); }
                    } else {
                        assert_eq!(g.state.screen, GameScreen::Bag, "{case} should stay in ItemMenuLoop frame{t}");
                        if bike && t == 0 { assert!(format!("{:?}",g.bag_screen.phase()).starts_with("FieldMessage"), "Bicycle skips USE/TOSS"); }
                        let expected_stock = if item == ItemId::Repel && t >= 120 { 1 } else { stock };
                        assert_eq!(g.save_data.game_data.bag.item_quantity(item), u16::from(expected_stock), "{case} consumption before PROMPT acknowledgement at{t}");
                        if (case.starts_with("nugget") || case == "bike-surf") && t == 120 {
                            assert!(format!("{:?}",g.bag_screen.phase()).starts_with("FieldMessage"), "first scroll must not close a multi-page refusal");
                        }
                        if t >= 240 { assert_eq!(format!("{:?}",g.bag_screen.phase()), "Browsing"); }
                    }
                }
                if let Some(path) = capture {
                    let dir = path.join(case); std::fs::create_dir_all(&dir).unwrap(); full.save_png(&dir.join(format!("frame-{t:04}.png"))).unwrap();
                    rows.push(serde_json::json!({"t":t,"input":input.raw_current(),"screen":format!("{:?}",g.state.screen),"phase":format!("{:?}",g.bag_screen.phase()),"cursor":g.bag_screen.cursor(),"inventory":g.save_data.game_data.bag.items(),"dialogue":g.bag_screen.toss_dialogue(),"overworld":pokered_core::snapshot::OverworldSnapshot::capture(&g.overworld)}));
                }
            }
            if let Some(path) = capture { std::fs::write(path.join(case).join("frames.json"),serde_json::to_string_pretty(&rows).unwrap()).unwrap(); }
        }
    }
    #[test]
    fn field_use_owns_prompt_return_and_consumption() { std::thread::Builder::new().stack_size(16*1024*1024).spawn(||run(None)).unwrap().join().unwrap(); }
    #[test]
    #[ignore = "controlled bag field-use before/after capture"]
    fn capture_field_bag_213() { let path=std::path::PathBuf::from(std::env::var("FIELD_BAG_CAPTURE_213").unwrap());std::thread::Builder::new().stack_size(16*1024*1024).spawn(move||run(Some(&path))).unwrap().join().unwrap(); }
}
