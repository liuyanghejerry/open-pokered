from pathlib import Path
import os,json,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus'
side=os.environ.get('FIELD_BAG_SIDE_213','native'); binary=r/f'audit-213-{side}-a4-immutable/app'; wt=root/'.task-tmp'/('fidelity-213-field-bag-checkout' if side=='native' else 'fidelity-213-field-bag-before-checkout')
for trial in [1,2]:
 out=r/f'audit-213-{side}-capture-a4-{trial}';assert not out.exists();out.mkdir();env=dict(os.environ,FIELD_BAG_CAPTURE_213=str(out),LD_LIBRARY_PATH='/tmp/pokered-build-lib')
 with (r/f'{out.name}.log').open('w') as log: subprocess.run([str(binary),'capture_field_bag_213','--ignored','--nocapture'],cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
a=r/f'audit-213-{side}-capture-a4-1';b=r/f'audit-213-{side}-capture-a4-2';cases=sorted(p.name for p in a.iterdir());assert len(cases)==15
for case in cases:
 files=sorted((a/case).iterdir());assert len(files)==302
 assert all(p.read_bytes()==(b/case/p.name).read_bytes() for p in files)
 rows=json.loads((a/case/'frames.json').read_text());assert len(rows)==301
report={'side':side,'cases':cases,'frames_per_case_repeat':301,'png_count':9030,'full_raw_json_and_every_png_repeats_byte_exact':True,'each_frame_retained_full_pixels_identical':True,'scope':'Controlled coherent world/item fixtures, pure Bag entry; same input/screen/frame on each side; not natural traversal or absolute original CPU/PPU/layout equality.'}
(r/f'audit-213-{side}-capture-verification-a4.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
