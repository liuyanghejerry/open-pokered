from pathlib import Path
import subprocess,hashlib,json,shutil,os,re,sys
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';kind=sys.argv[1];wt=root/'.task-tmp'/({'master':'fidelity-226-master-pc-quantity-checkout','native':'fidelity-228-pc-item-list-checkout'}[kind]);out=r/f'audit-228-pc-item-list-{kind}-a2-immutable';out.mkdir(exist_ok=False);log=(r/f'audit-228-pc-item-list-{kind}-build-a2.log').read_text();assert 'Finished `test` profile' in log;paths=re.findall(r'Executable .*?\((/[^\n]+)\)',log);m={'base':'ab9a272202270b9370690bdfb874edc12af89c31','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'sources':{p:hashlib.sha256((wt/p).read_bytes()).hexdigest() for p in ['crates/pokered-core/src/pc_screen.rs','crates/pokered-app/src/game.rs']},'binaries':{}}
for binary in (['app'] if kind=='master' else ['core','app']):
 matches=[p for p in paths if f'pokered_{binary}-' in p];assert len(matches)==1,matches;shutil.copy2(matches[0],out/binary);m['binaries'][binary]=hashlib.sha256((out/binary).read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(root/'.task-tmp/fidelity-18-27'))
if kind=='native':
 for binary in ['core','app']:
  with (r/f'audit-228-{binary}-tests-a2.log').open('w') as f:p=subprocess.run([str(out/binary),'--test-threads=4'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
  print(binary,p.returncode,flush=True);assert p.returncode==0
else:
 with (r/'audit-228-master-owner-negative-a2.log').open('w') as f:p=subprocess.run([str(out/'app'),'pc_item_list_simultaneous_ab_selects_without_mutating_inventory','--nocapture'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==101,p.returncode;print('baseline normative negative',p.returncode,flush=True)
for repeat in [1,2]:
 cap=r/f'audit-228-pc-item-list-{kind}-capture-a2-{repeat}';assert not cap.exists()
 with (r/f'audit-228-pc-item-list-{kind}-capture-a2-{repeat}.log').open('w') as f:p=subprocess.run([str(out/'app'),'capture_pc_item_list_228','--ignored','--nocapture'],cwd=wt,env=env|{'PC_ITEM_LIST_CAPTURE_228':str(cap)},stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,(repeat,p.returncode);print('capture',kind,repeat,p.returncode,flush=True)
 if repeat==2:
  first=r/f'audit-228-pc-item-list-{kind}-capture-a2-1';files=sorted(p.relative_to(cap) for p in cap.rglob('*') if p.is_file());assert files==sorted(p.relative_to(first) for p in first.rglob('*') if p.is_file());assert all((cap/p).read_bytes()==(first/p).read_bytes() for p in files)
