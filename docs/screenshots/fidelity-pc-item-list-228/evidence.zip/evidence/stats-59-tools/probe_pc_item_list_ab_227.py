exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state'
mode=os.environ.get('FIDELITY_PC_MODE','withdraw');speed=int(os.environ.get('FIDELITY_PC_SPEED','5'));tag=os.environ.get('FIDELITY_PC_TAG','a1');moves={'withdraw':0,'deposit':1,'toss':2}[mode]
for trial in [1,2]:
 out=r/f'audit-227-original-{mode}-{tag}-{trial}';assert not out.exists();out.mkdir()
 p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]]);now=[-1];events=[];cues={n:None for n in ['PCMainMenu','PlayerPCMenu','DisplayListMenuID','DisplayChooseQuantityMenu']};need=[False];ack_until=-1;last_ack=-100;held=None
 assert get('wNumBoxItems')==1
 if tag!='a1':
  p.memory[symbols['wOptions'][1]]=(get('wOptions')&0xf0)|speed
  p.memory[symbols['wNumBagItems'][1]]=1
  a=symbols['wBagItems'][1];p.memory[a]=0x14;p.memory[a+1]=4;p.memory[a+2]=0xff
  a=symbols['wBoxItems'][1];p.memory[a+1]=4
 def hook(n):
  if n in cues and cues[n] is None:cues[n]=now[0]
  if n=='WaitForTextScrollButtonPress':need[0]=True
  events.append({'t':now[0],'routine':n,'cycles':p._cycles(),'no_delay':bool(get('wStatusFlags5')&0x40),'cursor':get('wCurrentMenuItem')})
 for n in list(cues)+['PlayerPC','PlayerPCWithdraw','PrintText','WaitForTextScrollButtonPress']:
  assert n in symbols,n;p.hook_register(*symbols[n],hook,n)
 rows=[]
 for t in range(2400):
  now[0]=t;key='a' if t<2 else None
  m=cues['PCMainMenu'];pc=cues['PlayerPCMenu'];li=cues['DisplayListMenuID'];qty=cues['DisplayChooseQuantityMenu']
  if m is not None and pc is None:
   if m+70<=t<m+72:key='down'
   if m+94<=t<m+96:key='a'
  if pc is not None and li is None:
   for n in range(moves):
    if pc+70+n*24<=t<pc+72+n*24:key='down'
   if pc+70+moves*24<=t<pc+72+moves*24:key='a'
  if li is not None and qty is None and li+70<=t<li+72:key='ab'
  if need[0] and held is None and t-last_ack>=20 and qty is None:
   need[0]=False;ack_until=t+2;last_ack=t
  if t<ack_until:key='a'
  if key!=held:
   if held:
    for button in (['a','b'] if held=='ab' else [held]):p.button_release(button)
   if key:
    for button in (['a','b'] if key=='ab' else [key]):p.button_press(button)
   held=key
  p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png');rows.append({'t':t,'input':key,'no_delay':bool(get('wStatusFlags5')&0x40),'cues':dict(cues),'cursor':get('wCurrentMenuItem')})
  if cues['DisplayChooseQuantityMenu'] is not None and t>=cues['DisplayChooseQuantityMenu']+40:break
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
 assert all(v is not None for v in cues.values()),cues
 print(trial,cues,'select_to_quantity',cues['DisplayChooseQuantityMenu']-(cues['DisplayListMenuID']+70),flush=True)
 if trial==2:
  old=r/f'audit-227-original-{mode}-{tag}-1';assert sorted(f.name for f in out.iterdir())==sorted(f.name for f in old.iterdir());assert all(f.read_bytes()==(old/f.name).read_bytes() for f in out.iterdir())
