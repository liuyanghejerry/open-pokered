from pathlib import Path
import subprocess,os,json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');out=[]
for mode in ['withdraw','deposit','toss']:
 tag='list-ab-slow-a1';env=dict(os.environ,FIDELITY_PC_MODE=mode,FIDELITY_PC_SPEED='5',FIDELITY_PC_TAG=tag)
 with (r/f'audit-227-original-{mode}-{tag}.log').open('w') as f:p=subprocess.run([str(r/'stats-59-tools/venv/bin/python'),str(r/'stats-59-tools/probe_pc_item_list_ab_227.py')],env=env,stdout=f,stderr=subprocess.STDOUT)
 print(mode,p.returncode,flush=True);assert p.returncode==0
 rows=json.loads((r/f'audit-227-original-{mode}-{tag}-1/frames.json').read_text());cue=rows[-1]['cues'];assert any(x['input']=='ab' for x in rows);out.append({'mode':mode,'cues':cue,'list_ab_enters_quantity':cue['DisplayChooseQuantityMenu'] is not None,'repeat_byte_exact':True,'pngs':len(rows)*2})
(r/'audit-227-original-pc-list-ab-results.json').write_text(json.dumps(out,indent=2)+'\n')
