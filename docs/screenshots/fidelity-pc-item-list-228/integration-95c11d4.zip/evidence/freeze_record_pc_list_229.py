from pathlib import Path
import subprocess,hashlib,json,shutil,os,re,sys
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';kind=sys.argv[1];wt=root/'.task-tmp'/({'master':'fidelity-226-master-pc-quantity-checkout','native':'fidelity-228-pc-item-list-checkout'}[kind]);out=r/f'audit-229-pc-list-{kind}-immutable';out.mkdir(exist_ok=False);log=(r/('audit-229-pc-list-master-build-a1.log' if kind=='master' else 'audit-229-list-all-tests-build-a1.log')).read_text();assert 'Finished `test` profile' in log
paths=re.findall(r'Executable unittests src/lib.rs \((/[^\n]+/pokered_app-[^\)]+)\)',log);assert len(paths)==1,paths
if kind=='native':
 original=r/'audit-229-list-all-tests-a1-immutable'/Path(paths[0]).name;results=json.loads((r/'audit-229-list-all-unit-and-integration-results-a1.json').read_text());assert results['every_binary_completed'] and results['all_pass'];assert original.is_file();shutil.copy2(original,out/'app')
else:shutil.copy2(paths[0],out/'app')
m={'base':'95c11d4a73c7499066d62e866f1e2d35b5a21822','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'sources':{p:hashlib.sha256((wt/p).read_bytes()).hexdigest() for p in ['crates/pokered-core/src/pc_screen.rs','crates/pokered-app/src/game.rs']},'binary':hashlib.sha256((out/'app').read_bytes()).hexdigest()};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(root/'.task-tmp/fidelity-18-27'))
if kind=='master':
 with (r/'audit-229-pc-list-master-negative.log').open('w') as f:p=subprocess.run([str(out/'app'),'pc_item_list_simultaneous_ab_selects_without_mutating_inventory','--nocapture'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==101,p.returncode;s=(r/'audit-229-pc-list-master-negative.log').read_text();assert 'left: ItemMenu' in s and 'right: ItemQuantity' in s,s;print('baseline valid phase failure',flush=True)
for repeat in [1,2]:
 cap=r/f'audit-229-pc-list-{kind}-capture-{repeat}';assert not cap.exists()
 with (r/f'audit-229-pc-list-{kind}-capture-{repeat}.log').open('w') as f:p=subprocess.run([str(out/'app'),'capture_pc_item_list_228','--ignored','--nocapture'],cwd=wt,env=env|{'PC_ITEM_LIST_CAPTURE_228':str(cap)},stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,(repeat,p.returncode);print('capture',kind,repeat,p.returncode,flush=True)
 if repeat==2:
  first=r/f'audit-229-pc-list-{kind}-capture-1';files=sorted(p.relative_to(cap) for p in cap.rglob('*') if p.is_file());assert files==sorted(p.relative_to(first) for p in first.rglob('*') if p.is_file());assert all((cap/p).read_bytes()==(first/p).read_bytes() for p in files)
