import pathlib,zipfile,shutil,json,hashlib,subprocess
root=pathlib.Path('/home/jerry/develop/open-pokered'); r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-197-quantity-checkout';dest=wt/'docs/screenshots/fidelity-quantity-split-197';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=wt/'docs/screenshots/fidelity-quantity-controls-185/evidence.zip'
with zipfile.ZipFile(dest/'evidence.zip','w',zipfile.ZIP_DEFLATED) as out:
 with zipfile.ZipFile(old) as z:
  for n in z.namelist():
   if n.startswith(('audit-185-original-','original-source/')):out.writestr('historical-original/'+n,z.read(n))
 for side in ['master','native']:
  for repeat in [1,2]:
   base=r/f'audit-197-{side}-capture-a2-{repeat}'
   for p in base.rglob('*'):
    if p.is_file():out.write(p,str(p.relative_to(r)))
   log=r/f'{base.name}.log';out.write(log,log.name)
 for name in ['audit-197-core-suite-a2.log','audit-197-app-suite-a2.log','audit-197-owner-pixels-a2.log','audit-197-native-build-a2.log','audit-197-master-build-a2.log']:
  p=r/name;out.write(p,name)
 for name in ['audit-197-native-a2-immutable','audit-197-master-a2-immutable']:
  out.write(r/name/'manifest.json',name+'/manifest.json')
 for p in json.loads((r/'audit-197-native-a2-immutable/manifest.json').read_text())['sources']:
  out.write(wt/p,'final-source/'+p)
 out.write(r/'package_quantity_197.py','package_quantity_197.py')
for mode,label in [(0,'withdraw'),(1,'deposit'),(2,'toss')]:
 for frame,boundary in [(1,'down'),(9,'up')]:
  for side,title in [('master','before'),('native','after')]:
   shutil.copy2(r/f'audit-197-{side}-capture-a2-1/mode-{mode}/frame-{frame:04}.png',dest/f'{label}-{boundary}-{title}.png')
verify={'base':'748c221b2ae8b2fd73824123b095f50b7b47d24f','native':json.loads((r/'audit-197-native-a2-immutable/manifest.json').read_text()),'master':json.loads((r/'audit-197-master-a2-immutable/manifest.json').read_text()),'tests':{'core':2712,'app':191,'app_ignored':15,'pixel_owner':'3 modes x 40 frames x 160x144 pixels, retained equals full after every update'},'repeat':'each side 120 PNG + 3 frames.json byte-exact across two repetitions','files':{p.name:sha(p) for p in dest.iterdir() if p.suffix in ['.png','.zip']},'scope':'Native quantity controls only. Historical original ROM recordings prove wrap and key precedence; no final GBA or fresh playthrough claim.'}
(dest/'verification.json').write_text(json.dumps(verify,indent=2)+'\n')
(dest/'README.md').write_text('''# Quantity controls: standalone split 197

This PR contains quantity controls only, based on actual master `748c221`.
Original `home/list_menu.asm::DisplayChooseQuantityMenu` wraps DOWN from 1
back to the stack maximum and UP from maximum back to 1, checking A, B,
UP, DOWN in that order. PC withdraw/deposit/toss and bag toss now wrap.
PC, bag and mart quantity adapters prioritize A over cancellation/directions.
Mart already wrapped; its remaining flow is unchanged.

## Current standalone evidence

Actual master and final repair use the identical controlled Game/RenderSession
capture helper: four Potions in bag and PC, English, audio disabled, real PC
message/menu/list input followed by quantity input DOWN at frame1, UP at9,
DOWN at17, B at25. Each of three modes records forty frames. Before/after
screenshots share inputs and frame indices. Before quantities are 1,2,1;
after quantities are 4,1,4. B returns to the item list; both inventories stay4.
Every update checks all160x144 retained pixels against full rendering.
Each side is repeated twice: all120 PNG and all3 JSON files match byte-for-byte.
JSON reports quantity/phase/inputs and invariant inventories, not global RNG.

Five source_quantity core tests cover stacks1/4/99, allPC modes, bag toss,
mart buy/sell, simultaneous keys and stock/money behavior. Final core2712
and app191 tests pass (15 app tests intentionally ignored). The normal owner
pixel test passes; the ignored capture is invoked explicitly for screenshots.
App-only baseline/default desktop and core+app repair select the same features:
core has no default features. No source edits occurred during either build.
Frozen binary/source hashes and raw recordings are in verification/evidence.

The archive retains original ROM quantity/chord recordings and assembly from
historical185, including both repeats. Those recordings establish original
controls; older broad-branch Native/GBA results are not presented as results
for this independent PR. No ROM or executable is published. GBA release and
performance checks must pass on this PR's exact head without changing budgets.

Bag's subsequent toss confirmation and PC YES/NO defaults are separate audit
items; this PR does not claim to repair those flows. No fresh mainline claim.
''')
print('packaged',len(list(dest.iterdir())),'files; zip bytes',(dest/'evidence.zip').stat().st_size)
