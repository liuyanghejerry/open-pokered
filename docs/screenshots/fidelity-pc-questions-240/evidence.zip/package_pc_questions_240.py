from pathlib import Path
import json,re,hashlib,zipfile,shutil,subprocess
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-238-pc-questions-checkout';d=wt/'docs/screenshots/fidelity-pc-questions-240';d.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();files={}
results=json.loads((r/'audit-240-quantity-all-unit-and-integration-results-a1.json').read_text());assert results['every_binary_completed'] and results['all_pass']
for side in ['master','native']:
 manifest=json.loads((r/f'audit-240-pc-questions-{side}-immutable/manifest.json').read_text());assert manifest['base']=='3badf5a7359c93e684f4d8ef7d5329a83fe28da2'
 if side=='native':
  for p,h in manifest['sources'].items():assert sha((wt/p).read_bytes())==h,p
 for repeat in [1,2]:
  cap=r/f'audit-240-pc-questions-{side}-capture-{repeat}';assert len(list(cap.iterdir()))==9
  for context in cap.iterdir():assert len(list(context.iterdir()))==4
  for p in cap.rglob('*'):
   if p.is_file():assert p.suffix in ['.json','.png'];files[str(p.relative_to(r))]=p
  files[cap.name+'.log']=r/(cap.name+'.log')
 files[f'audit-240-pc-questions-{side}-immutable/manifest.json']=r/f'audit-240-pc-questions-{side}-immutable/manifest.json'
for mode in ['withdraw','deposit','toss']:
 for speed in [1,3,5]:
  prefix='audit-236-original' if speed==5 else 'audit-237-original';tag='question-return-hooks-a1' if speed==5 else f'question-return-hooks-{speed}-a1'
  for repeat in [1,2]:
   folder=r/f'{prefix}-{mode}-{tag}-{repeat}'
   for p in folder.iterdir():
    if p.is_file() and p.suffix in ['.json','.png']:files[str(p.relative_to(r))]=p
for name in ['audit-237-original-pc-question-all-speeds-verification.json','audit-240-pc-questions-master-negative.log','audit-240-pc-questions-master-build-a1.log','audit-240-quantity-all-tests-build-a1.log','audit-240-quantity-all-unit-and-integration-results-a1.json','audit-240-pc-item-questions-owner-helper.rs','audit-240-pc-item-questions-before-owner-helper.rs','freeze_run_all_tests_240.py','freeze_record_pc_questions_240.py','package_pc_questions_240.py','stats-59-tools/probe_pc_question_returns_236.py','stats-59-tools/probe_pc_question_returns_237.py','stats-59-tools/run_original_pc_question_returns_236.py','stats-59-tools/run_original_pc_question_returns_237.py']:files[name]=r/name
files['audit-240-quantity-all-tests-a1-immutable/manifest.json']=r/'audit-240-quantity-all-tests-a1-immutable/manifest.json'
for row in results['results']:files[row['log']]=r/row['log']
for name in ['crates/pokered-core/src/pc_screen.rs','crates/pokered-app/src/game.rs','crates/pokered-app/src/render/pc.rs','crates/pokered-app/src/render/session.rs','crates/pokered-data/src/ui_text.rs']:files['candidate-source/'+name]=wt/name
files['master-game-with-test-only-helper.rs']=root/'.task-tmp/fidelity-240-master-pc-questions-checkout/crates/pokered-app/src/game.rs'
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['engine/menus/players_pc.asm','home/print_text.asm','home/list_menu.asm','data/text/text_2.asm']:files['original-source/'+name]=ref/name
png={};blobs=set()
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  b=p.read_bytes()
  if p.suffix=='.png':
   h=sha(b);png[name]=h
   if h not in blobs:blobs.add(h);z.writestr('png-blobs/'+h+'.png',b)
  else:z.writestr(name,b)
 z.writestr('png-files.json',json.dumps(png,indent=2)+'\n')
with zipfile.ZipFile(d/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for name,context,stage,t in [('operation','withdraw-5','menu-initial',3),('withdraw','withdraw-5','list-initial',3),('deposit','deposit-5','list-initial',3),('toss','toss-5','list-initial',3),('list-return','withdraw-5','list-return',20),('menu-return','withdraw-5','menu-return',20)]:
 for side,label in [('master','before'),('native','after')]:shutil.copy2(r/f'audit-240-pc-questions-{side}-capture-1/{context}/{stage}/frame-{t:03}.png',d/f'{name}-{label}.png')
tot=[0,0,0]
for row in results['results']:
 m=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored',row['summary']);assert m
 for i in range(3):tot[i]+=int(m[i+1])
v={'base':'3badf5a7359c93e684f4d8ef7d5329a83fe28da2','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'tests':{'programs':len(results['results']),'pass':tot[0],'fail':tot[1],'ignore':tot[2]},'source_cases':9,'native_stages_per_case':4,'PNG':len(png),'repeat_raw_png_byte_exact':True,'every_native_cached_full_frame_pixel_equal':True,'all_archive_files_roundtrip_byte_exact':True,'archive_sha256':sha((d/'evidence.zip').read_bytes()),'archive_bytes':(d/'evidence.zip').stat().st_size,'scope':'PC item operation/list questions; logical PrintText handoff anchors, not absolute CPU/PPU timing or complete menu polling fidelity'}
(d/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
