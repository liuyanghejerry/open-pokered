
#[cfg(all(test,not(target_os="none")))]
mod pc_item_questions_owner_240 {
 use super::*;
 use pokered_core::pc_screen::PcPhase;
 fn tick(g:&mut PokemonGame,input:&mut InputState,held:&mut Vec<GbButton>,keys:Vec<GbButton>){input.begin_frame();for &k in held.iter(){if !keys.contains(&k){input.release(k);}}for &k in &keys {if !held.contains(&k){input.press(k);}}*held=keys;g.update(input);}
 fn chars(g:&PokemonGame)->Option<usize>{Some(g.pc_screen.as_ref().unwrap().item_question_chars())}
 fn record(g:&mut PokemonGame,input:&mut InputState,held:&mut Vec<GbButton>,save_path:&std::path::Path,capture:Option<&std::path::Path>,context:&str,stage:&str,ready:usize,count:usize,delay:usize,no_delay:bool,list:bool) {
  use pokered_data::items::ItemId;
  let mut session=crate::render::session::RenderSession::new();let mut retained=FrameBuffer::new(dotzuki_engine::render_config::RenderConfig::new(160,144),pokered_renderer::Rgba::WHITE);let mut scroll=|_:&mut [u8],_:usize,_:usize,_:i32,_:i32,_:u8|{};let mut rows=Vec::new();
  for t in 0..=ready+20 {
   if t>0 {tick(g,input,held,vec![]);}
   session.render(g,&mut retained,&mut scroll);let mut full=FrameBuffer::new(dotzuki_engine::render_config::RenderConfig::new(160,144),pokered_renderer::Rgba::WHITE);g.draw(&mut full);assert_eq!(retained.packed(),full.packed(),"{context}/{stage} cached/full {t}");
   assert_eq!(g.save_data.game_data.bag.item_quantity(ItemId::Potion),4);assert_eq!(g.save_data.game_data.pc_items.item_quantity(ItemId::Potion),4);assert!(!save_path.exists());
   let phase=format!("{:?}",g.pc_screen.as_ref().unwrap().phase());
   if capture.is_none(){
    assert_eq!(phase,if t<ready {"ItemQuestion"}else if list {"ItemList"}else{"ItemMenu"},"{context}/{stage} source handoff {t}");
    let expected=if t<3 {0}else if no_delay {count}else{((t-3)/delay+1).min(count)};assert_eq!(chars(g),Some(expected),"{context}/{stage} source glyph {t}");
   }
   if let Some(root)=capture {let dir=root.join(context).join(stage);std::fs::create_dir_all(&dir).unwrap();full.save_png(&dir.join(format!("frame-{t:03}.png"))).unwrap();rows.push(serde_json::json!({"t":t,"input":input.raw_current(),"phase":phase,"chars":chars(g),"pc":format!("{:?}",g.pc_screen.as_ref().unwrap()),"bag_potions":g.save_data.game_data.bag.item_quantity(ItemId::Potion),"pc_potions":g.save_data.game_data.pc_items.item_quantity(ItemId::Potion),"owned_save_exists":save_path.exists(),"overworld":pokered_core::snapshot::OverworldSnapshot::capture(&g.overworld)}));}
  }
  if let Some(root)=capture{std::fs::write(root.join(context).join(stage).join("frames.json"),serde_json::to_vec_pretty(&rows).unwrap()).unwrap();}
 }
 fn run(capture:Option<&std::path::Path>){
  use pokered_data::items::ItemId;
  for (speed,delay) in [(pokered_core::game_state::TextSpeed::Fast,1usize),(pokered_core::game_state::TextSpeed::Medium,3),(pokered_core::game_state::TextSpeed::Slow,5)] {for (mode,cursor,count) in [("withdraw",0,28),("deposit",1,27),("toss",2,29)] {
   let context=format!("{mode}-{delay}");
   let private_dir=std::env::temp_dir().join(format!("pc-questions-240-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
   std::fs::create_dir(&private_dir).unwrap();let save_path=private_dir.join("owned.sav");assert!(!save_path.exists());
   #[cfg(feature="debug-server")]let mut g=PokemonGame::new_with_options(GameVersion::Red,Some(save_path.clone()),None,None,false,None,false,true,None);
   #[cfg(not(feature="debug-server"))]let mut g=PokemonGame::new_with_options(GameVersion::Red,Some(save_path.clone()),None,None,false,None,false,true);
   g.audio=None;g.set_seed(42);g.state.config.language=pokered_core::game_state::Lang::En;g.state.config.text_speed=speed;
   g.save_data.game_data.bag=pokered_core::items::inventory::Inventory::new_bag();
   g.save_data.game_data.pc_items=pokered_core::items::inventory::Inventory::new_pc();
   g.save_data.game_data.bag.add_item(ItemId::Potion,4).unwrap();g.save_data.game_data.pc_items.add_item(ItemId::Potion,4).unwrap();
   assert_eq!(g.save_data.game_data.bag.item_quantity(ItemId::Potion),4);assert_eq!(g.save_data.game_data.pc_items.item_quantity(ItemId::Potion),4);
   g.state.screen=GameScreen::Overworld;g.overworld.warp_to_map(MapId::ViridianPokecenter,13,4);g.overworld.state.player.facing=pokered_core::overworld::Direction::Up;
   let idle=InputState::new();for _ in 0..120{g.update(&idle);}
   assert!(pokered_core::overworld::update::is_script_walkable_tile(g.overworld.map_data.as_ref().unwrap(),13,4));

   let mut input=InputState::new();let mut held=Vec::new();let mut found=false;
   for t in 0..2000 {
    let phase=g.pc_screen.as_ref().map(|p|p.phase());let keys=if t==0 {vec![GbButton::A]}else if t%8!=0 {vec![]}else {match phase {Some(PcPhase::Message)=>vec![GbButton::A],Some(PcPhase::MainMenu)=>{if g.pc_screen.as_ref().unwrap().main_menu().cursor()<1 {vec![GbButton::Down]}else{vec![GbButton::A]}},_=>vec![]}};tick(&mut g,&mut input,&mut held,keys);
    let phase=g.pc_screen.as_ref().map(|p|format!("{:?}",p.phase()));if matches!(phase.as_deref(),Some("ItemQuestion")|Some("ItemMenu")){found=true;break;}
   }
   assert!(found,"{context} hidden PC initial operation question");
   record(&mut g,&mut input,&mut held,&save_path,capture,&context,"menu-initial",3,22,delay,true,false);
   for _ in 0..49 {tick(&mut g,&mut input,&mut held,vec![]);}
   for _ in 0..cursor {tick(&mut g,&mut input,&mut held,vec![GbButton::Down]);tick(&mut g,&mut input,&mut held,vec![]);}
   tick(&mut g,&mut input,&mut held,vec![GbButton::A]);
   record(&mut g,&mut input,&mut held,&save_path,capture,&context,"list-initial",3,count,delay,true,true);
   for _ in 0..49 {tick(&mut g,&mut input,&mut held,vec![]);}
   tick(&mut g,&mut input,&mut held,vec![GbButton::A]);tick(&mut g,&mut input,&mut held,vec![GbButton::A]);
   for _ in 0..3+9*delay+8 {tick(&mut g,&mut input,&mut held,vec![]);}
   assert_eq!(g.pc_screen.as_ref().unwrap().phase(),PcPhase::ItemQuantity);
   tick(&mut g,&mut input,&mut held,vec![GbButton::B]);
   record(&mut g,&mut input,&mut held,&save_path,capture,&context,"list-return",3+count*delay,count,delay,false,true);
   for _ in 0..49 {tick(&mut g,&mut input,&mut held,vec![]);}
   tick(&mut g,&mut input,&mut held,vec![GbButton::B]);
   record(&mut g,&mut input,&mut held,&save_path,capture,&context,"menu-return",3+22*delay,22,delay,false,false);
   std::fs::remove_dir_all(private_dir).unwrap();
  }}
 }
 #[test]fn pc_item_questions_match_nine_source_speed_paths(){std::thread::Builder::new().stack_size(16*1024*1024).spawn(||run(None)).unwrap().join().unwrap();}
 #[test]#[ignore="actual PC operation/list initial/return question captures"]fn capture_pc_item_questions_240(){let path=std::path::PathBuf::from(std::env::var("PC_ITEM_QUESTIONS_CAPTURE_240").unwrap());std::thread::Builder::new().stack_size(16*1024*1024).spawn(move||run(Some(&path))).unwrap().join().unwrap();}
}
