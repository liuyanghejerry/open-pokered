from pathlib import Path
import subprocess,os
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
for mode in ['withdraw','deposit','toss']:
 with (r/f'audit-236-original-question-returns-{mode}.log').open('w') as log:p=subprocess.run([str(r/'stats-59-tools/venv/bin/python'),str(r/'stats-59-tools/probe_pc_question_returns_236.py')],env=dict(os.environ,FIDELITY_PC_MODE=mode,FIDELITY_PC_SPEED='5'),stdout=log,stderr=subprocess.STDOUT)
 print(mode,p.returncode,flush=True);assert p.returncode==0
