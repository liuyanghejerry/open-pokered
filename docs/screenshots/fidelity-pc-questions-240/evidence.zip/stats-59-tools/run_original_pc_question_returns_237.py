from pathlib import Path
import subprocess,os
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
for speed in [3,1]:
 for mode in ['withdraw','deposit','toss']:
  with (r/f'audit-237-original-question-returns-{mode}-{speed}.log').open('w') as log:p=subprocess.run([str(r/'stats-59-tools/venv/bin/python'),str(r/'stats-59-tools/probe_pc_question_returns_237.py')],env=dict(os.environ,FIDELITY_PC_MODE=mode,FIDELITY_PC_SPEED=str(speed)),stdout=log,stderr=subprocess.STDOUT)
  print(mode,speed,p.returncode,flush=True);assert p.returncode==0
