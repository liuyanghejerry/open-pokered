from pathlib import Path
import json,re,hashlib,zipfile,shutil,subprocess
from PIL import Image
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-258-pc-item-scroll-checkout';out=wt/'docs/screenshots/fidelity-pc-item-scroll-263';base='47395a7d631e10c9ef2d12587e76504918a981ae';sha=lambda b:hashlib.sha256(b).hexdigest();files={}
proof=json.loads((r/'audit-263-before-source-promoted-master-equivalence.json').read_text());assert proof['current_master']==base and proof['entire_crates_tree_equal'];tests=json.loads((r/'audit-263-scroll-all-unit-and-integration-results-a1.json').read_text());assert tests['all_pass'] and tests['every_binary_completed'] and len(tests['results'])==78;cli=json.loads((r/'audit-263-scroll-cli-regression-results.json').read_text());assert cli['base']==base and cli['fresh_m01_m03'] and cli['separate_process_s07_save_continue'];cases=[]
for case in ['down','return']:
 name='audit-256-original-withdraw-list-scroll-manual-three-items-a1' if case=='down' else 'audit-257-original-withdraw-list-scroll-down3-up2-three-items-a1'
 for repeat in [1,2]:
  folder=r/f'{name}-{repeat}';rows=json.loads((folder/'frames.json').read_text());assert all(x['pc_items']==[20,4,11,3,4,2,255] for x in rows);assert (rows[-1]['cursor'],rows[-1]['list_scroll'])==((2,1) if case=='down' else (0,1))
  for p in folder.iterdir():assert p.suffix in ['.png','.json'];files[str(p.relative_to(r))]=p
  if repeat==2:
   other=r/f'{name}-1';assert all(p.read_bytes()==(other/p.name).read_bytes() for p in folder.iterdir())
 for side in ['master','native']:
  for repeat in [1,2]:
   folder=r/f'audit-263-{side}-scroll-{case}-{repeat}';assert not (folder/'owned.sav').exists();rows=json.loads((folder/'frames.json').read_text());assert all(x['bag']==rows[0]['bag'] and not x['owned_save_exists'] for x in rows);assert rows[-1]['state']['pc_phase']=='ItemList'
   for p in folder.iterdir():assert p.suffix in ['.png','.json'];files[str(p.relative_to(r))]=p
   if repeat==2:
    other=r/f'audit-263-{side}-scroll-{case}-1';assert all(p.read_bytes()==(other/p.name).read_bytes() for p in folder.iterdir())
   if case=='return':assert ((folder/'frame-220.png').read_bytes()==(folder/'frame-070.png').read_bytes())==(side=='master')
 cases.append({'case':case,'original_cursor':2 if case=='down' else 0,'original_scroll':1,'source_two_repeats_byte_exact':True,'master_two_repeats_byte_exact':True,'candidate_two_repeats_byte_exact':True,'source_full_PC_inventory_unchanged':True,'native_bag_unchanged':True,'no_native_automatic_save':True,'native_PC_inventory_asserted_in_core_and_cached_renderer_tests':True})
a=Image.open(r/'audit-263-master-scroll-down-1/frame-190.png');b=Image.open(r/'audit-263-native-scroll-down-1/frame-190.png');label_checks=[]
for label,ya,yb in [('ANTIDOTE',20,8),('POKE BALL',32,20),('CANCEL',44,32)]:
 assert a.crop((18,ya-2,130,ya+10)).tobytes()==b.crop((18,yb-2,130,yb+10)).tobytes();label_checks.append({'label':label,'same_pixels_after_row_translation':True})
for name in ['audit-263-before-source-promoted-master-equivalence.json','audit-263-scroll-all-tests-build-a1.log','audit-263-scroll-all-unit-and-integration-results-a1.json','audit-263-scroll-all-tests-a1-immutable/manifest.json','audit-263-scroll-cli-build-a2.log','audit-263-scroll-cli-immutable/manifest.json','audit-263-scroll-cli-regression-results.json','audit-263-scroll-cli-regression-run.log','audit-263-master-scroll-run.log','audit-263-native-scroll-run.log','audit-256-manual-scroll-results.json','audit-257-original-scroll-return-run.log','record_pc_scroll_263.py','freeze_run_scroll_all_tests_263.py','freeze_run_scroll_cli_263.py','package_pc_scroll_263.py','stats-59-tools/probe_pc_list_manual_scroll_256.py','stats-59-tools/probe_pc_list_scroll_return_257.py']:
 p=r/name;assert p.exists(),name;files[name]=p
for x in tests['results']:files[x['log']]=r/x['log']
for name in ['crates/pokered-core/src/pc_screen.rs','crates/pokered-app/src/render/pc.rs','crates/pokered-app/src/render/session.rs']:files['candidate-source/'+name]=wt/name
ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
for name in ['home/list_menu.asm','home/window.asm','engine/menus/players_pc.asm']:files['original-source/'+name]=ref/name
out.mkdir(parents=True,exist_ok=False);png={};blobs=set()
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():
  data=p.read_bytes()
  if p.suffix=='.png':
   h=sha(data);png[name]=h
   if h not in blobs:blobs.add(h);z.writestr('png-blobs/'+h+'.png',data)
  else:z.writestr(name,data)
 z.writestr('png-files.json',json.dumps(png,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip') as z:
 for name,p in files.items():assert z.read('png-blobs/'+png[name]+'.png' if name in png else name)==p.read_bytes(),name
for case in ['down','return']:
 end=190 if case=='down' else 220
 for side,label in [('master','before'),('native','after')]:shutil.copy2(r/f'audit-263-{side}-scroll-{case}-1/frame-{end:03}.png',out/f'{case}-{label}.png')
total=[0,0,0]
for x in tests['results']:
 m=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored',x['summary']);assert m
 for i in range(3):total[i]+=int(m[i+1])
v={'base':base,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'tests':{'programs':78,'pass':total[0],'fail':total[1],'ignore':total[2]},'cases':cases,'label_crops':label_checks,'cached_and_full_render_match_for_221_frames':True,'three_item_modes_core_navigation_cancel_and_inventory_verified':True,'PNG':len(png),'archive_roundtrip_byte_exact':True,'archive_sha256':sha((out/'evidence.zip').read_bytes()),'archive_bytes':(out/'evidence.zip').stat().st_size,'scope':'three-row item viewport and retained scroll only; controlled snapshot and synthetic cache fixture, not natural playthrough; native PC stock is asserted in core/cache tests, not via missing TCP getter; menu geometry/background, input guards/repeat and other PC text/audio remain under audit'}
(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
