from pathlib import Path
import sys,subprocess,shutil,hashlib,json,os
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-258-pc-item-scroll-checkout';out=r/'audit-263-scroll-cli-immutable';out.mkdir(exist_ok=False);binary=root/'.task-tmp/fidelity-258-pc-item-scroll-native-target/debug/pokered-app';assert 'Finished `dev` profile' in (r/'audit-263-scroll-cli-build-a2.log').read_text();shutil.copy2(binary,out/'pokered-app');sha=lambda b:hashlib.sha256(b).hexdigest();manifest={'base':'47395a7d631e10c9ef2d12587e76504918a981ae','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt).decode().strip(),'binary':sha((out/'pokered-app').read_bytes()),'sources':{p:sha((wt/p).read_bytes()) for p in ['crates/pokered-core/src/pokemon/pc_menu.rs','crates/pokered-core/src/pokemon/pc_menu_tests.rs','crates/pokered-core/src/pc_screen.rs','crates/pokered-app/src/game.rs','crates/pokered-app/src/render/pc.rs','crates/pokered-app/src/render/session.rs']}};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');sys.path.insert(0,str(root/'scripts'));import playthrough as pt;import scenarios as sc
artifact=r/'audit-263-scroll-cli-regression-artifacts';artifact.mkdir(exist_ok=False)
class RecordedGame(pt.Game):
 def __init__(self,*args,**kwargs):
  kwargs['binary']=out/'pokered-app';kwargs['seed']=42;kwargs['speed']=0;super().__init__(*args,**kwargs)
 def close(self):
  self.log.flush();dest=artifact/self.run_dir.name;shutil.copytree(self.run_dir,dest);super().close()
sc.Game=RecordedGame
g=RecordedGame()
try:
 for fn in [pt.m01_boot,pt.m02_oak_speech,pt.m03_leave_house]:fn(g)
 print('FRESH M01-M03 PASS',flush=True)
finally:g.close()
sc.s07_save_roundtrip();print('SEPARATE-PROCESS S07 SAVE/CONTINUE PASS',flush=True)
(r/'audit-263-scroll-cli-regression-results.json').write_text(json.dumps({'head':manifest['head'],'base':manifest['base'],'binary_sha256':manifest['binary'],'fresh_m01_m03':True,'separate_process_s07_save_continue':True,'seed':42,'speed':0},indent=2)+'\n')
