from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';out=w/'docs/screenshots/fidelity-pc-confirm-177';out.mkdir(parents=True,exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());m=load(r/'audit-177-debug-a2-immutable/manifest.json');assert all(h(w/n)==sha for n,sha in m['sources'].items())
master=r/'audit-177-master31-change-box-a1-1';repeat=r/'audit-177-master31-change-box-a1-2';files=sorted(p.name for p in master.iterdir() if p.suffix in ['.png','.json']);assert files==sorted(p.name for p in repeat.iterdir() if p.suffix in ['.png','.json']);assert all((master/n).read_bytes()==(repeat/n).read_bytes() for n in files)
rows=load(master/'frames.json');after=load(r/'audit-177-native-change-box-a2-1/frames.json');assert [v['input'] for v in rows]==[v['input'] for v in after];assert rows[10]['state']['pc_phase']=='BillsMenu' and after[10]['state']['pc_phase']=='Message'
for pkg,num in [('core',2750),('data',263),('app',222),('agent',54),('audio',99)]:assert f'{num} passed; 0 failed;' in (r/f'audit-177-suite-{pkg}-a5.log').read_text()
shutil.copy2(master/'frame-0010.png',out/'change-box-before.png');shutil.copy2(r/'audit-177-native-change-box-a2-1/frame-0010.png',out/'change-box-after.png')
entries={}
for prefix in ['audit-176-original-change-box-a1','audit-176-original-change-box-early-a1','audit-176-native-change-box-a5','audit-176-native-change-box-early-a1','audit-177-native-change-box-a2','audit-177-native-change-box-early-a2','audit-177-master31-change-box-a1']:
 for d in r.glob(prefix+'-*'):
  if d.is_dir():
   for p in d.iterdir():
    if p.is_file() and p.suffix in ['.png','.json']:entries[str(p.relative_to(r))]=p
for name in ['audit-176-pc-confirm-verification.json','audit-176-pc-confirm-source-audit.json','audit-176-native-pc-snapshot.json','audit-176-native-pc-setup.json','audit-177-pc-replay-verification.json','audit-177-gba-source-manifest-a5.json','audit-177-gba-performance-a5.json','audit-177-gba-performance-a5-repeat.json','audit-177-gba-compare-a5.log','audit-177-gba-compare-a5-repeat.log','audit-177-gba-build-a5.log','audit-177-native-build-a5.log','audit-177-debug-build-a2.log','audit-177-master31-debug-build-a1.log']:
 entries[name]=r/name
for pkg in ['core','data','app','agent','audio']:entries[f'audit-177-suite-{pkg}-a5.log']=r/f'audit-177-suite-{pkg}-a5.log'
for name in ['audit-177-debug-a2-immutable','audit-177-master31-debug-immutable','audit-177-after-a5-immutable']:entries[name+'/manifest.json']=r/name/'manifest.json'
for name in ['probe_pc_change_box_176.py','probe_pc_change_box_early_176.py','run_native_pc_change_177.py','run_native_pc_change_early_177.py','run_master_pc_change_177.py','verify_pc_confirm_176.py','verify_pc_repair_177.py','freeze_run_pc_177.py','package_pc_confirm_177.py']:entries['tools/'+name]=r/'stats-59-tools'/name
for n in m['sources']:entries['source/'+n]=w/n
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
v={'parent_head':'1cb51db4641b37a38f1b1289c3cce115e11578de','master_head':'31b1eda3112514d6bc803af559ec7f7c9e20374f','source_hashes':m['sources'],'native_tests':{'core':2750,'data':263,'app':222,'app_ignored':33,'agent':54,'audio':99},'original_native_replay':load(r/'audit-177-pc-replay-verification.json'),'master_before':{'two_repeats_byte_exact':True,'same_post_cue_inputs':True,'frame_offset':10,'phase':'BillsMenu'},'gba_budget':'FAILED 2 of31 metrics; same ELF two complete measurements identical; retained failures, unchanged budget; NOT merge-ready','archive':{'bytes':archive.stat().st_size,'sha256':h(archive),'entries':len(entries)},'remaining':['GBA original budget regression','CONT physical half-row scrolling','release/toss original runtime matched scenarios','PC quantity/list/menu authored prompt clocks','PC PCM bank matching','global text init/close/arrow','movement17 logical/27 RGB differences','final exact-head fresh m01-m49 and independent SAVE/CONTINUE']};(out/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(v['archive'])
