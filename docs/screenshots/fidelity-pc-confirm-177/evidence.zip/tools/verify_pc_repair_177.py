from pathlib import Path
import json,hashlib
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');out={}
for name,ref in [('native-change-box-a2','original-change-box-a1'),('native-change-box-early-a2','original-change-box-early-a1')]:
 a=r/f'audit-177-{name}-1';b=r/f'audit-177-{name}-2';files=sorted(p.name for p in a.iterdir() if p.suffix in ['.png','.json']);assert files==sorted(p.name for p in b.iterdir() if p.suffix in ['.png','.json']);assert all((a/n).read_bytes()==(b/n).read_bytes() for n in files)
 rows=json.loads((a/'frames.json').read_text());orig=json.loads((r/f'audit-176-{ref}-1/frames.json').read_text());cue=orig[-1]['change_cue'];assert [v['input'] for v in rows]==[v['input'] for v in orig[cue:]]
 counts=[v['state']['frame_count'] for v in rows];assert all(y-x==1 for x,y in zip(counts,counts[1:]));out[name]={'frames':len(rows),'files':len(files),'two_repeats_byte_exact':True,'exact_post_cue_original_inputs':True,'one_frame_per_input':True,'phase_transitions':[{'t':v['t'],'phase':v['state']['pc_phase']} for i,v in enumerate(rows) if i==0 or v['state']['pc_phase']!=rows[i-1]['state']['pc_phase']],'frames_sha256':hashlib.sha256((a/'frames.json').read_bytes()).hexdigest()}
(r/'audit-177-pc-replay-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
