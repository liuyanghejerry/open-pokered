from pathlib import Path
import json,hashlib
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus')
pairs=['original-change-box-a1','original-change-box-early-a1','native-change-box-a5','native-change-box-early-a1'];out={}
for key in pairs:
 a=r/f'audit-176-{key}-1';b=r/f'audit-176-{key}-2';names=sorted(p.name for p in a.iterdir() if p.is_file());assert names==sorted(p.name for p in b.iterdir() if p.is_file())
 for name in names: assert (a/name).read_bytes()==(b/name).read_bytes(),(key,name)
 rows=json.loads((a/'frames.json').read_text());entry={'two_repeats_byte_exact':True,'frames':len(rows),'files':len(names),'frames_sha256':hashlib.sha256((a/'frames.json').read_bytes()).hexdigest()}
 if key.startswith('native'):
  counts=[row['state']['frame_count'] for row in rows];assert all(y-x==1 for x,y in zip(counts,counts[1:]));entry['one_hardware_frame_per_input_and_capture']=True
  entry['phase_transitions']=[{'t':row['t'],'phase':row['state']['pc_phase']} for i,row in enumerate(rows) if i==0 or row['state']['pc_phase']!=rows[i-1]['state']['pc_phase']]
 out[key]=entry
(r/'audit-176-pc-confirm-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
