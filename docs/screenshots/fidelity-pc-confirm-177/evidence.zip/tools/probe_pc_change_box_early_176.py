exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
r=root/'.task-tmp/fidelity-39-plus';rom=r/'safari-147-source-setup/reference.gbc';start=r/'audit-172-main-pc-slow-setup/pretrigger.state'
for trial in [1,2]:
 out=r/f'audit-176-original-change-box-early-a1-{trial}';out.mkdir(exist_ok=True)
 p=PyBoy(str(rom),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(start.read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]]);now=[-1];events=[];main=[None];bills=[None];change=[None];yes=[None];need=[False];ack_until=-1;last_ack=-100;held=None
 def hook(n):
  if n=='PCMainMenu' and main[0] is None:main[0]=now[0]
  if n=='BillsPCMenu' and bills[0] is None:bills[0]=now[0]
  if n=='ChangeBox' and change[0] is None:change[0]=now[0]
  if n=='WaitForTextScrollButtonPress':need[0]=True
  if n=='DisplayTwoOptionMenu' and change[0] is not None and yes[0] is None:yes[0]=now[0]
  events.append({'t':now[0],'routine':n,'cycles':p._cycles(),'no_delay':bool(get('wStatusFlags5')&0x40),'menu_cursor':get('wCurrentMenuItem')})
 for n in ['ActivatePC','PCMainMenu','BillsPC_','BillsPCMenu','BillsPCChangeBox','ChangeBox','PrintText','Paragraph','_ContText','WaitForTextScrollButtonPress','YesNoChoice','DisplayTwoOptionMenu']:
  assert n in symbols,n;p.hook_register(*symbols[n],hook,n)
 rows=[]
 for t in range(2200):
  now[0]=t;key='a' if t<2 else None
  if main[0] is not None and bills[0] is None and main[0]+70<=t<main[0]+72:key='a'
  if bills[0] is not None and change[0] is None:
   for delta in [70,94,118]:
    if bills[0]+delta<=t<bills[0]+delta+2:key='down'
   if bills[0]+150<=t<bills[0]+152:key='a'
  if change[0] is not None:
   delta=t-change[0]
   key='a' if delta in [0,1,4,5] else ('up' if delta in [2,3] else None)
  if need[0] and change[0] is None and held is None and t-last_ack>=20 and yes[0] is None:
   need[0]=False;ack_until=t+2;last_ack=t
  if t<ack_until:key='a'
  if key!=held:
   if held:p.button_release(held)
   if key:p.button_press(key)
   held=key
  p.tick(1);p.screen.image.save(out/f'frame-{t:04}.png');rows.append({'t':t,'input':key,'no_delay':bool(get('wStatusFlags5')&0x40),'main_cue':main[0],'bills_cue':bills[0],'change_cue':change[0],'yes_no_cue':yes[0],'menu_cursor':get('wCurrentMenuItem')})
  if change[0] is not None and t>=change[0]+60:break
 (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');p.stop(save=False)
 assert all(v[0] is not None for v in [main,bills,change]),(main,bills,change);assert yes[0] is None
 waits=[v for v in events if v['routine']=='WaitForTextScrollButtonPress' and v['t']>=change[0]]
 print(trial,{'main':main[0],'bills':bills[0],'change':change[0],'yes':yes[0],'waits':[v['t'] for v in waits],'mode_change':rows[change[0]]['no_delay'],'mode_end':rows[-1]['no_delay']},flush=True)
 assert len(waits)==1,waits;assert rows[-1]['no_delay']
 if trial==2:
  old=r/'audit-176-original-change-box-early-a1-1';assert sorted(f.name for f in out.iterdir())==sorted(f.name for f in old.iterdir());assert all(f.read_bytes()==(old/f.name).read_bytes() for f in out.iterdir())
