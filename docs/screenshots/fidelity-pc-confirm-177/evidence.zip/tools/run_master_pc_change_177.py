from pathlib import Path
import sys,os,json,socket,subprocess,hashlib
root=Path('/home/jerry/develop/open-pokered');w=root/'.task-tmp/fidelity-93-master-before';r=root/'.task-tmp/fidelity-39-plus';sys.path.insert(0,str(w/'scripts'));from debug_drive import DebugClient
original=json.loads((r/'audit-176-original-change-box-a1-1/frames.json').read_text());cue=original[-1]['change_cue'];controls=[v['input'] for v in original[cue:]]
for trial in [1,2]:
 out=r/f'audit-177-master31-change-box-a1-{trial}';out.mkdir(exist_ok=True)
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib');log=(r/f'audit-177-master31-change-box-a1-{trial}.log').open('w');p=subprocess.Popen([str(r/'audit-177-master31-debug-immutable/pokered-app'),'run','--headless','--debug-port',str(port),'--speed','0','--skip-intro','--no-audio','--seed','42','--save',str(out/'isolated.sav'),'--snapshot',str(r/'audit-176-native-pc-snapshot.json'),'--lang','en','--scripts-dir',str(w/'crates/pokered-data/maps')],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
 d=None
 try:
  d=DebugClient(port=port)
  def drive(keys):
   v=d.cmd(cmd='press_timeline',buttons=keys,advance=True);assert v.get('ok'),v
  def state():return d.state()
  v=d.cmd(cmd='warp',map='ViridianPokecenter',x=13,y=4);assert v.get('ok'),v
  drive([None]*120+['up']*20+[None]*20+['a']*20+[None]*20);(out/'setup-state.json').write_text(json.dumps(state(),indent=2)+'\n');print(trial,'first',state().get('pc_phase'),flush=True)
  def reach(target):
   for _ in range(500):
    if state().get('pc_phase')==target:return
    drive(['a',None])
   raise AssertionError((target,state()))
  reach('MainMenu');drive(['a',None]);reach('BillsMenu')
  for _ in range(3):drive(['down',None])
  rows=[]
  for t,key in enumerate(controls):
   drive([key]);v=state();response=d.cmd(cmd='capture_frame',path=str(out/f'frame-{t:04}.png'));assert response.get('ok'),response;rows.append({'t':t,'input':key,'state':v})
  (out/'frames.json').write_text(json.dumps(rows,indent=2)+'\n');print(trial,'phases',[(x['t'],x['state'].get('pc_phase')) for x in rows if x['t']==0 or x['state'].get('pc_phase')!=rows[x['t']-1]['state'].get('pc_phase')],flush=True)
  assert rows[0]['state']['pc_phase']=='ChangeBoxConfirm';assert rows[10]['state']['pc_phase']=='BillsMenu'
 finally:
  if d:d.close()
  p.terminate()
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait()
  log.close()
 if trial==2:
  old=r/'audit-177-master31-change-box-a1-1';files=sorted(v.name for v in out.iterdir() if v.suffix in ['.png','.json']);assert files==sorted(v.name for v in old.iterdir() if v.suffix in ['.png','.json']);assert all((out/f).read_bytes()==(old/f).read_bytes() for f in files)
