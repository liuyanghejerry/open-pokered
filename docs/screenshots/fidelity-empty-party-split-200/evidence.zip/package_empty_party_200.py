from pathlib import Path
import re,hashlib,shutil,json,zipfile,subprocess,os
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';wt=root/'.task-tmp/fidelity-200-empty-party-checkout';before=root/'.task-tmp/fidelity-200-empty-party-before-checkout';f=r/'audit-200-master-a1-immutable';f.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
log=(r/'audit-200-master-build-a1.log').read_text();p=Path(re.search(r'Executable unittests src/lib.rs \(([^\n]*pokered_app-[^\n]*)\)',log).group(1));shutil.copy2(p,f/'app-tests');(f/'manifest.json').write_text(json.dumps({'base':'748c221','binary':sha(f/'app-tests'),'capture_source':sha(before/'crates/pokered-app/src/render/session.rs'),'scope':'actual master production with identical ignored helper appended'},indent=2))
for n in [1,2]:
 out=r/f'audit-200-master-capture-a1-{n}'
 with (r/f'{out.name}.log').open('w') as s:subprocess.run([str(f/'app-tests'),'capture_empty_party_200','--ignored','--nocapture'],cwd=before,env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',EMPTY_PARTY_CAPTURE_200=str(out)),stdout=s,stderr=subprocess.STDOUT,check=True)
a=r/'audit-200-master-capture-a1-1';b=r/'audit-200-master-capture-a1-2'
for p in a.iterdir():assert p.read_bytes()==(b/p.name).read_bytes(),p
for side in ['master','native']:
 rows=json.loads((r/f'audit-200-{side}-capture-a1-1/frames.json').read_text());print(side,[(x['frame'],x['screen'],x['items'][0]) for x in rows[:3]])
dest=wt/'docs/screenshots/fidelity-empty-party-split-200';dest.mkdir(parents=True,exist_ok=True)
for frame,label in [(0,'menu'),(1,'select')]:
 for side,title in [('master','before'),('native','after')]:shutil.copy2(r/f'audit-200-{side}-capture-a1-1/frame-{frame:04}.png',dest/f'{label}-{title}.png')
with zipfile.ZipFile(dest/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 old=root/'.task-tmp/fidelity-91-plus-checkout/docs/screenshots/fidelity-empty-party-menu-106/raw-captures.zip'
 with zipfile.ZipFile(old) as src:
  for name in src.namelist():
   if name.startswith(('menu-106-source-','stats-59-tools/probe_menu_empty_106.py')):z.writestr('historical-original/'+name,src.read(name))
 for side in ['master','native']:
  for n in [1,2]:
   base=r/f'audit-200-{side}-capture-a1-{n}'
   for p in base.iterdir():z.write(p,str(p.relative_to(r)))
   p=r/f'{base.name}.log';z.write(p,p.name)
  p=r/f'audit-200-{side}-a1-immutable/manifest.json';z.write(p,str(p.relative_to(r)))
 for name in ['audit-200-native-build-a1.log','audit-200-master-build-a1.log','audit-200-core-tests-a1.log','audit-200-app-tests-a1.log','audit-200-helper.rs','prepare_empty_party_200.py','package_empty_party_200.py']:
  p=r/name;z.write(p,name)
 for name in ['crates/pokered-core/src/start_menu.rs','crates/pokered-core/src/start_menu_tests.rs','crates/pokered-app/src/render/session.rs']:z.write(wt/name,'final-source/'+name)
 ref=Path('/tmp/pokered-reference-audit-2_47ofmo/pokered-fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c')
 for name in ['engine/menus/draw_start_menu.asm','engine/menus/start_sub_menus.asm','home/start_menu.asm']:z.write(ref/name,'original-source/'+name)
verify={'base':'748c221b2ae8b2fd73824123b095f50b7b47d24f','native':json.loads((r/'audit-200-native-a1-immutable/manifest.json').read_text()),'master':json.loads((f/'manifest.json').read_text()),'tests':{'core':2708,'app':191,'app_ignored':15},'repeats':'both sides all8PNG+JSON byte-exact','files':{p.name:sha(p) for p in dest.iterdir() if p.suffix in ['.png','.zip']}}
(dest/'verification.json').write_text(json.dumps(verify,indent=2)+'\n');(dest/'README.md').write_text('''# Empty-party START menu: standalone split 200

Based on actual master748c221. Only StartMenuState item visibility and empty
party selection change. No field-clock, three-frame initialization/redraw,
party restore, input sampling or renderer rewrite is imported.

Original DrawStartMenu prints POKEMON unconditionally, six entries without
Pokedex/seven with it. StartMenu_Pokemon checks wPartyCount and jumps back
to RedisplayStartMenu if zero. This split keeps the entry and stays on START
when A selects it with no party; after receiving a party member it opens Party.
Core tests cover both Pokedex states, item order, A and subsequent party entry.

The current standalone owner test uses a controlled English empty-party Game,
Pallet(5,5), directly opened StartMenuState without Pokedex. A occurs at frame1;
all8 rendered frames compare retained/full pixels. Master's first item is ITEM
and A opens Bag; repair's first item is POKEMON and A keeps START. Both sides
use the identical helper/inputs/frame index and repeat twice; all8PNG+JSON are
byte-exact per side. No global RNG claim and no field-opening timing claim.
Frozen binary/source hashes, all raw frames and logs are in evidence.zip.
Core2708/app191 tests pass (15app intentionally ignored). GBA is gated by this
PR's own latest-head build/performance CI without relaxing budgets.

Historical106 original ROM recordings/probe and original assembly are retained
as source evidence. Its older Native/GBA claims are excluded. Three-frame
redisplay and field input boundaries remain with the larger movement/input
foundation split; this PR addresses menu availability/action only. No new full
mainline or independent Continue result is claimed. No ROM/binaries published.
''');print('packed',len(list(dest.iterdir())),'files')
