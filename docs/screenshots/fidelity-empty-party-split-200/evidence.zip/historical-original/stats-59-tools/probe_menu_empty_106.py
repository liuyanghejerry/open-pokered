exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/victory-100-source-setup-3f-hole';summary=[]

idx=0
for line in (source/'constants/event_constants.asm').read_text().splitlines():
 line=line.split(';',1)[0].strip()
 if line.startswith('const_skip'):idx+=int(line.split()[1])
 elif line.startswith('const '):
  if line.split()[1]=='EVENT_GOT_POKEDEX':break
  idx+=1
summary=[]
for dex in [False,True]:
 for trial in [1,2]:
  out=root/f'.task-tmp/fidelity-39-plus/menu-106-source-{int(dex)}-{trial}';out.mkdir(exist_ok=True)
  p=PyBoy(str(setup/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'pretrigger.state').read_bytes()));events=[];rows=[];now=[-1]
  p.memory[symbols['wPartyCount'][1]]=0
  address=symbols['wEventFlags'][1]+idx//8
  p.memory[address]=(p.memory[address]|(1<<(idx%8))) if dex else (p.memory[address]&~(1<<(idx%8)))
  p.memory[symbols['wBattleAndStartSavedMenuItem'][1]]=int(dex)
  def hook(name):events.append({'t':now[0],'routine':name,'a':p.register_file.A})
  for name in ['PlaySound','Joypad','DrawStartMenu','RedisplayStartMenu','StartMenu_Pokemon','DisplayPartyMenu']:
   p.hook_register(*symbols[name],hook,name)
  for t in range(100):
   now[0]=t
   for at,key,pressed in [(0,'start',True),(2,'start',False),(60,'a',True),(62,'a',False)]:
    if t==at:(p.button_press if pressed else p.button_release)(key)
   p.tick(1)
   if t in [50,61,65]:p.screen.image.save(out/f'frame-{t:04}.png')
   rows.append({'t':t,'party_count':int(p.memory[symbols['wPartyCount'][1]]),'current_item':int(p.memory[symbols['wCurrentMenuItem'][1]]),'max_item':int(p.memory[symbols['wMaxMenuItem'][1]])})
  p.stop(save=False);summary.append({'dex':dex,'trial':trial,'controlled_fixture':'PartyCount0,dexflag and savedcursor only; normal original menu code','dex_event_index':idx,'events':events,'rows':rows})
  print(dex,trial,[e for e in events if e['routine']!='Joypad'],flush=True)
(root/'.task-tmp/fidelity-39-plus/menu-106-source-empty-party.json').write_text(json.dumps(summary,indent=2))
