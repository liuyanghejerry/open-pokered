from pathlib import Path
import json,hashlib
p=Path(__file__).parent
for name,sha in json.loads((p/'sha256.json').read_text()).items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==sha,name
ids={'Potion':20,'Antidote':11,'PokeBall':4,'Revive':53,'EscapeRope':29,'Repel':30,'HyperPotion':18,'SuperPotion':19}
for case in ['partial','full','no','cancel','first','middle','last','single']:
 s=json.loads((p/f'source/{case}/trial1.json').read_text());n=json.loads((p/f'native/after/{case}/trial1.json').read_text());b=json.loads((p/f'native/before/{case}/trial1.json').read_text());assert len(s)==len(n)==len(b)==1801
 for kind in ['source','native/before','native/after']:assert (p/f'{kind}/{case}/trial1.json').read_bytes()==(p/f'{kind}/{case}/trial2.json').read_bytes()
 for t in range(1801):
  assert [v for name,qty in n[t]['bag']for v in [ids[name],qty]]+[255]==s[t]['bag'],(case,t)
  assert n[t]['cached_equals_full'] and b[t]['cached_equals_full'] and not n[t]['ordinary_save_exists']
 if case in ['partial','no','cancel']:assert all((n[t]['cursor'],n[t]['scroll'])==(b[t]['cursor'],b[t]['scroll'])for t in range(1801))
 else:assert all((n[t]['cursor'],n[t]['scroll'])==(s[t]['cursor']+s[t]['scroll'],s[t]['scroll'])==(0,0)for t in range(1500,1801))
print('PASS8 repeated cases: Source stock1801, depleted return301, partial/no/B preserved, cache1801')
