from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
root=Path('/home/jerry/develop/open-pokered');r=root/'.task-tmp/fidelity-39-plus';w=root/'.task-tmp/fidelity-91-plus-checkout';base=root/'.task-tmp/fidelity-93-master-before';out=w/'docs/screenshots/fidelity-field-typing-160';out.mkdir(parents=True,exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
# Identical capture code, pristine base production prefix, all actual tests >0.
helper=(r/'typing-160-capture-helper.rs').read_bytes()
for tree,revision in [(base,'31b1eda3112514d6bc803af559ec7f7c9e20374f'),(w,'dacc5cc7ecf383950fcba14ef08eaad651fc62f9')]:
 original=subprocess.check_output(['git','show',revision+':crates/pokered-app/src/game.rs'],cwd=tree)
 actual=(tree/'crates/pokered-app/src/game.rs').read_bytes()
 if tree==base:
  # All existing baseline additions are test modules after production ends.
  boundary=original.index(b"#[cfg(test)]\nmod session_guard_tests")
  assert actual[:boundary]==original[:boundary]
 else:assert actual.startswith(original)
 assert actual.endswith(helper)
assert subprocess.check_output(['git','diff','--name-only'],cwd=base).decode().strip()=='crates/pokered-app/src/game.rs'
counts=[]
for side in ['master','after']:
 for b in ['a','b']:
  for trial in [1,2]:
   directory=r/f'audit-160-{side}-fixed-{b}-{trial}'
   assert '1 passed' in (r/f'audit-160-{side}-fixed-{b}-{trial}.log').read_text()
   if trial==2:
    first=r/f'audit-160-{side}-fixed-{b}-1'
    assert all(f.read_bytes()==(first/f.name).read_bytes() for f in directory.iterdir())
for b in ['a','b']:
 before=load(r/f'audit-160-master-fixed-{b}-1/frames.json');after=load(r/f'audit-160-after-fixed-{b}-1/frames.json')
 assert [x['input_bits'] for x in before]==[x['input_bits'] for x in after]
 assert before[15]['letters']==30 and after[15]['letters']==6
 for pulse in [0,1]:
  original=load(r/f'audit-160-original-typing-{b}-{pulse}-1/frames.json');native=load(r/f'audit-160-after-final-typing-{b}-{pulse}-1/frames.json')
  rf=next(x['first_letter'] for x in original if x['first_letter'] is not None);nf=next(x['first_letter'] for x in native if x['first_letter'] is not None)
  get=lambda rows,f:[x['letters'] for x in rows if 0<=x['t']-f<=18]
  assert get(original,rf)==get(native,nf)
  counts.append(dict(button=b,pulse=pulse,original_first=rf,native_first=nf,relative_0_18=get(native,nf)))
  for kind in ['original-typing','after-final-typing']:
   x=r/f'audit-160-{kind}-{b}-{pulse}-1';y=r/f'audit-160-{kind}-{b}-{pulse}-2'
   assert all(f.read_bytes()==(y/f.name).read_bytes() for f in x.iterdir())
for name,src in [('before.png','audit-160-master-fixed-a-1/frame-0015.png'),('after.png','audit-160-after-fixed-a-1/frame-0015.png'),('original-reference.png','audit-160-original-typing-a-1-1/frame-0036.png')]:shutil.copy2(r/src,out/name)
assert '2737 passed; 0 failed' in (r/'audit-160-core-tests.log').read_text()
assert '208 passed; 0 failed' in (r/'audit-160-app-tests-final.log').read_text()
assert len([x for x in (r/'audit-160-gba-compare.log').read_text().splitlines() if ' -> ' in x])==31
assert 'GBA performance is within the configured regression budget.' in (r/'audit-160-gba-compare.log').read_text()
provenance=load(r/'audit-160-gba-provenance.json')
for name,sha in provenance['sources'].items():assert h(w/name)==sha
assert not provenance['baseline_changed']
for name in ['audit-160-gba-provenance.json','audit-160-gba-result.json','audit-160-gba-compare.log']:shutil.copy2(r/name,out/name.removeprefix('audit-160-'))
entries={}
# Capture raw frames, state, input, original executable hooks and all rejections.
for pattern in ['audit-160-original-typing-*','audit-160-master-fixed-*','audit-160-after-fixed-*','audit-160-after-final-typing-*','audit-160-*.log','audit-160-*-graph.txt','audit-159-text-entry.log','audit-159-choice-entry.log','typing-160-capture-helper.rs']:
 for p in r.glob(pattern):
  if p.is_dir():
   for f in p.rglob('*'):
    if f.is_file():entries[str(f.relative_to(r))]=f
  elif p.is_file():entries[str(p.relative_to(r))]=p
for name in ['probe_typing_pulse_original_159.py','probe_typing_tail_160.py','package_typing_input_160.py']:
 p=r/'stats-59-tools'/name;entries['tools/'+name]=p
for name in ['crates/pokered-core/src/overworld/screen.rs','crates/pokered-core/src/overworld/update.rs','crates/pokered-app/src/game.rs','scripts/playthrough_late.py']:entries['source/'+name]=w/name
entries['baseline-source/game.rs']=base/'crates/pokered-app/src/game.rs'
entries['mainline155-historical/playthrough_late.py']=r/'audit-155-playthrough-immutable/scripts/playthrough_late.py'
entries['mainline155-historical/log.txt']=r/'audit-155-playthrough.log'
for p in (r/'audit-155-playthrough').glob('m*.json'):entries['mainline155-historical/'+p.name]=p
manifest={name:h(p) for name,p in entries.items()}
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip') as z:
 for name,sha in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
v=dict(base='31b1eda3112514d6bc803af559ec7f7c9e20374f',parent='dacc5cc7ecf383950fcba14ef08eaad651fc62f9',reference='fbcf7d0e19a3a2db505440d3ccd3d40ca996c15c',helper_sha256=h(r/'typing-160-capture-helper.rs'),base_binary_sha256=h(r/'audit-160-master-final-immutable/pokered_app'),final_binary_sha256=h(r/'audit-160-after-final-immutable/pokered_app'),ROM_sha256=h(r/'safari-147-source-setup/reference.gbc'),SRAM_sha256=h(r/'safari-147-source-setup/safari-one-step.sav'),paired_frame=15,identical_inputs=True,repeat_byte_exact=True,relative_letter_counts=counts,tests='core2737;debug app208;27 ignored capture helpers;GBA31 unchanged baseline',archive_files=len(manifest)+1,archive_sha256=h(out/'evidence.zip'),images={p.name:h(p) for p in out.glob('*.png')},limits=['Controlled SRAM Continue then valid counter warp; not paid Safari entry or mainline proof.','Original firstglyph24 vs native3: relative logical counts only, no claim of absolute text startup or LCD parity.','Original finalglyph111->YES/NO114; native still requires fresh advance. Finalletter wait and DisplayTextID/nested command/session ownership remain pending.','Historical main155 passed m01-m28 then failed obsolete m29 endpoint assertion; driver expectation fixed4,3; no final-head m49/independentContinue proof.'])
(out/'verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(json.dumps(v,ensure_ascii=False))
