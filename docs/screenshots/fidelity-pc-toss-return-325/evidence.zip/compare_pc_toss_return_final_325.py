from pathlib import Path
import json
r=Path('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus');results=[];names={20:'Potion',11:'Antidote',4:'PokeBall',53:'Revive',29:'EscapeRope'}
def stock(raw):
 out=[]
 for i in range(0,len(raw),2):
  if raw[i]==255:break
  out.append([names[raw[i]],raw[i+1]])
 return out
for case in ['full_second','partial_second','full_scrolled','partial_scrolled','full_first','cancel_second_b','cancel_scrolled_b','cancel_second_no','cancel_scrolled_no']:
 d=r/f'audit-311-original-toss-list-select-{case}-three-items-a1-1';f=json.loads((d/'frames.json').read_text());anchor=f[-1]['cues']['PlayerPCMenu']+118;source={x['t']-anchor:x for x in f if x['t']>=anchor};assert (d/'frames.json').read_bytes()==(r/f'audit-311-original-toss-list-select-{case}-three-items-a1-2/frames.json').read_bytes();a=r/f'audit-325-toss-return-after-a5/toss-{case}/frames.json';assert a.read_bytes()==(r/f'audit-325-toss-return-after-a6/toss-{case}/frames.json').read_bytes();native=json.loads(a.read_text());before=json.loads((r/f'audit-325-toss-return-before-a5/toss-{case}/frames.json').read_text());assert(r/f'audit-325-toss-return-before-a5/toss-{case}/frames.json').read_bytes()==(r/f'audit-325-toss-return-before-a6/toss-{case}/frames.json').read_bytes()
 bad=[n['t'] for n in native if n['pc']!=stock(source[n['t']]['pc_items']) or n['bag']!=stock(source[n['t']]['bag_items'])];window=[n['t'] for n in native if n['t']>=715 and (n['cursor'],n['scroll'])!=(source[n['t']]['cursor']+source[n['t']]['list_scroll'],source[n['t']]['list_scroll'])];assert not bad and not window,(case,bad[:5],window[:5]);assert all(n['cached_equals_full'] and not n['ordinary_save_exists'] for n in native)
 assert native[-1]['phase']=='ItemList';
 if case.startswith('cancel'):assert native[-1]['phase']=='ItemList' and native[-1]['pc']==native[0]['pc']
 results.append({'case':case,'frames':1101,'stock_source_equal_every_frame':True,'cursor_scroll_source_equal_from_confirmation_resolution715':True,'final_cursor':native[-1]['cursor'],'final_scroll':native[-1]['scroll'],'canceled_without_consumption':case.startswith('cancel'),'repeats_equal':True,'cached_full_equal':True,'before_stock_mismatches':sum(n['pc']!=stock(source[n['t']]['pc_items']) for n in before),'generic_feedback_typing_and_arrow_blink_NOT_proved':True,'native_omits_original_prompt_ACK500':True,'scope':'inventory and post-resolution return window; question/confirmation entry timings unchanged from actual master' })
(r/'audit-325-source-native-toss-return-with-ack-summary.json').write_text(json.dumps(results,indent=2)+'\n');print('PASS9 source/native repeated Toss outcomes: partial/full and B/NO cancel; stock every frame, cursor/scroll from resolution715')
