import os,subprocess,json
from pathlib import Path
r=Path('/home/jerry/develop/open-pokered');b=r/'.task-tmp/fidelity-39-plus';wt=r/'.task-tmp/fidelity-91-plus-checkout';exe=r/'.task-tmp/fidelity-18-27/target/debug/deps/pokered_app-823b1783d030defc'
for build in ['after']:
 for moving in [False,True]:
  for trial in [1,2]:
   out=b/f'npc-134-walk-{moving}-{build}-{trial}'
   exe=r/('.task-tmp/fidelity-39-plus/unoptimized-target/debug/deps/pokered_app-ff0279f3644dd22e' if build=='master' else '.task-tmp/fidelity-18-27/target/debug/deps/pokered_app-823b1783d030defc')
   wt=r/('.task-tmp/fidelity-93-master-before' if build=='master' else '.task-tmp/fidelity-91-plus-checkout')
   env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',TMPDIR=str(r/'.task-tmp/fidelity-18-27'),FIDELITY_NPC_READY_WALK='1',FIDELITY_RETAINED_CAPTURE='1',FIDELITY_MOVEMENT_CAPTURE=str(out),FIDELITY_MOVEMENT_SRAM=str(b/'movement-91-road-setup/road.sav'),FIDELITY_MOVEMENT_X='20',FIDELITY_MOVEMENT_Y='30',FIDELITY_MOVEMENT_DIRECTION='down',FIDELITY_MOVEMENT_HOLD='16')
   if moving:env['FIDELITY_NPC_ALREADY_MOVING']='1'
   with (b/f'npc-134-walk-{moving}-{build}-{trial}.log').open('w') as f:result=subprocess.run([str(exe),'game::link_stats_cry_fidelity_tests::capture_actual_walk_bike_raw_91','--exact','--ignored','--nocapture','--test-threads=1'],cwd=wt,env=env,stdout=f,stderr=subprocess.STDOUT)
   assert result.returncode==0,result.returncode
   rows=json.loads((out/'frames.json').read_text());assert len(rows)==101;print(build,moving,trial,flush=True)
