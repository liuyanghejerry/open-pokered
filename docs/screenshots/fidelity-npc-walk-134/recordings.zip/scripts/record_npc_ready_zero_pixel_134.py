exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
base=root/'.task-tmp/fidelity-39-plus'
for trial in [1,2]:
 out=base/f'npc-134-ready-zero-source-valid-{trial}';out.mkdir(exist_ok=True)
 p=PyBoy(str(base/'movement-91-road-setup/road.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0)
 p.load_state(io.BytesIO((base/'movement-91-road-reference-False-1/pretrigger.state').read_bytes()))
 get=lambda n:int(p.memory[symbols[n][1]])
 def put(n,v):p.memory[symbols[n][1]]=v
 original={n:get(n) for n in ['wCurMap','wXCoord','wYCoord','wSprite01StateData1PictureID','wSprite01StateData2PictureID','wSprite01StateData2MovementByte1']}
 values={'wSprite01StateData1MovementStatus':2,'wSprite01StateData1ImageIndex':0,'wSprite01StateData1YStepVector':1,'wSprite01StateData1YPixels':44,'wSprite01StateData1XStepVector':0,'wSprite01StateData1XPixels':48,'wSprite01StateData1IntraAnimFrameCounter':0,'wSprite01StateData1AnimFrameCounter':0,'wSprite01StateData1FacingDirection':0,'wSprite01StateData2WalkAnimationCounter':0,'wSprite01StateData2MovementDelay':2,'wSprite01StateData2MapY':get('wYCoord')+3,'wSprite01StateData2MapX':get('wXCoord')+3,'wSprite01StateData2GrassPriority':0}
 for n,v in values.items():put(n,v)
 # Prime the actual OAM/LCD with the controlled walking NPC; preserve
 # all subsequent updates, including walking progress, as ordinary input.
 p.tick(4);p.screen.image.save(out/'pretrigger.png')
 with (out/'pretrigger.state').open('wb') as f:p.save_state(f)
 fields=['wPlayerLastStopDirection','wPlayerMovingDirection','wCheckFor180DegreeTurn','wSprite01StateData2MovementDelay','wSprite01StateData1IntraAnimFrameCounter','hVBlankCopySize','hAutoBGTransferEnabled','wFontLoaded','wWalkCounter','wSprite01StateData1MovementStatus','wSprite01StateData1ImageIndex','wSprite01StateData1YPixels','wSprite01StateData1XPixels','wSprite01StateData1AnimFrameCounter','wSprite01StateData2WalkAnimationCounter','wSprite01StateData2MapY','wSprite01StateData2MapX']
 events=[];index=[-1]
 def hook(name):events.append({'t':index[0],'routine':name,'LY':int(p.memory[0xff44]),'current_sprite_offset':get('hCurrentSpriteOffset'),**{n:get(n) for n in fields}})
 for n in ['DisplayTextIDInit','UpdateSprites','CopyScreenTileBufferToVRAM','DrawStartMenu','CloseStartMenu','CloseTextDisplay','InitMapSprites','LoadPlayerSpriteGraphics','LoadCurrentMapView','LoadTextBoxTilePatterns','ReloadMapSpriteTilePatterns','CopyVideoData','DelayFrame']:p.hook_register(*symbols[n],hook,n)
 rows=[]
 for t in range(-1,160):
  index[0]=t
  if t==0:p.button_press('down')
  if t==16:p.button_release('down')
  if t>=0:p.tick(1)
  p.screen.image.save(out/f'frame-{t+1:04}.png');rows.append({'t':t,**{n:get(n) for n in fields}})
 (out/'frames.json').write_text(json.dumps(rows,indent=2));(out/'events.json').write_text(json.dumps(events,indent=2));(out/'provenance.json').write_text(json.dumps({'original':original,'controlled_writes':values,'prime_frames':4,'input':'Down0..15 only','scope':'controlled NPC idle delay3, four real idle priming HW frames; actual player Down movement; no claimed natural random NPC placement'},indent=2));p.stop(save=False)
 print(trial,original,rows[0],flush=True);print([e for e in events if e['routine']!='UpdateSprites'],flush=True)
