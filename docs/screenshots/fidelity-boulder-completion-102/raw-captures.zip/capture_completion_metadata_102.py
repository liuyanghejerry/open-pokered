import os,subprocess,json
from pathlib import Path
from PIL import Image
r=Path('/home/jerry/develop/open-pokered');a=r/'.task-tmp/fidelity-39-plus';results=[]
for case in ['victory-hole']:
 for trial in [1,2]:
  out=a/f'boulder-102-metadata-{case}-{trial}'
  env=dict(os.environ,LD_LIBRARY_PATH='/tmp/pokered-build-lib',FIDELITY_DUST_SRAM=str(a/'dust-93-warp-setup/seafoam-valid.sav'),FIDELITY_DUST_CAPTURE=str(out))
  env['FIDELITY_DUST_SCENARIO' if case=='victory-hole' else 'FIDELITY_DUST_DIRECTION']=case
  q=subprocess.run([str(a/'boulder-102-hole-driver'),'capture_actual_boulder_dust_raw_93','--ignored','--nocapture','--test-threads=1'],cwd=r/'.task-tmp/fidelity-91-plus-checkout',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (a/f'{out.name}.log').write_text(q.stdout);assert q.returncode==0 and '1 passed' in q.stdout,q.stdout[-2000:]
  source=a/(f'victory-100-source-3f-hole-{trial}' if case=='victory-hole' else f'dust-99-startup-reference-{trial}' if case=='down' else f'dust-99-source-{case}-{trial}')
  files=sorted(out.glob('frame-*.png'));bad=[]
  for file in files:
   if Image.open(file).convert('RGB').tobytes()!=Image.open(source/file.name).convert('RGB').tobytes():bad.append(file.name)
  rows=json.loads((out/'frames.json').read_text())
  result={'case':case,'trial':trial,'frames':len(files),'RGB_bad':bad,'first_hole_event':next((x for x in rows if x.get('boulder_visible') is False),None)}
  if trial==2:
   prior=a/f'boulder-102-metadata-{case}-1'
   result['repeat_png_exact']=all((prior/f.name).read_bytes()==f.read_bytes() for f in files)
   result['repeat_json_exact']=(prior/'frames.json').read_bytes()==(out/'frames.json').read_bytes()
  results.append(result);print(case,trial,len(files),'RGB_bad',len(bad),'repeat',result.get('repeat_png_exact'),flush=True)
(a/'boulder-102-metadata-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
