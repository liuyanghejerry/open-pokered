from collections import deque
import shutil
exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
case='3f-hole';mapid,px,py,npc,event,script=(198,21,15,10,0x666,'VictoryRoad3F');stride=21
out=root/f'.task-tmp/fidelity-39-plus/victory-100-source-setup-{case}';out.mkdir(exist_ok=True);shutil.copyfile(run/'retail-save.gbc',out/'reference.gbc')
p=PyBoy(str(out/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((run/'retail-field.state').read_bytes()))
get=lambda n:int(p.memory[symbols[n.replace('Sprite05',f'Sprite{npc:02}')][1]])
def put(n,v):p.memory[symbols[n.replace('Sprite05',f'Sprite{npc:02}')][1]]=v
def tap(key,wait=100):p.button_press(key);p.tick(2);p.button_release(key);p.tick(wait-2)
def snap(name):
 d={n:get(n) for n in ['wCurMap','wXCoord','wYCoord','wCurrentMenuItem','wStatusFlags1','wWalkCounter']};print(name,d,flush=True);p.screen.image.save(out/(name+'.png'))
# Controlled destination entry is changed in WRAM immediately before the
# original warp loader reads it. Player/view still use its normal load pipeline.
def destination(ctx):
 if get('wCurMap')==mapid:
  base=symbols['wCurrentTileBlockMapViewPointer'][1];ptr=p.memory[base]+p.memory[base+1]*256;print('loaded-view',hex(ptr),get('wXCoord'),get('wYCoord'),flush=True);oldx,oldy=get('wXCoord'),get('wYCoord');ptr=ptr+((py-4)//2-(oldy-4)//2)*stride+(px-4)//2-(oldx-4)//2;p.memory[base]=ptr&255;p.memory[base+1]=ptr>>8
  put('wXCoord',px);put('wYCoord',py);put('wXBlockCoord',px%2);put('wYBlockCoord',py%2)
p.hook_register(*symbols['LoadTilesetHeader.done'],destination,None)
put('hWarpDestinationMap',mapid);put('wDestinationWarpID',0);put('wStatusFlags3',get('wStatusFlags3')|8);p.tick(240);snap('warp');assert (get('wCurMap'),get('wXCoord'),get('wYCoord'))==(mapid,px,py)
p.hook_deregister(*symbols['LoadTilesetHeader.done'])
put('wStatusFlags4',get('wStatusFlags4')|16)
# Keep the original boulder10 at (22,15); no controlled NPC placement.
p.tick(120);snap('placed')
tap('start')
for _ in range(7):
 if get('wCurrentMenuItem')==1:break
 tap('up',30)
assert get('wCurrentMenuItem')==1;tap('a')
for _ in range(6):
 if get('wCurrentMenuItem')==0:break
 tap('up',30)
assert get('wCurrentMenuItem')==0;tap('a')
for _ in range(3):tap('down',30)
tap('a',180)
for _ in range(5):tap('a')
tap('b');tap('b');assert get('wStatusFlags1')&1
p.button_press('right');p.tick(2);p.button_release('right');p.tick(120);snap('ready');assert (get('wXCoord'),get('wYCoord'))==(px,py);assert (get('wSprite05StateData2MapX'),get('wSprite05StateData2MapY'))==(26,19)
st=io.BytesIO();p.save_state(st);(out/'pretrigger.state').write_bytes(st.getvalue());p.stop(save=False)
for trial in [1,2]:
 dest=root/f'.task-tmp/fidelity-39-plus/victory-100-source-{case}-{trial}';dest.mkdir(exist_ok=True)
 p=PyBoy(str(out/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO(st.getvalue()));events=[];now=[-1]
 for n in ['MoveSprite','TryWalking',script+'DefaultScript','ReplaceTileBlock','AnimateBoulderDust',script+'_Script','HideObject','ShowObject']:
  p.hook_register(*symbols[n],lambda ctx:events.append({'t':now[0],'routine':ctx}),n)
 rows=[]
 for t in range(-1,200):
  now[0]=t
  if t==0:p.button_press('right')
  if t==16:p.button_release('right')
  if t>=0:p.tick(1)
  p.screen.image.save(dest/f'frame-{t+1:04}.png')
  rows.append({'t':t,'state':{n:get(n) for n in ['wCurMap','wXCoord','wYCoord','wWalkCounter','wMiscFlags','wCurrentMapScriptFlags','wSprite05StateData2MapX','wSprite05StateData2MapY','wSprite05StateData2WalkAnimationCounter','wSprite05StateData1YPixels']},'switch':bool(p.memory[symbols['wEventFlags'][1]+event//8]&(1<<(event%8))),'map_blocks':list(p.memory[0xc6e8:0xcbfc]),'oam':list(p.memory[0xfe00:0xfea0])})
 (dest/'frames.json').write_text(json.dumps(rows,indent=2));(dest/'events.json').write_text(json.dumps(events,indent=2));p.stop(save=False);print(trial,events[:30],flush=True)
