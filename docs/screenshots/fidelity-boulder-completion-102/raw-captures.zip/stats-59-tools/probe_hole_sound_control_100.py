exec(open('/home/jerry/develop/open-pokered/.task-tmp/fidelity-39-plus/stats-59-tools/record_retail_stats.py').read().split('for trial in [1,2]:')[0])
setup=root/'.task-tmp/fidelity-39-plus/victory-100-source-setup-3f-hole';summary=[]
for trial in [1,2]:
 p=PyBoy(str(setup/'reference.gbc'),window='null',sound_emulated=True,color_palette=[0xffffff,0xaaaaaa,0x555555,0]);p.set_emulation_speed(0);p.load_state(io.BytesIO((setup/'pretrigger.state').read_bytes()));events=[];now=[-1]
 for name in ['PlaySound','LoadPlayerSpriteGraphics','Joypad','MoveSprite','HideObject','ShowObject','DisplayTextID']:
  p.hook_register(*symbols[name],lambda name:events.append({'t':now[0],'routine':name,'a':p.register_file.A,'held':int(p.memory[symbols['hJoyHeld'][1]])}),name)
 for t in range(120):
  now[0]=t
  if t==0:p.button_press('right')
  if t==16:p.button_release('right')
  if t==71:p.button_press('start')
  if t==111:p.button_release('start')
  p.tick(1)
 p.stop(save=False);summary.append({'trial':trial,'events':events});print(trial,[e for e in events if e['routine']!='Joypad' or 65<=e['t']<=80],flush=True)
(root/'.task-tmp/fidelity-39-plus/victory-100-hole-sound-control.json').write_text(json.dumps(summary,indent=2))
